EX-99.1 2 q120lillysalesandearningsp.htm EXHIBIT 99.1 html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd" Document created using Wdesk 1  Copyright 2020 Workiva Exhibit

|April 23, 2020 | |Eli Lilly and Company |
| | |Lilly Corporate Center |
| | |Indianapolis, Indiana 46285 |
| | |U.S.A. |
| | |+1.317.276.2000 |
| | |www.lilly.com |

For Release:Immediately

Refer to: Mark Taylor; mark.taylor@lilly.com; (317) 276-5795 (Media)

Kevin Hern; hern_kevin_r@lilly.com; (317) 277-1838 (Investors)

Lilly Reports Strong First-Quarter Financial Results, Adjusts EPS Guidance

|• |Revenue in the first quarter of 2020 increased 15 percent , driven by 22 percent volume growth. Strong underlying demand for key growth products was augmented by approximately $250 million of additional revenue due to increased customer buying patterns and patient prescription trends due to the COVID-19 pandemic. |

|• |Key growth products launched since 2014, consisting of Trulicity, Taltz, Verzenio, Jardiance, Emgality, Olumiant, Basaglar, Tyvyt, Cyramza, and Baqsimi, contributed 19 percentage points of revenue growth and represented approximately 51 percent of total revenue. |

|• |First-quarter 2020 operating expenses grew 7 percent , driven by increased investments in R&D. |

|• |First-quarter 2020 earnings per share (EPS) decreased to $1.60 on a reported basis, reflecting the gain recognized on the disposition of Elanco Animal Health in Q1 2019, and increased to $1.75 on a non-GAAP basis. |

|• |In response to the COVID-19 pandemic, Lilly has focused on reliably supplying medicines and has redirected scientific efforts to help solve critical issues, including researching potential therapeutics, and providing diagnostic and testing services. |

|• |Other notable recent events include new approved indications for Trulicity and Taltz, and the completion of the Dermira acquisition. |

|• |2020 EPS guidance adjusted to be in the range of $6.20 to $6.40 on a reported basis and $6.70 to $6.90 on a non-GAAP basis. |

Eli Lilly and Company (NYSE: LLY) today announced financial results for the first quarter of 2020.

|$ in millions, except per share data |First Quarter |% |
| |2020 | |2019 |Change |
|Revenue |$ |5,859.8 | | |$ |5,092.2 | |15% |
|Net Income – Reported |1,456.5 | | |4,241.6 | |(66)% |
|EPS – Reported |1.60 | | |4.31 | |(63)% |
|Net Income – Non-GAAP |1,598.8 | | |1,236.7 | |29% |
|EPS – Non-GAAP |1.75 | | |1.33 | |32% |

Certain financial information for 2020 and 2019 is presented on both a reported and a non-GAAP basis. Some numbers in this press release may not add due to rounding. Reported results were prepared in accordance with U.S. generally accepted accounting principles (GAAP), include all revenue and expenses recognized during the periods, and reflect Elanco Animal Health (Elanco) as discontinued operations during 2019. Non-GAAP measures reflect adjustments for the items described in the reconciliation tables later in the release, and assume that the disposition of Elanco occurred at the beginning of 2019 (including the benefit from the reduction in shares of common stock outstanding). The company’s 2020 financial guidance is being provided on both a reported and a non-GAAP basis. The non-GAAP measures are presented to provide additional insights into the underlying trends in the company’s business.

“Lilly is rising to meet the challenges of the COVID-19 pandemic, whether it be by supporting our employees, our communities, patients with chronic diseases who are the most vulnerable to the virus, or directly attacking the disease with new and existing therapies,” said David A. Ricks, Lilly’s chairman and CEO. “Lilly’s purpose - to make life better - has never been more important. We're focused on reliably supplying medicines, keeping our employees safe and pushing scientific efforts at top speed to defeat COVID-19. We're also committed to improving the affordability of and access to o

|2 |

ur medicines, particularly insulin, during these challenging times."

“Lilly exited 2019 with strong revenue growth and margin expansion, driven by the uptake of our newer medicines. That momentum continued in Q1 2020 and was augmented by higher patient and supply chain purchasing due to the COVID-19 pandemic," commented Josh Smiley, Lilly's CFO. "Our revenue and operating margin outlook for 2020 is unchanged, but the economic and healthcare consequences of this pandemic are uncertain and could negatively affect our financial results later in 2020 and beyond, due to reduced non-COVID healthcare activities and global economic challenges. We are therefore widening the range of our 2020 EPS guidance to reflect both our underlying strong performance as well as future uncertainty; however, the long-term fundamentals of our business remain strong, as does our financial outlook for the mid-2020s and beyond.”

|3 |

Key Events Over the Last Three Months

COVID-19

|• |The company entered into an agreement with the National Institute of Allergy and Infectious Diseases (NIAID), part of the National Institutes of Health, to study baricitinib as an arm in NIAID's Adaptive COVID-19 Treatment Trial. The Phase 3 study will investigate the efficacy and safety of baricitinib as a potential treatment for hospitalized patients diagnosed with COVID-19. |

|• |The company announced that it will advance LY3127804, an investigational selective monoclonal antibody against Angiopoietin 2 (Ang2), to Phase 2 testing in pneumonia patients hospitalized with COVID-19 who are at a higher risk of progressing to acute respiratory distress syndrome (ARDS). |

|• |The company entered into an agreement with AbCellera to co-develop antibody products for the potential treatment and prevention of COVID-19. The collaboration will leverage AbCellera's rapid pandemic response platform, developed under the DARPA Pandemic Prevention Platform (P3) Program, and Lilly's global capabilities for rapid development, manufacturing and distribution of therapeutic antibodies. |

|• |The company announced an update on its clinical trial activities in light of the COVID-19 pandemic. The company has delayed most new study starts and has paused enrollment in most ongoing studies, but will continue ongoing clinical trials for patients who are already enrolled. |

Regulatory

|• |The U.S. Food and Drug Administration (FDA) approved Trulicity ® for the reduction of major adverse cardiovascular events in adults with type 2 diabetes who have established cardiovascular disease or multiple cardiovascular risk factors. |

|• |The FDA approved a supplemental Biologics License Application (sBLA) for Taltz ® for the treatment of pediatric patients (ages 6 to under 18) with moderate to severe plaque psoriasis who are candidates for systemic therapy or phototherapy. |

|• |The company's newest mealtime insulin received approval in both the European Union and |

|4 |

Japan for the treatment of adults with diabetes as part of a multiple daily injection regimen or delivered by an insulin pump. This novel, fast-acting formulation of insulin lispro is for use by adults with type 1 and type 2 diabetes to reduce blood glucose.

|• |The FDA issued a complete response letter for the supplemental New Drug Application (sNDA) of the investigational medicine empagliflozin 2.5 mg as an adjunct to insulin for adults with type 1 diabetes. The letter indicates that the FDA is unable to approve the application in its current form. |

Clinical

|• |An analysis performed by Washington University School of Medicine in the Dominantly Inherited Alzheimer Network Trials Unit (DIAN-TU) Study showed that solanezumab did not meet the primary endpoint of the study. At this time, Lilly does not plan to pursue a submission for solanezumab in people with dominantly inherited Alzheimer's disease (DIAD), also known as autosomal dominant Alzheimer's disease. |

|• |The company completed a Phase 4 study of Taltz in patients with moderate to severe psoriasis. Taltz demonstrated non-inferiority to guselkumab on the final secondary endpoint at week 24. As previously disclosed, Taltz achieved superiority compared to guselkumab on all primary and key secondary endpoints at week 12. |

|• |Mirikizumab met the co-primary and key secondary endpoints in a Phase 3, placebo-controlled study, which evaluated the safety and efficacy of mirikizumab for the treatment of moderate to severe plaque psoriasis over 52 weeks. A second Phase 3, placebo- and active- controlled 52-week study is expected to be completed later in 2020. |

Business Development/Other Developments

|• |The company entered into an exclusive global licensing and research collaboration with Sitryx, a biopharmaceutical company focused on regulating cell metabolism to develop disease-modifying therapeutics in immuno-oncology and immuno-inflammation. The collaboration will study up to four novel preclinical targets identified by Sitryx that could lead to potential |

|5 |

new medicines for autoimmune diseases.

|• |The company completed the acquisition of Dermira, Inc. The acquisition expands Lilly's immunology pipeline with the addition of lebrikizumab, which is being evaluated in a Phase 3 clinical development program for the treatment of moderate to severe atopic dermatitis in adolescent and adult patients, ages 12 years and older. The acquisition also expands Lilly's portfolio of marketed dermatology medicines with the addition of QBREXZA ® , a medicated cloth approved by the FDA for the topical treatment of primary axillary hyperhidrosis. |

First-Quarter Reported Results

In the first quarter of 2020, worldwide revenue was $5.860 billion, an increase of 15 percent compared with the first quarter of 2019. The increase in revenue was driven by a 22 percent increase due to volume, partially offset by a 6 percent decrease due to lower realized prices. The company estimates worldwide volume growth in the first quarter of 2020 was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic that increased worldwide revenue by approximately $250 million.

Revenue in the U.S. increased15 percent, to $3.329 billion, as increased volume of 19 percent was partially offset by lower realized prices. Increased U.S. volume for key growth products, including Trulicity, Taltz, Verzenio®, Emgality, Basaglar®, Jardiance®, and BaqsimiTM, as well as for Humalog®, was partially offset by decreased volume for Cialis® due to loss of patent exclusivity. The company estimates that U.S. volume growth in the first quarter of 2020 was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic that increased U.S. revenue by approximately $200 million.

Revenue outside the U.S. increased15 percent, to $2.531 billion, driven by increased volume of 25 percent, which was primarily from key growth products, including Tyvyt®, Trulicity, Olumiant®, Taltz, Jardiance, Verzenio, Cyramza® and Basaglar, as well as for Alimta®, partially offset by decreased volume for Strattera® due to loss of patent exclusivity. The increase in revenue due to volume was

|6 |

partially offset by lower realized prices and the unfavorable impact of foreign exchange rates. The company estimates that volume growth outside the U.S. in the first quarter of 2020 was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic that increased revenue outside the U.S. by approximately $50 million.

Gross margin increased18 percent, to $4.645 billion, in the first quarter of 2020 compared with the first quarter of 2019 and was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic. Gross margin as a percent of revenue was 79.3 percent, an increase of 1.7 percentage points compared with the first quarter of 2019. The increase in gross margin percent was primarily due to the prior year charges resulting from the withdrawal of Lartruvo®, favorable product mix, and greater manufacturing efficiencies, partially offset by lower realized prices on revenue.

Total operating expenses in the first quarter of 2020, defined as the sum of research and development and marketing, selling, and administrative expenses, increased7 percent to $2.942 billion compared with the first quarter of 2019. Research and development expenses increased13 percent to $1.392 billion, or 23.8 percent of revenue, driven by higher development expenses for late-stage assets. Marketing, selling, and administrative expenses increased2 percent to $1.550 billion.

In the first quarter of 2020, the company recognized acquired in-process research and development charges of $52.3 million related to the business development transaction with Sitryx. Inthefirstquarter of 2019, the company recognized acquired in-process research and development charges of$136.9 millionrelated to business development transactions with AC Immune SA and ImmuNext, Inc.

In the first quarter of 2020, the company recognized asset impairment, restructuring and other special charges of $59.9 million. The charges were primarily related to acquisition and integration costs as part of the closing of the acquisition of Dermira. In the first quarter of 2019, the company recognized asset impairment, restructuring and other special charges of $423.9 million, primarily

|7 |

associated with accelerated vesting of Loxo Oncology employee equity awards as part of the closing of the acquisition of Loxo Oncology.

Operating income in the first quarter of 2020 was $1.591 billion, compared to $645.1 million in the first quarter of 2019. The increase in operating income was primarily driven by higher gross margin and lower asset impairment, restructuring and other special charges and acquired in-process research and development charges, partially offset by higher research and development expenses.

Other income was $89.1 million in the first quarter of 2020, compared with $86.0 million in the first quarter of 2019. The increase in other income was driven primarily by higher net gains on investment securities, partially offset by lower interest income. The higher net gains on investments were due primarily to increased market valuations of two companies in Lilly's investment portfolio that are currently developing potential vaccines against COVID-19.

The effective tax rate was 13.3 percent in the first quarter of 2020, compared with 23.3 percent in the first quarter of 2019. The higher effective tax rate in the first quarter of 2019 was primarily due to the non-deductibility of the accelerated vesting of Loxo Oncology employee equity awards as part of the closing of the acquisition of Loxo Oncology, as well as tax expenses associated with the withdrawal of Lartruvo.

In the first quarter of 2020, net income and earnings per share were $1.457 billion and $1.60, respectively, compared with net income of $4.242 billion and earnings per share of $4.31 in the first quarter of 2019. The decrease in net income and earnings per share in the first quarter of 2020 was primarily driven by the $3.681 billion gain recognized on the disposition of Elanco in the first quarter of 2019, partially offset by higher operating income in 2020. Earnings per share in the first quarter of 2020 benefited from lower weighted-average shares outstanding as a result of the Elanco exchange offer.

|8 |

First-Quarter Non-GAAP Measures

On a non-GAAP basis, first-quarter 2020 gross margin increased15 percent, to $4.703 billion compared with the first quarter of 2019 and was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic. Gross margin as a percent of revenue was 80.3 percent, an increase of 0.1 percentage points. The increase in gross margin percent was primarily due to favorable product mix and manufacturing efficiencies, offset by the impact of lower realized prices on revenue.

Operating income on a non-GAAP basis increased$427.5 million, or 32 percent, to $1.762 billion in the first quarter of 2020 compared with the first quarter of 2019, due to higher gross margin, partially offset by higher research and development expenses.

The effective tax rate on a non-GAAP basis was 13.6 percent in the first quarter of 2020, compared with 12.9 percent in the first quarter of 2019. The higher effective tax rate for the first quarter of 2020 was driven primarily by a mix of earnings in higher tax jurisdictions, partially offset by an increase in net discrete tax benefits.

On a non-GAAP basis, in the first quarter of 2020 net income increased29 percent, to $1.599 billion, while earnings per share increased 32 percent, to $1.75, compared with $1.237 billion and $1.33, respectively, in the first quarter of 2019. The increase in net income and earnings per share was driven primarily by higher operating income, partially offset by higher income taxes.

For further detail of non-GAAP measures, see the reconciliation below as well as the "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information" table later in this press release.

|9 |

| |First Quarter |
| |2020 | |2019 |% Change |
|Earnings per share (reported) |$ |1.60 | | |$ |4.31 | |(63)% |
|Discontinued operations |— | | |(3.74 |) | |
|Earnings per share from continuing operations (reported) |1.60 | | |0.57 | | |
|Asset impairment, restructuring and other special charges |.06 | | |.44 | | |
|Lartruvo charges |— | | |.13 | | |
|Amortization of intangible assets |.05 | | |.04 | | |
|Acquired in-process research and development |.05 | | |.12 | | |
|Impact of reduced shares outstanding for non-GAAP reporting (a) |— | | |.03 | | |
|Earnings per share (non-GAAP) |$ |1.75 | | |$ |1.33 | |32% |
|Numbers may not add due to rounding. (a) Non-GAAP earnings per share assume that the disposition of Elanco occurred at the beginning of 2019 and, therefore, exclude the approximately 65.0 million shares of Lilly common stock retired in the Elanco exchange offer. | | | | |

|10 |

|Selected Revenue Highlights | | | | |
|(Dollars in millions) |First Quarter |
|Selected Products |2020 | |2019 | |% Change |
|Trulicity |$ |1,229.4 | | |$ |879.7 | | |40% |
|Humalog (a) |695.8 | | |730.8 | | |(5)% |
|Alimta |560.1 | | |499.2 | | |12% |
|Taltz |443.5 | | |252.5 | | |76% |
|Humulin ® |315.7 | | |297.7 | | |6% |
|Basaglar |303.7 | | |251.4 | | |21% |
|Forteo ® |272.4 | | |312.9 | | |(13)% |
|Jardiance (b) |267.5 | | |203.6 | | |31% |
|Cyramza |239.0 | | |198.3 | | |21% |
|Cymbalta ® |210.4 | | |164.1 | | |28% |
|Verzenio |188.0 | | |109.4 | | |72% |
|Olumiant |139.7 | | |82.1 | | |70% |
|Emgality |74.0 | | |14.2 | | |NM |
|Tyvyt |57.4 | | |9.9 | | |NM |
|Baqsimi |17.8 | | |— | | |NM |
|Total Revenue |5,859.8 | | |5,092.2 | | |15% |
|(a) Humalog includes Insulin Lispro (b) Jardiance includes Glyxambi ®, Synjardy ® , and Trijardy ® XR NM – not meaningful; Numbers may not add due to rounding |

|11 |

Impact of COVID-19 on First-Quarter 2020 Revenue

The company estimates that revenue in the first quarter of 2020 for many of its products was favorably impacted by increased customer buying patterns and patient prescription trends resulting from the COVID-19 pandemic that increased revenue by approximately $250 million worldwide, including approximately $200 million in the U.S. and approximately $50 million outside the U.S. The company believes that the increase in U.S. revenue from COVID-19 primarily impacted its portfolio of diabetes medicines, with estimated increases of approximately $70 million to $80 million for insulin products and approximately $30 million to $40 million for Trulicity. The company also estimates that U.S. revenue for Taltz was favorably impacted by approximately $20 million to $25 million.

Trulicity

First-quarter 2020 worldwide Trulicity revenue was $1.229 billion, an increase of 40 percent compared with the first quarter of 2019. U.S. revenue increased 40 percent, to $929.5 million, driven by increased volume, partially offset by lower realized prices. Trulicity's lower realized prices in the U.S. were primarily due to higher contracted rebates and changes in segment mix, partially offset by higher list prices. Revenue outside the U.S. was $299.9 million, an increase of 40 percent, driven by increased volume, partially offset by the unfavorable impact of foreign exchange rates and lower realized prices.

Humalog

For the first quarter of 2020, worldwide Humalog revenue decreased5 percent compared with the first quarter of 2019, to $695.8 million. Revenue in the U.S. decreased11 percent, to $398.6 million, driven primarily by lower realized prices due to changes in estimates for rebates and discounts and changes in segment mix, partially offset by increased volume. Revenue outside the U.S. increased5

|12 |

percent, to $297.2 million, primarily driven by increased volume, partially offset by the unfavorable impact of foreign exchange rates.

Alimta

For the first quarter of 2020, worldwide Alimta revenue increased12 percent compared with the first quarter of 2019, to $560.1 million. U.S. revenue increased15 percent, to $324.2 million, primarily driven by increased volume and, to a lesser extent, higher realized prices. Revenue outside the U.S. increased8 percent to $235.8 million, primarily driven by increased volume, partially offset by lower realized prices and, to a lesser extent, the unfavorable impact of foreign exchange rates.

Taltz

For the first quarter of 2020, worldwide Taltz revenue increased76 percent compared with the first quarter of 2019, to $443.5 million. U.S. revenue increased81 percent, to $327.5 million, driven by increased volume and, to a lesser extent, higher realized prices primarily due to changes in estimates for rebates and discounts. Revenue outside the U.S. increased62 percent, to $116.0 million, primarily driven by increased volume, partially offset by lower realized prices and the unfavorable impact of foreign exchange rates.

Humulin

For the first quarter of 2020, worldwide Humulin revenue increased6 percent compared with the first quarter of 2019, to $315.7 million. U.S. revenue increased6 percent, to $214.1 million, driven by increased volume, partially offset by lower realized prices due to changes in segment mix. Revenue outside the U.S. increased5 percent, to $101.5 million, due to increased volume and, to a lesser extent, higher realized prices, partially offset by the unfavorable impact of foreign exchange rates.

Basaglar

For the first quarter of 2020, worldwide Basaglar revenue increased21 percent compared with the first quarter of 2019, to $303.7 million. U.S. revenue increased16 percent, to $230.4 million, primarily

|13 |

driven by increased volume. Revenue outside the U.S. increased38 percent, to $73.3 million, driven by increased volume, partially offset by the unfavorable impact of foreign exchange rates. Basaglar is part of the company’s alliance with Boehringer Ingelheim. Lilly reports as cost of sales payments made to Boehringer Ingelheim for royalties and for its portion of the gross margin in 2020 and 2019, respectively.

Forteo

For the first quarter of 2020, worldwide Forteo revenue decreased13 percent compared with the first quarter of 2019, to $272.4 million. U.S. revenue decreased3 percent, to $122.5 million, driven by lower realized prices primarily due to the unfavorable impact of higher contracted rates. Revenue outside the U.S. decreased20 percent to $149.8 million, primarily driven by decreased volume and, to a lesser extent, lower realized prices.

The company expects further volume declines for Forteo as a result of competitive dynamics in the U.S. and the entry of generic and biosimilar competition following the loss of patent exclusivity in the third quarter of 2019 in the U.S., Japan and major European markets.

Jardiance

The company’s worldwide Jardiance revenue during the first quarter of 2020 was $267.5 million, an increase of 31 percent compared with the first quarter of 2019. U.S. revenue increased 15 percent, to $144.6 million, driven by increased volume. Revenue outside the U.S. was $122.9 million, an increase of 57 percent, driven by increased volume. Jardiance is part of the company’s alliance with Boehringer Ingelheim. Lilly reports as revenue royalties received on net sales of Jardiance and its portion of Jardiance’s gross margin in 2020 and 2019, respectively.

Cyramza

For the first quarter of 2020, worldwide Cyramza revenue was $239.0 million, an increase of 21 percent compared with the first quarter of 2019. U.S. revenue was $89.1 million, an increase of 19

|14 |

percent, primarily driven by increased volume. Revenue outside the U.S. was $149.9 million, an increase of 22 percent, primarily driven by increased volume.

Cymbalta

For the first quarter of 2020, worldwide Cymbalta revenue increased28 percentcompared with the first quarter of 2019, to $210.4 million. U.S. revenue was $11.6 millionin the first quarter. Revenue outside the U.S. increased29 percentto $198.8 million, driven by increased volume, partially offset by lower realized prices. The increase in volume outside the U.S. was primarily driven by the company’s sale of its rights for Xeristar in Spain.

Verzenio

For the first quarter of 2020, worldwide Verzenio revenue increased72 percent compared with the first quarter of 2019, to $188.0 million. U.S. revenue was $129.4 million, an increase of 38 percent, primarily driven by increased volume. Revenue outside the U.S. was $58.6 million, an increase of $42.7 million compared with the first quarter of 2019 driven by increased volume.

Olumiant

For the first quarter of 2020, Olumiant generated worldwide revenue of $139.7 million. U.S. revenue was $11.3 million. Revenue outside the U.S. was $128.4 million, an increase of 70 percent compared with the first quarter of 2019, driven by increased volume.

Emgality

For the first quarter of 2020, Emgality generated worldwide revenue of $74.0 million, an increase of $7.8 million compared with the fourth quarter of 2019. U.S. revenue was $67.3 million, an increase of $4.2 million compared with the fourth quarter of 2019, primarily driven by increased volume, partially offset by lower realized prices due to changes to estimates in rebates and discounts. Revenue outside of the U.S. was $6.7 million in the first quarter of 2020.

|15 |

Tyvyt

The company's Tyvyt revenue during the first quarter of 2020 was $57.4 million, an increase of $20.0 million compared with the fourth quarter of 2019. Tyvyt is part of the company’s alliance with Innovent Biologics, Inc. in China. Lilly reports total sales of Tyvyt made by Lilly as revenue, with payments made to Innovent for its portion of the gross margin reported as cost of sales. Lilly also reports as revenue a portion of the gross margin for Tyvyt sales made by Innovent.

Baqsimi

For the first quarter of 2020, Baqsimi generated worldwide revenue of $17.8 million. U.S revenue was $15.8 million, while revenue outside the U.S. was $2.0 million.

|16 |

2020 Financial Guidance

The company has updated certain elements of its 2020 financial guidance on a reported basis and a non-GAAP basis to reflect both management's expectations for operational performance and the uncertainty surrounding the extent and duration of the impact of the COVID-19 pandemic. Key management assumptions supporting the updated guidance include:

|• |The increased customer buying patterns and patient prescription trends associated with COVID-19 that were experienced in the first quarter of 2020 will largely be reversed over the course of 2020; |

|• |The reduction in new-to-brand prescription trends will peak in the second quarter of 2020 in the U.S. and much of Europe; |

|• |Healthcare activity, including non-COVID-19 related patient visits with their physicians, will align more closely with historical levels in the second half of 2020; |

|• |Increased utilization of patient affordability programs and changes in segment mix due to increased U.S. unemployment will negatively impact U.S. pricing; |

|• |Clinical trial enrollment in existing studies, as well as initiation of new clinical trials, will resume in the second half of 2020; and |

|• |Investment in COVID-19 related research, testing and support will continue throughout 2020. |

Based on the key assumptions outlined above, the company has adjusted earnings per share for 2020 to now be in the range of $6.20 to $6.40 on a reported basis and $6.70 to $6.90 on a non-GAAP basis.

|17 |

| |2020 Expectations |% Change from 2019 |
|Earnings per share (reported) (a) |$6.20 to $6.40 |25% to 29% |
|Amortization of intangible assets |.37 | |
|Acquired IPR&D (b) |.07 | |
|Asset impairment, restructuring and other special charges |.06 | |
|Earnings per share (non-GAAP) |$6.70 to $6.90 |11% to 14% |
|Numbers may not add due to rounding (a) Reported earnings per share percent change from 2019 calculated based on change from 2019 earnings per share from continuing operations. (b) Includes upfront payments for acquired in-process research and development transactions with Sitryx and AbCellera . | | |

The company still anticipates 2020 revenue between $23.7 billion and $24.2 billion. Revenue growth is still expected to be driven by volume from key growth products including Trulicity, Taltz, Basaglar, Jardiance, Verzenio, Cyramza, Olumiant, Emgality, Baqsimi and Tyvyt, as well as the addition of QBREXZA revenue and the potential launch of other new medicines. Revenue growth is expected to be partially offset by lower revenue for products that have lost patent exclusivity. Revenue growth is also expected to be partially offset by a low-single digit net price decline in the U.S. driven primarily by rebates and legislated increases to Medicare Part D cost sharing, patient affordability programs, and net price declines in China, Japan and Europe.

Gross margin as a percent of revenue is still expected to be approximately 79.0 percent on a reported basis and approximately 81.0 percent on a non-GAAP basis.

Marketing, selling and administrative expenses are still expected to be in the range of $6.2 billion to $6.4 billion. Research and development expenses are still expected to be in the range of $5.6 billion to $5.9 billion.

Operating margin percentage, defined as operating income as a percent of revenue, is still expected to be approximately 28 percent on a reported basis and 31 percent on a non-GAAP basis.

|18 |

Other income (expense) is now expected to be in the range of $0 to $150 million of expense.

The 2020 effective tax rate is still expected to be approximately 15 percent on both a reported basis and a non-GAAP basis.

The following table summarizes the company’s 2020 financial guidance:

| |2020 Guidance |
| |Prior | |Updated |
|Revenue |$23.7 to $24.2 billion | |Unchanged |
|Gross Margin % of Revenue (reported) |Approx. 79% | |Unchanged |
|Gross Margin % of Revenue (non-GAAP) |Approx. 81% | |Unchanged |
|Marketing, Selling & Administrative |$6.2 to $6.4 billion | |Unchanged |
|Research & Development |$5.6 to $5.9 billion | |Unchanged |
|Other Income/(Expense) |$(250) to $(100) million | |$(150) to $0 million |
|Tax Rate |Approx. 15% | |Unchanged |
|Earnings per share (reported) |$6.18 to $6.28 | |$6.20 to $6.40 |
|Earnings per share (non-GAAP) |$6.70 to $6.80 | |$6.70 to $6.90 |
|Operating Income % of Revenue (reported) |28% | |Unchanged |
|Operating Income % of Revenue (non-GAAP) |31% | |Unchanged |
|Non-GAAP guidance reflects adjustments presented in the earnings per share table above. |

|19 |

Webcast of Conference Call

As previously announced, investors and the general public can access a live webcast of the first-quarter 2020 financial results conference call through a link on Lilly’s website at www.lilly.com. The conference call will begin at 9:00 a.m. Eastern time (ET) today and will be available for replay via the website.

Lilly is a global healthcare leader that unites caring with discovery to create medicines that make life better for people around the world. We were founded more than a century ago by a man committed to creating high-quality medicines that meet real needs, and today we remain true to that mission in all our work. Across the globe, Lilly employees work to discover and bring life-changing medicines to those who need them, improve the understanding and management of disease, and give back to communities through philanthropy and volunteerism. F-LLY

This press release contains management’s current intentions and expectations for the future, all of which are forward- looking statements within the meaning of Section 27A of the Securities Act of 1933 and Section 21E of the Securities Exchange Act of 1934. The words “estimate”, “project”, “intend”, “expect”, “believe”, “target”, “anticipate” and similar expressions are intended to identify forward-looking statements. Actual results may differ materially due to various factors. There are significant risks and uncertainties in pharmaceutical research and development. There can be no guarantees that pipeline products will receive the necessary clinical and manufacturing regulatory approvals or that they will prove to be commercially successful. The company’s results may also be affected by such factors as the timing of anticipated regulatory approvals and launches of new products; market uptake of recently launched products; competitive developments affecting current products and our pipeline; the expiration of intellectual property protection for certain of the company’s products; the company’s ability to protect and enforce patents and other intellectual property; the impact of actions of governmental and private payers affecting the pricing of, reimbursement for, and access to pharmaceuticals; regulatory compliance problems or government investigations; regulatory actions regarding currently marketed products; unexpected safety or efficacy concerns associated with the company’s products; issues with product supply stemming from manufacturing difficulties or disruptions; regulatory changes or other developments; changes in patent law or regulations related to data-package exclusivity; litigation involving past, current or future products; unauthorized disclosure, misappropriation, or compromise of trade secrets or other confidential data stored in the company’s information systems, networks and facilities, or those of third parties with which the company shares its data; changes in tax law and regulations, including the impact of U.S. tax reform legislation enacted in December 2017 and related guidance; changes in inflation, interest rates, and foreign currency exchange rates; asset impairments and restructuring charges; changes in accounting standards promulgated by the Financial Accounting Standards Board and the Securities and Exchange Commission (SEC); acquisitions and business development transactions and related integration costs; information technology system inadequacies or operating failures; the impact of the evolving COVID-19 pandemic, and the global response thereto; reliance on third-party relationships and outsourcing arrangements; and global macroeconomic conditions. For additional information about the factors that could cause actual results to differ materially from forward-looking statements, please see the company’s latest Form 10-K and subsequent Forms 8-K and 10-Q filed with the SEC. You should not place undue reliance on forward-looking statements, which speak only as of the date of this release. Except as is require

|20 |

d by law, the company expressly disclaims any obligation to publicly release any revisions to forward-looking statements to reflect events after the date of this release.

# # #

Alimta® (pemetrexed disodium, Lilly)

Baqsimi™ (glucagon, Lilly)

Basaglar® (insulin glargine injection, Lilly)

Cialis® (tadalafil, Lilly)

Cymbalta® (duloxetine, Lilly)

Cyramza® (ramucirumab, Lilly)

Emgality® (galcanezumab-gnlm, Lilly)

Forteo® (teriparatide of recombinant DNA origin injection, Lilly)

Glyxambi® (empagliflozin/linagliptin, Boehringer Ingelheim)

Humalog® (insulin lispro injection of recombinant DNA origin, Lilly)

Humulin® (human insulin of recombinant DNA origin, Lilly)

Jardiance® (empagliflozin, Boehringer Ingelheim)

Lartruvo® (olaratumab, Lilly)

Olumiant® (baricitinib, Lilly)

QBREXZA® (Glycopyrronium cloth, Dermira)

Strattera® (atomoxetine, Lilly)

Synjardy® (empagliflozin/metformin, Boehringer Ingelheim)

Taltz® (ixekizumab, Lilly)

Trijardy™ XR (empagliflozin/linagliptin/metformin hydrochloride extended release tablets, Boehringer Ingelheim)

Trulicity® (dulaglutide, Lilly)

Tyvyt® (sintilimab injection, Lilly)

Verzenio® (abemaciclib, Lilly)

Third party trademarks used herein are trademarks of their respective owners.

|Eli Lilly and Company Employment Information |

| |March 31, 2020 | |December 31, 2019 | |
|Worldwide Employees |33,815 | |33,755 | |

|21 |

|Eli Lilly and Company |
|Operating Results (Unaudited) – REPORTED |
|(Dollars in millions, except per share data) |

| | |Three Months Ended |
| | |March 31, |
| | |2020 | | | |2019 |% Chg. |
|Revenue |$ |5,859.8 | |$ |5,092.2 | |15% |
|Cost of sales | |1,215.1 | | |1,138.7 | |7% |
|Research and development | |1,392.1 | | |1,230.5 | |13% |
|Marketing, selling and administrative | |1,549.6 | | |1,517.1 | |2% |
|Acquired in-process research and development | |52.3 | | |136.9 | |(62)% |
|Asset impairment, restructuring and other special charges | |59.9 | | |423.9 | |(86)% |
|Operating income | |1,590.8 | | |645.1 | |NM |
|Net interest income (expense) | |(78.2 |) | |(55.9 |) | |
|Net other income (expense) | |167.3 | | |141.9 | | |
|Other income (expense) | |89.1 | | |86.0 | |4% |
|Income before income taxes | |1,679.9 | | |731.1 | |NM |
|Income tax expense | |223.4 | | |170.0 | |31% |
|Net income from continuing operations | |1,456.5 | | |561.1 | |NM |
|Net income from discontinued operations | |— | | |3,680.5 | |NM |
|Net income |$ |1,456.5 | |$ |4,241.6 | |(66)% |
|Earnings from continuing operations - diluted | |1.60 | | |0.57 | |NM |
|Earnings from discontinued operations - diluted | |— | | |3.74 | |NM |
|Earnings per share - diluted |$ |1.60 | |$ |4.31 | |(63)% |
|Dividends paid per share |$ |0.7400 | |$ |0.6450 | |15% |
|Weighted-average shares outstanding (thousands) - diluted | |911,713 | | |984,001 | | |

NM – not meaningful

|22 |

|Eli Lilly and Company | | |
|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) | | |
|(Dollars in millions, except per share data) | | |
| |Three Months Ended March 31, 2020 | |Three Months Ended March 31, 2019 |
| |GAAP Reported |Adjustments (b) |Non-GAAP Adjusted (a) | |GAAP Reported |Adjustments (c) |Non-GAAP Adjusted (a) |
|Cost of sales |$ |1,215.1 | |$ |(58.6 |) |$ |1,156.5 | |$ |1,138.7 | |$ |(128.2 |) |$ |1,010.5 | |
|Acquired in-process research and development | |52.3 | | |(52.3 |) | |— | | |136.9 | | |(136.9 |) | |— | |
|Asset impairment, restructuring and other special charges | |59.9 | | |(59.9 |) | |— | | |423.9 | | |(423.9 |) | |— | |
|Income tax expense | |223.4 | | |28.5 | | |251.9 | | |170.0 | | |13.4 | | |183.4 | |
|Net income from continuing operations | |1,456.5 | | |142.3 | | |1,598.8 | | |561.1 | | |675.6 | | |1,236.7 | |
|Net income from discontinued operations | |— | | |— | | |— | | |3,680.5 | | |(3,680.5 |) | |— | |
|Net income | |1,456.5 | | |142.3 | | |1,598.8 | | |4,241.6 | | |(3,004.9 |) | |1,236.7 | |
|Earnings per share - diluted | |1.60 | | |0.15 | | |1.75 | | |4.31 | | |(2.98 |) | |1.33 | |
|Weighted-average shares outstanding (thousands) - diluted | |911,713 | | |— | | |911,713 | | |984,001 | | |(54,167 |) | |929,834 | |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

|(a) |The company uses non-GAAP financial measures that differ from financial statements reported in conformity with U.S. generally accepted accounting principles (GAAP). The company’s non-GAAP measures adjust reported results to exclude amortization of intangibles and items that are typically highly variable, difficult to predict, and of a size that could have a substantial impact on the company’s reported operations for a period. The company believes that these non-GAAP measures provide useful information to investors. Among other things, they may help investors evaluate the company’s ongoing operations. They can assist in making meaningful period-over-period comparisons and in identifying operating trends that would otherwise be masked or distorted by the items subject to the adjustments. Management uses these non-GAAP measures internally to evaluate the performance of the business, including to allocate resources and to evaluate results relative to incentive compensation targets. |

|23 |

Investors should consider these non-GAAP measures in addition to, not as a substitute for or superior to, measures of financial performance prepared in accordance with GAAP.

|(b) |Adjustments to certain GAAP reported measures for the three months ended March 31, 2020, include the following: |

|(Dollars in millions, except per share data) |Amortization (i) |IPR&D (ii) |Other specified items (iii) |Total |
|Cost of sales |$ |(54.4 |) |$ |— | |$ |(4.2 |) |$ |(58.6 |) |
|Operating expenses | |— | | |— | |
|Acquired in-process research and development |— | |(52.3 |) |— | |(52.3 |) |
|Asset impairment, restructuring and other special charges |— | |— | |(59.9 |) |(59.9 |) |
|Income taxes |11.3 | |11.0 | |6.2 | |28.5 | |
|Net income |43.1 | |41.3 | |57.9 | |142.3 | |
|Earnings per share - diluted |0.05 | |0.05 | |0.06 | |0.15 | |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

|i. |Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties. |

|ii. |Exclude costs associated with upfront payments for acquired in-process research and development projects acquired in a transaction other than a business combination. These costs were related to a business development transaction with Sitryx. |

|iii. |Asset impairment, restructuring and other special charges exclude primarily acquisition and integration costs as part of the closing of the acquisition of Dermira. |

|24 |

|(c) |Adjustments to certain GAAP reported measures for the three months ended March 31, 2019, include the following: |

|(Dollars in millions, except per share data) |Amortization (i) |IPR&D (ii) |Other specified items (iii) |Reduced shares outstanding (iv) |Lartruvo charges (v) |Discontinued operations (vi) |Total |
|Cost of sales |$ |(43.6 |) |$ |— | |$ |— | |$ |— | |$ |(84.6 |) |$ |— | |$ |(128.2 |) |
|Acquired in-process research and development |— | |(136.9 |) |— | |— | |— | |— | |(136.9 |) |
|Asset impairment, restructuring and other special charges |— | |— | |(411.8 |) |— | |(12.1 |) |— | |(423.9 |) |
|Income taxes |8.9 | |28.7 | |4.2 | |— | |(28.5 |) |— | |13.4 | |
|Net income |34.7 | |108.1 | |407.6 | |— | |125.2 | |(3,680.5 |) |(3,004.9 |) |
|Earnings per share - diluted |0.04 | |0.12 | |0.44 | |0.03 | |0.13 | |(3.74 |) |(2.98 |) |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

|i. |Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties. |

|ii. |Exclude costs associated with upfront payments for acquired in-process research and development projects acquired in a transaction other than a business combination. These costs were related to business development transactions with AC Immune SA and ImmuNext, Inc. |

|iii. |Exclude charges primarily associated with the accelerated vesting of Loxo Oncology employee equity awards as part of the closing of the acquisition of Loxo Oncology. |

|iv. |Non-GAAP earnings per share assume that the disposition of Elanco occurred at the beginning of 2019 and therefore include the benefit from the reduction in shares of common stock outstanding. |

|v. |Exclude charges related to the withdrawal of Lartruvo. |

|vi. |Exclude discontinued operations of Elanco. |

|25 |
