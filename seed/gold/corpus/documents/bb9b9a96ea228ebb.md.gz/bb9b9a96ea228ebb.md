EX-99.1 7 q322lillysalesandearningsp.htm EX-99.1 html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd" Document created using Wdesk  Copyright 2022 Workiva Document

Nov. 1, 2022

For Release: Immediately

Refer to: Jordan Bishop; jordan.bishop@lilly.com; (317) 473-5712 (Media)

Joe Fletcher; jfletcher@lilly.com; (317) 296-2884 (Investors)

Lilly Reports Solid Third-Quarter 2022 Financial Results and Continued Pipeline Progress

•Lilly's revenue in Q3 2022 increased 2%, or 7% on a constant currency basis, primarily driven by volume growth of key growth products, partially offset by lower realized prices and lower Alimta revenue following the entry of generics. Total worldwide volume in Q3 2022 increased 14%.

•Strong launch for Mounjaro led to $97.3 million in U.S. revenue in Q3 2022. The company also recognized $86.0 million in Mounjaro revenue related to a sales collaboration agreement for the right to sell and distribute Mounjaro in Japan.

•Pipeline advancements included the FDA granting Fast Track designation for tirzepatide in obesity, regulatory approvals in Europe and Japan for Mounjaro in type 2 diabetes, and the submission of lebrikizumab for moderate-to-severe atopic dermatitis in the U.S. and European Union.

•Key growth products - consisting of Verzenio, Trulicity, Mounjaro, Jardiance, Taltz, Emgality, Retevmo, Cyramza, Tyvyt and Olumiant - grew 19% and represented 70% of revenue in Q3 2022, excluding revenue from COVID-19 antibodies.

•Q3 2022 EPS increased 32% to $1.61 on a reported basis and increased 12% to $1.98 on a non-GAAP basis. Q3 2022 reported and non-GAAP EPS are both inclusive of $0.06 of acquired IPR&D and development milestone charges.

•2022 EPS guidance updated to be in the range of $6.50 to $6.65 on a reported basis and $7.70 to $7.85 on a non-GAAP basis, both inclusive of $0.67 of acquired IPR&D and development milestone charges.

INDIANAPOLIS, Nov. 1, 2022 - Eli Lilly and Company (NYSE: LLY) today announced its financial results for the third quarter of 2022.

"Lilly delivered another solid quarter with pipeline advancements across the portfolio, continued growth of key products, and impressive uptake from our recently launched medicine, Mounjaro, for type 2 diabetes," said David A. Ricks, Lilly's chair and CEO. "With four more launches expected by the end of next year and a potential major new indication for tirzepatide, Lilly continues to make progress for patients with unaddressed medical needs through our significant commitment to invest

Eli Lilly and Company | Lilly Corporate Center | Indianapolis, Indiana 46285 | U.S.A.

in R&D, welcome the best talent, and turn breakthroughs in our labs into medicines for people around the world."

Lilly shared numerous updates recently on key regulatory, clinical, business development and other events, including:

•The U.S. Food and Drug Administration (FDA) granting Fast Track designation for tirzepatide in obesity or overweight with weight-related comorbidities. Lilly plans to initiate a rolling submission in 2022 and complete the submission shortly after SURMOUNT-2 data is available, which is expected in April 2023;

•Regulatory authorities in Europe and Japan approving Mounjaro® for the treatment of adults with type 2 diabetes;

•The submission of lebrikizumab for the treatment of moderate-to-severe atopic dermatitis to the FDA and submission by Almirall in the European Union;

•The FDA granting accelerated approval for Retevmo® in adults with advanced or metastatic solid tumors with a RET gene fusion regardless of tumor type, and simultaneously granting traditional approval in adults with locally advanced or metastatic non-small cell lung cancer with a RET gene fusion, as detected by an FDA-approved test;

•The commercial availability of bebtelovimab for purchase by states, hospitals and certain other providers;

•Supplying an additional 60,000 doses of bebtelovimab to the U.S. government in Q3 2022 for approximately $110 million to be used for financially vulnerable patients;

•The entry into a definitive agreement to acquire Akouos, a precision genetic medicine company developing first-in-class adeno-associated viral vector-based gene therapies for the treatment of inner ear conditions, including sensorineural hearing loss;

•Announcing that Stephen Fry, Lilly’s executive vice president, human resources and diversity, will retire at the end of 2022 and Eric Dozier, senior vice president and chief commercial officer for Loxo@Lilly, will succeed him; and

•Publishing of Lilly's inaugural Sustainability Bond Allocation and Impact Report that highlights allocation of approximately 128 million euros across a range of projects since the issuance of the sustainability bonds in September 2021.

|2 |

For additional information on these and other important public announcements, visit the news section of Lilly's website.

Financial Results

|$ in millions, except per share data |Third Quarter |% | | | |
| |2022 | |2021 |Change | | | | | |
|Revenue |$6,941.6 | |$6,772.8 |2% | | | | | |
|Net Income – Reported |1,451.7 | |1,110.1 |31% | | | | | |
|EPS – Reported |1.61 | |1.22 |32% | | | | | |
|Net Income – Non-GAAP |1,789.2 | |1,614.2 |11% | | | | | |
|EPS – Non-GAAP |1.98 | |1.77 |12% | | | | | |

A discussion of the non-GAAP financial measures is included under "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)."

Third-Quarter Reported Results

In Q3 2022, worldwide revenue was $6.94 billion, an increase of 2% compared with Q3 2021, driven by a 14% increase in volume, partially offset by a 7% decrease due to lower realized prices and a 4% decrease from the unfavorable impact of foreign exchange rates. Key growth products, consisting of Verzenio®, Trulicity®, Mounjaro, Jardiance®, Taltz®, Emgality®, Retevmo, Cyramza®, Tyvyt® and Olumiant®, grew 19% and represented 70% of revenue for Q3 2022, excluding revenue from COVID-19 antibodies. Excluding revenue from Alimta®, which lost exclusivity in major markets, COVID-19 antibodies, and Olumiant for the treatment of COVID-19, worldwide revenue increased 9% in Q3 2022.

Revenue in the U.S. increased 11% to $4.42 billion, driven by a 15% increase in volume, partially offset by a 4% decrease due to lower realized prices. Excluding revenue from Alimta, COVID-19

|3 |

antibodies, and Olumiant for the treatment of COVID-19, revenue in the U.S. increased by 20%, primarily driven by volume from key growth products. The lower realized prices in the U.S. were primarily driven by Humalog®, due to unfavorable segment mix and list price reduction of Insulin Lispro injection.

Revenue outside the U.S. decreased 9% to $2.52 billion, driven by a 12% decrease due to lower realized prices and an 11% decrease from the unfavorable impact of foreign exchange rates, partially offset by a 13% increase in volume. The lower realized prices were primarily driven by the impact of government pricing in China from the National Reimbursement Drug List (NRDL) formulary for certain products, particularly Tyvyt and Verzenio, and volume-based procurement (VBP) for Humalog. The increase in volume outside the U.S. was largely driven by key growth products and the NRDL formulary in China, partially offset by decreased volume for Alimta and Cymbalta® resulting from generic competition. Additionally in Q3 2022, the company recognized $86.0 million in Mounjaro revenue related to a sales collaboration agreement with Mitsubishi Tanabe Pharma for the right to sell and distribute Mounjaro in Japan. Excluding revenue from Alimta, COVID-19 antibodies, and Olumiant for the treatment of COVID-19, revenue outside the U.S. decreased by 5%, or an increase of 6% on a constant currency basis.

Gross margin was relatively flat at $5.36 billion in Q3 2022 compared with Q3 2021. Gross margin as a percent of revenue was 77.3%, a decrease of 1.6 percentage points compared with Q3 2021. Gross margin in Q3 2021 included a benefit from the partial reversal of a previous inventory charge related to COVID-19 antibodies. Additionally, in 2022, lower realized prices and increased expenses due to inflation and logistics costs were offset by favorable product mix, including the impact of lower sales of Olumiant for the treatment of COVID-19, and the favorable impact of foreign exchange rates.

In Q3 2022, research and development expenses increased 6% to $1.80 billion, or 26% of revenue, driven by higher development expenses for late-stage assets, partially offset by the favorable impact of foreign exchange rates and lower development expenses for COVID-19 antibodies.

|4 |

Marketing, selling and administrative expenses increased 2% to $1.61 billion in Q3 2022, primarily driven by increased costs associated with the launch of Mounjaro, partially offset by the favorable impact of foreign exchange rates.

In Q3 2022, the company recognized acquired in-process research and development (IPR&D)and development milestone charges of $62.4 million compared with $177.6 million in Q3 2021.

In Q3 2022, the company recognized asset impairment, restructuring and other special charges of $206.5 million, primarily related to an intangible asset impairment for GBA1 Gene Therapy (PR001) due to changes in estimated launch timing. There were no asset impairment, restructuring and other special charges recognized in Q3 2021.

Operating income in Q3 2022 was $1.68 billion compared with $1.88 billion in Q3 2021. Operating margin percent, defined as operating income as a percent of revenue, was 24.2%, which includes a negative impact of approximately 90 basis points attributed to acquired IPR&D and development milestone charges.

Other expense was $111.0 million in Q3 2022 compared with other expense of $635.9 million in Q3 2021. The reduction in other expense was primarily driven by a charge of $405.2 million related to the repurchase of higher-cost debt in Q3 2021 as well as lower net losses on investments in equity securities in Q3 2022 compared with Q3 2021.

The effective tax rate was 7.3% in Q3 2022 compared with 10.9% in Q3 2021. The effective tax rate in Q3 2022 was impacted favorably by the implementation of the provision in the Tax Cuts and Jobs Act (the 2017 Tax Act) that requires capitalization and amortization of research and development expenses for tax purposes starting in 2022 and the intangible asset impairment charge. The effective tax rate in Q3 2021 reflected the tax impact of the charge related to the repurchase of higher-cost debt, partially offset by a net discrete tax detriment.

|5 |

In Q3 2022, net income and earnings per share (EPS) were $1.45 billion and $1.61, respectively, compared with $1.11 billion and $1.22 in Q3 2021. Q3 2022 EPS was inclusive of $0.06 of acquired IPR&D and development milestone charges compared with $0.17 in Q32021.

Third-Quarter Non-GAAP Measures

On a non-GAAP basis, Q3 2022 gross margin increased 3% to $5.49 billion compared with Q3 2021. Gross margin as a percent of revenue was 79.0% in both periods as lower realized prices and increased expenses due to inflation and logistics costs were offset by favorable product mix, including the impact of lower sales of Olumiant for the treatment of COVID-19, and the favorable impact of foreign exchange rates.

Operating income on a non-GAAP basis increased $116.9 million, or 6%, to $2.01 billion in Q3 2022 compared with Q3 2021. Operating margin percent was 28.9% on a non-GAAP basis, which includes a negative impact of approximately 90 basis points attributed to acquired IPR&D and development milestone charges.

The effective tax rate on a non-GAAP basis was 10.7% in Q3 2022 compared with 14.3% in Q3 2021. The effective tax rate for Q3 2022 reflects the favorable tax impact related to the implementation of the 2017 Tax Act.

On a non-GAAP basis in Q3 2022, net income and EPS were $1.79 billion and $1.98, respectively, compared with $1.61 billion and $1.77 in Q3 2021. Q3 2022 non-GAAP EPS was inclusive of $0.06 of acquired IPR&D and development milestone charges compared with $0.17 in Q32021.

For further detail on non-GAAP measures, see the reconciliation below as well as the "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)" table later in this press release.

|6 |

| |Third Quarter |
| |2022 | |2021 |% Change |
|Earnings per share (reported) |$ |1.61 | | |$ |1.22 | |32% |
|Asset impairment, restructuring and other special charges |.17 | | |— | | |
|Amortization of intangible assets |.11 | | |.12 | | |
|Net losses on investments in equity securities |.09 | | |.19 | | |
|Charge related to repurchase of higher-cost debt |— | | |.35 | | |
|Partial reversal of COVID-19 antibodies inventory charges |— | | |(.11) | | |
|Earnings per share (non-GAAP) |$ |1.98 | | |$ |1.77 | |12% |
|Numbers may not add due to rounding. | | | | |
|Acquired IPR&D and development milestone charges |.06 | | |.17 | |(63)% |

|7 |

Selected Revenue Highlights

|(Dollars in millions) |Third Quarter | |Year-to-Date | |
|Selected Products |2022 | |2021 | |% Change | |2022 | |2021 | |% Change | |
|Trulicity |$ |1,850.4 | | |$ |1,600.1 | | |16% | |$ |5,503.5 | | |$ |4,588.2 | | |20% | |
|COVID-19 antibodies (a) |386.6 | | |217.1 | | |78% | |1,985.5 | | |1,176.2 | | |69% | |
|Taltz |679.9 | | |593.1 | | |15% | |1,774.2 | | |1,565.4 | | |13% | |
|Verzenio |617.7 | | |335.5 | | |84% | |1,675.6 | | |945.8 | | |77% | |
|Humalog (b) |447.0 | | |626.7 | | |(29)% | |1,512.3 | | |1,851.3 | | |(18)% | |
|Jardiance (c) |573.3 | | |390.4 | | |47% | |1,453.7 | | |1,058.9 | | |37% | |
|Humulin ® |238.2 | | |286.7 | | |(17)% | |785.4 | | |923.8 | | |(15)% | |
|Cyramza |232.1 | | |253.4 | | |(8)% | |693.6 | | |762.5 | | |(9)% | |
|Alimta |119.4 | | |457.0 | | |(74)% | |691.1 | | |1,626.6 | | |(58)% | |
|Olumiant (d) |182.9 | | |406.9 | | |(55)% | |624.7 | | |809.1 | | |(23)% | |
|Basaglar ® |193.0 | | |192.8 | | |0% | |558.7 | | |650.1 | | |(14)% | |
|Emgality |168.5 | | |140.0 | | |20% | |475.2 | | |415.7 | | |14% | |
|Forteo |177.1 | | |200.9 | | |(12)% | |453.0 | | |617.8 | | |(27)% | |
|Tyvyt |76.8 | | |125.6 | | |(39)% | |235.8 | | |340.2 | | |(31)% | |
|Mounjaro |187.3 | | |— | | |NM | |203.2 | | |— | | |NM | |
|Retevmo |40.5 | | |33.6 | | |21% | |127.3 | | |76.1 | | |67% | |
|Total Revenue |6,941.6 | | |6,772.8 | | |2% | |21,239.6 | | |20,318.5 | | |5% | |
|(a) COVID-19 antibodies include sales for bamlanivimab administered alone, for bamlanivimab and etesevimab administered together, and for bebtelovimab, and were made pursuant to EUAs or similar regulatory authorizations (b) Humalog includes Insulin Lispro (c) Jardiance includes Glyxambi ® , Synjardy ® and Trijardy ® XR (d) Olumiant includes sales of baricitinib that were made pursuant to EUA or similar regulatory authorizations NM – not meaningful | |

|8 |

Trulicity

For Q3 2022, worldwide Trulicity revenue was $1.85 billion, an increase of 16% compared with Q3 2021. U.S. revenue increased 18% to $1.42 billion, driven by increased demand, partially offset by lower realized prices. The lower realized prices were driven by unfavorable segment mix and higher contracted rebates, partially offset by changes to estimates for rebates and discounts. Revenue outside the U.S. was $432.0 million, an increase of 8%, driven by increased demand, partially offset by the unfavorable impact of foreign exchange rates and, to a lesser extent, lower realized prices.

Taltz

For Q3 2022, worldwide Taltz revenue increased 15% compared with Q3 2021 to $679.9 million. U.S. revenue increased 17% to $493.8 million, driven by increased demand, partially offset by lower realized prices. Revenue outside the U.S. increased 9%to $186.1 million, driven by increased volume, partially offset by the unfavorable impact of foreign exchange rates and, to a lesser extent, lower realized prices.

Verzenio

For Q3 2022, worldwide Verzenio revenue increased 84% compared with Q3 2021 to $617.7 million. U.S. revenue was $414.8 million, representing an increaseof $215.1 million compared with Q3 2021, driven by increased demand. Revenue outside the U.S. was $202.9 million, an increase of 49%, driven by increased demand, partially offset by lower realized prices due to the impact of the NRDL formulary in China and the unfavorable impact of foreign exchange rates.

Humalog

For Q3 2022, worldwide Humalog revenue decreased 29% compared with Q3 2021 to $447.0 million. Revenue in the U.S. decreased 29% to $248.1 million, driven by unfavorable segment mix and list price reduction of Insulin Lispro injection. Revenue outside the U.S. decreased 29% to $198.8 million, driven by lower realized prices due to the impact of VBP in China and the unfavorable impact of foreign exchange rates.

|9 |

Jardiance

The company's worldwide Jardiance revenue for Q3 2022 was $573.3 million, an increase of 47% compared with Q3 2021. U.S. revenue increased 59% to $350.9 million, primarily driven by increased demand and changes to estimates for rebates and discounts. Revenue outside the U.S. was $222.4 million, an increase of 31%, primarily driven by increased demand, partially offset by the unfavorable impact of foreign exchange rates.

Jardiance is part of the company's alliance with Boehringer Ingelheim. Lilly reports as revenue royalties received on net sales of Jardiance.

Alimta

For Q3 2022, worldwide Alimta revenue decreased 74% compared with Q3 2021 to $119.4 million. U.S. revenue decreased 78% to $64.6 million, driven by decreased demand due to the entry of multiple generics in Q2 2022. Revenue outside the U.S. decreased 66% to $54.8 million, largely driven by decreased demand due to generic competition.

The company expects continued volume and revenue decline for Alimta as a result of generic competition due to the loss of patent exclusivity in major markets.

Olumiant

For Q3 2022, worldwide Olumiant revenue decreased 55% compared with Q3 2021 to $182.9 million. U.S. revenue decreased 88% to $22.9 million, driven by a decline in utilization for COVID-19 treatment. Revenue outside the U.S. was $160.0 million, a decrease of 25%, driven by the unfavorable impact of foreign exchange rates and a decline in utilization for COVID-19 treatment.

Emgality

For Q3 2022, Emgality generated worldwide revenue of $168.5 million, an increase of 20% compared with Q3 2021. U.S. revenue was $114.0 million, an increase of 14%, driven by increased

|10 |

demand. Revenue outside the U.S. was $54.6 million, an increase of 36%, primarily driven by increased demand, partially offset by the unfavorable impact of foreign exchange rates.

Tyvyt

For Q3 2022, the company's Tyvyt revenue in China was $76.8 million, a decrease of 39% compared with Q3 2021, driven by the impact of the NRDL formulary in China, which resulted in lower realized prices that were partially offset by increased volume, as well as increased competitive pressure.

Tyvyt is part of the company's alliance with Innovent. Lilly reports total sales of Tyvyt made by Lilly as revenue, with payments made to Innovent for its portion of the gross margin reported as cost of sales. Lilly also reports as revenue a portion of the gross margin for Tyvyt sales made by Innovent.

Mounjaro

For Q3 2022, worldwide Mounjaro revenue was $187.3 million. U.S. revenue was $97.3 million. Revenue outside the U.S. was $90.0 million, driven by revenue related to a sales collaboration agreement with Mitsubishi Tanabe Pharma for the right to sell and distribute Mounjaro in Japan.

2022 Financial Guidance

The company has updated certain elements of its 2022 financial guidance on both a reported and non-GAAP basis. EPS for 2022 is now expected to be in the range of $6.50 to $6.65 on a reported basis and $7.70 to $7.85 on a non-GAAP basis. The reductions in the reported and non-GAAP EPS ranges both reflect the unfavorable impact of foreign exchange rates as well as the $0.06 EPS impact associated with acquired IPR&D and development milestone charges in Q3 2022. The company's 2022 financial guidance reflects adjustments shown in the reconciliation table below.

|11 |

| |2022 Expectations | |% Change vs 2021 |
|Earnings per share (reported) |$6.50 to $6.65 | |6% to 9% |
|Net losses on investments in equity securities |.52 | | |
|Amortization of intangible assets |.51 | | |
|Asset impairment, restructuring, and other special charges |.17 | | |
|Earnings per share (non-GAAP) |$7.70 to $7.85 | |4% to 6% |
|Numbers may not add due to rounding | | | |
|Acquired IPR&D and development milestone charges |$.67 | | |

The company now anticipates 2022 revenue to be between $28.5 billion and $29.0 billion. This includes an additional $300 million of unfavorability from foreign exchange rates since the company's previous guidance update, for a total impact of approximately $1.0 billion of unfavorability from foreign exchange rates for the full year.

The company's outlook for gross margin, marketing, selling and administrative expenses, and research and development expenses remains unchanged.

Acquired IPR&D and development milestone charges are now expected to be approximately $670 million, reflecting total charges in the first nine months of the year. There have been no material acquired IPR&D and development milestone charges recognized to date in the fourth quarter and this financial guidance does not include any impact from potential or pending business development transactions in the fourth quarter of the year, including the company's pending acquisition of Akouos.

Operating margin percent on a reported basis has been reduced by 100 basis points and is now expected to be approximately 26%, driven by the intangible asset impairment for GBA1 Gene Therapy (PR001). Operating margin percent on a non-GAAP basis remains unchanged at approximately 29%.

|12 |

Other income (expense) for 2022 is now expected to be expense in the range of $600 million to $700 million on a reported basis and is still expected to be expense in the range of $0 to $100 million on a non-GAAP basis. The company's updated reported guidance reflects the impact of net losses on investments in equity securities during Q3 2022.

The company's financial results for Q3 2022 include the favorable impact related to the implementation of the provision of the 2017 Tax Act that requires capitalization and amortization of research and development expenses for tax purposes. The company's financial guidance for reported and non-GAAP tax rates of approximately 13% to 14% continues to assume this provision of the 2017 Tax Act will be deferred or repealed by Congress effective for 2022. If this provision of the 2017 Tax Act is not deferred or repealed by Congress effective for 2022, the company still expects the reported and non-GAAP tax rates to be approximately 10% to 11%.

Based on these changes, the company has lowered reported EPS guidance by $0.46 to now be in the range of $6.50 to $6.65 and lowered non-GAAP EPS guidance by $0.20 to now be in the range of $7.70 to $7.85. The reductions in the reported and non-GAAP EPS ranges both reflect the unfavorable impact of foreign exchange rates as well as the $0.06 EPS impact associated with acquired IPR&D and development milestone charges in Q3 2022. The reduction in reported EPS guidance also reflects the impact of the intangible asset impairment for GBA1 Gene Therapy (PR001) as well as additional net losses on investments in equity securities during Q3 2022.

|13 |

The following table summarizes the company's updated 2022 financial guidance:

| |2022 Guidance |
| |Prior | |Updated |
|Revenue |$28.8 to $29.3 billion | |$28.5 to $29.0 billion |
|Gross Margin % of Revenue (reported) |Approx. 76% | |Unchanged |
|Gross Margin % of Revenue (non-GAAP) |Approx. 78% | |Unchanged |
|Marketing, Selling & Administrative |$6.4 to $6.6 billion | |Unchanged |
|Research & Development |$7.1 to $7.3 billion | |Unchanged |
|Acquired IPR&D & Development Milestones |Approx. $610 million | |Approx. $670 million |
|Other Income/(Expense) (reported) |$(600) to $(500) million | |$(700) to $(600) million |
|Other Income/(Expense) (non-GAAP) |$(100) million to $0 | |Unchanged |
|Tax Rate |Approx. 13% to 14% | |Unchanged |
|Earnings per Share (reported) |$6.96 to $7.11 | |$6.50 to $6.65 |
|Earnings per Share (non-GAAP) |$7.90 to $8.05 | |$7.70 to $7.85 |
|Operating Margin % (reported) |Approx. 27% | |Approx. 26% |
|Operating Margin % (non-GAAP) |Approx. 29% | |Unchanged |
|Non-GAAP guidance reflects adjustments presented in the earnings per share table above. |

|14 |

Webcast of Conference Call

As previously announced, investors and the general public can access a live webcast of the Q3 2022 financial results conference call through a link on Lilly's website at investor.lilly.com/webcasts-and-presentations. The conference call will begin at 9 a.m. Eastern time today and will be available for replay via the website.

Non-GAAP Financial Measures

Certain financial information for 2022 and 2021 is presented on both a reported and a non-GAAP basis. Some numbers in this press release may not add due to rounding. Reported results were prepared in accordance with U.S. generally accepted accounting principles (GAAP) and include all revenue and expenses recognized during the periods. Non-GAAP measures reflect adjustments for the items described in the reconciliation tables later in the release. The press release and related materials provide certain GAAP and non-GAAP figures excluding the impact of foreign exchange rates. Lilly recalculates current period figures on a constant currency basis by keeping constant the exchange rates from the base period. Beginning in 2022, presentations of non-GAAP financial measures will not include adjustments for upfront charges and development milestones related to acquired IPR&D. Non-GAAP financial measures for Q3 2021 have been adjusted to reflect this updated presentation. The company's 2022 financial guidance is being provided on both a reported and a non-GAAP basis. The non-GAAP measures are presented to provide additional insights into the underlying trends in the company's business.

About Lilly

Lilly unites caring with discovery to create medicines that make life better for people around the world. We’ve been pioneering life-changing discoveries for nearly 150 years, and today our medicines help more than 47million people across the globe. Harnessing the power of biotechnology, chemistry and genetic medicine, our scientists are urgently advancing new discoveries to solve some of the world’s most significant health challenges, redefining diabetes care, treating obesity and curtailing its most devastating long-term effects, advancing the fight against Alzheimer’s disease, providing solutions to some of the most debilitating immune system disorders, and

|15 |

transforming the most difficult-to-treat cancers into manageable diseases. With each step toward a healthier world, we’re motivated by one thing: making life better for millions more people. That includes delivering innovative clinical trials that reflect the diversity of our world and working to ensure our medicines are accessible and affordable. To learn more, visitLilly.com and Lilly.com/newsroom.F-LLY

Cautionary Statement Regarding Forward-Looking Statements

This press release contains management's current intentions and expectations for the future, all of which are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933 and Section 21E of the Securities Exchange Act of 1934. The words "estimate", "project", "intend", "expect", "believe", "target", "anticipate" and similar expressions are intended to identify forward-looking statements. Actual results may differ materially due to various factors. The following include some but not all of the factors that could cause actual results or events to differ materially from those anticipated, including the impact of the evolving COVID-19 pandemic or any future pandemic, epidemic, or similar public health threat and the global response thereto; uncertainties related to the company's efforts to develop, manufacture, and distribute potential treatments for COVID-19; the significant costs and uncertainties in the pharmaceutical research and development process, including with respect to the timing and process of obtaining regulatory approvals; the impact and outcome of acquisitions and business development transactions and related integration costs; the expiration of intellectual property protection for certain of the company's products and competition from generic and/or biosimilar products; the company's ability to protect and enforce patents and other intellectual property; changes in patent law or regulations related to data package exclusivity; competitive developments affecting current products and the company's pipeline; market uptake of recently launched products; information technology system inadequacies, breaches, or operating failures; unauthorized access, disclosure, misappropriation, or compromise of confidential information or other data stored in the company's information technology systems, networks, and facilities, or those of third parties with whom the company shares its data; unexpected safety or efficacy concerns associated with the company's products; litigation, investigations, or other similar proceedings involving past, current, or future products or commercial activities as the company is largely self-insured; issues with product supply and regulatory approvals stemming from manufacturing difficulties, disruptions, or shortages, including as a result of demand, labor shortages, third-party performance, or regulatory actions related to our facilities; reliance on third-party relationships and outsourcing arrangements; regulatory changes or other developments; regulatory actions regarding currently marketed products; continued pricing pressures and the impact of actions of governmental and private payers affecting pricing of, reimbursement for, and access to pharmaceuticals; devaluations in foreign currency exchange rates or changes in interest rates, and inflation; changes in tax law, tax rates, or events that differ from the company's assumptions related to tax positions; asset impairments and restructuring charges; the impact of global macroeconomic conditions, trade disruptions, global disputes, unrest, war, or other costs, uncertainties and risks related to engaging in business in foreign jurisdictions; changes in accounting and reporting standards promulgated by the Financial Accounting Standards Board and the Securities and Exchange Commission (SEC); and regulatory compliance problems or government investigations. For additional information about the factors that could cause actual results or events to differ materially from forward-looking statements, please see the company's latest Form 10-K and subsequent Forms 8-K and 10-Q filed with the SEC. You should not place undue reliance on forward-looking statements, which speak only as of the date of this release. Except as is required by law, the company expressly disclaims any obligation to publicly release any revisions to forward-looking statements to reflect events after the date of this release.

 # # #

Alimta® (pemetrexed disodium, Lilly)

|16 |

Basaglar® (insulin glargine injection, Lilly)

Cymbalta® (duloxetine, Lilly)

Cyramza® (ramucirumab, Lilly)

Emgality® (galcanezumab-gnlm, Lilly)

Forteo® (teriparatide of recombinant DNA origin injection, Lilly)

Glyxambi® (empagliflozin/linagliptin, Boehringer Ingelheim)

Humalog® (insulin lispro injection of recombinant DNA origin, Lilly)

Humulin® (human insulin of recombinant DNA origin, Lilly)

Jardiance® (empagliflozin, Boehringer Ingelheim)

Mounjaro® (tirzepatide injection, Lilly)

Olumiant® (baricitinib, Lilly)

Qbrexza® (glycopyrronium cloth, Dermira)

Retevmo® (selpercatinib, Lilly)

Synjardy® (empagliflozin/metformin, Boehringer Ingelheim)

Taltz® (ixekizumab, Lilly)

Trijardy® XR (empagliflozin/linagliptin/metformin hydrochloride extended release tablets, Boehringer Ingelheim)

Trulicity® (dulaglutide, Lilly)

Tyvyt® (sintilimab injection, Innovent)

Verzenio® (abemaciclib, Lilly)

Third party trademarks used herein are trademarks of their respective owners.

|17 |

|Eli Lilly and Company |
|Operating Results (Unaudited) – REPORTED |
|(Dollars in millions, except per share data) |

| | |Three Months Ended | |Nine Months Ended |
| | |September 30, | |September 30, |
| | |2022 | |2021 | |% Chg. | |2022 | |2021 | |% Chg. |
|Revenue |$ |6,941.6 | |$ |6,772.8 | | |2% |$ |21,239.6 | |$ |20,318.5 | | |5% |
|Cost of sales | |1,579.1 | | |1,430.8 | | |10% | |5,081.7 | | |5,262.6 | | |(3)% |
|Research and development | |1,802.9 | | |1,705.3 | | |6% | |5,194.9 | | |5,032.4 | | |3% |
|Marketing, selling and administrative | |1,614.2 | | |1,577.9 | | |2% | |4,797.2 | | |4,839.6 | | |(1)% |
|Acquired IPR&D and development milestones | |62.4 | | |177.6 | | |(65)% | |668.4 | | |532.4 | | |26% |
|Asset impairment, restructuring and other special charges | |206.5 | | |— | | |NM | |206.5 | | |211.6 | | |(2)% |
|Operating income | |1,676.5 | | |1,881.2 | | |(11)% | |5,290.9 | | |4,439.9 | | |19% |
|Net interest income (expense) | |(61.4) | | |(76.6) | | | | |(210.3) | | |(240.4) | | | |
|Net other income (expense) | |(49.6) | | |(559.3) | | | | |(370.6) | | |116.1 | | | |
|Other income (expense) | |(111.0) | | |(635.9) | | |(83)% | |(580.9) | | |(124.3) | | |NM |
|Income before income taxes | |1,565.5 | | |1,245.3 | | |26% | |4,710.0 | | |4,315.6 | | |9% |
|Income tax expense | |113.8 | | |135.2 | | |(16)% | |402.9 | | |460.0 | | |(12)% |
|Net income |$ |1,451.7 | |$ |1,110.1 | | |31% |$ |4,307.1 | |$ |3,855.6 | | |12% |
|Earnings per share - diluted |$ |1.61 | |$ |1.22 | | |32% |$ |4.76 | |$ |4.23 | | |13% |
|Dividends paid per share |$ |.98 | | |.85 | | |15% |$ |2.94 | |$ |2.55 | | |15% |
|Weighted-average shares outstanding (thousands) - diluted | |903,782 | | |910,751 | | | | |904,480 | | |911,656 | | | |

NM – not meaningful

|18 |

|Eli Lilly and Company | | |
|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) | | |
|(Dollars in millions, except per share data) | | |
| |Three Months Ended September 30, 2022 | |Three Months Ended September 30, 2021 |
| |GAAP Reported |Adjustments (b) |Non-GAAP Adjusted (a) | |GAAP Reported |Adjustments (c) |Non-GAAP Adjusted (a) |
|Cost of sales |$ |1,579.1 | |$ |(124.1) | |$ |1,455.0 | |$ |1,430.8 | |$ |(9.0) | |$ |1,421.8 | |
|Asset impairment, restructuring and other special charges | |206.5 | | |(206.5) | | |— | | |— | | |— | | |— | |
|Other income (expense) | |(111.0) | | |107.7 | | |(3.3) | | |(635.9) | | |628.6 | | |(7.3) | |
|Income tax expense | |113.8 | | |100.8 | | |214.6 | | |135.2 | | |133.5 | | |268.7 | |
|Net income | |1,451.7 | | |337.5 | | |1,789.2 | | |1,110.1 | | |504.1 | | |1,614.2 | |
|Earnings per share - diluted | |1.61 | | |0.37 | | |1.98 | | |1.22 | | |0.55 | | |1.77 | |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

(a)The company uses non-GAAP financial measures that differ from financial statements reported in conformity with U.S. generally accepted accounting principles (GAAP). The company's non-GAAP measures adjust reported results to exclude amortization of intangibles and other items that are typically highly variable, difficult to predict, and of a size that could have a substantial impact on the company's reported operations for a period. The company believes that these non-GAAP measures provide useful information to investors. Among other things, they may help investors evaluate the company's ongoing operations. They can also assist in making meaningful period-over-period comparisons and in identifying operating trends that would otherwise be masked or distorted by the items subject to the adjustments. Management uses these non-GAAP measures internally to evaluate the performance of the business, including to allocate resources and to evaluate results relative to incentive compensation targets. Investors should consider these non-GAAP measures in addition to, not as a substitute for or superior to, measures of financial performance prepared in accordance with GAAP.

|19 |

(b)Adjustments to certain GAAP reported measures for the three months ended September 30, 2022, include the following:

|(Dollars in millions, except per share data) |Amortization (i) | |Equity investments (ii) | |Other specified items (iii) | | | |Total |
|Cost of sales |$ |(124.1) | | |$ |— | | |$ |— | | | | |(124.1) | |
|Asset impairment, restructuring and other special charges |— | | |— | | |(206.5) | | | | |(206.5) | |
|Other income (expense) |— | | |107.7 | | |— | | | | |107.7 | |
|Income tax expense |25.6 | | |24.9 | | |50.3 | | | | |100.8 | |
|Net income |98.5 | | |82.8 | | |156.2 | | | | |337.5 | |
|Earnings per share - diluted |0.11 | | |0.09 | | |0.17 | | | | |0.37 | |

Numbers may not add due to rounding.

 The table above reflects only line items with non-GAAP adjustments.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.Exclude net losses on investments in equity securities.

iii.Exclude primarily the intangible asset impairment for GBA1 Gene Therapy (PR001) due to changes in estimated launch timing.

(c)Adjustments to certain GAAP reported measures for the three months ended September 30, 2021, include the following:

|(Dollars in millions, except per share data) |Amortization (i) |Equity investments (ii) |Repurchase of Debt (iii) |Other specified items (iv) |Total |
|Cost of sales |$ |(137.1) | |$ |— | |$ |— | |$ |128.1 | |(9.0) | |
|Other income (expense) |— | |223.4 | |405.2 | |— | |628.6 | |
|Income tax expense |28.8 | |46.5 | |85.1 | |(26.9) | |133.5 | |
|Net income |108.3 | |176.9 | |320.1 | |(101.2) | |504.1 | |
|Earnings per share - diluted |0.12 | |0.19 | |0.35 | |(0.11) | |0.55 | |

Numbers may not add due to rounding.

 The table above reflects only line items with non-GAAP adjustments.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.Exclude net losses on investments in equity securities.

iii.Exclude charge related to the repurchase of higher-cost debt.

iv.Exclude partial reversal of COVID-19 antibodies inventory charge.

|20 |

|Eli Lilly and Company | | |
|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) | | |
|(Dollars in millions, except per share data) | | |
| |Nine Months Ended September 30, 2022 | |Nine Months Ended September 30, 2021 |
| |GAAP Reported |Adjustments (b) |Non-GAAP Adjusted (a) | |GAAP Reported |Adjustments (c) |Non-GAAP Adjusted (a) |
|Cost of sales |$ |5,081.7 | |$ |(450.0) | |$ |4,631.7 | |$ |5,262.6 | |$ |(771.4) | |$ |4,491.2 | |
|Asset impairment, restructuring and other special charges | |206.5 | | |(206.5) | | |— | | |211.6 | | |(211.6) | | |— | |
|Other income (expense) | |(580.9) | | |602.4 | | |21.5 | | |(124.3) | | |156.6 | | |32.3 | |
|Income tax expense | |402.9 | | |272.7 | | |675.6 | | |460.0 | | |232.0 | | |692.0 | |
|Net income | |4,307.1 | | |986.2 | | |5,293.3 | | |3,855.6 | | |907.6 | | |4,763.2 | |
|Earnings per share - diluted | |4.76 | | |1.09 | | |5.85 | | |4.23 | | |0.99 | | |5.22 | |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

(a)The company uses non-GAAP financial measures that differ from financial statements reported in conformity with U.S. generally accepted accounting principles (GAAP). The company's non-GAAP measures adjust reported results to exclude amortization of intangibles and other items that are typically highly variable, difficult to predict, and of a size that could have a substantial impact on the company's reported operations for a period. The company believes that these non-GAAP measures provide useful information to investors. Among other things, they may help investors evaluate the company's ongoing operations. They can also assist in making meaningful period-over-period comparisons and in identifying operating trends that would otherwise be masked or distorted by the items subject to the adjustments. Management uses these non-GAAP measures internally to evaluate the performance of the business, including to allocate resources and to evaluate results relative to incentive compensation targets. Investors should consider these non-GAAP measures in addition to, not as a substitute for or superior to, measures of financial performance prepared in accordance with GAAP.

|21 |

(b)Adjustments to certain GAAP reported measures for the nine months ended September 30, 2022, include the following:

|(Dollars in millions, except per share data) |Amortization (i) |Equity investments (ii) | |Other specified items (iii) | | | |Total |
|Cost of sales |(450.0) | |— | | |— | | | | |(450.0) | |
|Asset impairment, restructuring and other special charges |— | |— | | |(206.5) | | | | |(206.5) | |
|Other income (expense) |— | |602.4 | | |— | | | | |602.4 | |
|Income tax expense |93.1 | |129.3 | | |50.3 | | | | |272.7 | |
|Net income |356.9 | |473.1 | | |156.2 | | | | |986.2 | |
|Earnings per share – diluted |0.39 | |0.52 | | |0.17 | | | | |1.09 | |

Numbers may not add due to rounding.

The table above reflects only line items with non-GAAP adjustments.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.Exclude net losses on investments in equity securities.

iii.Exclude primarily the intangible asset impairment for GBA1 Gene Therapy (PR001) due to changes in estimated launch timing.

|22 |

(c)Adjustments to certain GAAP reported measures for the nine months ended September 30, 2021, include the following:

|(Dollars in millions, except per share data) |Amortization (i) |Equity investments (ii) |Repurchase of Debt (iii) |Other specified items (iv) | | | |Total |
|Cost of sales |$ |(395.0) | |$ |— | |$ |— | |$ |(376.4) | | | | |(771.4) | |
|Asset impairment, restructuring and other special charges |— | |— | |— | |(211.6) | | | | |(211.6) | |
|Other income (expense) |— | |(248.5) | |405.2 | |— | | | | |156.6 | |
|Income tax expense |81.8 | |(48.9) | |85.1 | |114.0 | | | | |232.0 | |
|Net income |313.2 | |(199.6) | |320.1 | |474.0 | | | | |907.6 | |
|Earnings per share - diluted |0.34 | |(0.22) | |0.35 | |0.52 | | | | |0.99 | |

Numbers may not add due to rounding.

 The table above reflects only line items with non-GAAP adjustments.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.Exclude net gains on investments in equity securities.

iii.Exclude charge related to the repurchase of higher-cost debt.

iv.Exclude primarily net inventory charges related to COVID-19 antibodies, an intangible asset impairment resulting from the sale of the rights to Qbrexza®, and acquisition and integration costs recognized as part of the closing of the acquisition of Prevail Therapeutics Inc.

|23 |
