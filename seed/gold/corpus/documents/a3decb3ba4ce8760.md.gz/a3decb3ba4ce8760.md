10-Q 1 a09-11040\_110q.htm 10-Q Table of Contents

**UNITED STATES  
SECURITIES AND EXCHANGE COMMISSION**

**WASHINGTON,
D.C. 20549**

**FORM 10-Q**

**(Mark
One)**

|**x** |**QUARTERLY REPORT
PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF
1934\.** |
| --- | --- |

**For
the quarterly period ended March 31, 2009**

**OR**

|**o** |**TRANSITION REPORT
PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF
1934\.** |
| --- | --- |

**For
the transition period from
               to**

**Commission
file number 0-26301**

**United Therapeutics Corporation**

(Exact Name of
Registrant as Specified in Its Charter)

|**Delaware** | |**52-1984749** |
| --- | --- | --- |
|(State or Other Jurisdiction of | |(I.R.S. Employer |
|Incorporation or Organization) | |Identification No.) |
| | | |
|**1110 Spring Street, Silver Spring, MD** | |**20910** |
|(Address of Principal Executive Offices) | |(Zip Code) |

**(301)
608-9292**

(Registrant’s Telephone
Number, Including Area Code)

(Former Name, Former
Address and Former Fiscal Year, If Changed Since Last Report)

Indicate by check mark whether
the registrant: (1) has filed all reports required to be filed by Section 13
or 15(d) of the Securities Exchange Act of 1934 during the preceding 12
months (or for such shorter period that the registrant was required to file
such reports), and (2) has been subject to such filing requirements for
the past 90 days. Yes x No o

Indicate by check mark
whether the registrant has submitted electronically and posted on its corporate
Web site, if any, every Interactive Data File required to be submitted and
posted pursuant to Rule 405 of Regulation S-T (§232.405 of this chapter)
during the preceding 12 months (or for such shorter period that the registrant
was required to submit and post such files). 
Yes o No o

Indicate by check mark
whether the registrant is a large accelerated filer, an accelerated filer, or a
non-accelerated filer. See definition of “accelerated filer and large
accelerated filer” in Rule 12b-2 of the Exchange Act. (Check One):

Large
accelerated filer x Accelerated filer o

Non-accelerated
filer o (Do not
check if a smaller reporting company) Smaller reporting company o

Indicate by check mark
whether the registrant is a shell company (as defined in Rule 12b-2 of the
Exchange Act). Yes o No x

The number of shares
outstanding of the issuer’s common stock, par value $.01 per share, as of April 24,
2009 was 26,451,577.

* * *  
Table of Contents

**INDEX**

| | |**Page** |
| --- | --- | --- |
| | | |
|**Part I.** |**FINANCIAL INFORMATION (UNAUDITED)** | |
| | | |
|Item 1. |Consolidated Financial Statements |3 |
| | | |
| |Consolidated Balance Sheets |3 |
| | | |
| |Consolidated Statements of Operations |4 |
| | | |
| |Consolidated Statements of Cash Flows |5 |
| | | |
| |Notes to Consolidated Financial Statements |6 |
| | | |
|Item 2. |Management’s Discussion and Analysis of Financial Condition and Results of Operations |17 |
| | | |
|Item 3. |Quantitative and Qualitative Disclosures About Market Risk |27 |
| | | |
|Item 4. |Controls and Procedures |27 |
| | | |
|**Part II.** |**OTHER INFORMATION** | |
| | | |
|Item 1A. |Risk Factors |27 |
| | | |
|Item 5. |Other Information |44 |
| | | |
|Item 6. |Exhibits |44 |
| | | |
|**SIGNATURES** | | |

2

* * *  
Table of Contents

**PART I.** FINANCIAL INFORMATION

Item 1. Consolidated Financial Statements

**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED BALANCE
SHEETS**

**(In thousands, except share data)**

| | |**March 31,  
2009** | |**December 31,  
2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**(Unaudited)** | |**(As Adjusted)(1)** | |
|**Assets** | | | | | |
|Current assets: | | | | | |
|Cash and cash equivalents | |$ |98,848 | |$ |129,452 | |
|Marketable investments | |86,945 | |106,596 | |
|Accounts receivable, net of allowance of
none for 2009 and 2008 | |49,410 | |28,311 | |
|Other receivable | |2,597 | |2,289 | |
|Prepaid expenses | |9,989 | |11,600 | |
|Inventories, net | |15,106 | |14,372 | |
|Deferred tax assets | |4,466 | |4,827 | |
|Total current assets | |267,361 | |297,447 | |
|Marketable investments | |133,572 | |100,270 | |
|Marketable investments and cash—restricted | |45,945 | |45,755 | |
|Goodwill and other intangibles, net | |7,800 | |7,838 | |
|Property, plant, and equipment, net | |255,592 | |222,717 | |
|Deferred tax assets | |170,956 | |177,659 | |
|Other assets ($8,177 and $7,685 for 2009
and 2008, measured under the fair value option) | |21,587 | |21,667 | |
|Total assets | |$ |902,813 | |$ |873,353 | |
| | | | | | |
|**Liabilities and Stockholders’ Equity** | | | | | |
|Current liabilities: | | | | | |
|Accounts payable | |$ |10,512 | |$ |20,334 | |
|Accrued expenses | |25,641 | |20,853 | |
|Other current liabilities | |23,608 | |16,251 | |
|Total current liabilities | |59,761 | |57,438 | |
|Notes payable | |209,235 | |205,691 | |
|Lease obligation | |29,524 | |29,261 | |
|Other liabilities | |16,129 | |15,673 | |
|Total liabilities | |314,649 | |308,063 | |
|Commitments and contingencies: | | | | | |
|Common stock subject to repurchase | |10,882 | |10,882 | |
|Stockholders’ equity: | | | | | |
|Preferred stock, par value $.01, 10,000,000
shares authorized, no shares issued | |— | |— | |
|Series A junior participating
preferred stock, par value $.01, 100,000 authorized, no shares issued | |— | |— | |
|Common stock, par value $.01, 100,000,000
shares authorized, 27,682,372 and 27,662,151 shares issued at March 31,
2009, and December 31, 2008, respectively, and 26,451,577 and 26,431,356
outstanding at March 31, 2009, and December 31, 2008, respectively | |277 | |276 | |
|Additional paid-in capital | |730,985 | |720,414 | |
|Accumulated other comprehensive (loss)
income | |(6,808 |) |(5,913 |) |
|Treasury stock at cost, 1,230,795 shares at
March 31, 2009 and December 31, 2008 | |(67,395 |) |(67,395 |) |
|Accumulated deficit | |(79,777 |) |(92,974 |) |
|Total stockholders’ equity | |577,282 | |554,408 | |
|Total liabilities and stockholders’ equity | |$ |902,813 | |$ |873,353 | |

**See accompanying notes to
consolidated financial statements.**

* * *

**(1) Adjusted
for the retrospective adoption of Financial Accounting Standards Board (FASB)
Staff Position No. APB 14-1, _Accounting for Convertible
Debt Instruments That May Be Settled in Cash Upon Conversion (Including
Partial Cash Settlement)_ (FSP APB 14-1) _._ See _Note 8:
Debt — Adoption of FSP APB 14-1._**

3

* * *  
Table of Contents

**UNITED
THERAPEUTICS CORPORATION**

**CONSOLIDATED
STATEMENTS OF OPERATIONS**

**(In
thousands, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
| | | | |**(as adjusted)(1)** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |76,858 | |$ |59,153 | |
|Service sales | |2,530 | |2,227 | |
|License fees | |342 | |667 | |
|Total revenues | |79,730 | |62,047 | |
| | | | | | |
|Operating expenses: | | | | | |
|Research and development | |20,959 | |21,076 | |
|Selling, general and
administrative | |29,218 | |19,331 | |
|Cost of product sales | |8,066 | |6,175 | |
|Cost of service sales | |920 | |711 | |
|Total operating expenses | |59,163 | |47,293 | |
| | | | | | |
|Income from operations | |20,567 | |14,754 | |
| | | | | | |
|Other income (expense): | | | | | |
|Interest income | |1,721 | |3,716 | |
|Interest expense | |(2,637 |) |(2,792 |) |
|Equity loss in affiliate | |(19 |) |(113 |) |
|Other, net | |364 | |(292 |) |
|Total other income (expense),
net | |(571 |) |519 | |
| | | | | | |
|Income before income tax | |19,996 | |15,273 | |
| | | | | | |
|Income tax expense | |(6,799 |) |(5,337 |) |
| | | | | | |
|Net income | |$ |13,197 | |$ |9,936 | |
| | | | | | |
|Net income per common share: | | | | | |
|Basic | |$ |0\.50 | |$ |0\.44 | |
|Diluted | |$ |0\.49 | |$ |0\.41 | |
| | | | | | |
|Weighted average number of
common shares outstanding: | | | | | |
|Basic | |26,440 | |22,333 | |
|Diluted | |27,152 | |24,076 | |

See accompanying notes to consolidated financial statements.

* * *

(1) Adjusted for the retrospective
adoption of FSP APB 14-1. See _Note 8: Debt — Adoption
of FSP APB 14-1._

4

* * *  
Table of Contents

**UNITED
THERAPEUTICS CORPORATION**

**CONSOLIDATED
STATEMENTS OF CASH FLOWS**

**(In
thousands)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
| | | | |**(as adjusted)(1)** | |
| | |**(Unaudited)** | |
| | | | | | |
|Cash flows from operating activities: | | | | | |
|Net income | |$ |13,197 | |$ |9,936 | |
|Adjustments to reconcile net income to net
cash provided by operating activities: | | | | | |
|Depreciation and amortization | |1,765 | |974 | |
|Provision for bad debt and inventory
obsolescence | |355 | |1,622 | |
|Deferred tax benefit | |6,799 | |5,337 | |
|Share-based compensation | |14,055 | |6,891 | |
|Amortization of debt discount and debt issue
costs | |4,140 | |3,574 | |
|Amortization of discount or premium on
investments | |252 | |(635 |) |
|Equity loss in affiliate and other | |(339 |) |230 | |
|Excess tax benefits from share-based
compensation | |(187 |) |(4,283 |) |
|Changes in operating assets and
liabilities: | | | | | |
|Restrictions on cash | |(2,735 |) |(534 |) |
|Accounts receivable | |(23,508 |) |(1,704 |) |
|Inventories | |(3,353 |) |(1,444 |) |
|Prepaid expenses | |1,609 | |(282 |) |
|Other assets | |135 | |(136 |) |
|Accounts payable | |(9,798 |) |8,338 | |
|Accrued expenses | |4,491 | |594 | |
|Other liabilities | |(5,576 |) |6,624 | |
|Net cash provided by operating activities | |1,302 | |35,102 | |
| | | | | | |
|Cash flows from investing activities: | | | | | |
|Purchases of property, plant and equipment | |(21,271 |) |(13,193 |) |
|Purchases of held-to-maturity investments | |(77,733 |) |(60,332 |) |
|Purchases of available-for-sale investments | |— | |(24,600 |) |
|Sales of available-for-sale investments | |— | |36,850 | |
|Maturities of held-to-maturity investments | |66,170 | |51,745 | |
|Net cash (used) by investing activities | |(32,834 |) |(9,530 |) |
| | | | | | |
|Cash flows from financing activities: | | | | | |
|Proceeds from the exercise of stock options | |856 | |8,566 | |
|Excess tax benefits from stock-based
compensation | |187 | |4,283 | |
|Principal payments on debt | |— | |(25 |) |
|Net cash provided by financing activities | |1,043 | |12,824 | |
| | | | | | |
|Effect of exchange rate changes on cash and
cash equivalents | |(115 |) |(73 |) |
|Net increase in cash and cash equivalents | |(30,604 |) |38,323 | |
|Cash and cash equivalents, beginning of
period | |129,452 | |139,323 | |
|Cash and cash equivalents, end of period | |$ |98,848 | |$ |177,646 | |
| | | | | | |
|Supplemental schedule of cash flow
information: | | | | | |
|Cash paid for interest | |$ |5 | |$ |— | |
|Cash paid for income taxes | |$ |1,398 | |$ |— | |

See accompanying notes to consolidated financial statements.

* * *

(1) Adjusted for the retrospective
adoption of FSP APB 14-1. See _Note 8: Debt — Adoption of
FSP APB 14-1._

5

* * *  
Table of Contents

**UNITED
THERAPEUTICS CORPORATION**

**NOTES
TO CONSOLIDATED FINANCIAL STATEMENTS**

**March 31,
2009  
(UNAUDITED)**

**1\.
Organization and Business Description**

United
Therapeutics Corporation is a biotechnology company focused on the development
and commercialization of unique products to address the unmet medical needs of
patients with chronic and life-threatening cardiovascular and infectious
diseases and cancer. We were incorporated in 1996 under the laws of the State
of Delaware and have the following wholly-owned subsidiaries: Lung Rx, Inc.,
Unither Pharmaceuticals, Inc., Unither Telmed, Ltd., Unither.com, Inc.,
United Therapeutics Europe, Ltd., Unither Therapeutik GmbH, Unither
Pharma, Inc., Medicomp, Inc., Unither Neurosciences, Inc.,
LungRx Limited, Unither Biotech Inc., and Unither Virology, LLC. As
used in these notes to the consolidated financial statements, unless the
context otherwise requires, the terms “we,” “us,” “our,” and similar terms
refer to United Therapeutics Corporation and its consolidated subsidiaries.

Our lead
product is Remodulin ® (treprostinil
sodium) Injection (Remodulin). Remodulin was first approved in 2002 by the
United States Food and Drug Administration (FDA) for use as a continuous
subcutaneous infusion for the treatment of pulmonary arterial hypertension
(PAH). Since 2002, the FDA has expanded its approval of Remodulin for
intravenous use and for the treatment of patients who require transition from
Flolan ® . Remodulin
is also approved for use in countries outside of the United States,
predominantly for subcutaneous administration.

We have
generated pharmaceutical revenues from sales of Remodulin and license fees in
the United States, Canada, the European Union (EU), South America and Asia. In
addition, we have generated non-pharmaceutical revenues from telemedicine
products and services in the United States.

**2\. Basis
of Presentation**

The
accompanying unaudited consolidated financial statements have been prepared in
accordance with the rules and regulations of the United States Securities
and Exchange Commission (SEC) for interim financial information. Accordingly,
they do not include all of the information and footnotes required by United
States generally accepted accounting principles (GAAP) for complete financial
statements. These consolidated financial statements should be read in
conjunction with the audited consolidated financial statements and the notes
thereto contained in our Annual Report on Form 10-K for the year ended December 31,
2008, as filed with the SEC on February 26, 2009. The financial statements
of the prior periods presented in this Quarterly Report on Form 10-Q have been
adjusted for the retrospective adoption of FSP APB 14-1 on January 1,
2009\. See Note 8 to these
consolidated financial statements for further discussion.

In our management’s
opinion, the accompanying consolidated financial statements contain all
adjustments, including normal recurring adjustments, necessary to fairly
present our financial position as of March 31, 2009, and our results of
operations and cash flows for the three months ended March 31, 2009 and
2008\. Interim results are not necessarily indicative of results for an entire
year.

**3\. Inventories**

Inventories are stated at the lower of cost
(first-in, first-out method) or market (current replacement cost) and consist
of the following, net of reserves (in thousands):

| | |**March 31,  
2009** | |**December 31,  
2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|Remodulin: | | | | | |
|Raw materials | |$ |3,786 | |$ |3,387 | |
|Work-in-progress | |7,547 | |6,558 | |
|Finished goods | |3,532 | |4,085 | |
|Remodulin delivery pumps and medical
supplies | |194 | |194 | |
|Cardiac monitoring equipment components and
supplies | |47 | |148 | |
|Total inventories | |$ |15,106 | |$ |14,372 | |

**4\.
Fair Value Measurements**

FASB’s
Statement of Financial Accounting Standards (SFAS) No. 157, _Fair Value Measurements_ (SFAS 157), defines fair value,
establishes a fair value hierarchy for assets and liabilities measured at fair
value and requires expanded disclosures about fair

6

* * *  
Table of Contents

value measurements. The
SFAS 157 hierarchy ranks the quality and reliability of inputs, or assumptions,
used in the determination of fair value and requires assets and liabilities
carried at fair value to be classified and disclosed in one of the following
categories based on the lowest level input that is significant to a fair value
measurement:

Level 1—Fair value is determined by using unadjusted quoted prices
that are available in active markets for identical assets and liabilities.

Level 2—Fair
value is determined by using inputs other than Level 1 quoted prices that
are directly or indirectly observable.

Level 3—Fair
value is determined by inputs that are unobservable and not corroborated by
market data.

Financial
assets and liabilities subject to fair value measurements are as follows (in
thousands):

| | |**As of March 31, 2009** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Level 1** | |**Level 2** | |**Level 3** | |**Balance** | |
|Assets | | | | | | | | | |
|Auction-rate securities(1) | |$ |— | |$ |— | |$ |27,838 | |$ |27,838 | |
|Auction-rate securities Put Option(2) | |— | |— | |8,177 | |8,177 | |
|Equity securities | |76 | |— | |— | |76 | |
|Money market funds(3) | |86,021 | |— | |— | |86,021 | |
|Federally-sponsored and corporate debt
securities(4) | |— | |219,842 | |— | |219,842 | |
|Total Assets | |$ |86,097 | |$ |219,842 | |$ |36,015 | |$ |341,954 | |
|Liabilities | | | | | | | | | |
|Convertible Senior Notes | |$ |261,539 | |$ |— | |$ |— | |$ |261,539 | |

* * *

(1) Included
in non-current marketable investments on the accompanying consolidated balance
sheet. The fair value of our auction-rate securities has been estimated using
both a discounted cash flow (DCF) analysis and a market comparables method — i.e.,
an analysis of the pricing relative to current secondary market sales
transactions. Both methods have been given equal weight in estimating the fair
value of our auction-rate securities. The key assumptions to the DCF model are
subjective and include the following: a reference, or benchmark, rate of
interest based on the London Interbank Offered Rate (LIBOR), the amounts and
timing of cash flows, and the weighted average expected life of a security and
its underlying collateral. In addition, the model considers the risks associated
with the creditworthiness of the issuer, the quality of the collateral
underlying the investment and illiquidity. The benchmark interest rate is then
adjusted upward depending on the degree of risk associated with each security
within our auction-rate securities portfolio. We have estimated the illiquidity
premium based on an analysis of the average discounts relating to sales of
comparable auction-rate securities within the secondary market.

(2) Included
within other non-current assets on the accompanying consolidated balance sheet.
We employ a DCF model to estimate the fair value of the Put Option. Key
assumptions used in the DCF model are judgmental and include: (i) a
discount factor equal to the rate of interest consistent with the expected term
of the Put Option and risk profile of the investment firm subject to the Put
Option; (ii) the amount and timing of expected cash flows; (iii) the
expected life of the Put Option prior to its exercise; and (iv) assumed
loan amounts (see the section below entitled _Auction-Rate
Securities_ for further information regarding the Put Option).

(3) Included
in cash and cash equivalents and marketable investments and cash—restricted on
the accompanying consolidated balance sheet.

(4) Included
in current and non-current marketable investments on the accompanying
consolidated balance sheet.

7

* * *  
Table of Contents

A
reconciliation of the beginning and ending balances of assets measured at fair
value using significant unobservable inputs (Level 3) for the three months
ended March 31, 2009, is presented below (in thousands):

| | |**Auction-rate  
Securities** | |**Auction-rate  
Securities Put  
Option** | |**Total** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Balance January 1, 2009 | |$ |27,976 | |$ |7,685 | |$ |35,661 | |
|Transfers to (from) Level 3 | |— | |— | |— | |
|Total gains/(losses) realized/unrealized
included in earnings(1) | |(138 |) |492 | |354 | |
|Total gains/(losses) included in other
comprehensive income | |— | |— | |— | |
|Purchases/issuances/settlements, net | |— | |— | |— | |
|Balance March 31, 2009 | |$ |27,838 | |$ |8,177 | |$ |36,015 | |

* * *

(1) Includes
a net gain of $354,000 for the three months ended March 31, 2009,
attributable to the change in unrealized losses from securities still held at March 31,
2009 (recognized within other income on the consolidated statement of
operations).

**_Auction-Rate
Securities_**

Our marketable
investments include AAA-rated, auction-rate securities (ARS) collateralized by
student loans that are approximately 91% guaranteed by the federal government.
Since February 2008, the ARS have been rendered illiquid as a result of
the collapse of the credit markets. To mitigate the risks associated with our ARS,
we entered into an Auction Rate Securities Rights Offer (Rights Offer) in the
fourth quarter of 2008, with the investment firm that maintains our ARS
account. Pursuant to the Rights Offer, we can sell our ARS to the investment
firm for a price equal to their par value (approximately $36.8 million) at
any time between June 30, 2010 and July 2, 2012 (Put Option). To help
meet any immediate liquidity needs, the Rights Offer also provides that we can
borrow up to the par value of the ARS; however, we do not expect to borrow
against the value of the ARS.

The Put Option
represents a freestanding, non-transferable financial instrument that is being
accounted for under the fair value option set forth in SFAS No.159, _The Fair Value Option for Financial Assets and
Financial Liabilities—Including an amendment of FASB Statement No.115_ (SFAS 159). Under SFAS 159, all changes in fair value of the Put
Option will be recognized within earnings. For the three months ended March 31,
2009, we recognized a gain of $492,000 related to the Put Option, which has
been included in other income on the consolidated statement of operations.
Since there is not an observable market for the Put Option, its fair value has
been estimated using significant unobservable inputs, as noted above.
Accordingly, the fair value of the Put Option has been included as a
Level 3 asset within the SFAS 157 hierarchy.

**5\.
Goodwill and Other Intangible Assets**

Goodwill and
other intangible assets comprise the following (in thousands):

| | |**As of March 31, 2009** | |**As of December 31, 2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |
|Goodwill | |$ |7,465 | |$ |— | |$ |7,465 | |$ |7,465 | |$ |— | |$ |7,465 | |
|Other intangible assets: | | | | | | | | | | | | | |
|Technology and patents | |4,532 | |(4,197 |) |335 | |4,532 | |(4,159 |) |373 | |
|Total | |$ |11,997 | |$ |(4,197 |) |$ |7,800 | |$ |11,997 | |$ |(4,159 |) |$ |7,838 | |

8

* * *  
Table of Contents

**6\. Supplemental
Executive Retirement Plan**

We maintain a supplemental
executive retirement plan (SERP) that is administered by the Compensation
Committee of our Board of Directors (the Board). The SERP is open to members of
a “select group of management or highly compensated employees” within the
meaning of ERISA section 201(2).

In connection with the
SERP, we maintain the United Therapeutics Corporation Supplemental Executive
Retirement Plan Rabbi Trust Document (Rabbi Trust) entered into with the
Wilmington Trust Company. The balance in the Rabbi Trust was approximately $5.1
million as of March 31, 2009 and December 31, 2008.  The Rabbi Trust is irrevocable and SERP
participants will have no preferred claim on, nor any beneficial ownership
interest in, any assets of the Rabbi Trust. 
The investments in the Rabbi Trust are classified as restricted
marketable investments and cash on our consolidated balance sheets.

The table
below discloses the components of the periodic benefit cost (in thousands):

| | |**Three Months  
Ended March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Service cost | |$ |661 | |$ |666 | |
|Interest cost | |139 | |96 | |
|Prior period service cost | |36 | |37 | |
|Net periodic benefit cost | |$ |836 | |$ |799 | |

**7\.
Share Tracking Awards Plan**

In June 2008,
our Board adopted the United Therapeutics Corporation Share Tracking Awards
Plan (STAP). Awards granted under the STAP (Awards) convey the right to receive
an amount in cash equal to the appreciation in our common stock, which is
calculated as the positive difference between the closing price of our common
stock on the date of grant and the date of exercise (the Appreciation). Awards
generally vest in one-third increments on each of the first three anniversaries
of the date of grant and expire on the tenth anniversary of the date of grant.
Upon the exercise of a vested Award, participants are entitled to receive the
Appreciation in cash. The STAP does not permit Awards to be settled through the
issuance of our common stock.

We account for
outstanding Awards as a liability pursuant to FASB Statement No. 123
(revised 2004), _Share-Based Payment_ (SFAS 123R),
due to their cash-settlement provision. Accordingly, we estimate the fair value
of the Awards using the Black-Scholes-Merton valuation model and re-measure the
fair value of outstanding Awards at each quarterly reporting date until
settlement occurs or Awards are otherwise no longer outstanding. As of March 31,
2009, the STAP liability balance was approximately $13.2 million and has
been included in other current liabilities.

In estimating
the fair value of Awards, we are required to use subjective assumptions that
can materially impact fair value measurements and the resulting compensation
expense recognized. These assumptions include the expected volatility of the
price of our common stock, the risk-free interest rate, the expected term of
Awards, the expected forfeiture rate and the expected dividend yield.

9

* * *  
Table of Contents

The table
below presents the assumptions used to re-measure the fair value of Awards at March 31,
2009:

|Expected volatility | |48\.6 |% |
| --- | --- | --- | --- |
|Risk-free interest rate | |2\.7 |% |
|Expected term of Awards (in years) | |5\.8 | |
|Forfeiture rate | |7\.7 |% |
|Expected dividend | |0\.0 |% |

A summary of
the status and activity of the STAP is presented below:

| | |**Number of  
Awards** | |**Weighted-  
Average  
Exercise  
Price** | |**Weighted  
Average  
Remaining  
Contractual  
Term  
(Years)** | |**Aggregate  
Intrinsic  
Value  
(in 000s)** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Outstanding at January 1, 2009 | |1,811,498 | |$ |50\.64 | | | | | |
|Granted | |1,041,365 | |65\.83 | | | | | |
|Exercised | |— | |— | | | | | |
|Forfeited | |(10,551 |) |50\.90 | | | | | |
|Outstanding at March 31, 2009 | |2,842,312 | |$ |56\.20 | |9\.6 | |$ |28,301 | |
|Awards exercisable at March 31, 2009 | |— | |$ |— | |— | |$ |— | |
|Awards expected to vest at March 31,
2009 | |2,659,742 | |$ |56\.19 | |9\.6 | |$ |26,516 | |

The weighted
average fair value of Awards granted during the three months ended March 31,
2009, was $34.32.

Share-based
compensation expense relating to the STAP is as follows (in thousands):

| | |**Three Months  
Ended  
March 31, 2009** | |
| --- | --- | --- | --- | --- |
|Cost of service sales | |$ |11 | |
|Research and development | |1,987 | |
|Selling, general and administrative | |2,568 | |
|Share-based compensation expense before
taxes | |4,566 | |
|Related income tax benefits | |(1,552 |) |
|Share-based compensation expense, net of
taxes | |$ |3,014 | |
|Total share-based compensation expense
capitalized in inventory | |$ |138 | |

**8\.
Debt**

**_Convertible Senior
Notes_**

On October 30,
2006, we issued at par value $250.0 million of 0.50% Convertible Senior
Notes due October 2011 (Convertible Senior Notes). We pay interest on the
Convertible Senior Notes semi-annually on April 15 and October 15 of
each year. The Convertible Senior Notes are unsecured, unsubordinated
obligations that rank equally with all of our other unsecured and
unsubordinated indebtedness. The initial conversion price is $75.2257 per share
and the number of shares on which the aggregate consideration is to be
determined upon conversion is approximately 3,323,332 shares. Conversion can
occur: (i) anytime after July 15, 2011; (ii) during any calendar
quarter that follows a calendar quarter in which the price of our common stock
exceeded 120% of the initial conversion price for at least 20 days during
the 30 consecutive trading day period ending on the last trading day of the quarter;
and (iii) during the ten consecutive trading-day period following any five
consecutive trading day period in which the trading price of the Convertible
Senior Notes was less than 95% of the closing price of our common stock
multiplied by the then current conversion rate; or (iv) upon specified
distributions to our shareholders, corporate transactions, or in the event that
our common stock ceases to be listed on the NASDAQ Global Select Market
(NASDAQ) and is not listed for trading on another U.S. national or regional
securities exchange.

10

* * *  
Table of Contents

Upon
conversion, a holder of our Convertible Senior Notes will receive: (i) cash
equal to the lesser of the principal amount of the note or the conversion value
(equal to the number of shares underlying the Convertible Senior Notes
multiplied by the then current conversion price per share); and (ii) to
the extent the conversion value exceeds the principal amount of the Convertible
Senior Notes, shares of our common stock. In the event of a change in control,
as defined in the indenture under which the Convertible Senior Notes have been
issued, holders may require us to purchase all or a portion of their
Convertible Senior Notes for 100% of the principal plus accrued and unpaid
interest, if any. As of March 31, 2009, the conversion value of the
Convertible Senior Notes did not exceed their principal value.

**_Adoption of FSP APB 14-1_**

On January 1,
2009, we adopted FSP APB 14-1, which applies to certain convertible
debt instruments that may be settled in cash or other assets, or partially in
cash, upon conversion. Issuers of such instruments are required under FSP
APB 14-1 to account for their liability and equity components separately
in a manner that reflects the issuer’s nonconvertible debt borrowing rate when
interest expense is subsequently recognized . FSP APB 14-1 requires
retrospective application. Accordingly, the accompanying prior period
consolidated financial statements have been adjusted to reflect the adoption of
FSP APB 14-1.

The
Convertible Senior Notes fall within the scope of FSP APB 14-1 because their
terms include partial cash settlement. Pursuant to FSP APB 14-1, we are
accounting for the debt and conversion components of the Convertible Senior
Notes separately. As such, we estimated the fair value of the Convertible
Senior Notes without the conversion feature as of the date of issuance
(Liability Component). The estimated fair value of the Liability Component was
approximately $177.6 million and was determined using a discounted cash flow
approach. Key inputs used to estimate the fair value of the Liability Component
included the following:

· Our estimated non-convertible
borrowing rate as of October 2006—the date the Convertible Senior Notes
were issued;

· The amount and timing of cash flows;
and

· The expected life.

The excess of
the proceeds received over the estimated fair value of the Liability Component
totaling $72.4 million was allocated to the conversion feature (Equity
Component) and a corresponding offset was recognized as a discount to reduce
the net carrying value of the Convertible Senior Notes. The discount is being
amortized to interest expense over a five-year period ending October 2011
(the expected life of the Liability Component) using the interest method and an
effective rate of interest of 7.5%.

Interest
expense associated with the Convertible Senior Notes consisted of the following
(in thousands):

|**Three Months Ended March 31,** | |**2009** | |**2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|Contractual coupon rate of interest | |$ |312 | |$ |312 | |
|Discount amortization | |3,544 | |3,291 | |
|Interest expense—Convertible Senior Notes | |$ |3,856 | |$ |3,603 | |

Amounts
comprising the carrying amount of the Convertible Senior Notes are as follows
(in thousands):

| | |**March 31,  
2009** | |**December 31,  
2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|Principal balance | |$ |249,978 | |$ |249,978 | |
|Discount, net of accumulated amortization
of $31,661 and $28,117 | |(40,743 |) |(44,287 |) |
|Carrying amount | |$ |209,235 | |$ |205,691 | |

11

* * *  
Table of Contents

The impact of
the adoption of FSP APB 14-1 on the results of operations for the three-month
periods ended March 31, 2009 and 2008 is presented below (in thousands,
except for per share data):

| | |**Three Months Ended March 31, 2009** | |**Three Months Ended March 31, 2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Before the  
Impact of FSP  
APB 14-1** | |**Incremental  
Impact of  
Adoption of  
FSP APB 14-1** | |**As Reported** | |**As  
Previously  
Reported** | |**Incremental  
Impact of  
Adoption of  
FSP APB 14-1** | |**As Adjusted** | |
|Interest expense | |$ |— | |(2,637 |) |$ |(2,637 |) |$ |(108 |) |(2,684 |) |$ |(2,792 |) |
|Income tax expense | |(7,696 |) |897 | |(6,799 |) |(6,554 |) |1,217 | |(5,337 |) |
|Net income | |14,937 | |(1,740 |) | |13,197 | |11,403 | |(1,467 |) |9,936 | |
|Earnings per share: | | | | | | | | | | | | | |
|Basic | |$ |0\.56 | |$ |(0.06 |) |$ |0\.50 | |$ |0\.51 | |$ |(0.07 |) |$ |0\.44 | |
|Diluted | |$ |0\.55 | |$ |(0.06 |) |$ |0\.49 | |$ |0\.47 | |$ |(0.06 |) |$ |0\.41 | |

The impact of
the adoption of FSP APB 14-1 on balance sheet line items as of December 31,
2008, is presented below (in thousands):

| | |**December 31, 2008** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**As Previously  
Reported** | |**Incremental  
Impact of  
Adoption of  
FSP APB 14-1** | |**As Adjusted** | |
|Property, plant and equipment, net | |$ |221,066 | |$ |1,651 |(1) |$ |222,717 | |
|Deferred tax assets | |175,969 | |1,690 | |177,659 | |
|Other non-current assets | |22,974 | |(1,307 |) |21,667 | |
|Total | |$ |420,009 | |$ |2,034 | |$ |422,043 | |
| | | | | | | | |
|Accrued expenses and other current
liabilities | |$ |37,492 | |$ |(388 |) |$ |37,104 | |
|Notes payable, net | |249,978 | |(44,287 |) |205,691 | |
|Total | |$ |287,470 | |$ |(44,675 |) |$ |242,795 | |
| | | | | | | | |
|Additional paid-in capital | |$ |659,245 | |$ |61,169 | |$ |720,414 | |
|Accumulated deficit | |(78,514 |) |(14,460 |) |(92,974 |) |
|Total | |$ |580,731 | |$ |46,709 | |$ |627,440 | |

* * *

(1) Additional
capitalized interest relating to our construction projects in Maryland and
North Carolina resulting from the incremental interest expense recognized upon
the retrospective adoption of FSP APB 14-1.

**_Call Spread Option_**

Concurrent
with the issuance of the Convertible Senior Notes, we purchased call options on
our common stock in a private transaction with Deutsche Bank AG London (Call
Option). The Call Option allows us to purchase up to approximately
3\.3 million shares of our common stock at $75.2257 per share from Deutsche
Bank AG London, equal to the amount of our common stock related to the
conversion value that we could deliver to Note Holders upon conversion. We must
issue shares of our common stock upon conversion of the Convertible Senior
Notes once our stock price exceeds $75.2257 per share. The Call Option will
terminate upon the earlier of the maturity date of the Convertible Senior Notes
or the first day all of the Convertible Senior Notes are no longer outstanding
due to conversion or otherwise. We paid approximately $80.8 million for
the Call Option, which was recorded as a reduction to additional
paid-in-capital.

In a separate
transaction that took place concurrently with the issuance of the Convertible
Senior Notes, we sold warrants to Deutsche Bank AG London under which Deutsche
Bank AG London has the right to purchase approximately 3.3 million shares
of our common stock at an exercise price of $105.689 per share (Warrant).
Proceeds received from the Warrant totaled approximately $45.4 million and
were recorded as additional paid-in-capital.

The
combination of the Call Option and Warrant effectively reduces the potential
dilutive impact of the Convertible Senior Notes. The Call Option has a strike
price equal to the initial conversion price of the Convertible Senior Notes and
the Warrant has a higher strike price of $105.689 per share that caps the
amount of dilution protection provided. The Call Option and Warrant are settled
on a net share basis. The Warrant may be settled in registered or unregistered
shares, subject to certain potential adjustments in the

12

* * *  
Table of Contents

delivery amount. Furthermore,
if additional shares are required to be delivered with respect to a settlement
in unregistered shares or any anti-dilution adjustments with respect to the
Convertible Senior Notes, the Warrant provides that in no event shall we be
required to deliver more than approximately 6.6 million shares in
connection with the Warrant. We have reserved approximately 6.6 million
shares for the settlement of the Warrant and have sufficient shares available
as of March 31, 2009, to effect such settlement.

Deutsche Bank
AG London is responsible for providing 100% of the shares of our common stock
upon an exercise of the Call Option triggered by a Convertible Senior Note holder’s
conversion. The shares of our common stock that Deutsche Bank AG London will
deliver must be obtained from existing shareholders. If the market price per
share of our common stock is above $105.689 per share, we will be required to
deliver to Deutsche Bank AG London shares of our common stock representing the
value in excess of the Warrant strike price. In accordance with the provisions
of EITF Issue No. 00-19, _Accounting for
Derivative Financial Instruments Indexed to, and Potentially Settled in, a
Company’s Own Stock_ (EITF 00-19) and SFAS No. 133, _Accounting for Derivatives
and Hedging Activities_ (SFAS 133),
these instruments are both indexed to our common stock and classified as
equity; therefore, the Call Option and Warrant qualify for the scope exception
under SFAS 133 and are not accounted for as derivative instruments.

**_Interest Expense_**

Details of
interest expense are presented below (in thousands):

| | |**Three Months  
Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Interest expense | |$ |4,713 | |$ |3,393 | |
|Capitalized interest(1) | |(2,076 |) |(601 |) |
|Total | |$ |2,637 | |$ |2,792 | |

* * *

(1)           Interest
associated with the construction of our facilities in Maryland and North
Carolina.

**9\.  Lease
Obligation**

We currently
lease a laboratory facility in Silver Spring, Maryland (Phase I
Laboratory), pursuant to a synthetic lease arrangement (Lease) entered into in June 2004
with Wachovia Development Corporation and its affiliates (Wachovia). Under the
Lease, Wachovia funded $32.0 million toward the construction of the
Phase I Laboratory on land we own. Subsequent to the completion of
construction in May 2006, Wachovia leased the Phase I Laboratory to
us. Monthly rent is equal to the 30-day LIBOR plus 55 basis points (1.1% as of March 31,
2009) applied to the amount Wachovia funded toward construction. The base term
of the Lease ends in May 2011 (Base Term). Upon the end of the Base Term,
we will have the right to exercise one of the following options under the
Lease: (1) renew the lease for an additional five-year term (subject to
the approval of both parties); (2) purchase the Phase I Laboratory
from Wachovia for approximately $32.0 million; or (3) sell the
Phase I Laboratory and repay Wachovia’s construction costs with the
proceeds from the sale. If the sale proceeds are insufficient to repay Wachovia’s
construction costs, we must fund the shortfall up to the maximum residual value
guarantee of approximately $27.5 million. From the inception of the Lease
through August 2008, we accounted for the Lease as an off-balance sheet
arrangement — i.e., an operating lease.

Since December 2007,
we have been constructing a combination office and laboratory facility that
will attach to the Phase I Laboratory (Phase II Facility) with funds
generated from our operations. As of September 30, 2008, we received
Wachovia’s acknowledgement of our plan to make structural modifications to the
Phase I Laboratory in order to connect it to the Phase II Facility.
As a result, we could no longer consider the Phase I Laboratory a
standalone structure, which was required to maintain off-balance sheet
accounting for the Lease. Consequently, as of September 30, 2008, we were
considered the owners of the Phase I Laboratory for accounting
purposes.  Furthermore, because the Lease
does not meet criteria set forth in EITF Issue No. 97-10, _The Effect of Lessee Involvement in Asset
Construction,_ and FASB Statement No. 98, _Accounting for Leases_ , we are accounting
for the Lease as a financing obligation. Accordingly, we capitalized
$29.0 million, the estimated fair value of the Phase I Laboratory,
and recognized a corresponding lease obligation on our consolidated balance
sheet. We are accreting the lease obligation to $32.0 million, the
purchase price of the Phase I Laboratory, through the recognition of
periodic interest charges using the effective interest method. The accretion
period will run through the end of the Base Term. Related interest charges for
the three months ended March 31, 2009, were approximately $263,000. In
addition, we are depreciating the Phase I Laboratory over its estimated useful
life.

13

* * *  
Table of Contents

**10\. Stockholders’ Equity**

**_Earnings per share_**

Basic earnings
per share is computed by dividing net income by the weighted average number of
shares of common stock outstanding during the period. Diluted earnings per
common share is computed by dividing net income by the weighted average number
of shares of common stock outstanding during the period, plus the potential
dilutive effect of other securities if such securities were converted or
exercised.

The components
of basic and diluted earnings per share were as follows (in thousands, except
per share amounts):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
| | | | |**(As Adjusted)** | |
|Net income (Numerator) | |$ |13,197 | |$ |9,936 | |
|Shares (Denominator): | | | | | |
|Weighted average outstanding shares for
basic EPS | |26,440 | |22,333 | |
|Effect of dilutive securities: | | | | | |
|Convertible Senior Notes(1) | |— | |467 | |
|Dilutive effect of stock options(2) | |712 | |1,276 | |
|Adjusted weighted average shares for
diluted EPS | |27,152 | |24,076 | |
|Earnings per share: | | | | | |
|Basic | |$ |0\.50 | |$ |0\.44 | |
|Diluted | |$ |0\.49 | |$ |0\.41 | |
|Stock options and warrants excluded from
calculation(3) | |3,924 | |4,440 | |

* * *

(1) Pursuant to FASB Statement No. 128, _Earnings per Share_ , and related guidance, we cannot consider
the impact of shares that we have the right to receive under the terms of the
Call Option (see _Note 8: Debt — Call Spread Option_ to these consolidated financial statements) in the calculation of diluted
earnings per share as their impact would be anti-dilutive. As of March 31,
2009 and 2008, we would have been entitled to receive none and 467,000 shares
of our common stock, respectively, under the Call Option, which would have
offset the dilutive effect of the Convertible Senior Notes. Under the Call
Option Deutsche Bank AG London is required to purchase shares of our common
stock from the open market.

(2) Calculated
using the treasury stock method.

(3) Certain
stock options and warrants were excluded from the computation of diluted
earnings per share because their impact would be anti-dilutive.

**_Stock
Option Plan_**

We account for
stock option awards in accordance with SFAS 123R, as interpreted by Staff
Accounting Bulletins Nos. 107 and 110 issued by the SEC. Accordingly, we
utilize the Black-Scholes-Merton valuation model for estimating the fair value
of stock option awards as of their grant dates. Option valuation models,
including Black-Scholes-Merton, require the input of subjective assumptions.
Changes in these assumptions can materially affect the grant date fair value of
an award. There were no stock options granted during the three-months ended March 31,
2009\.

14

* * *  
Table of Contents

A summary of
the status and activity of employee stock options is presented below:

| | |**Number of  
Shares** | |**Weighted-  
Average  
Exercise  
Price** | |**Weighted  
Average  
Remaining  
Contractual  
Term  
(Years)** | |**Aggregate  
Intrinsic  
Value  
(in 000s)** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Outstanding at January 1, 2009 | |4,586,691 | |$ |54\.75 | | | | | |
|Granted | |— | |— | | | | | |
|Exercised | |(20,221 |) |42\.35 | | | | | |
|Forfeited | |(8,974 |) |62\.03 | | | | | |
|Outstanding at March 31, 2009 | |4,557,496 | |$ |54\.79 | |6\.7 | |$ |54,431 | |
|Options exercisable at March 31, 2009 | |2,506,226 | |$ |50\.10 | |5\.6 | |$ |42,827 | |
|Expected to vest at March 31, 2009 | |1,980,118 | |$ |62\.52 | |8\.1 | |$ |11,061 | |

Total employee stock
option expense recognized for the three-month periods ended March 31, 2009
and 2008, is as follows (in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Cost of service sales | |$ |13 | |$ |15 | |
|Research and development | |2,669 | |2,669 | |
|Selling, general and administrative | |6,807 | |3,608 | |
|Share-based compensation expense before
taxes | |9,489 | |6,292 | |
|Related income tax benefits | |(3,226 |) |(2,328 |) |
|Total stock option expense, net of taxes | |$ |6,263 | |$ |3,964 | |
|Total stock option expense capitalized in
inventory | |$ |226 | |$ |195 | |

Information regarding
both employee and non-employee exercises is summarized below (dollars in
thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Number of options exercised | |20,221 | |235,317 | |
|Cash received for stock option exercises | |$ |856 | |$ |8,566 | |

**11\. Comprehensive Income**

Comprehensive income comprised the following
(in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Net income | |$ |13,197 | |$ |9,936 | |
|Other comprehensive income: | | | | | |
|Foreign currency translation loss | |(904 |) |(150 |) |
|Unrecognized prior period service cost, net
of tax of $14 and $284, respectively | |22 | |(484 |) |
|Unrecognized actuarial pension loss, net of
tax of none and $133, respectively | |— | |(227 |) |
|Unrealized loss on available-for-sale
securities, net of tax of $7 and $641, respectively | |(13 |) |(1,116 |) |
|Comprehensive loss | |$ |12,302 | |$ |7,959 | |

15

* * *  
Table of Contents

**12\. Income Taxes**

Income tax expense for
the three-month periods ended March 31, 2009 and 2008, is based on the
estimated annual effective tax rate for the entire year. The estimated annual
effective tax rate is subject to adjustment in subsequent quarterly periods as
estimates of pretax income for the year are revised. The effective tax rates
for the three-month periods ended March 31, 2009 and 2008, were
approximately 34 percent and 35 percent, respectively.

As of March 31,
2009, we had available for federal income tax purposes approximately $50.3
million in business tax credit carryforwards. These carryforwards expire at
various dates through 2028. Certain business tax credit carryforwards that were
generated prior to December 2007 may be subject to limitations on their
use pursuant to Internal Revenue Code Section 382 as a result of ownership
changes as defined therein. However, we do not expect these that these business
tax credits will expire unused.

We file U.S. federal
income tax returns and various state and foreign income tax returns. All of our
U.S. federal income tax returns remain open for examination since we have not
utilized any of our business credits. State jurisdictions that remain subject
to examination relate to our filings for the years 2005 through 2007. We are
unaware of any uncertain tax positions for which it is reasonably possible that
the total amounts of unrecognized tax benefits would significantly increase or
decrease within the next 12 months.

**13\. Segment Information**

We have two reportable
business segments: pharmaceutical and telemedicine.  The pharmaceutical segment includes all
activities associated with the research, development, manufacturing and
commercialization of our therapeutic products. The telemedicine segment
includes all activities associated with the development and manufacturing of
patient monitoring products and the delivery of patient monitoring services.
The telemedicine segment is managed separately because diagnostic services
require different technologies and marketing strategies than therapeutic
products.

Segment information as
of and for the three-month periods ended March 31, 2009 and 2008, is
presented below (in thousands):

| | |**As of and for the three months ended March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from external customers | |$ |77,160 | |$ |2,570 | |$ |79,730 | |$ |59,756 | |$ |2,291 | |$ |62,047 | |
|Income before income tax | |20,136 | |(140 |) |19,996 | |15,081 | |192 | |15,273 | |
|Total assets | |884,628 | |18,185 | |902,813 | |624,605 | |12,294 | |636,899 | |

When combined, the
segment information above agrees with the totals reported in the consolidated
financial statements.  There are no
inter-segment transactions.

For the three-month
periods ended March 31, 2009 and 2008, revenues from our three
distributors based in the United States represented approximately 86 percent
and 85 percent, respectively, of our total net revenues.

16

* * *  
Table of Contents

**Item 2.** **MANAGEMENT’S DISCUSSION
AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS**

The following discussion
should be read in conjunction with our Annual Report on Form 10-K for the
year ended December 31, 2008, and the consolidated financial statements
and accompanying notes included elsewhere in this Quarterly Report on Form 10-Q.
The following discussion contains forward-looking statements made pursuant to
the safe harbor provisions of Section 21E of the Securities Exchange Act
of 1934 and the Private Securities Litigation Reform Act of 1995, including the
statements listed in the section entitled _Part II,
Item 1A—Risk Factors_ , below. These statements are based on our
beliefs and expectations about future outcomes and are subject to risks and
uncertainties that could cause our actual results to differ materially from
anticipated results. Factors that could cause or contribute to such differences
include those described under the section entitled _, Risk
Factors_ , in Part II of this Quarterly Report on Form 10-Q;
factors described in our Annual Report on Form 10-K for the year ended December 31,
2008, under the section entitled _Part I, Item 1A—Risk
Factors—Forward-Looking Statements_ ; and
factors described in other cautionary statements, cautionary language and risk
factors set forth in other filings with the Securities and Exchange Commission
(SEC). We undertake no obligation to publicly update these forward-looking
statements, whether as a result of new information, future events or otherwise.

**Overview**

We are a
biotechnology company focused on the development and commercialization of
unique products to address the unmet medical needs of patients with chronic and
life-threatening cardiovascular and infectious diseases and cancer. Since our
inception in June 1996, we have devoted a significant amount of our
resources to research and development programs and acquisitions.

Our key
therapeutic platforms include:

· Prostacyclin analogues: stable
synthetic forms of prostacyclin, an important molecule produced by the body
that has powerful effects on blood vessel health and function;

· Phosphodiesterase 5 (PDE5)
inhibitors: molecules that act to inhibit the degradation of cyclic guanosine
monophosphate (cGMP) in cells. cGMP is activated by nitric oxide (NO), a
naturally occurring substance in the body that mediates the relaxation of
vascular smooth muscle;

· Monoclonal antibodies: antibodies
that activate patients’ immune systems to treat cancer; and

· Glycobiology antiviral agents: a
novel class of small, sugar-like molecules that have shown pre-clinical
indications of efficacy against a broad range of viruses.

We focus most
of our resources on these key therapeutic platforms. In addition, we devote
resources to the commercialization and development of telemedicine products and
services, principally for the detection of cardiac arrhythmias (abnormal heart
rhythms).

We began
generating pharmaceutical revenues in 2002 upon receiving approval from the FDA
for our lead product, Remodulin ® (treprostinil sodium) Injection (Remodulin) to
be administered via subcutaneous (under the skin) infusion for the treatment of
pulmonary arterial hypertension (PAH). Since 2002, the FDA has expanded its
approval of Remodulin for intravenous (in the vein) use and for the treatment
of patients who require transition from Flolan ® . In addition to the United States,
Remodulin is approved in many other countries worldwide, primarily for subcutaneous
use. We are also developing both inhaled and oral forms of treprostinil for the
treatment of PAH. To further these initiatives, we filed a New Drug Application
(NDA) with the FDA for our inhaled formulation of treprostinil in June 2008
and a Marketing Authorization Application (MAA) with the European Medicines
Agency (EMEA) for inhaled treprostinil in December 2008. Presently, FDA
and EMEA reviews of inhaled treprostinil are underway. The EMEA granted Orphan
Medicinal Product Designation for inhaled and oral treprostinil for PAH in April 2004
and August 2005, respectively. We are currently conducting several
clinical trials related to oral treprostinil.

**_Revenues_**

We derive
substantially all of our revenues from the sale of Remodulin.

Our sales and
marketing team included approximately 80 employees as of March 31, 2009.
We divide our sales force into two teams. One sales team is primarily
responsible for medical practice accounts that are historical Remodulin
prescribers. The other sales team focuses on medical practices that have not
previously prescribed Remodulin. In addition, our distributors supplement the
efforts of our sales force. The market in which we operate is highly
competitive. The success of our sales force and ultimate sales

17

* * *  
Table of Contents

levels achieved is affected by
the activities of other companies that market and sell competing therapies. It
is our expectation that the competition within our industry will continue to
increase.

Our domestic
distributors, Accredo Therapeutics, Inc. (Accredo), CuraScript, Inc.
(CuraScript), and CVS Caremark Corporation (Caremark), sell Remodulin to
patients in the United States. We also engage various international
distributors to sell Remodulin abroad. Because discontinuation of Remodulin
therapy can be life-threatening, we require that our distributors maintain
minimum contingent inventory levels. Because of this requirement, sales of
Remodulin to our distributors in any given quarter may not be entirely
indicative of patient demand. Our distributors typically place one bulk order
per month in the first half of the month. The size of bulk distributor orders
is based on estimates of future demand and considerations of contractual
minimum inventory requirements. As such, our sales of Remodulin are affected by
the timing and magnitude of these bulk orders by our distributors.

In addition to
revenues derived from sales of Remodulin, we generate revenues from the sale of
telemedicine products and services in the United States. Our telemedicine
products and services are designed to detect cardiac arrhythmias and ischemic
heart disease, a condition that causes poor blood flow to the heart.

**_Expenses_**

Since our
inception, we have devoted substantial resources toward our various research
and development initiatives. Accordingly, we incur considerable costs relating
to our clinical trials and research, conducted both internally and by third
parties, on a variety of projects to develop pharmaceutical therapies. We also
seek to acquire promising technologies and/or compounds from third parties to
be incorporated in our developmental projects and products through licensing
arrangements or acquisitions. Principal components of our operating expenses
consist of research and development, selling, general and administrative, and
cost of both product and service sales.

**Major
Research and Development Projects**

Our major
research and development projects focus on the use of prostacyclin analogues
and PDE5 inhibitors to treat cardiovascular diseases, monoclonal antibodies to
treat a variety of cancers and glycobiology antiviral agents to treat
infectious diseases.

**_Cardiovascular
Disease Projects_**

_Inhaled treprostinil._ We are developing an inhaled formulation of treprostinil sodium for the
treatment of PAH. In November 2007, we completed a Phase III trial of
inhaled treprostinil in patients with PAH who were also being treated with
Tracleer ® , an oral
endothelin receptor antagonist (ERA), or Revatio ® , a PDE5 inhibitor. This trial, TRIUMPH-1
( **TR** eprostinil **I** nhalation **U** sed in the **M** anagement of **P** ulmonary Arterial **H** ypertension), demonstrated a highly
statistically significant improvement in median six-minute walk distance.

Subsequently,
we submitted an NDA in June 2008 to obtain FDA approval to market inhaled
treprostinil in the U.S. The Optineb ® nebulizer, an ultra-sonic portable nebulizer
that was used exclusively for administration of inhaled treprostinil during the
TRIUMPH-1 trial, was submitted for approval as part of this filing. The Optineb
is manufactured exclusively by NEBU-TEC International Med Products Eike
Kern GmbH (NEBU-TEC). The Optineb is CE-marked in Europe, which means that
NEBU-TEC has asserted that the device conforms to European Union health and
safety requirements. In December 2008, we executed an Agreement of Sale
and Transfer and related agreements with NEBU-TEC to acquire the Optineb
business and all its related assets, properties and rights for an aggregate
purchase price of €5.0 million, plus up to €10.0 million in future
contingent consideration. We will not acquire these assets, properties and
rights until the FDA approves of our NDA for inhaled treprostinil.

In December 2008,
we also filed an MAA for inhaled treprostinil with the EMEA using the
centralized filing process. The Optineb was also included as part of our MAA
submission. The duration of a typical review of an NDA by the FDA and an MAA by
the EMEA is approximately 10 to 12 months, but can take significantly longer.

In March 2009,
the FDA notified us that it required human factors testing to validate the
instructions for use (IFU) of the Optineb in order to complete its evaluation
of our inhaled treprostinil NDA. On March 16, 2009, we issued a press release
disclosing this requirement and the likelihood that it would delay the FDA’s
review of our inhaled treprostinil NDA beyond the April 30, 2009, Prescription
Drug User Fee Act (PDUFA) date. We conducted a human factors study that
consisted of a relatively small number of volunteers and assessed whether the
revised IFU properly guided patients to accomplish such tasks as proper device
assembly and disassembly, drug administration and device cleaning. The study
also evaluated the occurrence of common use errors that a new user may
experience. We submitted the findings of this study to the FDA in April 2009,
and on April 28, 2009, the FDA notified us that it will require additional time
to complete its review of our inhaled treprostinil NDA and extended the PDUFA
date to July 30, 2009.  This three-month
extension was triggered by our April 2009 human factors study submission, which
was considered a major amendment to our NDA.

18

* * *  
Table of Contents

In December 2008
we began enrolling patients in an open-label study in the United States to
investigate what occurs when patients on Ventavis ® , the only currently approved
inhaled prostacyclin analogue, are switched to inhaled treprostinil.

_Oral treprostinil._ We are developing an oral formulation of
treprostinil (treprostinil diethanolamine). During the fourth quarter of 2006,
we initiated two clinical trials to evaluate the safety and efficacy of oral
treprostinil in patients with PAH, FREEDOM-C and FREEDOM-M. The FREEDOM-C trial
was a study of patients currently on approved background therapy using a PDE5
inhibitor, such as Revatio ® , or
an ERA, such as Tracleer ® , or a
combination of both. We completed enrollment for the FREEDOM-C trial in May 2008
and subsequently announced top-line results of the FREEDOM-C trial in November 2008.
Preliminary analysis of the data revealed that the trial did not achieve
statistical significance because the initial tablet strength was too high,
resulting in the inability to dose titrate (increase the dose to tolerability),
which, in turn, led to suboptimal dosing and a muting of the overall treatment
effect. Accordingly, the ongoing FREEDOM-M trial, discussed below, was modified
to address dose-tolerability issues by extending enrollment in that study and
providing newly-enrolled patients with the tablet strength that was better
tolerated among patients in the FREEDOM-C trial. We believe that the results of
the FREEDOM-C trial, particularly as they relate to treatment effect and
dosing, warrant the continued development of oral treprostinil. We are planning
a second trial based on FREEDOM-C, FREEDOM-C 2 , to continue studying dosage and efficacy
of oral treprostinil in PAH patients on approved background therapy. We
estimate enrolling 300 patients in the FREEDOM-C 2 trial beginning in mid 2009.

The FREEDOM-M
trial is a 12-week study of newly-diagnosed patients not currently on any
background therapy. Based on what we learned from the FREEDOM-C trial relating
to patient tolerability of our tablet strengths, we submitted a protocol
amendment to the FDA in February 2009 seeking to add 140 patients to the
ongoing FREEDOM-M trial and provide new patients with the 0.25 mg tablet
when they start the trial, which we learned from the FREEDOM-C trial is the
best-tolerated tablet strength. In addition, our amendment to the FREEDOM-M
protocol seeks to limit the primary statistical analysis of the trial to those
patients who started the trial using the 0.25 mg tablet. We believe that
the protocol amendment will allow us to more accurately assess the
effectiveness of oral treprostinil. We hope that by starting all newly added
patients on the 0.25 mg tablets and titrating their doses in 0.25 mg
increments, patients will better tolerate the therapy and reach an effective
maintenance dose. We also anticipate that the protocol amendment will reduce
the rate of premature discontinuation due to adverse events.  In April 2009, we began enrolling patients
under the amended protocol. The statistical assumptions of the amended study
provide for 90% power to observe a 45-meter treatment benefit in the six-minute
walk distance at the significance level of 0.01.  If we are able to successfully implement these
and other amendments to the study, we believe that the results will reflect the
expected dosing regimen for oral treprostinil. As of March 31, 2009, there
were approximately 172 patients enrolled in the FREEDOM-M trial.

_Tadalafil._ In November 2008, we entered into a
license agreement, a manufacturing and supply agreement and a stock purchase
agreement with Eli Lilly and Company (Lilly) to obtain exclusive rights to
develop, market, promote and commercialize the orally administered drug,
tadalafil for pulmonary hypertension. Tadalafil is also the active ingredient
in Cialis ® , which was
developed and is exclusively marketed by Lilly for the treatment of erectile
dysfunction. Pursuant to the license agreement, we paid an upfront fee to Lilly
of $25.0 million for the exclusive rights to commercialize tadalafil for
pulmonary hypertension in the United States and Puerto Rico. Under the
manufacturing and supply agreement, we will purchase tadalafil in finished form
from Lilly, which will manufacture and distribute tadalafil for us through its
wholesaler network. Lilly is also responsible for all aspects of FDA regulatory
review of tadalafil for PAH. Terms of the manufacturing and supply agreement
included an upfront fee of $125.0 million. Because FDA approval for
tadalafil for PAH is pending, the upfront fees paid to Lilly totaling
$150.0 million were charged as research and development expense during the
quarter ended December 31, 2008, as commercial approval had not been
granted. These agreements became effective in December 2008 upon the
issuance of approximately 3.2 million shares of our common stock to Lilly in
exchange for $150.0 million in accordance with the terms of the stock purchase
agreement.

_Beraprost-MR._ We are developing a modified release formulation
of beraprost (beraprost-MR), an oral prostacyclin analogue, for PAH.  In March 2007, we entered into an
amended version of our June 2000 license agreement with Toray Industries, Inc.
(Toray) to expand our rights related to the commercialization of beraprost-MR.
We are currently enrolling patients in a Phase II clinical trial of
beraprost-MR to explore multiple-dose tolerability in patients with PAH.
Additionally, we are planning a Phase III clinical program to evaluate the
efficacy of beraprost-MR for the treatment of PAH. In October 2007,
beraprost-MR received

19

* * *  
Table of Contents

regulatory approval in Japan
for the treatment of PAH, and in July 2008 beraprost-MR was granted Orphan
Medicinal Product Designation by the EMEA. The active ingredient in beraprost
was granted orphan drug designation in the United States in April 1999.

We incurred
expenses of approximately $11.4 million and $14.5 million for the
three-month periods ended March 31, 2009 and 2008, respectively, on our
cardiovascular programs. We have spent approximately $465.3 million from
inception to March 31, 2009, on our cardiovascular programs.

**_Cancer Disease Projects_**

In December 2007,
we entered into two agreements with Memorial Sloan-Kettering Cancer Center to
exclusively license certain rights to two investigational monoclonal antibodies
(3F8 and 8H9) for the treatment of neuroblastoma and metastatic brain
cancer. We have spent approximately $59.9 million from inception to March 31,
2009, on our cancer programs.

**_Infectious Disease
Projects_**

Pursuant to
our research agreement with the University of Oxford, we have the exclusive
right to commercialize miglustat as an antiviral agent for the treatment of all
sugar-coated viruses. Our infectious disease program also includes glycobiology
antiviral drug candidates in various preclinical and clinical stages of testing
for the treatment of a wide variety of viruses. Through our agreement with the
University of Oxford, we are also supporting research into new glycobiology
antiviral drug candidates and technologies. We have spent approximately
$39.1 million from inception to March 31, 2009, on our infectious
disease programs.

**Selling,
General and Administrative Expenses**

Selling,
general and administrative expenses consist primarily of departmental salaries
and related expenses, share-based compensation, travel, office expenses,
insurance, rent and utilities, professional fees, advertising and marketing,
and depreciation and amortization.

**Cost
of Product Sales**

Cost of
product sales comprises costs to manufacture or acquire products sold to
customers. We manufacture treprostinil using advanced intermediate compounds
purchased in bulk from third-party vendors. We utilize multiple vendors that
are capable of manufacturing greater quantities of these compounds less
expensively than we are. We expect to be able to commercially use treprostinil
manufactured in our new Silver Spring, Maryland, facility upon receiving FDA
approval for the facility, which we anticipate during the second quarter of
2009\. Our planned manufacturing process has been designed to give us the
flexibility to produce both treprostinil diethanolamine (the form of
treprostinil used in our oral tablet) and treprostinil sodium efficiently in
proportion to forecasted demand.

In April 2009,
Baxter Healthcare Corporation (Baxter) notified us that it planned to retire
the production line it uses to formulate Remodulin following the October 2010
expiration of the current term of our agreement.  Baxter has subsequently notified us that a
secondary production line might be available to formulate Remodulin and we are
in discussions to continue formulation of Remodulin on the alternative line. In
addition, we are in the process of evaluating alternative supply arrangements,
including the formulation of Remodulin in our combination office and laboratory
facility that we are currently constructing adjacent to our existing laboratory
in Silver Spring, Maryland. We expect to complete the construction of this
facility by the end of 2009. We are also seeking other third-party formulation
arrangements. To provide additional assurance that adequate inventories of
Remodulin will remain on hand at all times, we intend to increase our supply of
formulated Remodulin during 2009 to three years of expected demand and to
submit an application to extend the expiration date for Remodulin from 30
months to 36 months worldwide.  We plan
to maintain this inventory supply level on an ongoing basis.

**Future Prospects**

Our future initiatives
include expanding use of our prostacyclin therapy to include patients at
earlier stages in the PAH disease pathway.

20

* * *  
Table of Contents

Our NDA for inhaled
treprostinil is currently under review by the FDA for marketing approval. If we
are successful in obtaining FDA approval and do not encounter significant
delays in the review process, we could begin to recognize revenues from the
sale of inhaled treprostinil in the second half of 2009. In connection with the
pending commercialization of inhaled treprostinil, we may choose to enter into new
distribution agreements with certain of our specialty distributors worldwide.

In December 2008, we
licensed certain rights from Lilly related to the commercialization of orally
administered tadalafil for the treatment of pulmonary hypertension in the United
States and Puerto Rico. Currently, Lilly is seeking FDA approval for tadalafil
for PAH. If the FDA review process proceeds as anticipated, we could begin to
recognize revenues from the sale of tadalafil during the second half of 2009.

Our trial for our inhaled
formulation of treprostinil was successful and we believe that our FREEDOM-M
and FREEDOM-C 2 trials
of oral treprostinil will also be successful. We expect that the products
developed under these trials will generate future sources of revenue. However,
prior to FDA approval of inhaled and/or oral treprostinil for marketing, we
could be required to perform additional studies. This could cause unanticipated
delays in the commercialization of these products and could impede our
continued rate of revenue growth. However, because PAH is a progressive disease
with no cure, many patients continue to deteriorate on currently-approved oral
and inhaled therapies. This presents market growth opportunities for Remodulin
as a viable alternative or complementary treatment to these therapies.
Furthermore, we believe that the market for Remodulin will continue to expand
as more patients are diagnosed with PAH each year.

Our future growth and
profitability will depend on many factors. These factors include, but are not
limited to, the timing of commercialization of products in the later stages of
development, the selling prices of, and demand for, our products and services,
the degree of reimbursement by public and private insurance organizations, and
the competition we face from others within our industry.

**Financial Position**

Cash,
cash equivalents and marketable investments (excluding all restricted amounts)
at March 31, 2009, were approximately $319.4 million compared to
approximately $336.3 million as of December 31, 2008. The decrease
can be attributed principally to customary variances in the timing of sales and
related cash collections and cash used for our construction projects in
Maryland and North Carolina.

Restricted
cash and marketable investments of $45.9 million at March 31, 2009,
comprise approximately $40.8 million pledged as security for our financing
arrangements related to our Phase I Laboratory and approximately $5.1
million placed in the Rabbi Trust. At December 31, 2008, approximately
$40.7 million was pledged as security for our Phase I Laboratory and
approximately $5.1 million was placed in the Rabbi Trust.

Accounts
receivable was approximately $49.4 million at March 31, 2009, compared to
$28.3 million at December 31, 2008. The increase in accounts receivable
reflects the overall continued growth in sales of Remodulin in addition to
typical variations in the timing and magnitude of sales and associated cash
collections.

Property,
plant and equipment at March 31, 2009, was approximately $255.6 million,
an increase of $32.9 million from $222.7 million at December 31, 2008. The
increase in property, plant and equipment corresponded directly to expenditures
relating to our construction projects in Maryland and North Carolina.
Construction of the North Carolina facility was completed in February 2009
and the Maryland facility is expected to be completed in late 2009.

Accounts
payable decreased by approximately $9.8 million from approximately
$20.3 million at December 31, 2008, to $10.5 million at March 31,
2009\. The decrease in accounts payable can be attributed to the timing of
payments based on our semi-monthly payment cycle and the timing and volume of
contractor invoices related to our construction projects.

Stockholders’
equity was approximately $577.3 million at March 31, 2009, compared to
approximately $554.4 million at December 31, 2008. The increase of
$22.9 million in stockholders’ equity was driven in large part by the
recognition of approximately $9.7 million in stock-option based compensation
and the reduction to the accumulated deficit of approximately $13.2 million,
representing net earnings recognized for the three months ended March 31,
2009\.

21

* * *  
Table of Contents

**Results of Operations**

The following
table sets forth the components of net revenues (in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**% Change** | |
|Remodulin | |$ |76,810 | |$ |59,073 | |30\.0 |% |
|Telemedicine services and products | |2,570 | |2,291 | |12\.2 |% |
|Distributor fees | |342 | |667 | |(48.7 |)% |
|Other products | |8 | |16 | |(50.0 |)% |
| | | | | | | | |
|Total revenues | |$ |79,730 | |$ |62,047 | |28\.5 |% |

The growth in
revenues for the three-months ended March 31, 2009, corresponds in large
part to the continued increase in the number of patients being prescribed
Remodulin. For each of the three months ended March 31, 2009 and 2008,
approximately 89 percent our net Remodulin revenues were derived from our three
distributors based in the United States.

Total revenues
are reported net of estimated government rebates, prompt pay discounts and fees
due to our distributors for services. We pay government rebates to state
Medicaid agencies that pay for Remodulin. We estimate our liability for these
rebates based on the historical level of government rebates invoiced by state
Medicaid agencies relative to sales of Remodulin in the United States. Prompt
pay discounts are offered on sales of Remodulin if the related invoices are
paid in full, generally within 60 days from the date of sale. We estimate
our liability for prompt pay discounts based on historical payment patterns.
Fees paid to our distributors for services are estimated based on contractual
rates for specific services applied to the estimated units of service provided
by our distributors for the period.

The table
below presents a reconciliation of the liability accounts associated with
estimated government rebates, prompt pay discounts and fees to our distributors
for services and the net reductions to revenues relating to these items (in
thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |
|Liability accounts, at beginning of period | |$ |4,096 | |$ |2,878 | |
|Additions to liability attributed to sales
in: | | | | | |
|Current period | |2,582 | |3,949 | |
|Prior period | |— | |129 | |
|Payments or reductions attributed to sales
in: | | | | | |
|Current period | |(780 |) |(821 |) |
|Prior period | |(1,720 |) |(2,685 |) |
|Liability accounts, at end of period | |$ |4,178 | |$ |3,450 | |
|Net reductions to revenues | |$ |2,582 | |$ |4,078 | |

The table
below summarizes research and development expense by major project and
non-project components (dollars in thousands):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**Change** | |
|**Program:** | | | | | | | |
|Cardiovascular | |$ |11,418 | |$ |14,485 | |(21.2 |)% |
|Other | |4,885 | |3,324 | |47\.0 |% |
|Share-based compensation | |4,656 | |3,267 | |42\.5 |% |
|Total research and development expense | |$ |20,959 | |$ |21,076 | |(0.6 |)% |

_Cardiovascular._ Cardiovascular expense for the three months
ended March 31, 2008, included a $3.0 million milestone payment made in
connection with the development of beraprost-MR under our amended agreement
with Toray. There were no milestone payments made to Toray during the three
months ended March 31, 2009.

22

* * *  
Table of Contents

_Share-based
compensation._ We incurred approximately $2.0 million
in compensation expense related to our Share Tracking Awards Plan (STAP) as a
result of increases in both the closing price of our common stock on March 31,
2009, over the price on December 31, 2008, and the time Awards have
accrued towards vesting as of March 31, 2009.

The table
below summarizes selling, general and administrative expense by major
categories (dollars in thousands):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**Change** | |
|**Category:** | | | | | | | |
|General and administrative | |$ |11,383 | |$ |8,839 | |28\.8 |% |
|Sales and marketing | |8,459 | |6,884 | |22\.9 |% |
|Share-based compensation | |9,376 | |3,608 | |159\.9 |% |
|Total selling, general and administrative
expense | |$ |29,218 | |$ |19,331 | |51\.1 |% |

_General and
administrative._ The increase in general and
administrative expenses during the quarter ended March 31, 2009, compared
to the same quarter last year resulted primarily from an increase in
professional fees of $2.1 million relating to follow-up services on
transactions entered into during the fourth quarter of 2008.

_Share-based compensation._ Share-based compensation increased for the
quarter ended March 31, 2009, compared to the same quarter in 2008, as a
result of the recognition of approximately $2.5 million in compensation
relating to the fair value of a potential year-end stock option grant to our
Chief Executive Officer, which is governed by her employment agreement.  In addition, during the three months ended March 31,
2009, we incurred approximately $2.6 million in compensation related to the
STAP as a result of increases in both the closing price of our common
stock on March 31, 2009, over the price on December 31, 2008, and the
time awards have accrued towards vesting as of March 31, 2009.

_Income
taxes._ Income tax expense was approximately $6.8
million and $5.3 million for the three-month periods ended March 31, 2009
and 2008, respectively.  The income tax expense
is based on the estimated annual effective tax rate and is subject to
adjustment in subsequent quarterly periods as estimates of pre-tax income for
the year are revised. The estimated tax rates for the three months ended March 31,
2009 and 2008, were approximately 34 percent and 37 percent, respectively.

**Liquidity
and Capital Resources**

Since
Remodulin’s initial approval by the FDA in 2002, we have funded our operations
principally from Remodulin-related revenues and expect to do so in the future.
We believe that our existing revenues and working capital resources will be
adequate to fund our operations as demand for Remodulin has grown steadily
since 2002 and our customer base remains stable. Furthermore, we believe that
our customer base presents minimal credit risk. We have several therapies that
are in the later stages of development and believe that, if approved for
marketing, they will augment future revenue growth and cash flows. However, any
projections of future cash needs and cash flows are inherently subject to
uncertainty. To compensate for such uncertainty, we may raise additional cash
in the future and believe we have options and the ability to do so. See _Part II, Item 1A—Risk
Factors—We have a history of losses and may not maintain profitability_ and _Part II,_ _Item 1A—Risk Factors—We may fail to meet third-party projections
for our revenues or profits_ .

**_Operating Cash Flows
and Working Capital_**

Net cash
provided by operating activities was approximately $1.3 million for the
three months ended March 31, 2009, compared to approximately $35.1 million
for the three months ended March 31, 2008. The decline in cash provided by
operating activities reflects an increase in accounts receivable as a result of
the timing of sales of Remodulin and their subsequent collections and the
reduction in cash flows related to a decrease in accounts payable of
approximately $18.1 million when compared to the three months ended March 31,
2008 due to customary variances in the timing of payment processing.

At March 31,
2009, we had working capital of approximately $207.6 million, compared to
approximately $240.0 million at December 31, 2008. The decrease in
working capital corresponded mainly to the investment of approximately $11.6
million in long-term marketable securities and approximately $21.3 million to
fund our construction projects in Maryland and North Carolina.

23

* * *  
Table of Contents

**_Auction-Rate
Securities_**

At March 31,
2009, we held approximately $36.8 million (par value) of illiquid auction-rate
securities (ARS). The decline in value of these securities reflects market-related
liquidity conditions resulting from the general collapse of the credit markets.
The ARS are collateralized by student loan portfolios that are approximately
91% guaranteed by the federal government and maintain a credit rating of AAA.
Historically, these securities provided liquidity to investors through their
interest rate reset feature — i.e., interest rates on these securities are
reset through a bidding process (or auction) at frequent, pre-determined
intervals (typically every 7 to 28 days). At each reset date, investors
could either rollover and maintain their holdings or liquidate them at par
value. Since February 2008, auctions related to our ARS have failed,
rendering these securities illiquid.

To mitigate
the risks associated with these securities, we entered into an Auction Rate
Securities Rights Offer (Rights Offer) with an investment firm that maintains
our ARS account during the fourth quarter of 2008. Pursuant to the Rights
Offer, we can sell our ARS to the investment firm for a price equal to the par
value of these securities ($36.8 million) at any time between June 30, 2010
and July 2, 2012. In addition, to help meet any immediate liquidity needs,
the Rights Offer also provides that we can borrow up to the par value of the
ARS.

While we
believe we have the ability to hold these investments until the credit markets
improve sufficiently to allow us to liquidate the ARS without realizing
significant losses, we entered into the Rights Offer to provide us with
additional flexibility to recover the full cost of our investment prior to the
maturity of these securities. However, the Rights Offer carries with it
counterparty credit risk. Based on our anticipated cash requirements and cash
flows, we do not believe that the risks associated with the ARS will materially
impact our ability to meet our obligations.

**_Construction
Projects_**

In February 2009,
we completed the construction of a facility in Research Triangle Park, North
Carolina (RTP Facility). The RTP Facility is approximately 200,000 square feet
and consists of a manufacturing operation and office space. We intend to use
the manufacturing operation primarily to formulate oral treprostinil. In
addition, it is expected that the RTP Facility will support the production and
distribution of other drug candidates that we are developing. The offices are
used by our clinical development and sales and marketing staffs.

In December 2007,
we began constructing a combination office and laboratory facility (the Phase
II Facility) that will attach to our existing laboratory in Silver Spring,
Maryland (Phase I Laboratory). Projected costs to construct this facility
are anticipated to reach $100.0 million. In November 2008, we agreed
to the terms of a construction management agreement with the Whiting-Turner
Contracting Company relating to the construction of the Phase II Facility.
Under the terms of the contract, costs to complete the construction of the
Phase II Facility generally cannot exceed a guaranteed maximum price of $61.3 million.
The guaranteed maximum price excludes certain costs of construction that we
expect to incur and that have been included in our projected costs to complete
the Phase II Facility. Whiting-Turner will be responsible for any cost
overruns above the guaranteed maximum price and will share a portion of the
savings in the event costs of constructing the Phase II Facility are less
than the guaranteed maximum price. In addition, Whiting-Turner is subject to
penalties in the event that construction of the Phase II Facility is not
completed by November 16, 2009, unless an agreed-upon change order alters
the scope of work set forth under the construction management agreement.

We spent
approximately $6.8 million and $10.4 million relating to the
construction of the RTP Facility and Phase II Facility, respectively,
during the three months ended March 31, 2009. As of March 31, 2009,
inception-to-date expenditures approached $121.0 million on these two
construction projects. We expect to continue to fund the construction of the
Phase II Facility using existing cash and cash flows generated by our
operations.

**_Share Tracking
Awards Plan_**

Awards granted
under the STAP entitle participants to receive an amount in cash equal to the
appreciation in our common stock, which is calculated as the positive
difference between the closing price of our common stock on the date of grant
and the date of exercise. Accordingly, the STAP could require substantial cash
payments as awards begin to vest in June 2009 and participants exercise
their awards. Our operating budgets incorporate anticipated cash requirements
of the STAP, and we believe future cash flows will be sufficient to accommodate
our obligations under the STAP.

**_Convertible Senior
Notes_**

On October 30,
2006, we issued at par value $250.0 million of 0.50% Convertible Senior
Notes due October 2011 (Convertible Senior Notes). We pay interest on the
Convertible Senior Notes semi-annually on April 15 and October 15 of
each year. The Convertible Senior Notes are unsecured, unsubordinated
obligations that rank equally with all of our other unsecured and
unsubordinated indebtedness. The initial conversion price is $75.2257 per share
and the number of shares on which the aggregate consideration is to be
determined upon conversion is approximately 3,323,332 shares. Conversion can
occur: (i) anytime after July 15,

24

* * *  
Table of Contents

2011; (ii) during any
calendar quarter that follows a calendar quarter in which the price of our
common stock exceeded 120% of the initial conversion price for at least
20 days during the 30 consecutive trading day period ending on the last
trading day of the quarter; (iii) during the ten consecutive trading-day
period following any five consecutive trading day period in which the trading
price of the Convertible Senior Notes was less than 95% of the closing price of
our common stock multiplied by the then-current conversion rate; or (iv) upon
specified distributions to our shareholders, corporate transactions, or in the
event that our common stock ceases to be listed on the NASDAQ and is not listed
for trading on another U.S. national or regional securities exchange.

Upon
conversion, a holder of the Convertible Senior Notes will receive: (i) cash
equal to the lesser of the principal amount of the note or the conversion value
(equal to the number of shares underlying the Convertible Senior Notes
multiplied by the then current conversion price per share); and (ii) to
the extent the conversion value exceeds the principal amount of the Convertible
Senior Notes, shares of our common stock. In the event of a change in control,
as defined in the indenture under which the Convertible Senior Notes have been
issued, note holders may require us to purchase all or a portion of their
Convertible Senior Notes for 100% of the principal plus accrued and unpaid
interest, if any. Furthermore, because of the Convertible Senior Notes
contingent conversion provisions, note holders may be able to convert their
holdings prior to October 2011. However, it is our expectation, based on
our understanding of the historical behavior of holders of convertible notes
with terms similar to ours, that most, if not all of our outstanding Convertible
Senior Notes will be held until they mature in October 2011. On January 1,
2009, we adopted Financial Accounting Standards Board (FASB) Staff Position No.
APB 14-1, _Accounting for Convertible Debt Instruments That
May Be Settled in Cash Upon Conversion (Including Partial Cash Settlement)_ (FSP APB 14-1) as the Convertible Senior Notes fall within its scope. The
adoption of FSP APB 14-1 did not change the contractual cash flow requirements
of the Convertible Senior Notes; however, adoption had a material impact on our
consolidated financial statements. See Note 8 of the consolidated financial
statements included elsewhere in this Quarterly Report on Form 10-Q.

**_Lease Obligation_**

We currently
lease our Phase I Laboratory pursuant to a synthetic lease agreement
(Lease) entered into in June 2004 with Wachovia. Under the Lease, Wachovia
funded $32.0 million toward the construction of the Phase I
Laboratory on land we own. Subsequent to the completion of construction in May 2006,
Wachovia leased the Phase I Laboratory to us. Monthly rent is equal to the
30-day LIBOR plus 55 basis points (1.1% as of March 31, 2009) applied to
the amount Wachovia funded toward construction. The base term of the Lease ends
in May 2011 (Base Term). Upon the end of the Base Term, we will have the
right to exercise one of the following options under the Lease: (1) renew
the lease for an additional five-year term (subject to the approval of both
parties); (2) purchase the Phase I Laboratory from Wachovia for
approximately $32.0 million; or (3) sell the Phase I Laboratory
and repay Wachovia’s construction costs with the proceeds from the sale. If
sales proceeds are insufficient to repay Wachovia’s construction costs, we must
fund the shortfall up to the maximum residual value guarantee of approximately
$27.5 million. From inception of the Lease through August 2008, we
accounted for it as an off-balance sheet arrangement — i.e., an operating
lease.

Since December 2007,
we have been constructing the Phase II Facility with funds generated from
our operations. As of September 30, 2008, we received Wachovia’s
acknowledgement of our plan to make structural modifications to the
Phase I Laboratory in order to connect it to the Phase II Facility.
As a result, we could no longer consider the Phase I Laboratory a
standalone structure, which was required to maintain off-balance sheet
accounting for the Lease. Consequently, as of September 30, 2008, we are
considered the owners of the Phase I Laboratory for accounting purposes;
furthermore, because the Lease does not meet criteria set forth in EITF Issue No. 97-10, _The Effect of Lessee Involvement in Asset
Construction,_ and SFAS No. 98, _Accounting
for Leases_ , we are accounting for the Lease as a financing
obligation. Accordingly, we capitalized $29.0 million, the estimated fair
value of the Phase I Laboratory, and recognized a corresponding lease
obligation on our consolidated balance sheet. We are accreting the lease
obligation to $32.0 million, the purchase price of the Phase I
Laboratory, through the recognition of periodic interest charges using the
effective interest method. The accretion period began on September 30,
2008, and will run through the end of the Base Term. Related interest charges
for the three months ended March 31, 2009, were approximately $263,000. In
addition, we are depreciating the Phase I Laboratory over its estimated
economic useful life. The change in accounting recognition of the Lease did not
affect our cash flow requirements under the arrangement.

Using the
30-day LIBOR as of March 31, 2009, plus 55 basis points, our estimated
annual rent under the Lease would be $334,000. Approximately $40.8 million
of our marketable investments at March 31, 2009, have been pledged as
collateral for the Lease and are included within restricted marketable
investments and cash on our consolidated balance sheet.

**Summary of
Critical Accounting Policies**

The preparation of our
consolidated financial statements in conformity with accounting principles
generally accepted in the United States ( GAAP) requires our management to make estimates and
assumptions that affect the amounts reported in our consolidated financial
statements and accompanying notes. On an ongoing basis, we evaluate our
estimates and judgments.  Our estimates
and judgments are based on historical and anticipated results and trends and on
other assumptions that we believe are reasonable under the circumstances,
including assumptions regarding future events. By their nature, our estimates
are subject to an inherent degree of uncertainty and, as such, actual results
may differ. We discussed accounting policies and assumptions that involve a
higher degree of judgment and complexity within _Part II,
Item 7—Management’s Discussion and Analysis of Financial Condition and Results
of Operations_ in our Annual Report on Form 10-K for the year
ended December 31, 2008. There have been no material changes to our
critical accounting policies and estimates as disclosed in our Annual Report on
Form 10-K for the year ended December 31, 2008, except for our
adoption of FSP APB 14-1 on January 1, 2009 (see Note 8 to our
consolidated financial statements included elsewhere in this Quarterly Report
on Form 10-Q).

25

* * *  
Table of Contents

**Recent
Accounting Developments**

In May 2008,
the FASB issued FSP APB 14-1. FSP APB 14-1 applies to certain
convertible debt instruments that may be settled in cash or other assets, or
partially in cash, upon conversion. Issuers of such instruments are required
under FSP APB 14-1 to account for the liability and equity components
separately in a manner that reflects the issuer’s nonconvertible debt borrowing
rate when interest expense is subsequently recognized. Specifically, FSP
APB 14-1 requires the difference between the convertible debt proceeds and
the fair value of the liability, absent any conversion rights, to be assigned
to the equity component and recognized as part of stockholders’ equity and as a
discount for determining the carrying value of the debt. The discounted
carrying value of the debt is amortized as interest expense using the interest
method over the expected life of the debt. FSP APB 14-1 became effective
for us retrospectively on January 1, 2009, and had a material impact on
our consolidated financial statements. See _Note 8: Debt—Adoption of
FSP APB 14-1_ to our consolidated financial statements included
within this Quarterly Report on Form 10-Q.

In June 2008,
the FASB issued EITF Issue No. 07-5, _Determining
Whether an Instrument (or Embedded Feature) Is Indexed to an Entity’s Own Stock_ (EITF 07-5). EITF 07-5 supersedes EITF Issue No. 01-6, _The Meaning of ‘Indexed to a Company’s Own Stock’_ ,
and provides guidance in evaluating whether certain financial instruments or
embedded features can be excluded from the scope of Statement of Financial
Accounting Standards (SFAS) No. 133, _Accounting
for Derivatives and Hedging Activities_ (SFAS 133).
EITF 07-5 sets forth a two-step approach that evaluates an instrument’s
contingent exercise and settlement provisions for the purpose of determining
whether such instruments are indexed to an issuer’s own stock (a requirement
necessary to comply with the scope exception under SFAS 133).
EITF 07-5 became effective for us as of January 1, 2009. Adoption of
EITF 07-5 did not affect the manner in which we account for financial
instruments that are within its scope.

In March 2008,
the FASB issued SFAS No. 161, _Disclosures
about Derivative Instruments and Hedging Activities—an Amendment of FASB
Statement No. 133_ (SFAS 161). SFAS 161 requires
companies to provide enhanced disclosures regarding derivative instruments and
hedging activities and requires companies to better convey the purpose of
derivative use in terms of the risks they intend to manage. Disclosures
required under SFAS 161 include: (a) how and why a company uses
derivative instruments; (b) how derivative instruments and related hedged
items are accounted for under SFAS 133 and its related interpretations;
and (c) how derivative instruments and related hedged items affect a
company’s financial position, financial performance, and cash flows.
SFAS 161 retains the same scope as SFAS 133 and is effective for
fiscal years and interim periods beginning after November 15, 2008.
Adoption of SFAS 161 had no impact on our consolidated financial
statements.

In December 2007,
the FASB issued SFAS No. 160, _Noncontrolling
Interests in Consolidated Financial Statements—an Amendment of ARB No. 51_ (SFAS 160). SFAS 160 establishes accounting and reporting standards
for the noncontrolling interest in a subsidiary and for the deconsolidation of
a subsidiary. This statement became effective for us on January 1, 2009,
except for certain retrospective disclosure requirements. Adoption of
SFAS 160 did not impact our consolidated financial statements upon
adoption.

In December 2007,
the FASB issued SFAS No. 141 (Revised 2007), _Business Combinations—a Replacement of FASB Statement No. 141_ (SFAS 141R). SFAS 141R significantly changes the principles and
requirements for how the acquirer of a business recognizes and measures in its
financial statements the identifiable assets acquired, liabilities assumed, and
any noncontrolling interest in an acquiree. SFAS 141R also provides guidance
for recognizing and measuring goodwill acquired in a business combination and
determines what information to disclose to enable users of the financial
statements to evaluate the nature and financial effects of a business
combination. SFAS 141R is effective, prospectively, for fiscal years
beginning after December 15, 2008, except for certain retrospective
adjustments to deferred tax balances. The adoption of SFAS 141R had no impact
on our consolidated financial statements.

In June 2007,
the FASB issued EITF Issue No. 07-1, _Accounting
for Collaboration Arrangements Related to the Development and Commercialization
of Intellectual Property_ (EITF 07-1). EITF 07-1 provides
guidance on how the parties to a collaborative agreement should account for
costs incurred and revenue generated on sales to third parties and how sharing
payments pursuant to a collaboration agreement should be presented in the
income statement. EITF 07-1 will be effective for fiscal years beginning
after December 15, 2008, and interim periods within those fiscal years and
shall be applied retrospectively. Adoption of EITF 07-1 had no impact on our
consolidated financial statements.

26

* * *  
Table of Contents

**Item 3. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET
RISK**

As of March 31,
2009, we hold investments of approximately $36.8 million (par value) in
ARS. We are exposed to market risk related to the ARS as a result of the
general collapse of the credit markets and the continued uncertainty
surrounding the financial markets. The ARS maintain an AAA credit rating and
are backed by student loan portfolios that are approximately 91% guaranteed by
the federal government. However, since February 2008, auctions for the ARS
have failed, rendering these securities illiquid. Consequently, the fair value
of the ARS has continued to decline in value. As of March 31, 2009, the
estimated fair value of these securities was approximately $27.8 million.
Because we classify the ARS as trading securities, all future changes in fair
value of the ARS will be recognized within earnings until the securities are
liquidated or otherwise disposed. Furthermore, there can be no assurances that
the ARS will ever fully recover their value.

To mitigate
market-related risks associated with our investment, we entered into the Rights
Offer, under which we have a Put Option that gives us the ability to
require the investment firm (the counterparty to the Rights Offer) to
repurchase the ARS at a price equal to their par value anytime between June 30,
2010 and July 2, 2012. The Put Option has been recognized at fair value as
a financial asset on our consolidated balance sheet and subsequent changes in
its fair value will be recognized within earnings. We expect the future price
movements relating to the ARS and the Put Option to largely offset one
another — i.e., as the value of the ARS decreases, we would expect the
rights associated with the Put Option to increase in value. However, the Rights
Offer and the related Put Option still expose us to counterparty credit risk.

At March 31,
2009, we have invested approximately $219.8 million in debt securities
issued by corporations and federally-sponsored agencies. The market value of
these investments varies inversely with changes in current market interest
rates. In general, as rates increase, the market value of a debt investment
would be expected to decrease. Similarly, as rates decrease, the market value
of a debt investment would be expected to increase. To address market risk, we
hold related investments until maturity so that they can be redeemed at their
stated or face value. At March 31, 2009, our investments in debt
securities issued by corporations and federally-sponsored agencies had a
weighted average stated interest rate of approximately 2.3%. These investments
mature at various times through December 2010 and are callable annually.

There has been
a prolonged period of significant deterioration and instability in the
financial markets that has persisted into 2009. This period of extraordinary
disruption and readjustment in the financial markets exposes us to additional
investment risk. The value and liquidity of the securities in which we invest
could deteriorate rapidly and the issuers of such securities could be subject
to credit rating downgrades. In light of the current market conditions and
these additional risks, we actively monitor market conditions and developments
specific to the securities and security classes in which we invest. We believe
that we take a conservative approach to investing our funds in that we invest
exclusively in highly-rated securities with relatively short maturities.
Furthermore, we do not invest in the types of securities that we believe expose
us to undue risks. While we believe we take prudent measures to mitigate
investment related risks, such risks cannot be fully eliminated, as there are
circumstances outside of our control, as noted above in the discussion of our
ARS.

**Item 4.    CONTROLS AND PROCEDURES**

Based on their
evaluation, as of March 31, 2009, the Chief Executive Officer and Chief
Financial Officer have concluded that our disclosure controls and procedures
(as defined in Rule 13a-15(e) and 15d-15(e) under the Securities
Exchange Act of 1934, as amended) are effective to provide reasonable assurance
that information required to be disclosed by us in reports that we file or
submit under the Securities Exchange Act of 1934, as amended, is recorded,
summarized, processed and reported within the time periods specified in the SEC’s
rules and forms and to provide reasonable assurance that such information
is accumulated and communicated to our management, including the Chief
Executive Officer and Chief Financial Officer, as appropriate to allow timely
decisions regarding required disclosure. There have been no changes in our
internal control over financial reporting that occurred during the period
covered by this report that have materially affected, or are reasonably likely
to materially affect, such internal control over financial reporting.

**Part II.** **OTHER INFORMATION**

**Item 1A. 
RISK FACTORS**

**Forward-Looking
Statements**

This Quarterly
Report on Form 10-Q contains forward-looking statements made pursuant to
the safe harbor provisions of Section 21E of the Securities Exchange Act
of 1934 (the Exchange Act) and the Private Securities Litigation Reform Act of
1995 which are based on our beliefs and expectations as to future outcomes.
These statements include, among others, statements relating to the following:

27

* * *  
Table of Contents

· Expectations of revenues,
profitability, and cash flows;

· The timing and outcome of clinical
studies and regulatory filings, including our expectation that our FREEDOM-M
and FREEDOM-C 2 clinical trials will be successful;

· The achievement and maintenance of
regulatory approvals;

· The existence and activities of
competitors;

· The pricing of Remodulin
(treprostinil sodium) Injection (Remodulin);

· The expected levels and timing of
Remodulin sales;

· The dosing and rate of patient
consumption of Remodulin;

· The impact of generic products on
Remodulin sales;

· The outcome of potential future
regulatory actions, including audits and inspections, from the FDA and
international regulatory agencies;

· The adequacy of our intellectual
property protections and expiration dates on our patents;

· The ability of third parties to
market, distribute and sell our products;

· The sufficiency of current and future
working capital;

· The expectation that our Convertible
Senior Notes will be held to maturity;

· The ability to obtain financing or
raise cash in the future;

· The value of our common stock;

· The expectation of future repurchases
of shares of our common stock subject to repurchase from Toray;

· The timing and expectations of the
completion and costs relating to our construction projects;

· The expected impact of new accounting
standards;

· The expectation of liquidating our
investment holdings without significant losses and expectations with respect to
future credit market conditions;

· The potential effects of the Rights
Offer and our expectations of not exercising our right to borrow under the
Rights Offer;

· The results of our clinical trials;

· The pace and timing of enrollment in
our clinical trials;

· The expectation and timing of regulatory
approvals for inhaled treprostinil, oral treprostinil and tadalafil and the
timing of related sales;

· The expectation and timing of
regulatory approval for our Phase I Laboratory;

· The expectation, outcome and timing
of marketing approvals in countries within the European Union for intravenous
Remodulin and inhaled treprostinil;

· The timing, resubmission, completion
and outcome of applications for marketing authorization of subcutaneous
Remodulin in Ireland, Spain and the United Kingdom;

28

* * *  
Table of Contents

· The expected timing of commencing
commercial activities in Japan with Mochida Pharmaceutical Co., Inc.;

· The expected timing of payments to
third parties under license agreements;

· The outcome of any litigation in
which we are or become involved;

· The expectation that we will locate
another formulator for Remodulin to replace Baxter and obtain necessary
regulatory approvals, or reach an agreement with Baxter for the continued
formulation of Remodulin on a different production line;

· Our expectation that we will increase
our Remodulin inventory levels from a two-year to a three-year supply; and

· The expectation that our business tax
credit carryforwards will not expire unused.

Any statements
preceded by, followed by or that include any form of the words “believe,” “expect,”
“predict,” “anticipate,” “forecast,” “project,” “intend,” “estimate,” “should,”
“could,” “may,” “will,” or similar expressions. 
Other statements contained or incorporated by reference in this
Quarterly Report on Form 10-Q that are not historical facts.

The statements
identified as forward-looking statements may exist in the section entitled _Part I, Item 2—Management’s Discussion and
Analysis of Financial Condition and Results of Operations_ or
elsewhere in this Quarterly Report on Form 10-Q. These statements are
subject to risks and uncertainties and our actual results may differ materially
from anticipated results. Factors that may cause such differences include, but
are not limited to, those discussed below. We undertake no obligation to
publicly update forward-looking statements, whether as a result of new
information, future events or otherwise.

**Risks Related to Our Business**

**We
have a history of losses and may not maintain profitability.**

Although we
have maintained periods of annual profitability, we have experienced both
annual and quarterly net losses. For the year ended December 31, 2008, we
recognized a net loss of approximately $49.0 million principally from the
expensing of one-time fees totaling $150.0 million relating to the
acquisition of certain license rights to tadalafil from Lilly. While we believe
we formulate our annual operating budgets with reasonable assumptions and
targets, certain non-cash charges and other factors that may be beyond our
control could affect our profitability and cause uneven quarterly and annual
operating results.

**We
rely heavily on sales of Remodulin to produce revenues.**

During the
three months ended March 31, 2009, Remodulin sales accounted for
approximately 96 percent of our total revenues. A wide variety of events, many
of which are described in other risk factors below, could cause Remodulin sales
to decline. For example, if regulatory approvals for Remodulin were withdrawn,
we would be unable to sell our product and our business could be jeopardized.
In the event that GlaxoSmithKline PLC (formerly Glaxo Wellcome, Inc.)
(Glaxo) terminates its assignment agreement or Pfizer, Inc.
(Pfizer) terminates its license agreement, we would have no further rights to
utilize assigned patents or trade secrets to develop and commercialize
Remodulin. Any substantial change in the dosing pattern of patients using
Remodulin, due to combination therapy, side effects, death or any other reason,
could decrease related revenues. In addition, we rely on third parties to
produce, market, distribute and sell Remodulin. The inability of one of these
third parties to perform these functions, or the failure of any of these
parties to perform successfully, could cause our revenues to suffer. Because we
are very dependent on sales of Remodulin, any reduction in Remodulin sales
would cause our results of operations to suffer.

**Most
of our pharmaceutical products are in clinical development and may never
generate profits.**

Our only
pharmaceutical product currently in commercial distribution is Remodulin for
subcutaneous and intravenous administration. Most of our pharmaceutical products
are at various stages of clinical development; therefore, many of these
products may not become commercially available for a number of years, if at
all. We might not maintain or obtain regulatory approvals for our
pharmaceutical products and may not be able to sell our pharmaceutical products
commercially. Even if we are able to sell our products, we may not be
profitable or may not be able to sustain any profitability we achieve.

29

* * *  
Table of Contents

**We
may not successfully compete with established and newly-developed drugs,
products and the companies that develop and market them.**

We compete
with established drug companies during product development for, among other
things, funding, licenses, expertise, personnel, clinical trial patients, and
third-party collaborators. We also compete with these companies following the
approval of our products. Most of these competitors have substantially greater
financial, marketing, sales, distribution and technical resources than we do.
These competitors also possess more experience in areas such as research and
development, clinical trials, sales and marketing and regulatory matters than we
do.

There are
existing treatments that compete with our products, especially in the field of
PAH. Patients and doctors may perceive these competing products as safer, more
effective, more convenient and/or less expensive than Remodulin. Accordingly,
sales of Remodulin may not increase, or may decrease if doctors prescribe less
Remodulin than they prescribe presently.

For the
treatment of PAH, we compete with many approved products in the United States
and worldwide, including the following:

· _Flolan_ . The
first product approved by the FDA for the treatment of PAH, Flolan is a
prostacyclin analogue that is delivered by intravenous infusion. Glaxo began
marketing Flolan in the United States in 1996. The generic exclusivity period
for Flolan expired in April 2007;

· _Other epoprostenol
formulations_ . In April 2008, Teva Pharmaceuticals Industries Ltd. (Teva)  announced that the FDA approved its generic
version of epoprostenol for the treatment of PAH. Teva’s epoprostenol is the
first approved generic version of Flolan. In June 2008,
GeneraMedix Inc. (GeneraMedix) received FDA approval for its version of
epoprostenol. In February 2009, Actelion Ltd (Actelion) announced that it
had entered into an agreement with GeneraMedix to acquire its epoprostenol
product;

· _Ventavis_ .
Approved in December 2004 in the United States and in September 2003
in Europe, Ventavis is the only prostacyclin analogue that has been approved
for inhalation. Ventavis was initially marketed by CoTherix, Inc. (CoTherix), in the United States and is
marketed by Schering AG in Europe as Iloprost. In January 2007, CoTherix
was acquired by Actelion, the manufacturer and distributor of Tracleer;

· _Tracleer_ . The
first oral drug to be approved for PAH, Tracleer is also the first drug in its
class of endothelin receptor antagonists (ERAs). Tracleer was approved in December 2001
in the United States and in May 2002 in Europe. Tracleer is marketed
worldwide by Actelion;

· _Revatio_ .
Approved in June 2005 in the United States, Revatio is an oral therapy and
is marketed by Pfizer. Revatio contains sildenafil, the same active ingredient
as Viagra, and is the first PDE5 inhibitor to be approved for PAH;

· _Letairis_ ™.
Approved in June 2007 in the United States, Letairis is an oral therapy
marketed by Gilead Sciences, Inc. (Gilead) in the United States for the
treatment of PAH. Like Tracleer, Letairis is an ERA. In April 2008, Glaxo
received marketing authorization from the European Medicines Agency (EMEA) for
Letairis in Europe where it is known as Volibris ® ; and

· _Thelin_ ® . Approved in August 2006
in the European Union, Thelin is an oral therapy, and was developed and
initially marketed by Encysive
Pharmaceuticals Inc. (Encysive), for the treatment of PAH. Like Tracleer
and Letairis, Thelin is an ERA. In June 2008, Pfizer completed its
acquisition of Encysive. Pfizer has announced that it plans to conduct a
pivotal Phase III clinical trial to support registration of Thelin in the
United States and eventually receive FDA approval.

Doctors may
reduce the dose of Remodulin they give to their patients if they prescribe our
competitors’ products in combination with Remodulin. In addition, certain
competing products are less invasive than Remodulin and the use of these
products may delay or prevent initiation of Remodulin therapy.

As a result of
merger activity, Actelion, Gilead and Pfizer presently control all non-generic
approved therapies for PAH in the United States except for Remodulin.
Furthermore, Actelion controls one of the two recently approved formulations of
epoprostenol. In addition to reducing the number of competitors, each of these
companies exerts considerable influence over prescribers through the sales and
marketing of their respective therapies and through market dominance in this
therapeutic area. The future commercialization of additional generic forms of
PAH therapies could exert downward pressure on the pricing of our products.

30

* * *  
Table of Contents

**Discoveries
or development of new products or technologies by others may make our products
obsolete or less useful.**

Companies may
discover or introduce new products that render all or some of our technologies
and products obsolete or noncompetitive. Researchers are continually making new
discoveries that may lead to new technologies that treat the diseases for which
our products are intended. In addition, alternative approaches to treat chronic
diseases, such as gene therapy, may make our products obsolete or
noncompetitive. Other investigational therapies for PAH could be used in
combination with, or as a substitute for Remodulin. If this happens, doctors
may reduce the dose of Remodulin they give to their patients or may prescribe other
treatments instead of Remodulin. This could decrease demand for Remodulin and
reduce related sales.

Remodulin and
our other treprostinil-based products may have to compete with investigational
products currently being developed by other companies, including:

· _Cialis_ . An
approved oral treatment for erectile dysfunction, Cialis is currently marketed
by Lilly and is in the same class of drugs as Revatio, PDE5 inhibitors.
Tadalafil is the active ingredient in Cialis. The PHIRST-1 Study of tadalafil
for the treatment of PAH was successful and FDA approval of tadalafil for PAH
is currently pending. Although we have entered into a license agreement whereby
Lilly has granted us the exclusive right to commercialize tadalafil for the
treatment of pulmonary hypertension in the United States and Puerto Rico, Lilly
will retain the rights to commercialize tadalafil for the treatment of
pulmonary hypertension outside the United States and Puerto Rico;

· _Terguride_ . In May 2008,
Ergonex Pharma announced that the FDA granted orphan drug status to Terguride
for the treatment of PAH. Terguride is a serotonin receptor 5-HT2B and 5-HT2A
antagonist. Terguride is currently being evaluated for the treatment of PAH in
a pivotal Phase II clinical study in Europe;

· _Actelion-1_ .
Actelion-1 is a tissue-targeting ERA being developed by Actelion. Actelion is
conducting a Phase III study of Actelion-1 to evaluate its safety and
efficacy in delaying disease progression and mortality in patients with PAH;

· _Gleevec_ ® . An approved oral treatment
for chronic myeloid leukemia (a cancer of the blood and bone marrow), Gleevec
is currently marketed by Novartis Pharmaceuticals Corporation. A Phase II
study presented at the European Respiratory Society showed promising results
for Gleevec in the treatment of PAH. Other research is ongoing;

· _Aviptadil_ . An
inhaled formulation of a vasoactive intestinal peptide, Aviptadil is being
developed by mondoBIOTECH Holding SA for the treatment of PAH. In September 2006,
mondoBIOTECH Holding SA announced that it had outlicensed Aviptadil for
the treatment of PAH to Biogen Idec Inc. A small study of Aviptadil
revealed that it tended to improve oxygenation in patients with PAH. Further
studies are ongoing;

· _PRX-08066_ . A
serotonin receptor 5-HT2B antagonist, PRX-08066 is being developed by Epix
Pharmaceuticals, Inc. as an oral tablet for the treatment of PAH. In August 2008,
Epix Pharmaceuticals, Inc. announced the initiation of a right-heart
catheter study of PRX-08066 in patients with pulmonary hypertension due to
chronic obstructive pulmonary disease;

· _PulmoLAR_ ™.
Currently in development by PR Pharmaceuticals, Inc., PulmoLAR is a
once-a-month injectible therapy that contains a metabolite of estradiol and has
been shown in animal and cell models to address certain processes associated
with PAH;

· _Fasudil_ . Oral
and inhaled formulations of Fasudil, a rho-kinase inhibitor, may be developed
by Actelion for the treatment of PAH. Fasudil is currently approved in Japan as
an intravenous drug to treat a disease unrelated to PAH;

· _Sorafenib_ .
Originally marketed by Bayer HealthCare AG (Bayer) as Nexavar ® for
advanced renal cell cancer, Sorafenib is a small molecule that inhibits Raf
kinase and may interfere with the thickening of blood vessel walls associated
with PAH. On May 20, 2008, the results of a University of Chicago study
were released demonstrating that PAH patients taking Nexavar showed improvement
in their ability to exercise;

31

* * *  
Table of Contents

· _Recombinant Elafin_ .
Currently being developed by PROTEO Biotech AG, Recombinant Elafin is a
synthetic version of a protein that is produced naturally in the body and may
inhibit inflammatory reactions. In March 2007, Elafin was granted orphan
drug status in the European Union for the treatment of PAH and chronic
thromboembolic pulmonary hypertension;

· _NS-304_ . A novel
orally available prostaglandin I2 receptor agonist, NS-304 is being developed
by Nippon Shinyaku and Actelion pursuant to an April 2008 license
agreement. Under the terms of the agreement, Actelion will take over a
Phase IIa clinical study of NS-304 for PAH being conducted by Nippon
Shinyaku in Europe and will be responsible for global development and
commercialization of NS-304 outside Japan;

· _Cicletanine_ .
Marketed by Navitas Pharma for hypertension in Europe, Cicletanine is an eNOS
coupler that works to increase the flexibility of blood vessel linings. In May 2008,
Gilead and Navitas Assets, LLC (Navitas) announced that they entered into
an agreement whereby Gilead acquired all of Navitas’ assets related to its
cicletanine business. In December 2008, Gilead began a Phase II
clinical trial to assess the efficacy, safety, and tolerability of cicletanine
in PAH patients;

· _6R-BH4_ . A
naturally occurring enzyme cofactor that is required for numerous biochemical
and physiologic processes, including the synthesis of nitric oxide (NO), 6R-BH4
is being developed by BioMarin Pharmaceutical Inc. for the treatment of
various cardiovascular indications and phenylketonuria. Currently, several
Phase II clinical trials of 6R-BH4 for cardiovascular disease are
underway. A Phase II trial of 6R-BH4 for peripheral arterial disease (PAD)
failed to meet its primary endpoint;

· _ONO-1301_ .
ONO-1301 is a novel, long-acting prostacyclin agonist with thromboxane synthase
inhibitory activity being developed by scientists at the National
Cardiovascular Center Research Institute in Osaka, Japan. Current published
reports have indicated that the compound has shown promising results;

· _Riociguat (BAY 63-2521)._ Riociguat is an oral soluble guanylate cyclase stimulator that activates the
major cellular receptor for NO and mediates a wide range of physiological
effects through elevation of intracellular cyclic guanosine monophosphate (cGMP) levels leading to pulmonary
vasodilation. Riociguat is being developed by Bayer for the treatment of
chronic thromboembolic pulmonary hypertension and PAH. A Phase II clinical
trial of Riociguat was successfully completed and two Phase III trials are
currently underway;

· _Aironite_ ™.
Currently being developed by Aires Pharmaceuticals, Inc. under a license
agreement with the National Institutes of Health, Aironite is a novel inhaled
nitrite therapy that has been shown in preclinical models to prevent the
progression of pulmonary hypertension. Aironite has been granted orphan drug
status by the FDA. A Phase I study of Aironite has been completed; and

· _Generic Iloprost_ .
The orphan drug exclusivity on Iloprost will expire in 2011. We believe that
multiple manufacturers are working on a generic formulation that will result in
future sales upon expiration of the patent term.

There may be
other drugs in development for PAH in addition to those listed above.
Furthermore, there may be currently approved drugs that prove effective in
treating PAH. If any of these drugs are marketed for the treatment of PAH,
sales of Remodulin could decrease.

**If
third-party payers will not reimburse patients for our drug products or if
third-party payers limit the amount of reimbursement, our sales will suffer.**

Our commercial
success depends heavily on third-party payers, such as Medicare, Medicaid and
private insurance companies, which agree to reimburse patients for the costs of
our pharmaceutical products. These third-party payers frequently challenge the
pricing of new and expensive drugs, and it may be difficult for distributors
selling Remodulin to obtain reimbursement from these third-party payers.
Remodulin and the associated infusion pumps and supplies are very expensive. We
believe our investigational products, if approved, will also be very expensive.
Presently, most third-party payers, including Medicare and Medicaid, reimburse
patients for the cost of Remodulin therapy. In the past, Medicare has not
reimbursed the full cost of the therapy for some patients. The Medicare
Modernization Act requires that we negotiate a new price for Remodulin with the
Centers for Medicare and Medicaid Services (CMS). As a result of the staggered
implementation of this Act, Remodulin has not yet been subject to the pricing
provisions. To the extent that private insurers or managed care programs follow
any reduced Medicaid and Medicare coverage and payment developments, the
negative impact on our business would be compounded. Additionally, some states
have enacted health care reform legislation. Further federal and state
developments are possible and such potential legislative activity could
adversely impact our business.

32

* * *  
Table of Contents

Third-party
payers may not approve our new products for reimbursement or may not continue
to approve Remodulin for reimbursement. Furthermore, third-party payers may
reduce the amount of reimbursement for Remodulin based on changes in pricing of
other therapies for PAH, including generic formulations of other approved
therapies, such as Flolan. If third-party payers do not approve a product of
ours for reimbursement or limit the amount of reimbursement, sales will
decline, as patients could opt for a competing product that is approved for
reimbursement.

**Reimbursement
for cardiac monitoring services by Medicare is highly regulated and subject to
change. The operation of our cardiac monitoring facility is subject to rules and
regulations governing Independent Diagnostic Testing Facilities (IDTFs).
Failure to comply with these rules could prevent us from receiving
reimbursement for our cardiac services from Medicare and some commercial
payers.**

We receive approximately
15 percent of our cardiac monitoring service revenues from Medicare
reimbursements. Reimbursement from Medicare for cardiac monitoring services is
subject to statutory and regulatory changes, rate adjustments and
administrative rulings. All of these factors could materially affect the range
of services covered or the reimbursement rates paid by Medicare for use of our
cardiac monitoring services. In 2007, CMS instituted a change in the method for
calculating reimbursement under the Physician Fee Schedule that will be
implemented over a four-year period. Consequently, CMS has reduced
reimbursement for our cardiac monitoring services each year since 2007. Similar
reductions are expected through 2010. We cannot predict whether future
modifications to Medicare’s reimbursement policies could reduce the amounts we
receive from Medicare for the services we provide. Additionally, Medicare’s
reimbursement rates can affect the rate that commercial payers are willing to
pay for our products and services.

The Medicare
program is administered by CMS. CMS imposes extensive and detailed requirements
on medical service providers. These requirements include, but are not limited
to, rules that govern how we structure our relationships with physicians,
how and when we submit reimbursement claims, how we operate our monitoring
facilities and how we provide our cardiac monitors and monitoring services. Our
failure to comply with applicable Medicare rules could result in the
discontinuance of our reimbursements, the return of funds paid to us, civil
monetary penalties, criminal penalties and/or exclusion from the Medicare
program.

Additionally,
in order for us to receive reimbursement for cardiac monitoring services from
Medicare and some commercial payers, we must maintain a call center certified
as an IDTF. Certification as an IDTF requires that we follow strict regulations
governing how the center operates, such as requirements regarding
certifications of the technicians who review data transmitted from our cardiac
monitors. If regulations change, we may have to alter operating procedures at
our monitoring facilities, which could increase our costs significantly. If we
fail to obtain and maintain IDTF certification, our services may no longer be
reimbursed by Medicare and some commercial payers, which could negatively
affect our telemedicine business.

33

* * *  
Table of Contents

**We
rely in part on third parties to market, distribute and sell most of our
products and those third parties may not perform.**

We are
currently marketing three products in our cardiovascular therapeutic platform:
Remodulin in our prostacyclin analogue platform and CardioPAL ® SAVI cardiac event monitors and Decipher
Holter monitors in our telemedicine platform. We also have several products
across all of our therapeutic platforms in the clinical trial stage. We do not
have the ability to independently conduct clinical studies, obtain regulatory
approvals, market, distribute and sell all of our products. Therefore, we rely
on experienced third parties to perform some of these functions. We may not
locate acceptable contractors or enter into favorable agreements with them. If
third parties do not successfully carry out their contractual duties or meet
expected deadlines, we might not be able to market, distribute and sell our
products and future revenues could suffer.

We rely on
Accredo, CuraScript, and Caremark to market, distribute, and sell
Remodulin in the United States. Accredo, CuraScript and Caremark are also
responsible for convincing third-party payers to reimburse patients for the
cost of Remodulin, which has a substantial acquisition cost. If our
distributors do not achieve acceptable profit margins, they may not continue to
sell our products. Furthermore, if our distributors in the United States and
abroad are unsuccessful in their efforts, our revenues will suffer.  If our distributors devote fewer resources to
sell Remodulin, our sales could be negatively affected.

**Our
operations depend on compliance with complex FDA and comparable international
regulations. Failure to obtain approvals on a timely basis or to achieve
continued compliance could delay or halt commercialization of our products.**

The products
we develop must be approved for marketing and sale by regulatory agencies and,
once approved, are subject to extensive regulation by the FDA and comparable
regulatory agencies outside the United States. The process of obtaining and
maintaining regulatory approvals for new drugs is lengthy, expensive and
uncertain. The manufacture, distribution, advertising and marketing of these
products are also subject to extensive regulation. Any new product approvals we
receive in the future could include significant restrictions on the use or
marketing of the product. Potential products may fail to receive marketing
approval on a timely basis, or at all. If granted, product approvals can be
withdrawn for failure to comply with regulatory requirements. Product approvals
can also be withdrawn upon the occurrence of adverse events following
commercial introduction. In addition, our marketed products and how we
manufacture and sell these products are subject to continued, extensive
regulation and review.

Although we
have never experienced product specification failures with respect to Remodulin
vials, discovery of previously unknown problems with our marketed products or
problems with our manufacturing, regulatory, promotional or commercialization
activities could result in regulatory restrictions on our products, including
withdrawal of the products from the market. If we fail to comply with
applicable regulatory requirements, we could be subject to penalties that may
consist of fines, suspension of regulatory approvals, product recalls, seizure
of products and criminal prosecution.

**Reports
of side effects, such as sepsis, associated with intravenous Remodulin could
cause physicians and patients to avoid or discontinue use of Remodulin in favor
of alternative treatments.**

Sepsis is a
serious and potentially life-threatening infection of the bloodstream caused by
a wide variety of bacteria. Intravenous prostacyclins are infused continuously
through a catheter placed in a large vein in the patient’s chest. Sepsis is an
expected consequence of this type of delivery. As a result, sepsis is included
as a risk in both the Remodulin and Flolan package inserts.

In 2007, the
Scientific Leadership Committee (SLC) of the Pulmonary Hypertension Association
announced new guidance relating to the treatment of PAH patients on long-term
intravenous therapy. The SLC reminded physicians to be aware of the range of
possible gram negative and gram-positive infectious organisms in patients with
long-term central catheters and to treat them appropriately. We have been
informed that the SLC is planning a study to evaluate the risk of sepsis and
sepsis sub-types among parenterally-delivered prostanoids. In February 2008,
the FDA approved a revised Remodulin package insert that more fully described
the known infection risk and appropriate techniques to be practiced when
preparing and administering Remodulin intravenously. In the Spring of 2008, the
SLC published catheter maintenance guidelines for intravenous prostacyclin
administration to minimize the risks of developing bloodstream infections.

Although a
discussion of the risk of sepsis is currently included on the Remodulin label,
and the occurrence of sepsis is familiar to physicians who prescribe
intravenously administered therapies, concerns about bloodstream infections may
adversely affect a physician’s prescribing practice of Remodulin. If that
occurs, sales of Remodulin and our profitability could suffer.

34

* * *  
Table of Contents

**We
have transitioned our manufacturing operations to a new location and if the FDA
and other international agencies do not approve our new location for commercial
use, our ability to produce treprostinil sodium, the active ingredient in
Remodulin, could suffer.**

In July 2008,
we submitted a supplement to the Remodulin NDA for approval of our Phase I
Laboratory. We plan to manufacture treprostinil in our Phase I Laboratory
on a larger scale than we did in our facility in Chicago, Illinois, which we
closed in May 2007. Until we receive FDA and international approvals of
our Phase I Laboratory, we cannot sell products containing compounds
manufactured there. We currently maintain a two-year supply of formulated
Remodulin based on anticipated demand. Therefore, if approval of the Phase I
Laboratory is unexpectedly delayed beyond two years, we may encounter a
shortage of treprostinil. Consequently, this could reduce the availability of
our commercial products and negatively affect sales and our ability to conduct
clinical trials.

**We
depend on third parties to formulate and manufacture our products and related
devices. Our ability to generate commercial sales or conduct clinical trials
could suffer if our third-party suppliers and producers fail to perform.**

We manufacture
treprostinil with raw materials and advanced intermediate compounds supplied by
vendors. The inability of our vendors to supply these raw materials and
advanced intermediate compounds in the quantities we require could delay the
manufacture of treprostinil for commercial use and for use in clinical trials.

We also rely
on third parties to formulate our treprostinil-based products. Baxter
formulates Remodulin from the treprostinil we supply. In April 2009,
Baxter notified us that it intends to discontinue formulating Remodulin in October 2010
at the end of the current term of our agreement — as Baxter intends to retire
the production line currently used to formulate Remodulin. However, Baxter has
indicated that a secondary production line may be available to formulate
Remodulin. We are in discussions with Baxter regarding its continued
formulation of Remodulin beyond October 2010. In addition, we are in the
process of evaluating alternative supply arrangements, including the
formulation of Remodulin in our combination office and laboratory facility that
we are currently constructing adjacent to our Phase I Laboratory. We
expect to complete the construction of this facility by the end of 2009. In
addition, we are seeking other third-party formulation arrangements. To provide
additional assurance that adequate inventories of Remodulin will remain on hand
at all times, we intend to increase our supply of formulated Remodulin during
2009 to three years of expected demand and submit an application to extend the
expiration date for Remodulin from 30 months to 36 months worldwide.
Furthermore, we intend to maintain the increased inventory requirement in the
future. However, if we experience significant delays in receiving FDA approval
for an alternative supply arrangement, including approval for the Phase I
Laboratory, we may not have sufficient Remodulin in inventory to meet commercial
demand and our revenues could suffer.

Catalent
Pharma Solutions, Inc. (Catalent) conducts stability studies on Remodulin
for us, formulates treprostinil in both inhaled and oral forms for our clinical
trials and analyzes other products that we are developing. Beginning in the
second half of 2009, we plan to formulate oral treprostinil at our new
manufacturing facility in Research Triangle Park, North Carolina. This will be
our initial attempt at formulating oral treprostinil without the use of a third
party and we may therefore encounter unforeseen obstacles. Additionally, we
rely on third parties to manufacture all of our products other than
treprostinil.

We engage
NEBU-TEC to manufacture the Optineb nebulizer used with inhaled treprostinil.
NEBU-TEC is responsible for managing the manufacturing process of the Optineb
in accordance with all applicable regulatory requirements. Because regulatory
approval of inhaled treprostinil will be linked to regulatory approval of the
Optineb, any regulatory compliance problems encountered by NEBU-TEC relative to
the manufacture of this device could delay or adversely affect regulatory
approvals of inhaled treprostinil. Consequently, this could impede our growth
and our revenues could suffer. In addition, following regulatory approval of
inhaled treprostinil, any inability to manufacture the Optineb in sufficient
quantities to meet patient demand could have an adverse effect on our revenue
growth.

Pursuant to a
license arrangement entered into in 2008, Lilly agreed to grant us the
exclusive right to commercialize tadalafil, the active ingredient in Cialis,
for the treatment of pulmonary hypertension in the United States and Puerto
Rico. Upon receiving FDA approval of tadalafil for PAH, Lilly will manufacture
tadalafil for us and we will use Lilly’s wholesaler network to distribute
tadalafil.

Although our
current suppliers could be replaced, a change in suppliers may delay the
distribution of Remodulin and our other products and services, and impede the
progress of our clinical trials and commercial launch plans. This would
adversely affect our research and development and future sales efforts.

Our
manufacturing strategy includes the following risks:

35

* * *  
Table of Contents

· The manufacturing processes for some
of our investigational products have not been tested in quantities necessary
for commercial sales;

· We are planning to formulate all of
our treprostinil-based therapies for commercial use ourselves and have never done
so previously;

· A long lead time is needed to
manufacture treprostinil and Remodulin, and the manufacturing process is
complex;

· We and the manufacturers and
formulators of our products are subject to the FDA’s current Good Manufacturing
Practices in the United States and similar stringent regulatory standards
internationally. Although we can control compliance issues with respect to our
internal synthesis and manufacturing processes, we do not have control over
regulatory compliance by our third-party manufacturers;

· Even if we and the manufacturers and
formulators of our products were to comply with domestic and international drug
manufacturing regulations, the sterility and quality of the products being
manufactured and formulated could be deficient. If this were to occur, such
products would not be available for sale or use;

· If we have to replace a manufacturing
or formulation contractor for any reason or abandon our own manufacturing
operations, the FDA and international drug regulators would require new testing
and compliance inspections. Furthermore, a new manufacturer or formulator,
including any replacement for Baxter (who intends to discontinue formulating
Remodulin in October 2010), would have to be educated in the processes
necessary to manufacture and commercially validate our product;

· We may be unable to contract with
manufacturers and formulators for those products that we do not plan to
manufacture or formulate internally or may be unable to contract with
manufacturers and formulators that will serve as alternative suppliers for those
products that we plan to manufacture or formulate internally; and

· The supply of materials and
components necessary to manufacture and package Remodulin and our other
products may become scarce or interrupted. Disruptions to the supply of these
materials could delay the manufacture and subsequent sale of such products. Any
products manufactured with substituted materials or components would be subject
to approvals from the FDA and international regulatory agencies before they
could be sold. The timing of such FDA and international regulatory approval is
difficult to predict.

Any of these
factors could delay clinical studies or commercialization of our products,
entail higher costs, and result in our inability to effectively sell our
products.

**If our products
fail in clinical studies, we will be unable to obtain or maintain FDA and
international approvals and will be unable to sell those products.**

In order to
sell our pharmaceutical products, we must receive regulatory approvals. To
obtain those approvals, we must conduct clinical studies demonstrating that our
drug products, including their delivery mechanisms, are safe and effective.
Furthermore, the FDA and international regulatory agencies may require us to
perform additional clinical studies beyond those we planned. If we cannot
obtain approval from the FDA and international regulatory agencies for a
product, that product cannot be sold and our future revenue growth may decline.

36

* * *  
Table of Contents

In the past,
several of our product candidates have failed or been discontinued at various
stages in the product development process. Some of these products include:
OvaRex ® MAb for the treatment of advanced ovarian
cancer; immediate release beraprost for early stage peripheral vascular
disease; Ketotop for osteoarthritis of the knee and UT-77 for chronic
obstructive pulmonary disease.

In November 2008,
we reported that our FREEDOM-C trial of oral treprostinil did not achieve
statistical significance for its primary endpoint. As a result, we have
redesigned our current FREEDOM-M trial and planning for a new FREEDOM-C 2 trial. Consequently, we expect delays in
completing our clinical trials for oral treprostinil and do not anticipate
filing an NDA before 2012.

The length of
time that it takes for us to complete clinical trials and obtain regulatory
approval for product marketing varies by product and by product use. Furthermore,
we cannot predict with certainty the length of time it will take to complete
necessary clinical trials or obtain regulatory approval of our future products.

Our planned,
ongoing or completed clinical studies might be stopped, delayed, or disqualified
for various reasons. These reasons include:

· The drug is ineffective, or
physicians believe that the drug is ineffective;

· Patients do not enroll in our studies
at the rate we expect;

· Patients experience severe side
effects during treatment;

· Other investigational or approved
therapies are viewed as more effective or convenient by physicians or patients;

· Our clinical study sites do not
adhere to the study protocol;

· Our studies do not comply with
applicable regulations or guidelines;

· We do not pass inspections by
regulatory agencies;

· Patients die during our studies
because their disease is too advanced or because they experience medical
problems unrelated to the drug being studied or an adverse event related to the
study drug;

· Ongoing or new clinical trials
conducted by drug companies in addition to our own clinical trials may reduce
the number of patients available for our trials;

· Drug supplies are unavailable or
unsuitable for use in our studies; and

· The results of preclinical testing
cause delays in our studies.

In addition,
the FDA and international regulatory authorities have substantial discretion
over the approval process for pharmaceutical products. As such, these
regulatory agencies may not agree that we have demonstrated the requisite level
of product safety and efficacy.

**Our
corporate compliance program cannot guarantee that we comply with all
potentially applicable federal, state and international regulations.**

The
development, manufacture, distribution, pricing, sales, marketing, and
reimbursement of our products, together with our general operations, are
subject to extensive federal, state, local and international regulations that
are constantly changing and being updated with more stringent requirements.
While we have developed and instituted corporate compliance programs, we cannot
ensure that we will always be in compliance with these regulations. If we fail
to comply with any of these regulations, we could be subject to a range of
penalties including but not limited to: the termination of clinical trials, the
failure to approve a product candidate, restrictions on our products or
manufacturing processes, withdrawal of our products from the market,
significant fines, exclusion from government healthcare programs, and other
sanctions or litigation.

37

* * *  
Table of Contents

**If
the licenses, assignments and alliance agreements we depend on are breached or
terminated, we would lose our right to develop and sell the products covered by
such agreements.**

Our business
depends upon the acquisition, assignment and license of drugs and other
products that have been discovered and initially developed by others. Related
drugs and other products include Remodulin, tadalafil and all other products in
our key therapeutic platforms. Under our product license agreements, we receive
certain rights to existing intellectual property owned by third parties subject
to the terms of each license agreement. Our assignment agreements transfer all
right, title and interest in the intellectual property to us, subject to the
terms of each agreement. We also obtain licenses to other third-party
technologies to conduct our business. In addition, we may be required to obtain
licenses to other third party technologies to commercialize our early-stage
products. This dependence contains the following risks:

· We may be unable to obtain future
licenses or assignment agreements at a reasonable cost or at all;

· If any of our licenses or assignment
agreements are terminated, we will lose our rights to develop and market the
products covered by such licenses or assignment agreements;

· Our licenses and assignment
agreements generally provide the licensor or assignor the right to terminate in
the event we breach such agreements — e.g., we fail to pay royalties and
other fees timely;

· If a licensor or assignor fails to
maintain the intellectual property licensed or assigned to us as required by
most of our licenses and assignment agreements, we may lose our rights to
develop and market some or all of our products. In addition, we may be forced
to incur substantial costs to maintain the intellectual property ourselves or
force the licensor or assignor to do so; and,

· If Lilly is unable to obtain or
maintain FDA approval for tadalafil, we will be unable to develop and
commercialize tadalafil for the treatment of pulmonary hypertension.

**Certain
license and assignment agreements relating to our products may restrict our
ability to develop products in certain countries and/or for particular diseases
and may impose other restrictions on our freedom to develop and market our
products.**

When we
acquire, license, or receive assignments of drugs and other products that have
been discovered and initially developed by others, our rights may be limited.
For instance, our rights to market tadalafil are limited to the United States
and Puerto Rico. However, we would have an opportunity to negotiate with Lilly
for rights to market tadalafil in another country in the event that Lilly
decides not to market tadalafil in that country.

Provisions in
our license and assignment agreements may impose other restrictions that affect
the development and marketing of our products. For example, in assigning
Remodulin to us, Glaxo retained an exclusive option and right of first refusal
to negotiate a license agreement with us if we decide to license any aspect of
the commercialization of Remodulin anywhere in the world. Similarly, our
amended license agreement with Toray to develop and market beraprost-MR
includes a conditional non-compete clause benefiting Toray in that it grants
Toray the right to be our exclusive provider of beraprost-MR. We must also meet
certain minimum annual sales to maintain our exclusive rights to beraprost-MR.
Pursuant to our license agreement relating to the commercialization of
tadalafil, Lilly retains authority over all regulatory activities. In addition,
Lilly possesses the right to determine the retail price for tadalafil and the
price at which we will purchase tadalafil from Lilly. Furthermore, we cannot
undertake any additional investigatory work with respect to tadalafil in other
indications of pulmonary hypertension without the prior approval of Lilly.
These restrictions could affect our freedom to develop and market our products
in the future.

**If
our or our suppliers’ patents or other intellectual property protections are
inadequate, our revenues and profits could suffer or our competitors could
force our products out of the market.**

Our U.S.
patent for the method of treating PAH with Remodulin will expire in October 2014
(it has already received the maximum five-year extension) and our corresponding
patents in various countries throughout the EU will expire in June 2014
(based on the grant of our European patent term extension, which awards us the
maximum 5-year extension available in the EU). 
Our U.S. patents for inhaled treprostinil will expire in 2018 and our
corresponding patents in various countries throughout the EU will expire in March 2020.  Competitors may develop products based on the
same active ingredients as our products and market those products after our
patents expire, or design around or seek to invalidate our existing patents
before they expire.  If this happens, our
sales would suffer and our profits could decline significantly.  In addition, if our suppliers’ intellectual
property protection is inadequate, our sales and profits could be adversely
affected.  Pursuant to a license
arrangement entered into in 2008, Lilly granted us the exclusive right to
commercialize tadalafil, the active ingredient in Cialis, for the treatment of
pulmonary hypertension in the United States and Puerto Rico.  FDA approval of tadalafil for pulmonary
hypertension is

38

* * *  
Table of Contents

currently pending and the
patent for tadalafil relating to treatment of pulmonary hypertension expires in
2017\.  As a result, there is a limited
period before competing generic equivalents will enter the market.  Any delays in FDA approval would further
reduce the period during which we would be able to market tadalafil before
generic competitors enter the market.

We have been
granted patents in the U.S. for the synthesis of Remodulin, but other patent
applications that have been or may be filed by us may not result in the
issuance of additional patents.  The
scope of any patent may not be sufficient to deter competitors.  Furthermore, the patent laws of international
jurisdictions where we intend to sell our products may not protect our rights
to the same extent as the patent laws of the U.S.

In addition to
patent protection, we also rely on trade secrets, proprietary know-how and
technological advances.  We enter into
confidentiality agreements with our employees and others, but these agreements
may be ineffective in protecting our proprietary information.  Others may independently develop
substantially equivalent proprietary information or obtain access to our
know-how.

Litigation,
which can be costly, may be necessary to enforce or defend our patents or
proprietary rights and may not conclude in our favor.  While we have settled previous litigation to
enforce our arginine patents, we may initiate future litigation against other
parties we believe have violated our patents or other proprietary rights.  If such litigation is unsuccessful or if the
patents are invalidated or canceled, we may have to write off any related
intangible assets, which could significantly reduce our earnings.  Any licensed rights, patents or other
intellectual property we possess may be challenged, invalidated, canceled,
infringed or circumvented and therefore, may not provide any competitive
advantage to us.

In July 2005,
Vanderbilt University filed a lawsuit in the U.S. District Court for the
District of Delaware against ICOS Corporation (ICOS) seeking to add three
of its scientists as co-inventors of the tadalafil compound and method-of-use-patents.  Lilly has since acquired ICOS.  The patents that are the subject of this
lawsuit are the same patents licensed to us by Lilly under our December 2008
license agreement.  In January 2009,
the district court judge ruled in favor of ICOS/Lilly, declining to add any of
these scientists as an inventor on either patent.  The plaintiff may appeal this ruling.  Lilly believes these claims are without legal
merit and expects to prevail in any appeal of this litigation; however, it is
not possible to determine the outcome. 
An unfavorable final outcome could have a material adverse impact on our
license for tadalafil.

Patents may be
issued to others and this could impede the manufacture or sale of our
products.  We may have to license those
patents and pay significant fees or royalties to the owners of those patents in
order to keep marketing our products. 
These added fees could reduce our profits.

To the extent
valid third-party patents cover our products or services, we or our strategic
collaborators would be required to seek licenses from the holders of these
patents in order to manufacture, use, or sell our products and services.  Payments under these licenses would reduce
our profits from the sale of related products and services.  We may be unable to obtain these licenses on
acceptable terms, or at all.  If we fail
to obtain a required license or are unable to alter the design of our
technology to avoid infringing a third-party patent, we may be unable to market
some of our products and services, which would limit our sales and future
growth.

Proposed
changes to U.S. patent law are currently pending in Congress.  If these proposed patent reforms become law,
it could make it easier for patents to be invalidated and/or could reduce the
amount of damages awarded in cases of patent infringement.  Because we rely on patents to protect our
products, proposed patent reform could negatively impact our business.

Pursuant to
our agreements with certain business partners, any new inventions or
intellectual properties arising from our activities will be jointly owned by us
and these partners.  If we do not have
rights to new developments or inventions that arise during the terms of these
agreements, or we have to share the rights with others, we may lose some or all
of the benefit of these new developments or inventions, which may mean a loss
of future profits or cost savings.

**Our
success depends in large part on our ability to operate without infringing
third-party patents or other proprietary rights.**

If we infringe
third-party patents, we may be prevented from commercializing products or may
be required to obtain licenses from those third parties. We may be unable to
obtain alternative technologies or acquire a license on reasonable terms or at
all. If we fail to obtain such licenses or alternative technologies, we may be
unable to develop or commercialize some or all of our products.

39

* * *  
Table of Contents

**We
may not maintain adequate insurance and this could expose us to significant
product liability claims.**

The testing,
manufacturing, marketing, and sale of human drugs and diagnostics involve
product liability risks. Although we currently maintain product liability
insurance, we may not be able to maintain this insurance at an acceptable cost,
if at all. In addition, our insurance coverage may not be adequate for all
potential claims. If claims or losses significantly exceed our liability
insurance coverage, we may be forced out of business.

**Our
marketable investments maybe subject to a loss in value and liquidity.**

There has been
significant deterioration and instability in the financial markets. Even though
we believe we take a conservative approach to investing our funds, these
periods of extraordinary disruption and readjustment in the financial markets
expose us to investment risk. Related risks could result in a significant loss
of value and liquidity of our investments. Furthermore, issuers of the
securities we hold could be subject to credit rating downgrades. This could
result in future impairment charges with respect to our investment portfolio
and our cash flows and operating results could be negatively affected.

**If
we need additional financing and cannot obtain it, product development and
sales efforts may be limited.**

We may need to
spend more money than anticipated. Unplanned expenditures could be significant
and may result from necessary modifications to product development plans or
product offerings in response to difficulties encountered with clinical
studies. We may also face unexpected costs in preparing products for commercial
sales, or in maintaining sales of Remodulin. We may be unable to obtain
additional funds on commercially reasonable terms or at all. If additional
funds are unavailable, we may be compelled to delay clinical studies, curtail
operations or obtain funds through collaborative arrangements that may require
us to relinquish rights to certain products or potential markets.

Settlement of
our Convertible Senior Notes will involve significant outlays of our cash.
Specifically, the Convertible Senior Notes will require us to repay in cash,
upon maturity or conversion, the approximately $250.0 million principal
balance or the conversion value, whichever is less. Under the current market
conditions, some of the holders of our Convertible Senior Notes may seek
liquidity, which could cause them to convert their notes prior to the maturity
date. If we do not have sufficient financial resources or are unable to obtain
suitable financing to pay amounts due upon the maturity or conversion of the
Convertible Senior Notes, we would be in default.

We adopted our
STAP in June 2008. Awards granted under our STAP entitle participants to
receive in cash an amount equal to the appreciation in our common stock, which
is calculated as the positive difference between the closing price of our
common stock on the date of grant and the date of exercise. Consequently, we
may be required to make significant cash payments under the STAP. If we do not
have sufficient funds to meet our obligations under our STAP, or are unable to
secure alternative sources of financing on terms acceptable to us, we may lose
key employees and could face litigation.

**Improper
handling of hazardous materials used in our activities could expose us to
significant liabilities.**

Our research
and development and manufacturing activities involve the controlled use of
chemical and hazardous substances. Furthermore, we are expanding these
activities to new locations. In addition, patients may dispose of excess
treprostinil using means we do not control. Such activities subject us to
numerous federal, state, and local environmental and safety laws and
regulations. These laws and regulations govern the management, storage and
disposal of hazardous materials. We may be required to incur significant costs
in order to comply with current or future environmental laws and regulations.
We may also be subject to substantial fines and penalties for failure to comply
with these laws and regulations. While we believe we comply with laws and
regulations governing these materials, the risk of accidental contamination or
injury from these materials cannot be completely eliminated. Furthermore, once
chemical and hazardous materials leave our site, we cannot control what our
hazardous waste removal contractors choose to do with these materials. In the
event of an accident, we could be liable for substantial civil damages or costs
associated with the cleanup of the release of hazardous materials. Any related
liability could exceed our resources and could have a materially adverse effect
on our business, financial condition and results of operations.

40

* * *  
Table of Contents

**We
may encounter substantial difficulties managing our growth.**

Several risks
are inherent in our business development plans. Achieving our goals will
require substantial investments in research and development, sales and
marketing, and facilities. For example, we have spent considerable resources
building and seeking regulatory approvals for our laboratories and
manufacturing facilities. These facilities may be insufficient to meet future
demand for our products. Conversely, we may have excess capacity at these
facilities if future demand falls short of our expectations. In addition,
constructing our facilities is expensive, and our ability to recover our
investment will depend on sales of the products manufactured at these
facilities in sufficient volume to substantially increase our revenues.

If we
experience sales growth, we may have difficulty managing inventory levels.
Marketing new therapies is complicated, and gauging future demand is difficult
and uncertain.

**We
invest in auction-rate securities that are subject to market risk and the
recent problems in the financial markets could adversely affect the value and
liquidity of our investments in these securities.**

As of March 31,
2009, our non-current marketable securities included approximately
$36.8 million (par value) in ARS that have remained illiquid since February 2008.
In November 2008, we elected to participate in a court-ordered repurchase
program run by the investment firm from which we purchased our ARS. From the
period beginning on June 30, 2010 and ending July 2, 2012, we can
require the investment firm to repurchase any of our ARS at par value. Our
ability to fully recover the carrying amount of these investments is limited in
the near term. Furthermore, we may never recover the value of these securities
if the investment firm fails to perform its obligations under the repurchase
program or we cannot sell these securities ourselves under satisfactory terms.

**Our
ability to recognize the full value of our business tax credits may be limited.**

As of March 31,
2009, we had approximately $50.3 million in business tax credit
carryforwards. These tax credit carryforwards expire on various dates through
2028\. The Internal Revenue Service (IRS) has not yet audited or reviewed these
business tax credits since we have not yet utilized them. We have conducted
reviews of these business tax credits and have recognized reserves for those
business tax credits that we believe may be disallowed upon examination by the
IRS. However, it is possible that the IRS may reduce our business tax credits
further. Any reduction in business tax credits will increase our tax expense
and shorten the period before we are required to pay federal income taxes.

In addition,
certain business tax credit carryforwards that were generated at various dates
prior to December 2007 may be subject to limitations on their use pursuant
to Internal Revenue Code Section 382 (Section 382) as a result of
ownership changes as defined therein. Presently, we do not expect that these
business tax credits will expire unused. If Section 382 ownership changes
occur in the future, the utilization of related carryforwards may be deferred
and may expire unused.

Furthermore,
our future operations may not generate sufficient taxable profits in order to
utilize our business tax credit carryforwards. In such an event, all or a
portion of our business tax credit carryforwards might expire unused.

**Risks Related to Our Common Stock**

**The
price of our common stock could be volatile and could decline.**

The common
stock of drug and biotechnology companies is subject to a substantial degree of
volatility. As such, there may be significant price and volume fluctuations in
the market that may be unrelated to a particular company’s operating
performance. The table below sets forth the high and low closing prices for our
common stock for the periods indicated:

| | |**High** | |**Low** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|January 1, 2007—December 31, 2007 | |$ |108\.62 | |$ |47\.87 | |
|January 1, 2008—December 31, 2008 | |$ |115\.98 | |$ |49\.01 | |
|January 1, 2009—March 31, 2009 | |$ |73\.28 | |$ |59\.19 | |

The price of
our common stock could decline suddenly due to the following factors, among
others:

· Quarterly and annual financial and
operating results;

· Failure to meet estimates or
expectations of securities analysts or our projections;

41

* * *  
Table of Contents

· The pace of enrollment in and results
of our clinical trials;

· Physician, patient, investor or
public concerns regarding the efficacy and/or safety of products marketed or
being developed by us or by others;

· Changes in, or new legislation and
regulations affecting reimbursement of Remodulin by Medicare or Medicaid and
changes in reimbursement policies of private health insurance companies;

· Announcements by us or others of
technological innovations or new products or announcements regarding our
existing products;

· Developments in patent or other
proprietary rights;

· Future sales of substantial amounts
of our common stock by us or our existing stockholders;

· Future issuances of common stock by
us or any other activity which could be viewed as being dilutive to our
shareholders;

· Rumors among or incorrect statements
by investors and/or analysts concerning our company, our products, or
operations;

· Failure to maintain, or changes to,
our approvals to sell Remodulin;

· Failure to obtain approval of a NDA
from the FDA and international regulatory agencies;

· Failure to obtain approval for our
Phase I Laboratory from the FDA and international regulatory agencies;

· Accumulation of significant short
positions in our common stock by hedge funds or other investors or the
significant accumulation of our common stock by hedge funds or other
institutional investors with investment strategies that may lead to short-term
holdings;

· Timing and outcome of additional regulatory
submissions and approvals; and

· General market conditions.

**We
may fail to meet third-party projections for our revenue or profits.**

Many
independent securities analysts publish quarterly and annual projections of our
revenues and profits. These projections are developed independently by the
securities analysts based on their own analyses. Such estimates are inherently
subject to uncertainty, particularly because we do not generally provide
forward-looking guidance to the public. As a result, actual revenues and net
income may differ from projections developed by securities analysts. Even small
variations in reported revenues and profits compared to securities analysts’
expectations can lead to significant changes in our stock price.

**Sales
of shares of our common stock may depress our stock price.**

The price of
our common stock could decline upon the occurrence of any of the following
events: if we issue common stock to raise capital or to acquire a license or
business; if our stockholders transfer ownership of our common stock, or sell
substantial amounts in the public market; or, if investors become concerned
that substantial sales of our common stock may occur. A decrease in the price
of our common stock could make it difficult for us to raise capital or fund
acquisitions through the use of our stock.

42

* * *  
Table of Contents

The conversion
of some or all of the Convertible Senior Notes when the price of our common
stock reaches or exceeds $105.67 per share would dilute the ownership interests
of our existing stockholders. The Convertible Senior Notes are convertible
initially into approximately 3.3 million shares of our common stock. Any
sales in the public market of our common stock issued upon such conversion
could adversely affect the prevailing market price of our common stock.
Furthermore, the existence of the Convertible Senior Notes may encourage short
selling by market participants because the conversion of the Convertible Senior
Notes could depress the price of our common stock.

To the extent
outstanding options are exercised or additional shares of capital stock are
issued, existing stockholder ownership may be further diluted.

**The
fundamental change purchase feature of the Convertible Senior Notes may delay
or prevent an otherwise beneficial attempt to take over our company.**

We may be
required to repurchase the Convertible Senior Notes by their holders in the
event of a fundamental change, which includes a takeover of our company. This
may delay or prevent a takeover of our company that would otherwise be
beneficial to our stockholders.

**Provisions
of Delaware law and our certificate of incorporation, by-laws, shareholder
rights plan, and employment and license agreements could prevent or delay a
change of control or change in management that may be beneficial to our public
stockholders.**

Certain
provisions of Delaware law and our certificate of incorporation, by-laws and
shareholder rights plan may prevent, delay or discourage:

· A merger, tender offer or proxy
contest;

· The assumption of control by a holder
of a large block of our securities; and

· The replacement or removal of current
management by our stockholders.

For example,
our certificate of incorporation divides our Board into three classes. Members
of each class are elected for staggered three-year terms. This provision may
make it more difficult for stockholders to change the majority of directors. It
may also deter the accumulation of large blocks of our common stock by limiting
the voting power of such blocks.

Non-compete
and other restrictive covenants in most of our employment agreements will
terminate upon a change in control that is not approved by our Board.

We enter into
certain license agreements that generally prohibit our counterparties to these
agreements or their affiliates from taking necessary steps to acquire or merge
with us, either directly or indirectly throughout the term of these agreements,
plus a specified period thereafter. We are also party to certain license
agreements that restrict our ability to assign or transfer the rights licensed
to us thereunder to third parties, including parties with whom we wish to
merge, or those attempting to acquire us. These agreements often require that
we obtain the prior consent of the counterparties to these agreements if we are
contemplating a change in control. If our counterparties to these agreements
withhold their consent, related agreements could be terminated and we would
lose all rights thereunder. These restrictive change-in-control provisions
could impede or prevent mergers that could benefit our stockholders.

**Our
existing directors and executive officers own a substantial portion of our
common stock and might be able to influence the outcome of matters requiring
stockholder approval.**

Our directors
and executive officers beneficially owned approximately 6.3% of our outstanding
common stock as of March 31, 2009. Shares beneficially owned include stock
options that could be exercised by those directors and executive officers
within 60 days of March 31, 2009. Accordingly, these stockholders as
a group may be able to influence the outcome of matters requiring stockholder
approval, including the election of our directors. Such stockholder influence
could delay or prevent a change in control that could benefit our stockholders.

43

* * *  
Table of Contents

**Because
we do not intend to pay dividends, stockholders must rely on stock appreciation
for any return on their investment in us.**

We have never
declared or paid cash dividends on any of our capital stock. Furthermore, we
intend to retain our earnings for future growth and therefore do not anticipate
paying cash dividends in the future. As a result, the return on an investment
in our common stock will depend entirely upon the future appreciation in our
stock price. There can be no assurances that our common stock will appreciate
in value or even maintain the price at which stockholders have purchased their
shares.

**Item 5.   OTHER INFORMATION**

**_Indemnification Agreements_**

On April 29, 2009, our
Board, acting upon the recommendation of its nominating and governance
committee, approved a new form of indemnification agreement for our directors
and executive officers (Indemnification Agreement).  Following Board approval, we entered into
Indemnification Agreements with each of our current directors and executive
officers.  These Indemnification Agreements
supersede and replace any prior indemnification agreements between us and our
directors and executive officers.

The Indemnification
Agreement clarifies and updates the prior form of indemnification agreement,
which we had used since 1999.  The Indemnification
Agreement provides for indemnification against expenses, judgments, fines and
penalties actually and reasonably incurred by an indemnitee in connection with
threatened, pending or completed actions, suits or other proceedings, subject
to certain limitations.  The
Indemnification Agreement also provides for the advancement of expenses in
connection with a proceeding prior to a final, nonappealable judgment or other
adjudication, provided that the indemnitee provides an undertaking to repay to
us any amounts advanced if the indemnitee is ultimately found not to be
entitled to indemnification by us.  The
Indemnification Agreement sets forth procedures for making and responding to a
request for indemnification or advancement of expenses, as well as dispute
resolution procedures that will apply to any dispute between us and an
indemnitee arising under the Indemnification Agreement.

The foregoing description is
qualified in its entirety by reference to the form of Indemnification Agreement
attached hereto as Exhibit 10.1

**Item 6.    EXHIBITS**

|**Exhibit No.** | |**Description** |
| --- | --- | --- | --- |
| | | |
|3\.1 | | |Amended and
Restated Certificate of Incorporation of the Registrant, incorporated by
reference to Exhibit 3.1 of the Registrant’s Registration Statement on
Form S-1 (Registration No. 333-76409) |
| | | | |
|3\.2 | | |Second
Amended and Restated By-laws of the Registrant, incorporated by reference to
Exhibit 3.2 to the Registrant’s Quarterly Report on Form 10-Q for
the fiscal quarter ended March 31, 2008 |
| | | | |
|10\.1 |\* | |Form of
Indemnification Agreement entered into by the Registrant and each of its Directors
and Executive Officers |
| | | | |
|10\.2 |\* | |Amended and
Restated Executive Employment Agreement between the Registrant and Martine A.
Rothblatt, effective as of January 1, 2009 |
| | | | |
|10\.3 |\* | |Form of
Amendment to Executive Employment Agreement for Roger Jeffs, Paul Mahon and
John Ferrari, effective as of January 1, 2009 |
| | | | |
|12\.1 | | |Ratio of
Earnings to Fixed Charges |
| | | | |
|31\.1 | | |Certification
of Chief Executive Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
| | | | |
|31\.2 | | |Certification
of Chief Financial Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
| | | | |
|32\.1 | | |Certification
of Chief Executive Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |
| | | | |
|32\.2 | | |Certification
of Chief Financial Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |

* * *

\*   
Designates management contracts and compensation plans.

44

* * *  
Table of Contents

**SIGNATURES**

Pursuant to the requirements of the Securities
Exchange Act of 1934, the registrant has duly caused this report to be signed
on its behalf by the undersigned thereunto duly authorized.

| |UNITED
THERAPEUTICS CORPORATION |
| --- | --- | --- |
| | | |
| | | |
|Date:
May 1, 2009 |/s/
MARTINE A. ROTHBLATT |
| |By: |Martine A.
Rothblatt, Ph.D. |
| |Title: |_Chairman
and Chief Executive Officer_ |
| | |
| | |
| |/s/ JOHN M.
FERRARI |
| |By: |John M.
Ferrari |
| |Title: |_Chief
Financial Officer and Treasurer_ |

45

* * *  
Table of Contents

**EXHIBIT
INDEX**

|**Exhibit No.** | |**Description** |
| --- | --- | --- | --- |
| | | |
|3\.1 | | |Amended and
Restated Certificate of Incorporation of the Registrant, incorporated by
reference to Exhibit 3.1 of the Registrant’s Registration Statement on
Form S-1 (Registration No. 333-76409) |
| | | | |
|3\.2 | | |Second
Amended and Restated By-laws of the Registrant, incorporated by reference to
Exhibit 3.2 to the Registrant’s Quarterly Report on Form 10-Q for
the fiscal quarter ended March 31, 2008 |
| | | | |
|10\.1 |\* | |Form of
Indemnification Agreement entered into by the Registrant and each of its Directors
and Executive Officers |
| | | | |
|10\.2 |\* | |Amended and
Restated Executive Employment Agreement between the Registrant and Martine A.
Rothblatt, effective as of January 1, 2009 |
| | | | |
|10\.3 |\* | |Form of
Amendment to Executive Employment Agreement for Roger Jeffs, Paul Mahon and
John Ferrari, effective as of January 1, 2009 |
| | | | |
|12\.1 | | |Ratio of
Earnings to Fixed Charges |
| | | | |
|31\.1 | | |Certification
of Chief Executive Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
| | | | |
|31\.2 | | |Certification
of Chief Financial Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
| | | | |
|32\.1 | | |Certification
of Chief Executive Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |
| | | | |
|32\.2 | | |Certification
of Chief Financial Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |

* * *

\*   
Designates management contracts and compensation plans.

46

* * *