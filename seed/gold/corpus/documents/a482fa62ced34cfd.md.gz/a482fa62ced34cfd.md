EX-99.1 2 a14-17848\_1ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: James Edgemond

(301) 608-9292

Jedgemond@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**SECOND QUARTER 2014 FINANCIAL RESULTS**

· **Total Revenues of $322.8 million**

· **Earnings per Share of $2.35 per Basic Share or $2.10 per Diluted Share**

· **Non-GAAP Earnings of $2.57 per Basic Share or $2.30 per Diluted Share**

Silver Spring, MD, July 29, 2014: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the second quarter ended June 30, 2014.

“Our continued growth shows that our medicines are reaching increasing numbers of patients suffering from pulmonary arterial hypertension (PAH),” said Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “The commercial launch this quarter of our extended-release tablet called Orenitram ® harkens an opportunity to bring prostacyclin-based medicine to more PAH patients in the U.S. than ever before, by providing a less-invasive route of administration than our prostacyclin infusion therapy called Remodulin ® .”

Total revenues for the quarter ended June 30, 2014 were $322.8 million, up from $280.6 million for the quarter ended June 30, 2013. Net income for the quarter ended June 30, 2014 was $111.9 million or $2.35 per basic share, compared to $79.9 million or $1.60 per basic share for the same quarter in 2013. Gross margin from sales was $282.6 million for the quarter ended June 30, 2014, compared to $245.2 million for the same quarter last year. Non-GAAP earnings(1) for the quarter ended June 30, 2014 were $122.4 million, compared to $125.1 million for the same quarter in 2013.

* * *

(1) See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net income to non-GAAP earnings below.

* * *  
**Financial Results for the Three Months Ended June 30, 2014**

_Revenues_

The table below summarizes the components of net revenues (dollars in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Cardiopulmonary products: | | | | | | | |
|Remodulin | |$ |138,152 | |$ |124,311 | |11\.1 |% |
|Tyvaso | |121,227 | |109,458 | |10\.8 |% |
|Adcirca | |55,318 | |43,726 | |26\.5 |% |
|Orenitram | |6,632 | |— | |100\.0 |% |
|Other | |1,473 | |3,111 | |(52.7 |)% |
|Total net revenues | |$ |322,802 | |$ |280,606 | |15\.0 |% |

Revenues for the quarter ended June 30, 2014 increased by $42.2 million, compared to the same quarter in 2013. The growth in product revenues reflects the continuing increase in the number of patients being treated with our products and the launch of Orenitram.

_Expenses_

The table below summarizes research and development expense by major project and non-project components (dollars in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Project and non-project component: | | | | | | | |
|Cardiopulmonary | |$ |28,274 | |$ |28,537 | |(0.9 |)% |
|Share-based compensation expense | |1,047 | |14,158 | |(92.6 |)% |
|Other | |10,421 | |11,922 | |(12.6 |)% |
|Total research and development expense | |$ |39,742 | |$ |54,617 | |(27.2 |)% |

_Share-based compensation._ The decrease in share-based compensation of $13.1 million for the quarter ended June 30, 2014, compared to the same quarter in 2013, resulted primarily from the decline in the price of our common stock.

The table below summarizes selling, general and administrative expense by major categories (dollars in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Category: | | | | | | | |
|General and administrative | |$ |47,889 | |$ |35,445 | |35\.1 |% |
|Sales and marketing | |22,046 | |17,344 | |27\.1 |% |
|Share-based compensation (benefit) expense | |(1,904 |) |18,576 | |(110.2 |)% |
|Total selling, general and administrative expense | |$ |68,031 | |$ |71,365 | |(4.7 |)% |

_General and administrative._ The increase in general and administrative expense of $12.4 million for the quarter ended June 30, 2014, compared to the same quarter in 2013, was driven by increases in professional and consulting fees, salaries and related expenses and grants to non-affiliated, not-for-profit organizations.

_Sales and marketing._ The increase in sales and marketing expense of $4.7 million for the three months ended June 30, 2014, compared to the same three-month period in 2013, was the result of expenses incurred with the commercial launch of Orenitram and an increase in salaries and related expenses due to the growth of our sales operations.

* * *  
_Share-based compensation._ The decrease in share-based compensation of $20.5 million for the quarter ended June 30, 2014, compared to the same quarter in 2013, resulted from the decline in the price of our common stock.

_Income Taxes_

The provision for income taxes was $61.2 million for the quarter ended June 30, 2014, compared to $38.7 million for the same quarter in 2013. Our estimated annual effective tax rates were 35 percent and 33 percent as of June 30, 2014 and June 30, 2013, respectively.  Our 2014 estimated annual effective tax rate increased as of June 30, 2014 primarily due to a reduction in the amount of business tax credits we expect to generate during 2014 versus our estimate at June 30, 2013.

**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for the following charges, as applicable: (1) interest; (2) license fees; (3) depreciation and amortization; (4) impairment charges; and (5) share-based compensation (stock option, share tracking award and employee stock purchase plan expense).

A reconciliation of net income to non-GAAP earnings is presented below (in thousands, except per share data):

| | |**Three Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |
|Net income, as reported | |$ |111,852 | |$ |79,864 | |
|Adjust for the following charges: | | | | | |
|Interest expense | |4,746 | |4,520 | |
|License fees | |— | |— | |
|Depreciation and amortization | |7,641 | |7,680 | |
|Impairment charges | |— | |— | |
|Share-based compensation (benefit) expense | |(1,873 |) |32,986 | |
|Non-GAAP earnings | |$ |122,366 | |$ |125,050 | |
| | | | | | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |2\.57 | |$ |2\.51 | |
|Diluted | |$ |2\.30 | |$ |2\.38 | |
| | | | | | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |47,617 | |49,800 | |
|Diluted | |53,252 | |52,648 | |

**Conference Call**

We will host a half-hour teleconference on Tuesday, July 29, 2014, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406 and using access code 67533397.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

* * *  
**About Orenitram (treprostinil) Extended-Release Tablets**

Indication

Orenitram is a prostacyclin vasodilator indicated for treatment of pulmonary arterial hypertension (PAH) (WHO Group 1) to improve exercise capacity. The study that established effectiveness included predominately patients with WHO functional class II-III symptoms and etiologies of idiopathic or heritable PAH (75%) or PAH associated with connective tissue disease (19%).

When used as the sole vasodilator, the effect of Orenitram on exercise is about 10% of the deficit, and the effect, if any, on a background of another vasodilator is probably less than this. Orenitram is probably most useful to replace subcutaneous, intravenous, or inhaled treprostinil, but this use has not been studied.

Important Safety Information for Orenitram

· Orenitram is contraindicated in patients with severe hepatic impairment (Child Pugh Class C).

· Abrupt discontinuation or sudden large reductions in dosage of Orenitram may result in worsening of PAH symptoms.

· Orenitram inhibits platelet aggregation and increases the risk of bleeding.

· Orenitram should not be taken with alcohol as release of treprostinil from the tablet may occur at a faster rate than intended.

· The Orenitram tablet shell does not dissolve. In patients with diverticulosis (blind-end pouches), Orenitram tablets can lodge in a diverticulum.

· Concomitant administration of Orenitram with diuretics, antihypertensive agents, or other vasodilators increases the risk of symptomatic hypotension.

· Orenitram inhibits platelet aggregation; there is an increased risk of bleeding, particularly among patients receiving anticoagulants.

· Co-administration of Orenitram and the CYP2C8 enzyme inhibitor gemfibrozil increases exposure to treprostinil; therefore, Orenitram dosage reduction may be necessary in these patients.

· Pregnancy Category C.  Animal reproductive studies with Orenitram have shown an adverse effect on the fetus.  There are no adequate and well-controlled studies in humans.

· Safety and effectiveness in patients under 18 years of age have not been established.

· There is a marked increase in the systemic exposure to treprostinil in hepatically impaired patients.

· In the 12-week placebo-controlled monotherapy study, adverse reactions with rates at least 5% higher on Orenitram than on placebo included headache, diarrhea, nausea, flushing, pain in jaw, pain in extremity, hypokalemia, and abdominal discomfort.

**For Full Prescribing Information for Orenitram, visit www.orenitram.com or call 1-877-UNITHER (1-877-864-8437).**

**About Remodulin (treprostinil) Injection**

Indication

Remodulin is a prostacyclin vasodilator indicated for the treatment of pulmonary arterial hypertension (PAH) (WHO Group 1) to diminish symptoms associated with exercise. Studies establishing effectiveness included patients with NYHA Functional Class II-IV symptoms and etiologies of idiopathic or heritable PAH (58%), PAH associated with congenital systemic-to-pulmonary shunts (23%), or PAH associated with connective tissue diseases (19%). It may be administered as a continuous subcutaneous infusion or continuous intravenous infusion; however, because of the risks associated with chronic indwelling central venous catheters, including serious blood stream infections, continuous intravenous infusion should be reserved for patients who are intolerant of the subcutaneous route, or in whom these risks are considered warranted.

In patients with PAH requiring transition from Flolan ® (epoprostenol sodium), Remodulin is indicated to diminish the rate of clinical deterioration. The risks and benefits of each drug should be carefully considered prior to transition.

Important Safety Information for Remodulin

· Chronic intravenous (IV) infusions of Remodulin are delivered using an indwelling central venous catheter. This route is associated with the risk of blood stream infections (BSI) and sepsis, which may be fatal. Therefore, continuous subcutaneous (SC) infusion is the preferred mode of administration.

· Remodulin should be used only by clinicians experienced in the diagnosis and treatment of PAH.

· Remodulin is a potent pulmonary and systemic vasodilator. It lowers blood pressure, which may be further lowered by other drugs that also reduce blood pressure.

· Remodulin inhibits platelet aggregation and therefore, may increase the risk of bleeding, particularly in patients on anticoagulants.

* * *  
· Remodulin dosage adjustment may be necessary if inhibitors or inducers of CYP2C8 are added or withdrawn

· Initiation of Remodulin must be performed in a setting with adequate personnel and equipment for physiological monitoring and emergency care.

· Therapy with Remodulin may be used for prolonged periods, and the patient’s ability to administer Remodulin and care for an infusion system should be carefully considered.

· Remodulin dosage should be increased for lack of improvement in, or worsening of, symptoms and it should be decreased for excessive pharmacologic effects or for unacceptable infusion site symptoms.

· Abrupt withdrawal or sudden large reductions in dosage of Remodulin may result in worsening of PAH symptoms and should be avoided.

· Caution should be used in patients with hepatic or renal insufficiency.

· Adverse Events: In clinical studies of SC Remodulin infusion, the most common adverse events reported were infusion site pain and infusion site reaction (redness and swelling). These symptoms were often severe and sometimes required treatment with narcotics or discontinuation of Remodulin. The IV infusion of Remodulin has been associated with a risk of blood stream infections, arm swelling, paresthesias, hematoma, and pain. Other common adverse events ( > 3% more than placebo) seen with either SC or IV Remodulin were headache, diarrhea, nausea, jaw pain, vasodilatation, and edema.

**For Full Prescribing Information for Remodulin, visit http://www.remodulin.com or call 1-877-UNITHER (1-877-864-8437).**

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of unique products to address the unmet medical needs of patients with chronic and life-threatening conditions.

**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, that does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP.  A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, _Non-GAAP Earnings._

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, our expectations about continued increases in the number of patients using our therapies and our expectations regarding Orenitram’s potential. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of the date of this press release, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason. [uthr-g]

Orenitram, Remodulin and Tyvaso are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In thousands, except per share data)**

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**2014** | |**2013** | |
| | |**(Unaudited)** | |**(Unaudited)** | |
|Revenues: | | | | | | | | | |
|Net product sales | |$ |321,329 | |$ |277,495 | |$ |605,882 | |$ |520,641 | |
|Other | |1,473 | |3,111 | |6,323 | |5,101 | |
|Total revenues | |322,802 | |280,606 | |612,205 | |525,742 | |
|Operating expenses: | | | | | | | | | |
|Research and development | |39,742 | |54,617 | |52,190 | |105,047 | |
|Selling, general and administrative | |68,031 | |71,365 | |98,246 | |142,721 | |
|Cost of product sales | |38,709 | |32,320 | |69,309 | |61,633 | |
|Total operating expenses | |146,482 | |158,302 | |219,745 | |309,401 | |
|Operating income | |176,320 | |122,304 | |392,460 | |216,341 | |
|Other (expense) income: | | | | | | | | | |
|Interest income | |1,110 | |869 | |2,343 | |1,848 | |
|Interest expense | |(4,746 |) |(4,520 |) |(9,356 |) |(8,956 |) |
|Other, net | |349 | |(134 |) |802 | |121 | |
|Total other (expense) income, net | |(3,287 |) |(3,785 |) |(6,211 |) |(6,987 |) |
|Income before income taxes | |173,033 | |118,519 | |386,249 | |209,354 | |
|Income tax expense | |(61,181 |) |(38,655 |) |(136,873 |) |(67,165 |) |
|Net income | |$ |111,852 | |$ |79,864 | |$ |249,376 | |$ |142,189 | |
|Net income per common share: | | | | | | | | | |
|Basic | |$ |2\.35 | |$ |1\.60 | |$ |5\.09 | |$ |2\.84 | |
|Diluted | |$ |2\.10 | |$ |1\.52 | |$ |4\.54 | |$ |2\.71 | |
|Weighted average number of common shares outstanding: | | | | | | | | | |
|Basic | |47,617 | |49,800 | |49,002 | |50,003 | |
|Diluted | |53,252 | |52,648 | |54,948 | |52,386 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**June 30, 2014**

**(Unaudited, in billions)**

|Cash, cash equivalents and marketable securities (excluding restricted amounts) | |$ |0\.76 | |
| --- | --- | --- | --- | --- |
|Total assets | |1\.95 | |
|Total liabilities and temporary equity | |0\.78 | |
|Total stockholders’ equity | |1\.17 | |

* * *