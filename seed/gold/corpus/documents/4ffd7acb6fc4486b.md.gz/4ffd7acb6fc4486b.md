EX-99.1 2 a16-8745\_1ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: James Edgemond

(301) 608-9292

Jedgemond@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**FIRST QUARTER 2016 FINANCIAL RESULTS**

Silver Spring, MD and Research Triangle Park, NC, April 28, 2016: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the first quarter ended March 31, 2016.

“Our total revenues increased as compared to the same period in the prior year, which shows that our medicines are continuing to reach an increasing number of patients suffering from pulmonary arterial hypertension (PAH) and other life threatening diseases,” said Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Co-Chief Executive Officer. “Within our PAH product franchise, Orenitram ® continues to be prescribed to a growing number of patients and this momentum underscores our belief in the increasing clinical support for the use of our orally-administered prostacyclin analogues.”

Key financial highlights include (in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |**Selected  
Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Changes** | |
| | | | | | | | |
|Revenues | |$ |369\.0 | |$ |327\.5 | |12\.7 |% |
|Net income (loss) | |$ |235\.5 | |$ |(16.6 |) |NM |(2) |
|Non-GAAP earnings (1) | |$ |147\.3 | |$ |135\.0 | |9\.1 |% |
|Net income (loss), per diluted share | |$ |4\.84 | |$ |(0.36 |) |NM |(2) |
|Non-GAAP earnings, per diluted share (1) | |$ |3\.02 | |$ |2\.55 | |18\.4 |% |

* * *

(1)  See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net income to non-GAAP earnings below.

(2)  Calculation is not meaningful.

**Financial Results for the Three Months Ended March 31, 2016**

**Revenues**

The table below summarizes the components of total revenues (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Net product sales: | | | | | | | |
|Remodulin ® | |$ |139\.8 | |$ |146\.3 | |(4.4 |)% |
|Tyvaso ® | |102\.2 | |113\.4 | |(9.9 |)% |
|Adcirca ® | |72\.6 | |45\.3 | |60\.3 |% |
|Orenitram ® | |40\.2 | |20\.9 | |92\.3 |% |
|Unituxin ® | |14\.2 | |— | |N/A | |
|Other | |— | |1\.6 | |(100.0 |)% |
|Total revenues | |$ |369\.0 | |$ |327\.5 | |12\.7 |% |

Revenues for the three months ended March 31, 2016 increased by $41.5 million compared to the same period in 2015. The growth in revenues primarily resulted from: (1) a $27.3 million increase in Adcirca net product sales; (2) a $19.3 million increase in Orenitram net product sales; and (3) a $14.2 million increase in Unituxin net product sales. These revenue increases were partially offset by: (1) an $11.2 million decrease in Tyvaso net product sales; and (2) a $6.5 million decrease in Remodulin net product sales.

1

* * *  
**Expenses**

**Cost of product sales.** The table below summarizes cost of product sales by major categories (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|Cost of product sales | |$ |12\.6 | |$ |11\.2 | |12\.5 |% |
|Share-based compensation (benefit) expense | |(11.9 |) |9\.6 | |(224.0 |)% |
|Total cost of product sales | |$ |0\.7 | |$ |20\.8 | |(96.6 |)% |

_Share-based compensation._ The decrease in share-based compensation of $21.5 million for the three months ended March 31, 2016, as compared to the same period in 2015, corresponded to a 29 percent decrease in the price of our common stock during the three months ended March 31, 2016, compared to a 33 percent increase in the price of our common stock during the same period in 2015.

**Research and development expense.** The table below summarizes research and development expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|Research and development expense | |$ |36\.8 | |$ |35\.2 | |4\.5 |% |
|Share-based compensation (benefit) expense | |(37.2 |) |75\.0 | |(149.6 |)% |
|Total research and development expense | |$ |(0.4 |) |$ |110\.2 | |(100.4 |)% |

_Share-based compensation._ The decrease in share-based compensation of $112.2 million for the three months ended March 31, 2016, as compared to the same period in 2015, corresponded to a 29 percent decrease in the price of our common stock during the three months ended March 31, 2016, compared to a 33 percent increase in the price of our common stock during the same period in 2015.

**Selling, general and administrative expense.** The table below summarizes selling, general and administrative expense by major categories (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|General and administrative | |$ |78\.2 | |$ |37\.7 | |107\.4 |% |
|Sales and marketing | |22\.3 | |23\.7 | |(5.9 |)% |
|Share-based compensation (benefit) expense | |(95.5 |) |149\.9 | |(163.7 |)% |
|Total selling, general and administrative expense | |$ |5\.0 | |$ |211\.3 | |(97.6 |)% |

_General and administrative._ The increase in general and administrative expense of $40.5 million for the three months ended March 31, 2016, as compared to the same period in 2015, was primarily attributable to $37.0 million of charitable donations to a non-affiliated, non-profit organization that provides financial assistance to patients with PAH. These donations were made during the first quarter of 2016 and represent the full extent of our funding to this non-affiliated, non-profit organization for 2016. Our donations to the same non-affiliated, non-profit organization in 2015 totaled $17.0 million, all of which were paid during the second quarter of that year. We expense these types of grant payments in the period they are made.

_Share-based compensation._ The decrease in share-based compensation of $245.4 million for the three months ended March 31, 2016, as compared to the same period in 2015, corresponded to a 29 percent decrease in the price of our common stock during

2

* * *  
the three months ended March 31, 2016, compared to a 33 percent increase in the price of our common stock during the same period in 2015.

**Income Tax Expense**

The provision for income tax expense is based on an estimated annual effective tax rate that is subject to adjustment in subsequent quarterly periods if components used to estimate the annual effective tax rate are updated or revised. The estimated annual effective tax rates as of March 31, 2016 and March 31, 2015 were approximately 35 percent and approximately 38 percent, respectively. Our 2016 estimated annual effective tax rate decreased compared to the 2015 estimated annual effective tax rate primarily due to a decrease in non-deductible share-based compensation expense as compared to the prior year, which was driven largely by a decrease in our stock price.

**Share Repurchases**

In the first quarter of 2016, we repurchased approximately 1.0 million shares of our common stock at a total cost of $123.2 million. These purchases were made pursuant to our $500 million stock repurchase program, which is effective during calendar year 2016.

**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for the following charges, which are presented net of our annual effective income tax rate, as applicable: (1) interest expense; (2) license fees; (3) depreciation and amortization; (4) impairment charges; and (5) share-based compensation expense (stock option, share tracking award and employee stock purchase plan).

A reconciliation of net income (loss) to non-GAAP earnings is presented below (in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |
|Net income (loss), as reported | |$ |235\.5 | |$ |(16.6 |) |
|Adjust for the following charges (1) : | | | | | |
|Interest expense | |0\.4 | |1\.3 | |
|Depreciation and amortization | |5\.0 | |5\.1 | |
|Share-based compensation (benefit) expense | |(93.6 |) |145\.2 | |
|Non-GAAP earnings | |$ |147\.3 | |$ |135\.0 | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |3\.24 | |$ |2\.89 | |
|Diluted | |$ |3\.02 | |$ |2\.55 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |45\.4 | |46\.7 | |
|Diluted | |48\.7 | |53\.0 | |

* * *

(1) Non-GAAP earnings adjustments are presented net of the impact of our estimated effective income tax rates of approximately 35 percent and approximately 38 percent for the three months ended March 31, 2016 and 2015, respectively.

**Conference Call**

We will host a half-hour teleconference on Thursday, April 28, 2016, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406, and using access code: 93447541.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

3

* * *  
**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of innovative products to address the unmet medical needs of patients with chronic and life-threatening diseases.

**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, which does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, Non-GAAP Earnings.

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, statements relating to the continued sales growth of our products. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of April 28, 2016, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason.  [uthr-g]

Orenitram, Remodulin, Tyvaso and Unituxin are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

4

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In millions, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |369\.0 | |$ |325\.9 | |
|Other | |— | |1\.6 | |
|Total revenues | |369\.0 | |327\.5 | |
|Operating expenses: | | | | | |
|Cost of product sales | |0\.7 | |20\.8 | |
|Research and development | |(0.4 |) |110\.2 | |
|Selling, general and administrative | |5\.0 | |211\.3 | |
|Total operating expenses | |5\.3 | |342\.3 | |
|Operating income (loss) | |363\.7 | |(14.8 |) |
|Other (expense) income: | | | | | |
|Interest expense | |(0.6 |) |(2.1 |) |
|Other, net | |0\.8 | |0\.1 | |
|Total other income (expense), net | |0\.2 | |(2.0 |) |
|Income (loss) before income taxes | |363\.9 | |(16.8 |) |
|Income tax (expense) benefit | |(128.4 |) |0\.2 | |
|Net income (loss) | |$ |235\.5 | |$ |(16.6 |) |
|Net income (loss) per common share: | | | | | |
|Basic | |$ |5\.19 | |$ |(0.36 |) |
|Diluted | |$ |4\.84 | |$ |(0.36 |) |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |45\.4 | |46\.7 | |
|Diluted | |48\.7 | |46\.7 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**(Unaudited, in millions)**

| | |**March 31, 2016** | |
| --- | --- | --- | --- | --- |
|Cash, cash equivalents and marketable securities | |$ |985\.8 | |
|Total assets | |2,192.1 | |
|Total liabilities and temporary equity | |480\.3 | |
|Total stockholders’ equity | |1,711.8 | |

5

* * *