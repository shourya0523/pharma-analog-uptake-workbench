EX-99.1 2 a19-8867\_1ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: James Edgemond

(301) 608-9292

jedgemond@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**FIRST QUARTER 2019 FINANCIAL RESULTS**

Silver Spring, MD and Research Triangle Park, NC, May 1, 2019: United Therapeutics Corporation (Nasdaq: UTHR) today announced its financial results for the quarter ended March 31, 2019.

“I’m very pleased to report that last quarter we helped more pulmonary arterial hypertension (PAH) patients with our Remodulin, Tyvaso and Orenitram medicines than ever before,” said Martine Rothblatt, Ph.D., Chairman and Chief Executive Officer of United Therapeutics. “While we did also experience the disappointment of being unable to prove a morbidity/mortality benefit of esuberaprost in our _BEAT_ phase III trial, it is of course the nature of science that hypotheses are disproven as well as proven. No string of successes is without its setbacks, and we are confident of positive results being proven amongst our many other pivotal studies including the _DISTINCT_ study of dinutuximab for small cell lung cancer, the _INCREASE_ study of Tyvaso in pulmonary hypertension (PH) associated with interstitial lung disease, the _PERFECT_ study of Tyvaso in PH associated with COPD, the _SOUTHPAW_ study of Orenitram in PH associated with heart failure, the _ADVANCE OUTCOMES_ study of ralinepag in PAH, the _SAPPHIRE_ study of autologous gene therapy in PAH and our lung transplantation study.”

**Financial Results for the Three Months Ended March 31, 2019 compared to the Three Months Ended March 31, 2018**

Key financial highlights include (dollars in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
| | | | | | | | | | |
|Revenues | |$ |362\.6 | |$ |389\.2 | |$ |(26.6 |) |(7 |)% |
|Net (loss) income | |$ |(494.6 |) |$ |244\.5 | |$ |(739.1 |) |(302 |)% |
|Non-GAAP earnings (1) | |$ |157\.9 | |$ |164\.9 | |$ |(7.0 |) |(4 |)% |
|Net (loss) income, per basic share | |$ |(11.32 |) |$ |5\.65 | |$ |(16.97 |) |(300 |)% |
|Net (loss) income, per diluted share | |$ |(11.32 |) |$ |5\.57 | |$ |(16.89 |) |(303 |)% |
|Non-GAAP earnings, per diluted share (1) | |$ |3\.58 | |$ |3\.76 | |$ |(0.18 |) |(5 |)% |

* * *

(1) See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net (loss) income to non-GAAP earnings below.

**Revenues**

The table below summarizes the components of total revenues (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
|Net product sales: | | | | | | | | | |
|Remodulin ® | |$ |155\.5 | |$ |126\.8 | |$ |28\.7 | |23 |% |
|Tyvaso ® | |103\.8 | |94\.6 | |9\.2 | |10 |% |
|Orenitram ® | |58\.4 | |52\.2 | |6\.2 | |12 |% |
|Unituxin ® | |24\.9 | |18\.0 | |6\.9 | |38 |% |
|Adcirca ® | |20\.0 | |97\.6 | |(77.6 |) |(80 |)% |
|Total revenues | |$ |362\.6 | |$ |389\.2 | |$ |(26.6 |) |(7 |)% |

1

* * *

Revenues for the three months ended March 31, 2019 decreased by $26.6 million as compared to the same period in 2018.

Remodulin net product sales for the three months ended March 31, 2019 increased by $28.7 million as compared to the same period in 2018. U.S. Remodulin net product sales increased by $18.8 million, primarily due to an increase in the number of patients being treated with Remodulin and a price increase implemented in April 2018, which was the first price increase for Remodulin since 2010. International Remodulin net product sales increased by $9.9 million, primarily due to an increase in quantities shipped to international distributors.

Tyvaso net product sales for the three months ended March 31, 2019 increased by $9.2 million as compared to the same period in 2018. This increase was primarily due to an increase in the number of patients being treated with Tyvaso and a price increase implemented in January 2019.

Orenitram net product sales for the three months ended March 31, 2019 increased by $6.2 million as compared to the same period in 2018. This increase was primarily due to an increase in the number of patients being treated with Orenitram and a price increase implemented in January 2019.

Unituxin net product sales for the three months ended March 31, 2019 increased by $6.9 million as compared to the same period in 2018. This increase was primarily due to an increase in the number of vials sold.

Adcirca net product sales for the three months ended March 31, 2019 decreased by $77.6 million as compared to the same period in 2018. This decrease was due to a decrease in bottles sold following the onset of generic competition for Adcirca beginning in August 2018.

**Expenses**

**Cost of product sales** . The table below summarizes cost of product sales by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
|**Category:** | | | | | | | | | |
|Cost of product sales | |$ |28\.0 | |$ |59\.1 | |$ |(31.1 |) |(53 |)% |
|Share-based compensation expense (benefit) (1) | |1\.1 | |(5.9 |) |7\.0 | |119 |% |
|Total cost of product sales | |$ |29\.1 | |$ |53\.2 | |$ |(24.1 |) |(45 |)% |

* * *

(1) Refer to _Share-based compensation_ below for discussion.

_Cost of product sales, excluding share-based compensation._ The decrease in cost of product sales of $31.1 million for the three months ended March 31, 2019, as compared to the same period in 2018, was primarily attributable to a $32.8 million decrease in royalty expense for Adcirca because fewer bottles were sold due to the onset of generic competition for Adcirca beginning in August 2018.

**Research and development expense** . The table below summarizes research and development expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
|**Category:** | | | | | | | | | |
|Research and development projects | |$ |893\.8 | |$ |58\.2 | |$ |835\.6 | |NM |(2) |
|Share-based compensation expense (benefit) (1) | |3\.6 | |(22.5 |) |26\.1 | |116 |% |
|Total research and development expense | |$ |897\.4 | |$ |35\.7 | |$ |861\.7 | |NM |(2) |

* * *

(1) Refer to _Share-based compensation_ below for discussion.

(2) Calculation is not meaningful.

2

* * *

_Research and development expense, excluding share-based compensation._ The increase in research and development expense of $835.6 million for the three months ended March 31, 2019, as compared to the same period in 2018, was driven by continued investment in our product pipeline. Research and development expense for the treatment of cardiopulmonary diseases increased by $829.2 million for the three months ended March 31, 2019, as compared to the same period in 2018, due to: (1) an $800.0 million upfront payment to Arena Pharmaceuticals under our license agreement related to ralinepag, and $8.9 million of expenditures associated with the phase III _ADVANCE_ studies of ralinepag during the three months ended March 31, 2019; (2) a $12.5 million payment under our license and collaboration agreement with MannKind; (3) increased spending of $5.6 million on the development of drug delivery devices, including the Implantable System for Remodulin; and (4) increased spending on several clinical and non-clinical studies.

**Selling, general and administrative expense.** The table below summarizes selling, general and administrative expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
|Category: | | | | | | | | | |
|General and administrative | |$ |53\.9 | |$ |52\.8 | |$ |1\.1 | |2 |% |
|Sales and marketing | |13\.6 | |13\.3 | |0\.3 | |2 |% |
|Share-based compensation expense (benefit) (1) | |24\.5 | |(72.7 |) |97\.2 | |134 |% |
|Total selling, general and administrative expense | |$ |92\.0 | |$ |(6.6 |) |$ |98\.6 | |NM |(2) |

* * *

(1)           Refer to _Share-based compensation_ below for discussion.

(2)           Calculation is not meaningful.

**Share-based compensation** . The table below summarizes share-based compensation expense (benefit) by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |**Change** | |**Change** | |
|**Category:** | | | | | | | | | |
|Stock options | |$ |15\.7 | |$ |12\.7 | |$ |3\.0 | |24 |% |
|Restricted stock units | |2\.2 | |0\.9 | |1\.3 | |144 |% |
|Share tracking awards plan (STAP) | |11\.0 | |(115.0 |) |126\.0 | |110 |% |
|Employee stock purchase plan | |0\.3 | |0\.3 | |— | |— |% |
|Total share-based compensation expense (benefit) | |$ |29\.2 | |$ |(101.1 |) |$ |130\.3 | |129 |% |

_Share-based compensation_ . The increase in share-based compensation expense of $130.3 million for the three months ended March 31, 2019, as compared to the same period in 2018, was primarily due to: (1) a $126.0 million increase in STAP expense (benefit) driven by an 8% increase in our stock price for the three months ended March 31, 2019, as compared to a 24% decrease in our stock price for the same period in 2018; and (2) a $3.0 million increase in stock option expense due to additional awards granted and outstanding in 2019.

**Income Tax (Benefit) Expense**

The income tax benefit was $156.0 million for the three months ended March 31, 2019, as compared to income tax expense of $64.5 million for the same period in 2018. Our effective income tax rate (ETR) for the three months ended March 31, 2019 and

3

* * *

2018 was 24 percent and 21 percent, respectively. We recognized a loss before income taxes, and a corresponding income tax benefit, for the three months ended March 31, 2019, as a result of the one-time $800.0 million payment to Arena in January 2019. As a result of this loss, our anticipated tax credits, partially offset by non-deductible compensation expense, increase our tax benefit and resulting ETR for the three months ended March 31, 2019, compared to the three months ended March 31, 2018.

**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for: (1) share-based compensation expense (including expenses relating to stock options, restricted stock units, share tracking awards and our employee stock purchase plan); (2) license-related fees; and (3) tax impact on non-GAAP earnings adjustments.

A reconciliation of net (loss) income to non-GAAP earnings is presented in the following table (in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |
|Net (loss) income, as reported | |$ |(494.6 |) |$ |244\.5 | |
|Adjusted for the following charges: | | | | | |
|Share-based compensation expense (benefit) | |29\.2 | |(101.1 |) |
|License-related fees | |812\.5 | |— | |
|Tax (benefit) expense | |(189.2 |) |21\.5 | |
|Non-GAAP earnings | |$ |157\.9 | |$ |164\.9 | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |3\.61 | |$ |3\.81 | |
|Diluted | |$ |3\.58 | |$ |3\.76 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.7 | |43\.3 | |
|Diluted | |44\.1 | |43\.9 | |

**Conference Call**

We will host a half-hour teleconference on Wednesday, May 1, 2019, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406, and using access code: 5569533.

This teleconference will also be webcast and can be accessed via our website at http://ir.unither.com/events-presentations.

**About United Therapeutics**

United Therapeutics Corporation focuses on the strength of a balanced, value-creating biotechnology model. We are confident in our future thanks to our fundamental attributes, namely our obsession with quality and innovation, the power of our brands, our entrepreneurial culture and our bioinformatics leadership. We also believe that our determination to be responsible citizens — having a positive impact on patients, the environment and society — will sustain our success in the long term.

Through our wholly-owned subsidiary, Lung Biotechnology PBC, we are focused on addressing the acute national shortage of transplantable lungs and other organs with a variety of technologies that either delay the need for such organs or expand the supply. Lung Biotechnology is the first public benefit corporation subsidiary of a public biotechnology or pharmaceutical company.

4

* * *

**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, which does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by providing greater transparency with respect to the information our management uses to evaluate and compare the performance of our core operations and make operating decisions. This non-GAAP financial measure enables investors to see our business through the eyes of our management. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, Non-GAAP Earnings.

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, statements relating to our research and development pipeline, including the likelihood of success of our _DISTINCT, INCREASE,_ _PERFECT, SOUTHPAW, ADVANCE OUTCOMES,_ _SAPPHIRE_ and lung transplantation clinical studies. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of May 1, 2019, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason.  [uthr-g]

Orenitram, Remodulin, Tyvaso and Unituxin are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

5

* * *

**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In millions, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2019** | |**2018** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |362\.6 | |$ |389\.2 | |
|Total revenues | |362\.6 | |389\.2 | |
|Operating expenses: | | | | | |
|Cost of product sales | |29\.1 | |53\.2 | |
|Research and development | |897\.4 | |35\.7 | |
|Selling, general and administrative | |92\.0 | |(6.6 |) |
|Total operating expenses | |1,018.5 | |82\.3 | |
|Operating (loss) income | |(655.9 |) |306\.9 | |
|Other income (expense): | | | | | |
|Interest income | |9\.8 | |5\.3 | |
|Interest expense | |(10.3 |) |(2.6 |) |
|Other, net | |5\.8 | |(0.6 |) |
|Total other income, net | |5\.3 | |2\.1 | |
|(Loss) income before income taxes | |(650.6 |) |309\.0 | |
|Income tax benefit (expense) | |156\.0 | |(64.5 |) |
|Net (loss) income | |$ |(494.6 |) |$ |244\.5 | |
|Net (loss) income per common share: | | | | | |
|Basic | |$ |(11.32 |) |$ |5\.65 | |
|Diluted | |$ |(11.32 |) |$ |5\.57 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.7 | |43\.3 | |
|Diluted | |43\.7 | |43\.9 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**(Unaudited, in millions)**

| | |**March 31,  
2019** | |
| --- | --- | --- | --- | --- |
|Cash, cash equivalents and marketable investments | |$ |2,016.4 | |
|Total assets | |3,726.7 | |
|Total liabilities and temporary equity | |1,407.7 | |
|Total stockholders’ equity | |2,319.0 | |
| | | | | |

6

* * *