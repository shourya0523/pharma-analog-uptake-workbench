EX-99.1 2 a10-2670\_2ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: Andrew Fisher

(202) 483-7000

Afisher@unither.com

**UNITED THERAPEUTICS CORPORATION
REPORTS**

**2009 FOURTH QUARTER AND ANNUAL
FINANCIAL RESULTS**

· **Total Annual Revenues of $369.8
Million**

· **Annual Basic and Diluted Net
Income per Share of $0.37 and $0.35, Respectively**

· **Annual Earnings Before Non-Cash Charges of $2.80 per Basic Share, or
$2.66 per Diluted Share**

Silver Spring, MD, February 16, 2010: United Therapeutics
Corporation (NASDAQ: UTHR) today announced its financial results for the fourth
quarter and year ended December 31, 2009.

“We are pleased that our revenues for 2009 grew in excess of 30% for
the eighth consecutive year to $370 million,” remarked Martine Rothblatt,
Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “Along with
the continued positive trend relative to Remodulin, we are also excited about
the potential to reach even more pulmonary hypertension patients in 2010 with
Tyvaso and Adcirca.”

Total revenues for
the three months ended December 31, 2009, were $108.9 million, up from
$75.9 million for the three months ended December 31, 2008.  Net loss for the three months ended December 31,
2009, was $3.3 million or $0.06 per basic share, compared to a net loss of
$82.1 million or $1.73 per basic share for the three months ended December 31,
2008\. For the year ended December 31, 2009, we had net income of $19.5
million, or $0.37 per basic share and $0.35 per diluted share, as compared to a
net loss of $49.3 million, or $1.08 per basic and diluted share, for the year
ended December 31, 2008.  Research
and development expense for the three months and year ended December 31,
2008, included a $150.0 million charge related to a one-time, upfront payment
to Eli Lilly and Company (Lilly) pursuant to agreements for the license,
manufacture and supply of Adcirca (tadalafil) tablets for pulmonary
hypertension.

Earnings before
non-cash charges, a non-GAAP financial measure, defined as net (loss) income
before income taxes, non-cash interest, license fee expenses, depreciation,
amortization, impairment charges and share-based compensation (stock option and
share tracking award expense), for the three months ended December 31,
2009, was $36.2 million or $0.67 per basic share, compared to $25.1 million or
$0.53 per basic share for the three months ended December 31, 2008. All
share and per share amounts appearing in this press release reflect the
two-for-one split of our common stock, which occurred during the quarter ended September 30,
2009\.

* * *  
Results for the
three months and year ended December 31, 2008, have been adjusted for the
retrospective adoption of Financial Accounting Standards Board (FASB)
Accounting Standards Codification™ 470-20, _Debt with Conversion
Options and Other Options_ (formerly FASB Staff Position No. APB
14-1) (FASB ASC 470-20), which became effective January 1, 2009.

**Results**

**_Revenues._** Revenues
for the year ended December 31, 2009, increased by 31% over those for the
year ended December 31, 2008, from $281.5 million to $369.8 million. The
growth in revenues experienced during 2009 resulted in large part from the
increase in the number of patients prescribed Remodulin (treprostinil)
Injection and the commercial launches of our inhaled prostacyclin, Tyvaso
(treprostinil) Inhalation Solution, and our oral phosphodiesterase type 5
inhibitor, Adcirca. Gross margins from sales were $323.3 million and $249.2
million, or 88% and 89%, for the years ended December 31, 2009 and 2008,
respectively.

The table below summarizes the components of revenues (in thousands):

| | |**Three Months Ended  
December 31,** | |**Year Ended  
December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**2009** | |**2008** | |
| | | | | | | | | | |
|Revenues: | | | | | | | | | |
|Remodulin | |$ |86,415 | |$ |73,137 | |$ |331,579 | |$ |269,718 | |
|Tyvaso | |15,155 | |— | |20,268 | |— | |
|Adcirca | |4,275 | |— | |5,789 | |— | |
|Telemedicine
products and services | |2,795 | |2,370 | |10,968 | |9,485 | |
|Other products | |283 | |355 | |1,244 | |2,294 | |
|Total revenues | |$ |108,923 | |$ |75,862 | |$ |369,848 | |$ |281,497 | |

**_Operating Expenses._** Our operating expenses principally consist of
research and development, selling, general and administrative, and costs of
service and product sales.

The table below summarizes research and development expense by major
project and non-project components (in thousands):

| | |**Three Months Ended  
December 31,** | |**Year Ended  
December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**2009** | |**2008** | |
| | | | | | | | | | |
|**Project
and non-project:** | | | | | | | | | |
|Cardiovascular | |$ |22,906 | |$ |20,890 | |$ |61,575 | |$ |60,549 | |
|License fees | |— | |150,000 | |— | |150,000 | |
|Cancer | |793 | |687 | |3,093 | |2,771 | |
|Infectious
disease | |1,126 | |725 | |4,106 | |1,556 | |
|Share-based
compensation | |11,129 | |4,918 | |36,294 | |16,200 | |
|Other | |5,078 | |2,531 | |17,120 | |8,105 | |
|Total research
and development expense | |$ |41,032 | |$ |179,751 | |$ |122,188 | |$ |239,181 | |

* * *  
_Cardiovascular
license fees—Adcirca._ Cardiovascular license fees for
the year ended December 31, 2008, reflected the one-time, upfront payment
to Lilly of $150.0 million associated with the licensing and
commercialization of Adcirca, which we expensed during the quarter ended December 31,
2008\. There were no comparable transactions during the year ended December 31,
2009\.

_Share-based
compensation._ The
increase in share-based compensation expense for both the three months and year
ended December 31, 2009, over that for the same periods in 2008, was
primarily due to: (i) the increase in the fair value of awards granted
under the United Therapeutics Share Tracking Awards Plan (STAP) as a result of
the increase in the price of our common stock; (ii) an increase in the
number of outstanding STAP awards; and (iii) the number of STAP awards
vested and the time that unvested STAP awards had accrued toward vesting as of December 31,
2009\.

_Other._ The increase in other research and development expenses of approximately
$2.5 million and $9.0 million during the quarter and year ended December 31,
2009, respectively, as compared to the same periods in 2008, corresponded
mainly to an increase in expenditures related our investigational projects,
including those within our monoclonal antibody and glycobiology antiviral agent
therapeutic platforms, and an increase in personnel and overhead costs related
to supporting  our research and
development.  Research and development
expenses for our individual disclosed platforms includes only direct labor and
out-of-pocket expenses, and excludes overhead and indirect personnel costs.

The table below
summarizes selling, general and administrative expense by major categories (in
thousands):

| | |**Three Months Ended  
December 31,** | |**Year Ended  
December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**2009** | |**2008** | |
| | | | | | | | | | |
|**Category** | | | | | | | | | |
|General and
administrative | |$ |28,894 | |$ |13,171 | |$ |68,606 | |$ |41,284 | |
|Sales and
marketing | |11,860 | |8,778 | |43,593 | |32,899 | |
|Share-based
compensation | |15,823 | |(84 |) |64,139 | |20,123 | |
|Total selling,
general and administrative expense | |$ |56,577 | |$ |21,865 | |$ |176,338 | |$ |94,306 | |

_General and administrative._ During the three months and year ended December 31, 2009, general
and administrative expense increased $15.7 million and $27.3 million,
respectively, over the three months and year ended December 31, 2008, for
the following reasons:

· An impairment charge of $4.2 million recognized during
the three months ended

* * *  
December 31, 2009,
on three of our Silver Spring, Maryland, properties that housed employees prior
to relocating to our newly-completed combination office and laboratory building
in Silver Spring.  The old buildings are
scheduled to be razed in 2010 in connection with commencement of construction
on the last phase of our Silver Spring campus;

· Increases in professional fees of approximately $1.2
million and $4.2 million, for the three months and year ended December 31,
2009, respectively, related to ongoing litigation, reviewing potential
acquisitions, entering new license agreements, and other matters;

· $3.7 million of expenses during the three months ended
December 31, 2009, for validation work to manufacture Remodulin on
different equipment; and

· An increase in general operating expenses of $3.4
million and $13.7 million for the three months and year ended December 31,
2009, respectively, primarily resulting from the overall growth of the company
this year.

_Sales and marketing._ The increases in sales and marketing expenses for both the quarter and
year ended December 31, 2009, were primarily related to increased expenses
for the commercialization of our two new products, Tyvaso and Adcirca.

_Share-based compensation._ For the quarter ended December 31, 2009, share-based compensation
increased by $15.9 million over the same period in 2008 for two reasons.  First, during the quarter ended December 31,
2008, we reversed approximately $6.4 million in estimated compensation expense
that had been accrued through September 30, 2008, for a potential year-end
stock option grant to our Chief Executive Officer, which is based on a formula
in her employment agreement.  Our Chief Executive
Officer did not receive a stock option grant for the year ended December 31,
2008\.  By contrast, our Chief Executive
Officer did receive a year-end stock option grant at the end of 2009 in
accordance with the formula in her employment agreement, and we recognized
approximately $1.5 million in share-based compensation expense related to this
option grant for the quarter ended December 31, 2009.  The total share-based compensation recognized
during 2009 related to the year-end stock option grant to our Chief Executive
Officer was $14.5 million.  Second, the
remainder of the increase in share-based compensation expense for both the three months and year ended December 31,
2009, resulted from the following: (i) the increase in the fair value of
awards granted under the STAP as a result of the increase in the price of our
common stock; (ii) an increase in the number of outstanding STAP awards;
and (iii) the number of STAP awards vested and the time that unvested STAP
awards had accrued toward vesting as of December 31, 2009.

**_Income Tax Benefit._** As a result of the net losses we incurred before
income taxes, we recognized income tax benefits of $1.4 million and $53.1
million, respectively, for the three months ended December 31, 2009 and
2008\. For the year ended December 31, 2009, we recognized income tax
benefits of approximately $695,000 from the business tax credits we generate
from our orphan drug-related research and development activities.

* * *  
**Earnings Before Non-Cash Charges**

A reconciliation of net (loss) income to earnings before non-cash
charges is presented below (in thousands, except per share data):

| | |**Year
Ended December 31,** | |**Three
Months Ended** **  
** **December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008 (1)** **  
** **As
adjusted** | |**2007 (1)** **  
** **As
adjusted** | |**2006 (1)** **  
** **As
adjusted** | |**2009** | |**2008 (1)** **  
** **As
adjusted** | |
| | | | | | | | | | | | | | |
|Net (loss) income, as reported | |$ |19,462 | |$ |(49,327 |) |$ |12,353 | |$ |72,596 | |$ |(3,330 |) |$ |(82,070 |) |
|Add (subtract) non-cash charges: | | | | | | | | | | | | | |
|Amortization of debt discount and issue costs | |12,875 | |11,439 | |14,281 | |2,417 | |3,659 | |2,530 | |
|Income tax benefit, net of taxes paid | |(695 |) |(34,394 |) |(9,431 |) |(34,927 |) |(1,403 |) |(53,146 |) |
|License fee | |— | |150,000 |(2) |11,013 |(3) |— | |— | |150,000 | |
|Depreciation and amortization | |11,394 | |4,955 | |3,427 | |2,713 | |4,721 | |1,810 | |
|Impairments | |5,457 | |1,605 | |3,582 | |2,024 | |5,058 | |1,100 | |
|Share-based compensation | |100,810 | |36,393 | |48,766 | |23,513 | |27,502 | |4,852 | |
|Earnings before non-cash charges | |$ |149,303 | |$ |120,671 | |$ |83,991 | |$ |68,336 | |$ |36,207 | |$ |25,076 | |
| | | | | | | | | | | | | | |
|Earnings before non-cash charges per share: | | | | | | | | | | | | | |
|Basic(4) | |$ |2\.80 | |$ |2\.63 | |$ |1\.98 | |$ |1\.48 | |$ |0\.67 | |$ |0\.53 | |
|Diluted(5) | |$ |2\.66 | |$ |2\.42 | |$ |1\.87 | |$ |1\.42 | |$ |0\.62 | |$ |0\.51 | |

* * *

(1)  Adjusted for the retrospective adoption of FASB ASC
470-20.

(2) During the three months ended December 31, 2008, we made
a one-time payment of $150.0 million to Lilly related to our license and
manufacturing and supply agreements. We also issued approximately 3.2 million
shares of our common stock to Lilly for $150.0 million under a related stock purchase
agreement. Since there was no net impact on our cash flows associated with
these transactions, we have presented the related up-front payment as an
adjustment to net loss.

(3) During the year ended December 31, 2007, we issued
400,000 shares of our common stock to Toray Industries, Inc. The fair
value of the shares issued was expensed as research and development.

(4) Calculated by dividing earnings before non-cash charges
presented above by the weighted average number of shares outstanding for the period.

(5) Calculated by dividing earnings before non-cash charges
presented above by the weighted average number of shares outstanding for the
period adjusted for potentially dilutive securities. For the quarter and year
ended December 31, 2009, approximately 57.9 million shares and 56.1
million shares, respectively, were used to calculate diluted earnings before
non-cash charges. For the quarter and year ended December 31, 2008,
approximately 49.3 million shares and 49.9 million shares, respectively, were
used to calculate diluted earnings before non-cash charges.

* * *  
* * *  
**Conference Call**

We will host a half-hour
teleconference on Tuesday, February 16, 2010, at 9:00 a.m. Eastern
Time. The teleconference is accessible by dialing 888-695-0608, with international
callers dialing 719-325-2204. A rebroadcast of the teleconference will be
available for one week by dialing 888-203-1112, with international callers
dialing 719-457-0820 and using access code 5260604.

This teleconference is also being webcast and can be accessed via our
website at http://ir.unither.com/events.cfm.

**About United Therapeutics**

United
Therapeutics Corporation is a biotechnology company focused on the development
and commercialization of unique products to address the unmet medical needs of
patients with chronic and life-threatening conditions.

**Non-GAAP
Financial Information**

This press release
contains a financial measure that does not comply with United States generally
accepted accounting principles (GAAP). This measure supplements our financial
results prepared in accordance with GAAP as reported below.

We use earnings
before taxes and non-cash charges, a non-GAAP financial measure: (a) as
measurements of operating performance because it assists us in comparing our
operating performance on a consistent basis by excluding the impact of expenses
not directly resulting from our core operations; (b) for planning
purposes, including the preparation of our internal annual operating budget; (c) to
allocate resources to enhance the financial performance of our business; (d) to
evaluate the effectiveness of our operational strategies; and (e) to
evaluate our capacity to fund capital expenditures and expand our business. We
believe this non-GAAP financial measure enhances investors’ understanding of
our performance by excluding certain expenses that may not be indicative of our
core operating measures. In addition, because we have historically reported
earnings before non-cash charges to investors, we believe the inclusion of this
non-GAAP financial measure provides consistency in our financial reporting. The
presentation of this non-GAAP financial measure is not to be considered in
isolation or as a substitute for our financial results prepared in accordance
with GAAP. A reconciliation of earnings before non-cash charges to net income,
the most directly comparable GAAP financial measure, can be found in the table
above under _EARNINGS BEFORE NON-CASH CHARGES_ .

**Forward-looking Statements**

Statements included in this
press release that are not historical in nature are “forward-looking statements”
within the meaning of the Private Securities Litigation Reform Act of 1995.
Forward-looking statements include, among others, our expectations and
intentions

* * *  
related to financial
performance and results, including annual revenue growth and our expectations
about continued growth of Remodulin and Tyvaso and Adcirca’s potential to reach
more patients. These forward-looking
statements are subject to certain risks and uncertainties, such as those
described in our periodic reports filed with the Securities and Exchange
Commission, that could cause actual results to differ materially from
anticipated results.  Consequently, such
forward-looking statements are qualified by the cautionary statements,
cautionary language and risk factors set forth in our periodic reports and
documents filed with the Securities and Exchange Commission, including our most
recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q,
and current reports on Form 8-K.  We claim the protection of the safe
harbor contained in the Private Securities Litigation Reform Act of 1995
for forward-looking statements. We are
providing this information as of February 16, 2010, and assume no
obligation to update or revise the information contained in this press release
whether as a result of new information, future events or any other reason.
[uthr-g]

Remodulin
and Tyvaso are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered
trademark of Eli Lilly and Company.

* * *  
**UNITED
THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS OF OPERATIONS  
(In thousands, except per share data)**

| | |**Three Months Ended  
December 31,** | |**For the Years Ended  
December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008** | |**2009** | |**2008** | |
| | | | |**As Adjusted (1)** | | | |**As Adjusted (1)** | |
|Revenues: | | | | | | | | | |
|Net product
sales | |$ |105,945 | |$ |73,206 | |$ |357,870 | |$ |270,005 | |
|Service sales | |2,697 | |2,314 | |10,751 | |9,258 | |
|License fees | |281 | |342 | |1,227 | |2,234 | |
|Total revenues | |108,923 | |75,862 | |369,848 | |281,497 | |
|Operating
expenses: | | | | | | | | | |
|Research and
development | |41,032 | |179,751 | |122,188 | |239,181 | |
|Selling, general
and administrative | |56,577 | |21,865 | |176,338 | |94,306 | |
|Cost of product
sales | |12,233 | |7,267 | |40,890 | |26,957 | |
|Cost of service
sales | |1,263 | |839 | |4,431 | |3,109 | |
|Total operating
expenses | |111,105 | |209,722 | |343,847 | |363,553 | |
|(Loss) income
from operations | |(2,182 |) |(133,860 |) |26,001 | |(82,056 |) |
|Other income
(expense): | | | | | | | | | |
|Interest income | |1,005 | |2,302 | |5,146 | |11,025 | |
|Interest expense | |(3,659 |) |(2,530 |) |(12,875 |) |(11,439 |) |
|Equity loss in
affiliate | |(42 |) |(71 |) |(141 |) |(226 |) |
|Other, net | |145 | |(1,057 |) |636 | |(1,025 |) |
|Total other
(expense) income, net | |(2,551 |) |(1,356 |) |(7,234 |) |(1,665 |) |
|(Loss) income
before income tax benefit | |(4,733 |) |(135,216 |) |18,767 | |(83,721 |) |
|Income tax
benefit | |1,403 | |53,146 | |695 | |34,394 | |
|Net (loss)
income | |$ |(3,330 |) |$ |(82,070 |) |$ |19,462 | |$ |(49,327 |) |
|Net (loss)
income per common share: (2) | | | | | | | | | |
|Basic | |$ |(0.06 |) |$ |(1.73 |) |$ |0\.37 | |$ |(1.08 |) |
|Diluted | |$ |(0.06 |) |$ |(1.73 |) |$ |0\.35 | |$ |(1.08 |) |
|Weighted average
number of common shares outstanding: (2) | | | | | | | | | |
|Basic | |53,926 | |47,454 | |53,314 | |45,802 | |
|Diluted | |53,926 | |47,454 | |56,133 | |45,802 | |

* * *

(1) Adjusted for the retrospective adoption of FASB ASC
470-20.

(2) All share and per share data have been adjusted from previously
reported amounts to reflect the two-for-one stock split effected September 22,
2009\.

**SELECTED
CONSOLIDATED BALANCE SHEET DATA**

**(In
thousands)**

| | |**December 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2009** | |**2008 (1)** | |
|Cash, cash
equivalents and marketable securities (excluding restricted amounts of
$39,976 and $45,755, respectively) | |$ |378,120 | |$ |336,318 | |
|Total assets | |1,051,544 | |874,534 | |
|Total
liabilities and common stock subject to repurchase | |398,535 | |319,200 | |
|Total
stockholders’ equity | |653,009 | |555,334 | |

* * *

(1) Adjusted for the retrospective adoption of FASB ASC
470-20.

* * *