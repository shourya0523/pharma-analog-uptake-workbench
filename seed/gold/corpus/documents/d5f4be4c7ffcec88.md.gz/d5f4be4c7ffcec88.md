XML 76 R27.htm IDEA: XBRL DOCUMENT **Segment, Geographic and Other Revenue Information  
**

12 Months Ended

Dec. 31, 2015

[**Segment Reporting [Abstract]**](javascript:void\(0\);)

Segment, Geographic and Other Revenue Information

Segment, Geographic and Other Revenue Information

A. Segment Information

We manage our commercial operations through two distinct businesses: an Innovative Products business and an Established Products business. The Innovative Products business is composed of two operating segments, each of which has been led by a single manager in 2015 and 2014––the Global Innovative Pharmaceutical segment (GIP) and the Global Vaccines, Oncology and Consumer Healthcare segment (VOC). Effective February 8, 2016, the Innovative Products business is led by a single manager. The Established Products business consists of the Global Established Pharmaceutical segment (GEP), which is also led by a single manager. Each operating segment has responsibility for its commercial activities and for certain IPR&D projects for new investigational products and additional indications for in-line products that generally have achieved proof of concept. Each business has a geographic footprint across developed and emerging markets. As our operations were not managed under the new structure until the beginning of fiscal 2014, certain costs and expenses could not be directly attributed to one of the new operating segments. As a result, our operating segment results for 2013 include allocations. The amounts subject to allocation methods in 2013 were approximately $2.1 billion of selling, informational and administrative expenses and approximately $800 million of research and development expenses:

| | |
| --- | --- |
|• |The selling, informational and administrative expenses were allocated using proportional allocation methods based on associated selling costs, revenues or product-specific costs, as applicable. |

| | |
| --- | --- |
|• |The research and development expenses were allocated based on product-specific R&D costs or revenue metrics, as applicable. |

Management believes that the allocations are reasonable.

We regularly review our segments and the approach used by management to evaluate performance and allocate resources.

Operating Segments

Some additional information about each business and operating segment follows:

| |
| --- | --- | --- | --- | --- |
| | | | | |
|Innovative Products Business | |Established Products Business |
|Global Innovative Pharmaceutical segment:

GIP focuses on developing and commercializing novel, value-creating medicines that significantly improve patients’ lives. Key therapeutic areas include inflammation/immunology, cardiovascular/metabolic, neuroscience/pain and rare diseases and include leading brands, such as Xeljanz, Eliquis, Lyrica (U.S. and Japan), Enbrel (outside the U.S. and Canada) and Viagra (U.S. and Canada). | |Global Vaccines, Oncology and Consumer Healthcare segment:

VOC focuses on the development and commercialization of vaccines and products for oncology and consumer healthcare. Consumer Healthcare manufactures and markets several well known, over-the-counter (OTC) products. Each of the three businesses in VOC operates as a separate, global business, with distinct specialization in terms of the science and market approach necessary to deliver value to consumers and patients. | |Global Established Pharmaceutical segment:

GEP includes legacy brands that have lost or will soon lose market exclusivity in both developed and emerging markets, branded generics, generic sterile injectable products, biosimilars and infusion systems. |

Additionally, GEP has the knowledge and resources within R&D to develop small molecules, including injectables, and biosimilars. On September 3, 2015, we acquired Hospira, and its commercial operations are now included within GEP. Commencing from the acquisition date, and in accordance with our domestic and international reporting periods, our consolidated statement of income, primarily GEP’s operating results, for the year ended December 31, 2015 reflect four months of legacy Hospira U.S. operations and three months of legacy Hospira international operations. See Note 2A for additional information.

Our chief operating decision maker uses the revenues and earnings of the three operating segments, among other factors, for performance evaluation and resource allocation.

Other Costs and Business Activities

Certain costs are not allocated to our operating segment results, such as costs associated with the following:

| | |
| --- | --- |
|• |WRD, which is generally responsible for research projects until proof-of-concept is achieved and then for transitioning those projects to the appropriate operating segment for possible clinical and commercial development. R&D spending may include upfront and milestone payments for intellectual property rights. This organization also has responsibility for certain science-based and other platform-services organizations, which provide technical expertise and other services to the various R&D projects. WRD is also responsible for facilitating all regulatory submissions and interactions with regulatory agencies, including all safety-event activities. |

| | |
| --- | --- |
|• |Pfizer Medical, which, during the years 2013 through 2015, was responsible for the provision of medical information to healthcare providers, patients and other parties, transparency and disclosure activities, clinical trial results publication, grants for healthcare quality improvement and medical education, partnerships with global public health and medical associations, regulatory inspection readiness reviews, internal audits of Pfizer-sponsored clinical trials and internal regulatory compliance processes. |

| | |
| --- | --- |
|• |Corporate, representing platform functions (such as worldwide technology, global real estate operations, legal, finance, human resources, worldwide public affairs, compliance and worldwide procurement) and certain compensation and other corporate costs, such as interest income and expense, and gains and losses on investments. |

| | |
| --- | --- |
|• |Other unallocated costs, representing overhead expenses associated with our manufacturing and commercial operations not directly attributable to an operating segment. |

| | |
| --- | --- |
|• |Certain transactions and events such as (i) purchase accounting adjustments, where we incur expenses associated with the amortization of fair value adjustments to inventory, intangible assets and property, plant and equipment; (ii) acquisition-related costs, where we incur costs for executing the transaction, integrating the acquired operations and restructuring the combined company; and (iii) certain significant items, which include non-acquisition-related restructuring costs, as well as costs incurred for legal settlements, asset impairments and disposals of assets or businesses, including, as applicable, any associated transition activities. |

Segment Assets

We manage our assets on a total company basis, not by operating segment, as many of our operating assets are shared (such as our plant network assets) or commingled (such as accounts receivable, as many of our customers are served by multiple operating segments). Therefore, our chief operating decision maker does not regularly review any asset information by operating segment and, accordingly, we do not report asset information by operating segment. Total assets were approximately $167 billion as of December 31, 2015 and approximately $168 billion as of December 31, 2014 .

Selected Income Statement Information

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
|The following table provides selected income statement information by reportable segment: |
| | |Revenues | |Earnings (a) | |Depreciation and Amortization (b) |
| | |Year Ended December 31, | |Year Ended December 31, | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2015 | | |2014 | | |2013 | | |2015 | | |2014 | | |2013 | | |2015 | | |2014 | | |2013 | |
|Reportable Segments: | | | | | | | | | | | | | | | | | | |
|GIP | |$ |13,954 | | |$ |13,861 | | |$ |14,317 | | |$ |7,757 | | |$ |7,780 | | |$ |8,549 | | |$ |248 | | |$ |255 | | |$ |238 | |
|VOC | |12,803 | | |10,144 | | |9,285 | | |6,507 | | |4,692 | | |4,216 | | |306 | | |263 | | |231 | |
|GEP (c) | |21,587 | | |25,149 | | |27,619 | | |12,885 | | |16,199 | | |17,552 | | |422 | | |475 | | |478 | |
|Total reportable segments | |48,345 | | |49,154 | | |51,221 | | |27,149 | | |28,671 | | |30,318 | | |976 | | |993 | | |947 | |
|Other business activities (d) | |506 | | |253 | | |232 | | |(2,950 |) | |(3,092 |) | |(2,828 |) | |98 | | |91 | | |105 | |
|Reconciling Items: | | | | | | | | | | | | | | | | | | | | | | |
|Corporate (e) | |— | | |— | | |— | | |(5,430 |) | |(5,200 |) | |(5,689 |) | |354 | | |384 | | |432 | |
|Purchase accounting adjustments (e) | |— | | |— | | |— | | |(3,953 |) | |(3,641 |) | |(4,344 |) | |3,573 | | |3,782 | | |4,487 | |
|Acquisition-related costs (e) | |— | | |— | | |— | | |(894 |) | |(183 |) | |(376 |) | |75 | | |53 | | |124 | |
|Certain significant items (f) | |— | | |198 | | |132 | | |(4,321 |) | |(3,749 |) | |(692 |) | |48 | | |207 | | |167 | |
|Other unallocated | |— | | |— | | |— | | |(636 |) | |(567 |) | |(671 |) | |33 | | |27 | | |44 | |
| | |$ |48,851 | | |$ |49,605 | | |$ |51,584 | | |$ |8,965 | | |$ |12,240 | | |$ |15,716 | | |$ |5,157 | | |$ |5,537 | | |$ |6,306 | |

| | |
| --- | --- |
|(a) |Income from continuing operations before provision for taxes on income. |

| | |
| --- | --- |
|(b) |Certain production facilities are shared. Depreciation is allocated based on estimates of physical production. Amounts here relate solely to the depreciation and amortization associated with continuing operations. |

| | |
| --- | --- |
|(c) |On September 3, 2015, we acquired Hospira. Commencing from the acquisition date, and in accordance with our domestic and international reporting periods, our consolidated statement of income for the year ended December 31, 2015 reflects four months of legacy Hospira U.S. operations and three months of legacy Hospira international operations. See Note 2A for additional information. |

| | |
| --- | --- |
|(d) |Other business activities includes the revenues and operating results of Pfizer CentreSource, our contract manufacturing and bulk pharmaceutical chemical sales operation, which in 2015 includes the revenues and expenses related to our manufacturing and supply agreements with Zoetis. Other business activities also includes the costs managed by our WRD organization and our Pfizer Medical organization. |

| | |
| --- | --- |
|(e) |For a description, see the “Other Costs and Business Activities” section above. |

| | |
| --- | --- |
|(f) |Certain significant items are substantive, unusual items that, either as a result of their nature or size, would not be expected to occur as part of our normal business on a regular basis. |

For Revenues in 2014 and 2013, certain significant items primarily represent revenues related to our manufacturing and supply agreements with Zoetis. For additional information, see Note 2D.

For Earnings in 2015, certain significant items includes: (i) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $584 million , (ii) foreign currency loss and inventory impairment related to Venezuela of $878 million , (iii) certain asset impairments of $787 million , (iv) a charge related to pension settlements of $491 million , (v) charges for business and legal entity alignment of $282 million , (vi) charges for certain legal matters of $968 million and (vii) other charges of $332 million . For additional information, see Note 3 and Note 4.

For Earnings in 2014, certain significant items includes: (i) charges for certain legal matters of $999 million , (ii) certain asset impairments of $440 million , (iii) a charge for an additional year of Branded Prescription Drug Fee of $215 million , (iv) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $598 million , (v) an upfront fee associated with collaborative arrangement with Merck KGaA of $1.2 billion , (vi) charges for business and legal entity alignment of $168 million and (vii) other charges of $165 million . For additional information, see Note 2C, Note 3 and Note 4 .

For Earnings in 2013 , certain significant items includes: (i) patent litigation settlement income of $1.3 billion , (ii) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $1.3 billion , (iii) net charges for certain legal matters of $21 million , (iv) certain asset impairments of $836 million , (v) the gain associated with the transfer of certain product rights to Hisun Pfizer of $459 million , (vi) costs associated with the separation of Zoetis of $18 million and (vii) other charges of $290 million . For additional information, see Note 2E, Note 3 and Note 4.

Equity in the net income of investees accounted for by the equity method is not significant for any of our operating segments.

The operating segment information does not purport to represent the revenues, costs and income from continuing operations before provision for taxes on income that each of our operating segments would have recorded had each segment operated as a standalone company during the periods presented.

B. Geographic Information

Revenues exceeded $500 million in each of 12 countries outside the U.S. in 2015 , 2014 and 2013 . The U.S. is the only country to contribute more than 10% of total revenue in 2015 and 2014. The U.S. and Japan were the only countries to contribute more than 10% of total revenue in 2013.

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | |
|The following table provides revenues by geographic area: |
| | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2015 | | |2014 | | |2013 | |
|United States (a) | |$ |21,704 | | |$ |19,073 | | |$ |20,274 | |
|Developed Europe (a), (b) | |9,714 | | |11,719 | | |11,739 | |
|Developed Rest of World (a), (c) | |6,298 | | |7,314 | | |8,346 | |
|Emerging Markets (a), (d) | |11,136 | | |11,499 | | |11,225 | |
|Revenues | |$ |48,851 | | |$ |49,605 | | |$ |51,584 | |

| | |
| --- | --- |
|(a) |On September 3, 2015, we acquired Hospira. Commencing from the acquisition date, and in accordance with our domestic and international reporting periods, our consolidated statement of income for the year ended December 31, 2015 reflects four months of legacy Hospira U.S. operations and three months of legacy Hospira international operations. See Note 2A for additional information. |

| | |
| --- | --- |
|(b) |Developed Europe region includes the following markets: Western Europe, Finland and the Scandinavian countries. Revenues denominated in euros were $7.4 billion in 2015 , $9.0 billion in 2014 and $8.9 billion in 2013 . |

| | |
| --- | --- |
|(c) |Developed Rest of World region includes the following markets: Australia, Canada, Japan, New Zealand and South Korea. |

| | |
| --- | --- |
|(d) |Emerging Markets region includes, but is not limited to, the following markets: Asia (excluding Japan and South Korea), Latin America, Africa, Eastern Europe, Central Europe, the Middle East and Turkey. |

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | |
|Long-lived assets by geographic region follow (a) : |
| | |As of December 31, |
|(MILLIONS OF DOLLARS) | |2015 | | |2014 | | |2013 | |
|Property, plant and equipment, net | | | | | | |
|United States | |$ |7,072 | | |$ |5,575 | | |$ |5,885 | |
|Developed Europe (b) | |4,376 | | |4,606 | | |4,845 | |
|Developed Rest of World (c) | |660 | | |617 | | |696 | |
|Emerging Markets (d) | |1,658 | | |963 | | |971 | |
|Property, plant and equipment, net | |$ |13,766 | | |$ |11,762 | | |$ |12,397 | |

| | |
| --- | --- |
|(a) |Reflects legacy Hospira amounts in 2015 commencing on the Hospira acquisition date, September 3, 2015. |

| | |
| --- | --- |
|(b) |Developed Europe region includes the following markets: Western Europe, Finland and the Scandinavian countries. |

| | |
| --- | --- |
|(c) |Developed Rest of World region includes the following markets: Australia, Canada, Japan, New Zealand, and South Korea. |

| | |
| --- | --- |
|(d) |Emerging Markets region includes, but is not limited to, the following markets: Asia (excluding Japan and South Korea), Latin America, Africa, Eastern Europe, Central Europe, the Middle East and Turkey. |

C. Other Revenue Information

Significant Customers

We sell our biopharmaceutical products primarily to customers in the wholesale sector. In 2015 , sales to our three largest U.S. wholesaler customers represented approximately 14% , 11% and 10% of total revenues, respectively, and, collectively, represented approximately 23% of total trade accounts receivable as of December 31, 2015 . In 2014 , sales to our three largest U.S. wholesaler customers represented approximately 13% , 10% and 9% of total revenues, respectively, and, collectively, represented approximately 25% of total trade accounts receivable as of December 31, 2014 . In 2013, sales to our three largest U.S. wholesaler customers represented approximately 12% , 9% and 8% of total revenues, respectively. For all years presented, these sales and related trade accounts receivable were concentrated in our biopharmaceutical businesses.

Significant Product Revenues

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | |
|The following table provides detailed revenue information: |
| | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2015 | | |2014 | | |2013 | |
|INNOVATIVE PRODUCTS BUSINESS (a) | |$ |26,758 | | |$ |24,005 | | |$ |23,602 | |
|GIP (a) | |$ |13,954 | | |$ |13,861 | | |$ |14,317 | |
|Lyrica GIP (b) | |3,655 | | |3,350 | | |2,965 | |
|Enbrel (Outside the U.S. and Canada) | |3,333 | | |3,850 | | |3,774 | |
|Viagra GIP (c) | |1,297 | | |1,181 | | |1,180 | |
|BeneFIX | |752 | | |856 | | |832 | |
|Chantix/Champix | |671 | | |647 | | |648 | |
|Genotropin | |617 | | |723 | | |772 | |
|Refacto AF/Xyntha | |533 | | |631 | | |602 | |
|Xeljanz | |523 | | |308 | | |114 | |
|Toviaz | |267 | | |288 | | |236 | |
|BMP2 | |232 | | |228 | | |209 | |
|Somavert | |218 | | |229 | | |217 | |
|Rapamune | |197 | | |339 | | |350 | |
|Alliance revenue GIP (d) (o) | |1,254 | | |762 | | |1,878 | |
|All other GIP (e) | |405 | | |469 | | |540 | |
|VOC (a) | |$ |12,803 | | |$ |10,144 | | |$ |9,285 | |
|Prevnar family (f) | |6,245 | | |4,464 | | |3,974 | |
|Sutent | |1,120 | | |1,174 | | |1,204 | |
|Ibrance | |723 | | |— | | |— | |
|Xalkori | |488 | | |438 | | |282 | |
|Inlyta | |430 | | |410 | | |319 | |
|FSME-IMMUN/TicoVac | |104 | | |— | | |— | |
|All other V/O (e) | |298 | | |211 | | |164 | |
|Consumer Healthcare | |3,395 | | |3,446 | | |3,342 | |
|ESTABLISHED PRODUCTS BUSINESS (g) | |$ |21,587 | | |$ |25,149 | | |$ |27,619 | |
|Legacy Established Products (h) | |$ |11,745 | | |$ |13,016 | | |$ |14,089 | |
|Lipitor | |1,860 | | |2,061 | | |2,315 | |
|Premarin family | |1,018 | | |1,076 | | |1,092 | |
|Norvasc | |991 | | |1,112 | | |1,229 | |
|Xalatan/Xalacom | |399 | | |495 | | |589 | |
|Zoloft | |374 | | |423 | | |469 | |
|Relpax | |352 | | |382 | | |359 | |
|EpiPen | |339 | | |294 | | |273 | |
|Effexor | |288 | | |344 | | |440 | |
|Zithromax/Zmax | |275 | | |311 | | |387 | |
|Xanax/Xanax XR | |224 | | |253 | | |276 | |
|Cardura | |210 | | |263 | | |296 | |
|Neurontin | |196 | | |210 | | |216 | |
|Diflucan | |181 | | |208 | | |238 | |
|Tikosyn | |179 | | |141 | | |119 | |
|Depo-Provera | |170 | | |201 | | |191 | |
|Unasyn | |118 | | |96 | | |84 | |
|All other Legacy Established Products (e), (o) | |4,571 | | |5,145 | | |5,516 | |
|Peri-LOE Products (i) | |$ |5,326 | | |$ |8,855 | | |$ |10,151 | |
|Lyrica GEP (b) | |1,183 | | |1,818 | | |1,629 | |
|Zyvox | |883 | | |1,352 | | |1,353 | |
|Celebrex | |830 | | |2,699 | | |2,918 | |
|Pristiq | |715 | | |737 | | |698 | |
|Vfend | |682 | | |756 | | |775 | |
|Viagra GEP (c) | |411 | | |504 | | |701 | |
|Revatio | |260 | | |276 | | |307 | |
|All other Peri-LOE Products (e) | |362 | | |714 | | |1,770 | |
|Sterile Injectable Pharmaceuticals (j) | |$ |3,944 | | |$ |3,277 | | |$ |3,378 | |
|Medrol | |402 | | |381 | | |398 | |
|Sulperazon | |339 | | |354 | | |309 | |
|Fragmin | |335 | | |364 | | |359 | |
|Tygacil | |304 | | |323 | | |358 | |
|All other Sterile Injectable Pharmaceuticals (e) | |2,563 | | |1,855 | | |1,954 | |
|Infusion Systems (k) | |$ |403 | | |$ |— | | |$ |— | |
|Biosimilars (l) | |$ |63 | | |$ |— | | |$ |— | |
|Other Established Products (m) | |$ |106 | | |$ |— | | |$ |— | |
|OTHER (n) | |$ |506 | | |$ |451 | | |$ |364 | |
|Revenues | |$ |48,851 | | |$ |49,605 | | |$ |51,584 | |
|Total Lyrica (b) | |$ |4,839 | | |$ |5,168 | | |$ |4,595 | |
|Total Viagra (c) | |$ |1,708 | | |$ |1,685 | | |$ |1,881 | |
|Total Alliance revenues (o) | |$ |1,312 | | |$ |957 | | |$ |2,628 | |

| | |
| --- | --- |
|(a) |The Innovative Products business is composed of two operating segments: GIP and VOC. |

| | |
| --- | --- |
|(b) |Lyrica revenues from all of Europe, Russia, Turkey, Israel and Central Asia countries are included in Lyrica-GEP. All other Lyrica revenues are included in Lyrica-GIP. Total Lyrica revenues represent the aggregate of worldwide revenues from Lyrica-GIP and Lyrica-GEP. |

| | |
| --- | --- |
|(c) |Viagra revenues from the U.S. and Canada are included in Viagra-GIP. All other Viagra revenues are included in Viagra-GEP. Total Viagra revenues represent the aggregate of worldwide revenues from Viagra-GIP and Viagra-GEP. |

| | |
| --- | --- |
|(d) |Includes Eliquis, Rebif and Enbrel (in the U.S. and Canada through October 31, 2013). |

| | |
| --- | --- |
|(e) |All other GIP and All other V/O are a subset of GIP and VOC, respectively. All other Legacy Established Products, All other Peri-LOE Products and All other Sterile Injectable Pharmaceuticals are subsets of Established Products. |

| | |
| --- | --- |
|(f) |In 2015, all revenues were composed of Prevnar 13/Prevenar 13. In 2014 and 2013, revenues were composed of the Prevnar family of products, which included Prevnar 13/Prevenar 13 and, to a much lesser extent, Prevenar (7-valent). |

| | |
| --- | --- |
|(g) |The Established Products business consists of GEP, which includes all legacy Hospira commercial operations. Commencing from the acquisition date, September 3, 2015, and in accordance with our domestic and international reporting periods, our consolidated statement of income, primarily GEP’s operating results, for the year ended December 31, 2015 reflects four months of legacy Hospira U.S. operations and three months of legacy Hospira international operations. |

| | |
| --- | --- |
|(h) |Legacy Established Products include products that lost patent protection (excluding Sterile Injectable Pharmaceuticals and Peri-LOE Products). |

| | |
| --- | --- |
|(i) |Peri-LOE Products include products that have recently lost or are anticipated to soon lose patent protection. These products primarily include Celebrex, Zyvox and Revatio in most developed markets, Lyrica in the EU, Pristiq in the U.S. and Inspra in the EU. |

| | |
| --- | --- |
|(j) |Sterile Injectable Pharmaceuticals include generic injectables and proprietary specialty injectables (excluding Peri-LOE Products). |

| | |
| --- | --- |
|(k) |Infusion Systems include Medication Management Systems products composed of infusion pumps and related software and services, as well as I.V. Infusion Products, including large volume I.V. solutions and their associated administration sets. |

| | |
| --- | --- |
|(l) |Biosimilars include Inflectra (biosimilar infliximab), Nivestim (biosimilar filgrastim) and Retacrit (biosimilar epoetin zeta) in certain international markets. |

| | |
| --- | --- |
|(m) |Includes legacy Hospira’s One-to-One contract manufacturing and bulk pharmaceutical chemical sales organizations. |

| | |
| --- | --- |
|(n) |Other includes revenues from Pfizer CentreSource, our contract manufacturing and bulk pharmaceutical chemical sales organization, and revenues related to our manufacturing and supply agreements with Zoetis. |

| | |
| --- | --- |
|(o) |Total Alliance revenues represent the aggregate of worldwide revenues from Alliance revenues GIP and Alliance revenues GEP, which is included in All other Legacy Established Products. |