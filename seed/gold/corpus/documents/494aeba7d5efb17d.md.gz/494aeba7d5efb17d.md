EX-99.1 2 a14-11318\_1ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: Andrew Fisher

(202) 483-7000

Afisher@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**FIRST QUARTER 2014 FINANCIAL RESULTS**

· **Revenues of $289.4 million**

· **Net income of $137.5 million**

· **Earnings per Share of $2.73 per Basic Share or $2.43 per Diluted Share**

· **Non-GAAP Earnings of $1.77 per Basic Share or $1.57 per Diluted Share**

Silver Spring, MD, April 29, 2014: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the first quarter ended March 31, 2014.

“I am happy to report that our revenues and profits have risen nicely in line with ever-greater numbers of pulmonary arterial hypertension (PAH) patients being prescribed our medicines,” remarked Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “These financial results enable us to continue to develop our pipeline of more advanced therapeutic options for PAH.”

Total net revenues for the quarter ended March 31, 2014 were $289.4 million, up from $245.1 million for the quarter ended March 31, 2013. Gross margin from sales was $254.0 million for the quarter ended March 31, 2014, compared to $213.8 million for the same quarter last year. Net income for the quarter ended March 31, 2014 was $137.5 million or $2.73 per basic share, compared to $62.3 million or $1.24 per basic share for the same quarter in 2013.

Non-GAAP earnings(1) for the quarter ended March 31, 2014 were $89.0 million, compared to $110.1 million for the same quarter in 2013. For the quarter ended March 31, 2014, the price of our common stock declined 17 percent, which resulted in the recognition of a $60.7 million share-based compensation benefit, compared to a 14 percent stock price increase during the same quarter in 2013, and a corresponding share-based compensation expense of $35.2 million.  Our share-based compensation benefit during the quarter ended March 31, 2014 increased our net income before taxes, which in turned resulted in the recognition of $75.7 million tax expense for the quarter, compared to a $28.5 million tax expense for the same quarter in 2013.  The increased tax expense resulting from the share-based compensation benefit was the primary cause for the decrease in our non-GAAP earnings for the first quarter 2014 compared to the first quarter 2013.

* * *

(1)  See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net income to non-GAAP earnings below.

* * *  
**Financial Results for the Three Months Ended March 31, 2014**

_Revenues_

The table below summarizes the components of net revenues (dollars in thousands):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Cardiopulmonary products: | | | | | | | |
|Remodulin | |$ |136,106 | |$ |114,681 | |18\.7 |% |
|Tyvaso | |107,086 | |94,645 | |13\.1 |% |
|Adcirca | |41,361 | |33,820 | |22\.3 |% |
|Other | |4,850 | |1,990 | |143\.7 |% |
|Total net revenues | |$ |289,403 | |$ |245,136 | |18\.1 |% |

Revenues for the quarter ended March 31, 2014 increased by $44.3 million compared to the same quarter in 2013. The growth in product revenues reflects the continuing increase in the number of patients being treated with our products.

_Expenses_

The table below summarizes research and development expense by major project and non-project components (dollars in thousands):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Project and non-project component: | | | | | | | |
|Cardiopulmonary | |$ |28,288 | |$ |26,582 | |6\.4 |% |
|Share-based compensation (benefit) expense | |(26,574 |) |13,576 | |(295.7 |)% |
|Other | |10,734 | |10,272 | |4\.5 |% |
|Total research and development expense | |$ |12,448 | |$ |50,430 | |(75.3 |)% |

_Share-based compensation._ The decrease in share-based compensation of $40.2 million for the quarter ended March 31, 2014, compared to the same quarter in 2013, resulted primarily from a 17 percent decline in the price of our common stock for the quarter ended March 31, 2014, compared to a 14 percent increase in our stock price during the same period ended March 31, 2013.

The table below summarizes selling, general and administrative expense by major categories (dollars in thousands):

| | |**Three Months Ended  
March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |**Change** | |
|Category: | | | | | | | |
|General and administrative | |$ |43,148 | |$ |33,424 | |29\.1 |% |
|Sales and marketing | |18,923 | |17,388 | |8\.8 |% |
|Share-based compensation expense | |(31,856 |) |20,544 | |(255.1 |)% |
|Total selling, general and administrative expense | |$ |30,215 | |$ |71,356 | |(57.7 |)% |

_General and administrative._ The increase in general and administrative expenses of $9.7 million for the three months ended March 31, 2014, compared to the same three-month period in 2013, reflects increases in: (1) legal-related professional and consulting fees; (2) salaries and related expenses due to growth in our operations; and (3) grants to non-affiliated, non-profit organizations that provide financial assistance to patients with PAH.

_Share-based compensation._ The decrease in share-based compensation of $52.4 million for the quarter ended March 31, 2014, compared to the same quarter in 2013, resulted from a 17 percent decline in the price of our common stock for the quarter ended March 31, 2014, compared to a 14 percent increase in our stock price during the same period ended March 31, 2013.

* * *  
_Income Taxes_

The provision for income taxes was $75.7 million for the quarter ended March 31, 2014, compared to $28.5 million for the same quarter in 2013. The estimated annual effective tax rates remained substantially flat at 35 percent and 34 percent, respectively, as of March 31, 2014 and 2013.

**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for the following charges, as applicable: (1) interest; (2) license fees; (3) depreciation and amortization; (4) impairment charges; and (5) share-based compensation (stock option, share tracking award and employee stock purchase plan expense).

A reconciliation of net income to non-GAAP earnings is presented below (in thousands, except per share data):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |
|Net income, as reported | |$ |137,524 | |$ |62,325 | |
|Adjusted for the following charges: | | | | | |
|Interest expense | |4,610 | |4,436 | |
|License fees | |— | |— | |
|Depreciation and amortization | |7,565 | |8,165 | |
|Impairment charges | |— | |— | |
|Share-based compensation (benefit) expense | |(60,723 |) |35,213 | |
|Non-GAAP earnings | |$ |88,976 | |$ |110,139 | |
| | | | | | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |1\.77 | |$ |2\.19 | |
|Diluted | |$ |1\.57 | |$ |2\.10 | |
| | | | | | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |50,402 | |50,209 | |
|Diluted | |56,657 | |52,376 | |

**Conference Call**

We will host a half-hour teleconference on Tuesday, April 29, 2014, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406, and using conference code 25950152.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of unique products to address the unmet medical needs of patients with chronic and life-threatening conditions.

* * *  
**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, that does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, _Non-GAAP Earnings_ .

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, our remarks relating to our financial results and the continued development of our pipeline of more advanced therapeutic options for PAH. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of the date of this press release, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason. [uthr-g]

Orenitram is a trademark, and Remodulin and Tyvaso are registered trademarks, of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In thousands, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2014** | |**2013** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |284,553 | |$ |243,146 | |
|Other | |4,850 | |1,990 | |
|Total revenues | |289,403 | |245,136 | |
|Operating expenses: | | | | | |
|Research and development | |12,448 | |50,430 | |
|Selling, general and administrative | |30,215 | |71,356 | |
|Cost of product sales | |30,600 | |29,313 | |
|Total operating expenses | |73,263 | |151,099 | |
|Operating income | |216,140 | |94,037 | |
|Other (expense) income: | | | | | |
|Interest income | |1,232 | |979 | |
|Interest expense | |(4,610 |) |(4,436 |) |
|Other, net | |454 | |255 | |
|Total other (expense) income, net | |(2,924 |) |(3,202 |) |
|Income before income taxes | |213,216 | |90,835 | |
|Income tax expense | |(75,692 |) |(28,510 |) |
|Net income | |$ |137,524 | |$ |62,325 | |
|Net income per common share: | | | | | |
|Basic | |$ |2\.73 | |$ |1\.24 | |
|Diluted | |$ |2\.43 | |$ |1\.19 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |50,402 | |50,209 | |
|Diluted | |56,657 | |52,376 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**March 31, 2014**

**(Unaudited, in billions)**

|Cash, cash equivalents and marketable securities (excluding restricted amounts) | |$ |1\.14 | |
| --- | --- | --- | --- | --- |
|Total assets | |2\.11 | |
|Total liabilities and temporary equity | |0\.79 | |
|Total stockholders’ equity | |1\.32 | |

* * *