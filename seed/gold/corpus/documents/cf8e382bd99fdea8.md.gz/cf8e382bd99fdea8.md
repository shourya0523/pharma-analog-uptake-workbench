EX-99.1 2 exhibit991uthr12312023.htm EX-99.1 Document

Exhibit 99.1

For Immediate Release

United Therapeutics Corporation Reports Fourth Quarter and Full Year 2023 Financial Results

SILVER SPRING, Md. and RESEARCH TRIANGLE PARK, N.C., February 21, 2024: United Therapeutics Corporation (Nasdaq: UTHR ), a public benefit corporation, today announced its financial results for the quarter and year ended December 31, 2023. Full year 2023 revenues rose to a record $2.33 billion, reflecting 20% growth over 2022.

“Congratulations to the dedicated Unitherians who worked tirelessly to help us achieve our third straight quarter and second straight year of record revenue,” said Martine Rothblatt, Ph.D. , Chairperson and Chief Executive Officer of United Therapeutics. “This represents only the beginning of our growth, driven by a strong foundation in our current commercial business and upcoming enrollment milestones for our innovative pipeline. On top of this, we have continued momentum for our revolutionary organ manufacturing programs, with the first human clinical study of a bioengineered organ, the miroliver ELAP, cleared by the FDA, and the recent opening of the world’s first designated pathogen-free clinical supply facility to support our upcoming xenotransplantation clinical program.”

“Our commercial business remains a solid foundation supporting our innovative and revolutionary efforts to cure end stage organ disease,” said Michael Benkowitz , President and Chief Operating Officer of United Therapeutics. “To that end, in the fourth quarter we saw record revenue for our Tyvaso business, and we achieved solid growth in our U.S. Remodulin business, with strong revenue growth and a record number of patients on therapy despite the presence of generic competition since 2019.”

Fourth Quarter and Full Year 2023 Financial Results

Key financial highlights include (in millions, except per share data):

| | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Year Ended  
December 31, |
| |2023 | |2022 | |2023 | |2022 |
| | | | | | | | |
|Total revenues |$ |614\.7 | | |$ |491\.5 | | |$ |2,327.5 | | |$ |1,936.3 | |
|Net income |$ |217\.1 | | |$ |132\.1 | | |$ |984\.8 | | |$ |727\.3 | |
|Net income, per basic share |$ |4\.62 | | |$ |2\.88 | | |$ |21\.04 | | |$ |15\.98 | |
|Net income, per diluted share |$ |4\.36 | | |$ |2\.67 | | |$ |19\.81 | | |$ |15\.00 | |

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |1 |

* * *

Revenues

The table below presents the components of total revenues (dollars in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Dollar Change | |Percentage Change | |Year Ended  
December 31, | |Dollar Change | |Percentage Change |
| |2023 | |2022 | | | |2023 | |2022 | | |
|Net product sales: | | | | | | | | | | | | | | | |
|Tyvaso DPI ®(1) |$ |213\.7 | | |$ |92\.2 | | |$ |121\.5 | | |132 |% | |$ |731\.1 | | |$ |158\.3 | | |$ |572\.8 | | |362 |% |
|Nebulized Tyvaso ®(1) |136\.9 | | |150\.1 | | |(13.2) | | |(9) |% | |502\.6 | | |714\.7 | | |(212.1) | | |(30) |% |
|Total Tyvaso |350\.6 | | |242\.3 | | |108\.3 | | |45 |% | |1,233.7 | | |873\.0 | | |360\.7 | | |41 |% |
|Remodulin ®(2) |115\.1 | | |122\.5 | | |(7.4) | | |(6) |% | |494\.8 | | |500\.2 | | |(5.4) | | |(1) |% |
|Orenitram ® |84\.1 | | |75\.8 | | |8\.3 | | |11 |% | |359\.4 | | |325\.1 | | |34\.3 | | |11 |% |
|Unituxin ® |54\.2 | | |36\.7 | | |17\.5 | | |48 |% | |198\.9 | | |182\.9 | | |16\.0 | | |9 |% |
|Adcirca ® |6\.8 | | |10\.4 | | |(3.6) | | |(35) |% | |28\.9 | | |41\.3 | | |(12.4) | | |(30) |% |
|Other |3\.9 | | |3\.8 | | |0\.1 | | |3 |% | |11\.8 | | |13\.8 | | |(2.0) | | |(14) |% |
|Total revenues |$ |614\.7 | | |$ |491\.5 | | |$ |123\.2 | | |25 |% | |$ |2,327.5 | | |$ |1,936.3 | | |$ |391\.2 | | |20 |% |

(1) Net product sales include both the drug product and the respective inhalation device.

(2) Net product sales include sales of infusion devices including the Remunity® Pump.

Fourth Quarter 2023 Compared to Fourth Quarter 2022. Total Tyvaso revenues grew by 45% to $350.6 million in the fourth quarter of 2023, compared to $242.3 million in the fourth quarter of 2022. This growth was primarily due to an increase in quantities sold, driven by the commercial launch of Tyvaso DPI in June 2022 and continued growth in utilization by patients with pulmonary hypertension associated with interstitial lung disease ( PH-ILD ). The growth in Tyvaso DPI revenues resulted primarily from an increase in quantities sold. The decrease in nebulized Tyvaso revenues was primarily due to a decrease in U.S. quantities sold following the commercial launch of Tyvaso DPI, partially offset by an increase in international nebulized Tyvaso revenues, primarily due to the commercial launch of nebulized Tyvaso in Japan in December 2022, as shown in the table below. The decrease in Remodulin revenues resulted from a decrease in international Remodulin revenues, partially offset by an increase in U.S. Remodulin revenues, as shown in the table below. The increase in Orenitram revenues resulted from a price increase and an increase in quantities sold. The increase in Unituxin revenues resulted from an increase in quantities sold and a price increase.

Full Year 2023 Compared to Full Year 2022. Total Tyvaso revenues grew by 41% to $1,233.7 million in 2023, compared to $873.0 million in 2022. This growth was primarily due to an increase in quantities sold, driven by the commercial launch of Tyvaso DPI in June 2022 and continued growth in utilization by patients with PH-ILD. The growth in Tyvaso DPI revenues resulted primarily from an increase in quantities sold. The decrease in nebulized Tyvaso revenues was driven by a decrease in U.S. nebulized Tyvaso revenues, primarily due to a decrease in quantities sold following the commercial launch of Tyvaso DPI, partially offset by an increase in international nebulized Tyvaso revenues, primarily due to the commercial launch of nebulized Tyvaso in Japan in December 2022, as shown in the table below. The decrease in Remodulin revenues resulted from a decrease in international Remodulin revenues, partially offset by an increase in U.S. Remodulin revenues, as shown in the table below. The increase in Orenitram revenues resulted from a price increase and an increase in quantities sold. The increase in Unituxin revenues resulted primarily from a price increase.

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |2 |

* * *

The table below presents the breakdown of total revenues between the United States and rest-of-world ( ROW ) (in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended December 31, | |Year Ended December 31, | | | | |
| |2023 | |2022 | |2023 | |2022 | | |
| |U.S. |ROW |Total | |U.S. |ROW |Total | |U.S. |ROW |Total | |U.S. |ROW |Total | | | | |
|Net product sales: | | | | | | | | | | | | | | | | | | | |
|Tyvaso DPI (1) |$ |213\.7 | |$ |— | |$ |213\.7 | | |$ |92\.2 | |$ |— | |$ |92\.2 | | |$ |731\.1 | |$ |— | |$ |731\.1 | | |$ |158\.3 | |$ |— | |$ |158\.3 | | | | | |
|Nebulized Tyvaso (1) |123\.7 | |13\.2 | |136\.9 | | |148\.4 | |1\.7 | |150\.1 | | |477\.1 | |25\.5 | |502\.6 | | |708\.6 | |6\.1 | |714\.7 | | | | | |
|Total Tyvaso |337\.4 | |13\.2 | |350\.6 | | |240\.6 | |1\.7 | |242\.3 | | |1,208.2 | |25\.5 | |1,233.7 | | |866\.9 | |6\.1 | |873\.0 | | | | | |
|Remodulin (2) |106\.3 | |8\.8 | |115\.1 | | |97\.7 | |24\.8 | |122\.5 | | |414\.6 | |80\.2 | |494\.8 | | |407\.5 | |92\.7 | |500\.2 | | | | | |
|Orenitram |84\.1 | |— | |84\.1 | | |75\.8 | |— | |75\.8 | | |359\.4 | |— | |359\.4 | | |325\.1 | |— | |325\.1 | | | | | |
|Unituxin |48\.7 | |5\.5 | |54\.2 | | |36\.4 | |0\.3 | |36\.7 | | |181\.3 | |17\.6 | |198\.9 | | |170\.5 | |12\.4 | |182\.9 | | | | | |
|Adcirca |6\.8 | |— | |6\.8 | | |10\.4 | |— | |10\.4 | | |28\.9 | |— | |28\.9 | | |41\.3 | |— | |41\.3 | | | | | |
|Other |2\.6 | |1\.3 | |3\.9 | | |2\.8 | |1\.0 | |3\.8 | | |9\.8 | |2\.0 | |11\.8 | | |2\.8 | |11\.0 | |13\.8 | | | | | |
|Total revenues |$ |585\.9 | |$ |28\.8 | |$ |614\.7 | | |$ |463\.7 | |$ |27\.8 | |$ |491\.5 | | |$ |2,202.2 | |$ |125\.3 | |$ |2,327.5 | | |$ |1,814.1 | |$ |122\.2 | |$ |1,936.3 | | | | | |

(1) Net product sales include both the drug product and the respective inhalation device.

(2) Net product sales include sales of infusion devices including the Remunity Pump.

Expenses

Cost of sales. The table below summarizes cost of sales by major category (dollars in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Dollar Change | |Percentage Change | |Year Ended  
December 31, | |Dollar Change | |Percentage Change |
| |2023 | |2022 | | | |2023 | |2022 | | |
|Category: | | | | | | | | | | | | | | | |
|Cost of sales |$ |70\.1 | | |$ |55\.9 | | |$ |14\.2 | | |25 |% | |$ |255\.1 | | |$ |146\.7 | | |$ |108\.4 | | |74 |% |
|Share-based compensation expense (1) |0\.9 | | |2\.9 | | |(2.0) | | |(69) |% | |2\.4 | | |4\.9 | | |(2.5) | | |(51) |% |
|Total cost of sales |$ |71\.0 | | |$ |58\.8 | | |$ |12\.2 | | |21 |% | |$ |257\.5 | | |$ |151\.6 | | |$ |105\.9 | | |70 |% |

(1) See Share-based compensation below.

Cost of sales, excluding share-based compensation. The increase in cost of sales for the quarter ended December 31, 2023, as compared to the same period in 2022, was primarily due to an increase in Tyvaso DPI royalty expense and product costs following its commercial launch in June 2022.

The increase in cost of sales for the year ended December 31, 2023, as compared to the same period in 2022, was primarily due to an increase in Tyvaso DPI royalty expense and product costs, following its commercial launch in June 2022, and an increase in Remunity product sales.

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |3 |

* * *

Research and development expense. The table below summarizes the nature of research and development expense by major expense category (dollars in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Dollar Change | |Percentage Change | |Year Ended  
December 31, | |Dollar Change | |Percentage Change |
| |2023 | |2022 | | | |2023 | |2022 | | |
|Category: | | | | | | | | | | | | | | | |
|External research and development (1) |$ |50\.4 | | |$ |46\.7 | | |$ |3\.7 | | |8 |% | |$ |192\.0 | | |$ |168\.8 | | |$ |23\.2 | | |14 |% |
|Internal research and development (2) |43\.2 | | |35\.4 | | |7\.8 | | |22 |% | |146\.6 | | |131\.4 | | |15\.2 | | |12 |% |
|Share-based compensation expense (3) |5\.7 | | |11\.0 | | |(5.3) | | |(48) |% | |15\.6 | | |23\.8 | | |(8.2) | | |(34) |% |
|Impairments (4) |— | | |— | | |— | | |— |% | |— | | |— | | |— | | |— |% |
|Other (5) |52\.1 | | |0\.8 | | |51\.3 | | |NM (6) | |53\.8 | | |(1.1) | | |54\.9 | | |NM (6) |
|Total research and development expense |$ |151\.4 | | |$ |93\.9 | | |$ |57\.5 | | |61 |% | |$ |408\.0 | | |$ |322\.9 | | |$ |85\.1 | | |26 |% |

(1) External research and development primarily includes fees paid to third parties (such as clinical trial sites, contract research organizations, and contract laboratories) for preclinical and clinical studies and payments to third-party contract manufacturers before FDA approval of the relevant product.

(2) Internal research and development primarily includes salary-related expenses for research and development functions, internal costs to manufacture product candidates before FDA approval, and internal facilities-related expenses, including depreciation, related to research and development activities.

(3) See Share-based compensation below.

(4) Impairments primarily includes impairment charges to write down the carrying value of in-process research and development ( IPR&D ) and of certain property, plant, and equipment as a result of research and development activities. There were no impairment charges during the years ended December 31, 2023 and December 31, 2022.

(5) Other primarily includes upfront fees and milestone payments to third parties under license agreements related to development-stage products, adjustments to the fair value of our contingent consideration obligations, and costs to acquire certain IPR&D assets. During the quarter and year ended December 31, 2023, we recorded $46.0 million in IPR&D expense in connection with the acquisition of IVIVA Medical, Inc. ( IVIVA ).

(6) Calculation is not meaningful.

Research and development, excluding share-based compensation . The increase in research and development expense for the quarter ended December 31, 2023, as compared to the same period in 2022, was due to an increase in IPR&D expense in connection with the acquisition of IVIVA and increased expenditures related to the TETON 1 and TETON 2 clinical studies of nebulized Tyvaso in patients with idiopathic pulmonary fibrosis ( IPF ).

The increase in research and development expense for the year ended December 31, 2023, as compared to the same period in 2022, was due to: (1) an increase in IPR&D expense in connection with the acquisition of IVIVA; (2) increased expenditures related to the TETON 1 and TETON 2 clinical studies of nebulized Tyvaso in patients with IPF; and (3) increased expenditures related to organ manufacturing projects.

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |4 |

* * *

Selling, general, and administrative expense. The table below summarizes selling, general, and administrative expense by major category (dollars in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Dollar Change | |Percentage Change | |Year Ended  
December 31, | |Dollar Change | |Percentage Change |
| |2023 | |2022 | | | |2023 | |2022 | | |
|Category: | | | | | | | | | | | | | | | |
|General and administrative |$ |98\.1 | | |$ |89\.3 | | |$ |8\.8 | | |10 |% | |$ |374\.2 | | |$ |333\.2 | | |$ |41\.0 | | |12 |% |
|Sales and marketing |24\.1 | | |23\.0 | | |1\.1 | | |5 |% | |81\.8 | | |70\.8 | | |11\.0 | | |16 |% |
|Share-based compensation expense (1) |10\.0 | | |50\.9 | | |(40.9) | | |(80) |% | |21\.1 | | |78\.1 | | |(57.0) | | |(73) |% |
|Total selling, general, and administrative expense |$ |132\.2 | | |$ |163\.2 | | |$ |(31.0) | | |(19) |% | |$ |477\.1 | | |$ |482\.1 | | |$ |(5.0) | | |(1) |% |

(1) See Share-based compensation below.

General and administrative, excluding share-based compensation . The increase in general and administrative expense for the year ended December 31, 2023, as compared to the same period in 2022, was primarily due to increases in: (1) office expenses; (2) personnel expense due to growth in headcount; and (3) sponsorships and grants.

Sales and marketing, excluding share-based compensation . The increase in sales and marketing expense for the year ended December 31, 2023, as compared to the same period in 2022, was primarily due to increases in: (1) personnel expense due to growth in headcount; and (2) consulting expenses.

Share-based compensation. The table below summarizes share-based compensation expense by major category (dollars in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Dollar Change | |Percentage Change | |Year Ended  
December 31, | |Dollar Change | |Percentage Change |
| |2023 | |2022 | | | |2023 | |2022 | | |
|Category: | | | | | | | | | | | | | | | |
|Stock options |$ |2\.9 | | |$ |5\.8 | | |$ |(2.9) | | |(50) |% | |$ |15\.4 | | |$ |22\.6 | | |$ |(7.2) | | |(32) |% |
|Restricted stock units |14\.1 | | |12\.1 | | |2\.0 | | |17 |% | |52\.4 | | |35\.7 | | |16\.7 | | |47 |% |
|Share tracking awards plan ( STAP ) |(0.9) | | |46\.5 | | |(47.4) | | |(102) |% | |(30.7) | | |46\.7 | | |(77.4) | | |(166) |% |
| | | | | | | | | | | | | | | | |
|Employee stock purchase plan |0\.5 | | |0\.4 | | |0\.1 | | |25 |% | |2\.0 | | |1\.8 | | |0\.2 | | |11 |% |
|Total share-based compensation expense |$ |16\.6 | | |$ |64\.8 | | |$ |(48.2) | | |(74) |% | |$ |39\.1 | | |$ |106\.8 | | |$ |(67.7) | | |(63) |% |

The decrease in share-based compensation expense for the quarter ended December 31, 2023, as compared to the same period in 2022, was primarily due to an increase in STAP benefit driven by a three percent decrease in our stock price during the quarter ended December 31, 2023, as compared to a 33 percent increase in our stock price for the same period in 2022. The decrease in share-based compensation expense for the year ended December 31, 2023, as compared to the same period in 2022, was primarily due to: (1) an increase in STAP benefit driven by a 21 percent decrease in our stock price during 2023, as compared to a 29 percent increase in our stock price during 2022; and (2) a decrease in stock option expense due to fewer awards remaining outstanding in 2023, as compared to the same period in 2022, partially offset by an increase in restricted stock unit expense.

Other expense, net. The change in other expense, net for the year ended December 31, 2023, as compared to the same period in 2022, was primarily due to net unrealized and realized gains and losses on equity securities.

Income tax expense. Income tax expense was $289.5 million for the year ended December 31, 2023, compared to $223.3 million for the same period in 2022. Our effective income tax rate was approximately 23 percent for the years ended December 31, 2023 and 2022.

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |5 |

* * *

Inducement Restricted Stock Units

On February 19, 2024, we granted a total of 11,250 restricted stock units under our 2019 Inducement Stock Incentive Plan to six newly hired employees. All of these restricted stock units will vest in full on February 19, 2027, the third anniversary of the grant date, assuming continued employment on such date, and subject to the standard terms and conditions we filed with the SEC as Exhibit 10.2 to our Current Report on Form 8-K on March 1, 2019. We are providing this information in accordance with Nasdaq Listing Rule 5635(c)(4).

Webcast

We will host a webcast to discuss our fourth quarter and full year 2023 financial results on Wednesday, February 21, 2024, at 9:00 a.m. Eastern Time. The webcast can be accessed live via our website at https://ir.unither.com/events-and-presentations/default.aspx. A replay of the webcast will also be available at the same location on our website.

United Therapeutics: Enabling Inspiration

At United Therapeutics, our vision and mission are one. We use our enthusiasm, creativity, and persistence to innovate for the unmet medical needs of our patients and to benefit our other stakeholders. We are bold and unconventional. We have fun, we do good. We are the first publicly-traded biotech or pharmaceutical company to take the form of a public benefit corporation ( PBC ). Our public benefit purpose is to provide a brighter future for patients through (a) the development of novel pharmaceutical therapies; and (b) technologies that expand the availability of transplantable organs .

You can learn more about what it means to be a PBC here: unither.com/pbc.

Forward-Looking Statements

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, statements related to our future growth expectations from both our current commercial operations and our pipeline; our organ manufacturing programs, including our efforts to cure end-stage organ disease and the anticipated clinical trials of miroliver ELAP and our xenotransplantation program; and our goals of innovating for the unmet medical needs of our patients and to benefit our other stakeholders, furthering our public benefit purpose of developing novel pharmaceutical therapies and technologies that expand the availability of transplantable organs. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of February 21, 2024, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events, or any other reason.

MIROLIVERELAP, ORENITRAM, REMODULIN, REMUNITY, TYVASO, TYVASO DPI, and UNITUXIN are registered trademarks of United Therapeutics Corporation and/or its subsidiaries.

ADCIRCA is a registered trademark of Eli Lilly and Company.

For Further Information Contact:

Dewey Steadman at (202) 919-4097

https://ir.unither.com/contact-ir

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |6 |

* * *

UNITED THERAPEUTICS CORPORATION

CONSOLIDATED STATEMENTS OF OPERATIONS

(In millions, except per share data)

| | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended  
December 31, | |Year Ended  
December 31, |
| |2023 | |2022 | |2023 | |2022 |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| |(Unaudited) | | | | |
|Total revenues |$ |614\.7 | | |$ |491\.5 | | |$ |2,327.5 | | |$ |1,936.3 | |
|Operating expenses: | | | | | | | |
|Cost of sales |71\.0 | | |58\.8 | | |257\.5 | | |151\.6 | |
|Research and development |151\.4 | | |93\.9 | | |408\.0 | | |322\.9 | |
|Selling, general, and administrative |132\.2 | | |163\.2 | | |477\.1 | | |482\.1 | |
| | | | | | | | |
|Total operating expenses |354\.6 | | |315\.9 | | |1,142.6 | | |956\.6 | |
|Operating income |260\.1 | | |175\.6 | | |1,184.9 | | |979\.7 | |
| | | | | | | | |
|Interest income |51\.0 | | |20\.8 | | |162\.7 | | |45\.2 | |
|Interest expense |(15.1) | | |(12.3) | | |(59.3) | | |(32.4) | |
|Other expense, net |(0.6) | | |(5.3) | | |(14.0) | | |(40.2) | |
|Impairment of investment in privately-held company |— | | |— | | |— | | |(1.7) | |
|Total other income (expense), net |35\.3 | | |3\.2 | | |89\.4 | | |(29.1) | |
|Income before income taxes |295\.4 | | |178\.8 | | |1,274.3 | | |950\.6 | |
|Income tax expense |(78.3) | | |(46.7) | | |(289.5) | | |(223.3) | |
|Net income |$ |217\.1 | | |$ |132\.1 | | |$ |984\.8 | | |$ |727\.3 | |
|Net income per common share: | | | | | | | |
|Basic |$ |4\.62 | | |$ |2\.88 | | |$ |21\.04 | | |$ |15\.98 | |
|Diluted |$ |4\.36 | | |$ |2\.67 | | |$ |19\.81 | | |$ |15\.00 | |
|Weighted average number of common shares outstanding: | | | | | | | |
|Basic |47\.0 | | |45\.8 | | |46\.8 | | |45\.5 | |
|Diluted |49\.8 | | |49\.4 | | |49\.7 | | |48\.5 | |

SELECTED CONSOLIDATED BALANCE SHEET DATA

(In millions)

| | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |December 31, |
| |2023 | |2022 |
|Cash, cash equivalents, and marketable investments |$ |4,903.9 | | |$ |4,154.9 | |
|Total assets |7,167.0 | | |6,044.5 | |
|Total liabilities |1,182.2 | | |1,247.8 | |
|Total stockholders' equity |5,984.8 | | |4,796.7 | |

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |7 |

* * *

The table below presents the breakdown of select historical total revenues between the United States and ROW (in millions):

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended | | | | |
| |March 31, 2023 |June 30, 2023 |September 30, 2023 |December 31, 2023 | | |
| |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total | | | | |
|Net product sales: | | | | | | | | | | | | | | | | |
|Tyvaso DPI (1) |$ |118\.7 | |$ |— | |$ |118\.7 | |$ |193\.6 | |$ |— | |$ |193\.6 | |$ |205\.1 | |$ |— | |$ |205\.1 | |$ |213\.7 | |$ |— | |$ |213\.7 | | | | | |
|Nebulized Tyvaso (1) |115\.7 | |4\.0 | |119\.7 | |119\.6 | |5\.7 | |125\.3 | |118\.1 | |2\.6 | |120\.7 | |123\.7 | |13\.2 | |136\.9 | | | | | |
|Total Tyvaso |234\.4 | |4\.0 | |238\.4 | |313\.2 | |5\.7 | |318\.9 | |323\.2 | |2\.6 | |325\.8 | |337\.4 | |13\.2 | |350\.6 | | | | | |
|Remodulin (2) |93\.2 | |28\.2 | |121\.4 | |103\.5 | |23\.7 | |127\.2 | |111\.6 | |19\.5 | |131\.1 | |106\.3 | |8\.8 | |115\.1 | | | | | |
|Orenitram |88\.2 | |— | |88\.2 | |95\.1 | |— | |95\.1 | |92\.0 | |— | |92\.0 | |84\.1 | |— | |84\.1 | | | | | |
|Unituxin |44\.3 | |4\.8 | |49\.1 | |39\.5 | |4\.8 | |44\.3 | |48\.8 | |2\.5 | |51\.3 | |48\.7 | |5\.5 | |54\.2 | | | | | |
|Adcirca |7\.3 | |— | |7\.3 | |7\.5 | |— | |7\.5 | |7\.3 | |— | |7\.3 | |6\.8 | |— | |6\.8 | | | | | |
|Other |2\.3 | |0\.2 | |2\.5 | |3\.2 | |0\.3 | |3\.5 | |1\.7 | |0\.2 | |1\.9 | |2\.6 | |1\.3 | |3\.9 | | | | | |
|Total revenues |$ |469\.7 | |$ |37\.2 | |$ |506\.9 | |$ |562\.0 | |$ |34\.5 | |$ |596\.5 | |$ |584\.6 | |$ |24\.8 | |$ |609\.4 | |$ |585\.9 | |$ |28\.8 | |$ |614\.7 | | | | | |

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended | | | | |
| |March 31, 2022 |June 30, 2022 |September 30, 2022 |December 31, 2022 | | |
| |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total | | | | |
|Net product sales: | | | | | | | | | | | | | | | | |
|Tyvaso DPI (1) |$ |— | |$ |— | |$ |— | |$ |3\.0 | |$ |— | |$ |3\.0 | |$ |63\.1 | |$ |— | |$ |63\.1 | |$ |92\.2 | |$ |— | |$ |92\.2 | | | | | |
|Nebulized Tyvaso (1) |170\.1 | |1\.9 | |172\.0 | |196\.2 | |1\.8 | |198\.0 | |193\.9 | |0\.7 | |194\.6 | |148\.4 | |1\.7 | |150\.1 | | | | | |
|Total Tyvaso |170\.1 | |1\.9 | |172\.0 | |199\.2 | |1\.8 | |201\.0 | |257\.0 | |0\.7 | |257\.7 | |240\.6 | |1\.7 | |242\.3 | | | | | |
|Remodulin (2) |99\.1 | |32\.6 | |131\.7 | |108\.5 | |23\.5 | |132\.0 | |102\.2 | |11\.8 | |114\.0 | |97\.7 | |24\.8 | |122\.5 | | | | | |
|Orenitram |82\.8 | |— | |82\.8 | |79\.0 | |— | |79\.0 | |87\.5 | |— | |87\.5 | |75\.8 | |— | |75\.8 | | | | | |
|Unituxin |48\.0 | |7\.6 | |55\.6 | |43\.3 | |1\.2 | |44\.5 | |42\.8 | |3\.3 | |46\.1 | |36\.4 | |0\.3 | |36\.7 | | | | | |
|Adcirca |9\.8 | |— | |9\.8 | |10\.4 | |— | |10\.4 | |10\.7 | |— | |10\.7 | |10\.4 | |— | |10\.4 | | | | | |
|Other |— | |10\.0 | |10\.0 | |— | |— | |— | |— | |— | |— | |2\.8 | |1\.0 | |3\.8 | | | | | |
|Total revenues |$ |409\.8 | |$ |52\.1 | |$ |461\.9 | |$ |440\.4 | |$ |26\.5 | |$ |466\.9 | |$ |500\.2 | |$ |15\.8 | |$ |516\.0 | |$ |463\.7 | |$ |27\.8 | |$ |491\.5 | | | | | |

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |Three Months Ended | | | | |
| |March 31, 2021 |June 30, 2021 |September 30, 2021 |December 31, 2021 | | |
| |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total |U.S. |ROW |Total | | | | |
|Net product sales: | | | | | | | | | | | | | | | | |
|Tyvaso DPI (1) |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | |$ |— | | | | | |
|Nebulized Tyvaso (1) |122\.4 | |0\.6 | |123\.0 | |152\.6 | |1\.2 | |153\.8 | |160\.7 | |3\.5 | |164\.2 | |165\.0 | |1\.5 | |166\.5 | | | | | |
|Total Tyvaso |122\.4 | |0\.6 | |123\.0 | |152\.6 | |1\.2 | |153\.8 | |160\.7 | |3\.5 | |164\.2 | |165\.0 | |1\.5 | |166\.5 | | | | | |
|Remodulin (2) |107\.1 | |23\.1 | |130\.2 | |111\.0 | |28\.8 | |139\.8 | |106\.8 | |18\.6 | |125\.4 | |98\.5 | |19\.8 | |118\.3 | | | | | |
|Orenitram |72\.4 | |— | |72\.4 | |76\.2 | |— | |76\.2 | |85\.2 | |— | |85\.2 | |72\.3 | |— | |72\.3 | | | | | |
|Unituxin |42\.8 | |1\.1 | |43\.9 | |48\.3 | |4\.8 | |53\.1 | |44\.8 | |10\.5 | |55\.3 | |42\.2 | |7\.8 | |50\.0 | | | | | |
|Adcirca |9\.6 | |— | |9\.6 | |23\.6 | |— | |23\.6 | |14\.6 | |— | |14\.6 | |8\.1 | |— | |8\.1 | | | | | |
|Other |— | |— | |— | |— | |— | |— | |— | |— | |— | |— | |— | |— | | | | | |
|Total revenues |$ |354\.3 | |$ |24\.8 | |$ |379\.1 | |$ |411\.7 | |$ |34\.8 | |$ |446\.5 | |$ |412\.1 | |$ |32\.6 | |$ |444\.7 | |$ |386\.1 | |$ |29\.1 | |$ |415\.2 | | | | | |

(1) Net product sales include both the drug product and the respective inhalation device.

(2) Net product sales include sales of infusion devices including the Remunity Pump.

| | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |8 |