1. 
2. News Releases
3. Gilead-Sciences-Announces-Third-Quarter-2016-Financial-Results

November 1, 2016

# Gilead Sciences Announces Third Quarter 2016 Financial Results

Back

_**\- Product Sales of $7.4 billion \-**_

_**\- Diluted EPS of $2.49 per share -**_

_**\- Non-GAAP Diluted EPS of $2.75 per share -**_

_**\- Reiterates Full Year 2016 Guidance -**_

FOSTER CITY, Calif. \--(BUSINESS WIRE)--Nov. 1, 2016-- Gilead Sciences, Inc. (Nasdaq: GILD) announced today its results of
operations for the third quarter ended September 30, 2016 . The financial
results that follow represent a year-over-year comparison of third
quarter 2016 to the third quarter 2015. Total revenues were $7.5 billion in 2016 compared to $8.3 billion in 2015. Net income was $3.3 billion or $2.49 per diluted share in 2016 compared to $4.6 billion or $3.06 per
diluted share in 2015. Non-GAAP net income, which excludes amounts
related to acquisition-related, up-front collaboration, stock-based
compensation and other expenses, was $3.7 billion or $2.75 per diluted
share in 2016 compared to $4.8 billion or $3.22 per diluted share in
2015\.

|**Three Months Ended** |**Nine Months Ended** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**September 30,** |**September 30,** |
|**(In millions, except per share amounts)** |**2016** |**2015** |**2016** |**2015** |
|Product sales |$ |7,405 |$ |8,211 |$ |22,737 |$ |23,742 |
|Royalty, contract and other revenues |95 |84 |333 |391 |
|Total revenues |$ |7,500 |$ |8,295 |$ |23,070 |$ |24,133 |
|Net income attributable to Gilead |$ |3,330 |$ |4,600 |$ |10,393 |$ |13,425 |
|Non-GAAP net income \* |$ |3,677 |$ |4,836 |$ |12,128 |$ |14,285 |
|Diluted earnings per share |$ |2\.49 |$ |3\.06 |$ |7\.59 |$ |8\.73 |
|Non-GAAPdiluted earnings per share \* |$ |2\.75 |$ |3\.22 |$ |8\.87 |$ |9\.29 |

_\* Non-GAAP net income and non-GAAP diluted earnings per share exclude
acquisition-related, up-front collaboration, stock-based compensation
and other expenses. A reconciliation between GAAP and non-GAAP financial
information is provided in the tables on pages 7 and 8._

**Product Sales**

Total product sales for the third quarter of 2016 were $7.4 billion compared to $8.2 billion for the same period in 2015. Product sales for
the third quarter of 2016 were $5.1 billion in the United States , $1.4
billion in Europe , $452 million in Japan and $479 million in other
locations. Product sales for the third quarter of 2015 were $5.6 billion in the United States , $1.7 billion in Europe , $454 million in Japan and $504 million in other locations.

**Antiviral Product Sales**

Antiviral product sales, which include primarily products in Gilead’s
HIV and liver disease areas, were $6.8 billion for the third quarter of
2016 compared to $7.7 billion for the same period in 2015.

* HIV and other antiviral product sales were $3.5 billion compared to $2.9 billion for the same period in 2015. The increase was primarily
  due to the continued uptake of our tenofovir alafenamide (TAF) based
  products, Genvoya ® (elvitegravir 150 mg/cobicistat 150
  mg/emtricitabine 200 mg/tenofovir alafenamide 10 mg), Descovy ® (emtricitabine 200 mg/tenofovir alafenamide 25 mg) and Odefsey ® (emtricitabine
  200 mg/rilpivirine 25 mg/tenofovir alafenamide 25 mg).
* HCV product sales, which consist of Harvoni ® (ledipasvir 90
  mg/sofosbuvir 400 mg), Sovaldi ® (sofosbuvir 400 mg) and
  Epclusa ® (sofosbuvir 400 mg/velpatasvir 100 mg), were $3.3
  billion compared to $4.8 billion for the same period in 2015. The
  decline was due to lower sales of Harvoni and Sovaldi, partially
  offset by sales of Epclusa, which was launched in the United States and Europe in June and July 2016 , respectively.

**Other Product Sales**

Other product sales, which include Letairis ® (ambrisentan),
Ranexa ® (ranolazine) and AmBisome ® (amphotericin B
liposome for injection), were $564 million for the third quarter of 2016
compared to $509 million for the same period in 2015.

**Operating Expenses**

|**Three Months Ended** |**Nine Months Ended** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**September 30,** |**September 30,** |
|**(In millions)** |**2016** |**2015** |**2016** |**2015** |
|Research and development expenses (R&D) |$ |1,141 |$ |743 |$ |3,890 |$ |2,257 |
|Non-GAAP research and development expenses \* |$ |981 |$ |713 |$ |2,790 |$ |2,066 |
|Selling, general and administrative expenses (SG&A) |$ |831 |$ |903 |$ |2,406 |$ |2,360 |
|Non-GAAP selling, general and administrative expenses \* |$ |780 |$ |850 |$ |2,256 |$ |2,211 |

_\*_ _Non-GAAP R&D and SG&A expenses exclude acquisition-related,
up-front collaboration, stock-based compensation and other expenses. A
reconciliation between GAAP and non-GAAP financial information is
provided in the tables on pages 7 and 8._

During the third quarter of 2016, compared to the same period in 2015:

* Research and development expenses and non-GAAP research and
  development expenses \* increased primarily due to the
  overall progression of Gilead’s clinical studies, including a $200
  million milestone expense associated with Gilead’s purchase of Nimbus
  Apollo, Inc.
* Selling, general and administrative expenses and non-GAAP selling,
  general and administrative expenses \* decreased primarily
  due to lower branded prescription drug fee expense.

**Cash, Cash Equivalents and Marketable Securities**

As of September 30, 2016 , Gilead had $31.6 billion of cash, cash
equivalents and marketable securities compared to $24.6 billion as of June 30, 2016 . This increase was primarily due to the issuance of $5.0
billion aggregate principal amount of senior unsecured notes in September 2016 . Cash flow from operating activities was $4.3 billion for
the quarter. During the third quarter and the first nine months of 2016,
Gilead utilized $1.0 billion and $10.0 billion on stock repurchases,
respectively.

**Full Year 2016 Guidance Reiterated**

Gilead reiterates its full year 2016 guidance, as revised on July 25,
2016 :

|**(In millions, except percentages and per share amounts)** |**Updated July 25, 2016**

**Reiterated November 1, 2016** |
| --- | --- |
|Net Product Sales |$29,500 - $30,500 |
|Non-GAAP \* |
|Product Gross Margin |88% - 90% |
|R&D Expenses |$3,600 - $3,800 |
|SG&A Expenses |$3,100 - $3,300 |
|Effective Tax Rate |18\.0% - 20.0% |
|Diluted EPS Impact of Acquisition-related, Up-front Collaboration,
Stock-based Compensation and Other Expenses |$1.47 - $1.53 |

_\*_ _Non-GAAP Product Gross Margin, R&D and SG&A expenses and
effective tax rate exclude acquisition-related, up-front collaboration,
stock-based compensation and other expenses. A reconciliation between
GAAP and non-GAAP full year 2016 guidance is provided in the tables on
page 9._

**Corporate Highlights**

* Announced that Kelly A. Kramer was appointed to the company’s Board of
  Directors and Audit Committee. Ms. Kramer is currently Executive Vice
  President and Chief Financial Officer of Cisco Systems, Inc.
* Announced that Gilead entered into a partnership with the World Health
  Organization (WHO) to provide $20 million in funding and drug
  donations over five years to expand access to diagnostic services and
  treatment for visceral leishmaniasis (VL). As part of this
  collaboration, Gilead will donate 380,000 vials of AmBisome to meet
  the needs of WHO to treat VL in key endemic countries, including Bangladesh , Ethiopia , India , Nepal , South Sudan and Sudan .

**Product and Pipeline Updates announced by Gilead during the Third Quarter of 2016 include:**

* Announced that the European Commission granted marketing authorization
  for once-daily Truvada® (emtricitabine 200 mg/tenofovir disoproxil 245
  mg) in combination with safer-sex practices to reduce the risk of
  sexually acquired HIV-1 infection among uninfected adults at high
  risk, a strategy known as pre-exposure prophylaxis, or PrEP. Truvada
  was approved by the European Medicines Agency in 2005 for use in
  combination with other antiretroviral agents for the treatment of
  HIV-1 infection in adults aged 18 years and over, and is currently the
  most prescribed antiretroviral medicine in Europe as part of
  combination therapy.
* Announced that the European Commission granted marketing authorization
  for Epclusa, the first pan-genotypic, single tablet regimen for the
  treatment of adults with genotype 1-6 chronic hepatitis C virus (HCV)
  infection. Epclusa for 12 weeks was authorized for use in patients
  without cirrhosis or with compensated cirrhosis (Child-Pugh A), and in
  combination with ribavirin (RBV) for patients with decompensated
  cirrhosis (Child-Pugh B or C). Epclusa is also the first single tablet
  regimen approved for the treatment of patients with HCV genotype 2 and
  3, without the need for RBV. Physicians also have the flexibility to
  consider the addition of RBV for genotype 3 infected patients with
  compensated cirrhosis. The marketing authorization followed an
  accelerated review procedure by the European Medicines Agency ,
  reserved for medicinal products expected to be of major public health
  interest.

**Non-GAAP Financial Information**

The information presented in this document has been prepared by Gilead
in accordance with U.S. generally accepted accounting principles (GAAP),
unless otherwise noted as non-GAAP. Management believes non-GAAP
information is useful for investors, when considered in conjunction with
Gilead’s GAAP financial information, because management uses such
information internally for its operating, budgeting and financial
planning purposes. Non-GAAP information is not prepared under a
comprehensive set of accounting rules and should only be used to
supplement an understanding of Gilead’s operating results as reported
under GAAP. Non-GAAP measures may be defined and calculated differently
by other companies in the same industry. A reconciliation between GAAP
and non-GAAP financial information is provided in the tables on pages 7,
8 and 9.

**Conference Call**

At 4:30 p.m. Eastern Time today, Gilead’s management will host a
conference call and a simultaneous webcast to discuss results from its
third quarter 2016 as well as provide a general business update. To
access the webcast live via the internet, please connect to the
company’s website at [www.gilead.com/investors](http://www.gilead.com/investors) 15 minutes prior to the conference call to ensure adequate time for any
software download that may be needed to hear the webcast. Alternatively,
please call 1-877-359-9508 (U.S.) or 1-224-357-2393 (international) and
dial the conference ID 82848433 to access the call.

A replay of the webcast will be archived on the company’s website for
one year, and a phone replay will be available approximately two hours
following the call through November 3, 2016 . To access the phone replay,
please call 1-855-859-2056 (U.S.) or 1-404-537-3406 (international) and
dial the conference ID 82848433.

**About Gilead**

Gilead Sciences is a biopharmaceutical company that discovers, develops
and commercializes innovative therapeutics in areas of unmet medical
need. The company’s mission is to advance the care of patients suffering
from life-threatening diseases. Gilead has operations in more than 30
countries worldwide, with headquarters in Foster City, California .

**Forward-looking Statements**

Statements included in this press release that are not historical in
nature are forward-looking statements within the meaning of the Private
Securities Litigation Reform Act of 1995. Gilead cautions readers that
forward-looking statements are subject to certain risks and
uncertainties that could cause actual results to differ materially.
These risks and uncertainties include: Gilead’s ability to achieve its
anticipated full year 2016 financial results; Gilead’s ability to
sustain growth in revenues for its antiviral and other programs; the
risk that estimates of patients with HCV or anticipated patient demand
may not be accurate; the risk that private and public payers may be
reluctant to provide, or continue to provide, coverage or reimbursement
for new products, including Epclusa, Harvoni, Genvoya, Odefsey and
Descovy; the potential for increased pricing pressure and contracting
pressure as well as decreased volume and market share from additional
competitive HCV launches, austerity measures in European countries and Japan that may increase the amount of discount required on Gilead’s
products, additional negotiated discounts for patient access, shifts in
payer mix to more deeply discounted government payer segments and
geographic regions and decreases in treatment duration; availability of
funding for state AIDS Drug Assistance Programs (ADAPs) and Veterans
Administration (VA); continued fluctuations in ADAP and VA purchases
driven by federal and state grant cycles which may not mirror patient
demand and may cause fluctuations in Gilead’s earnings; the possibility
of unfavorable results from clinical trials involving investigational
compounds; Gilead’s ability to initiate clinical trials in its currently
anticipated timeframes; the levels of inventory held by wholesalers and
retailers which may cause fluctuations in Gilead’s earnings; Gilead’s
ability to submit new drug applications for new product candidates in
the timelines currently anticipated; Gilead’s ability to receive
regulatory approvals in a timely manner or at all, for new and current
products; Gilead’s ability to successfully commercialize its products,
including Epclusa, Harvoni, Genvoya, Odefsey and Descovy; the risk that
physicians and patients may not see advantages of these products over
other therapies and may therefore be reluctant to prescribe the
products; Gilead’s ability to successfully develop its oncology,
inflammation, cardiovascular and respiratory programs; safety and
efficacy data from clinical studies may not warrant further development
of Gilead’s product candidates; Gilead’s ability to complete its share
repurchase program due to changes in its stock price, corporate or other
market conditions; fluctuations in the foreign exchange rate of the U.S.
dollar that may cause an unfavorable foreign currency exchange impact on
Gilead’s future revenues and pre-tax earnings; and other risks
identified from time to time in Gilead’s reports filed with the U.S.
Securities and Exchange Commission ( SEC ). In addition, Gilead makes
estimates and judgments that affect the reported amounts of assets,
liabilities, revenues and expenses and related disclosures. Gilead bases
its estimates on historical experience and on various other market
specific and other relevant assumptions that it believes to be
reasonable under the circumstances, the results of which form the basis
for making judgments about the carrying values of assets and liabilities
that are not readily apparent from other sources. Actual results may
differ significantly from these estimates. You are urged to consider
statements that include the words may, will, would, could, should,
might, believes, estimates, projects, potential, expects, plans,
anticipates, intends, continues, forecast, designed, goal, or the
negative of those words or other comparable words to be uncertain and
forward-looking. Gilead directs readers to its press releases, Quarterly
Report on Form 10-Q for the quarter ended June 30, 2016 and other
subsequent disclosure documents filed with the SEC . Gilead claims the
protection of the Safe Harbor contained in the Private Securities
Litigation Reform Act of 1995 for forward-looking statements.

All forward-looking statements are based on information currently
available to Gilead, and Gilead assumes no obligation to update any such
forward-looking statements.

Gilead owns or has rights to various trademarks, copyrights and trade
names used in our business, including the following: GILEAD ® , GILEAD SCIENCES ® , AMBISOME ® , CAYSTON ® ,
COMPLERA ® , DESCOVY ® ,EMTRIVA ® ,
EPCLUSA ® , EVIPLERA ® , GENVOYA ® , HARVONI ® ,
HEPSERA ® , LETAIRIS ® , ODEFSEY ® , RANEXA ® ,
RAPISCAN ® , SOVALDI ® , STRIBILD ® , TRUVADA ® ,
TYBOST ® , VIREAD ® , VITEKTA ® , VOLIBRIS ® ,
and ZYDELIG ® .

ATRIPLA® is a registered trademark belonging to Bristol-Myers Squibb & Gilead Sciences, LLC . LEXISCAN® is a registered trademark belonging to Astellas U.S. LLC . MACUGEN® is a registered trademark belonging to Eyetech, Inc. SUSTIVA® is a registered trademark of Bristol-Myers Squibb
Pharma Company . TAMIFLU® is a registered trademark belonging to Hoffmann-La Roche Inc.

_For more information on Gilead Sciences, Inc. , please visit_ _[www.gilead.com](http://www.gilead.com)_ _or call the Gilead Public Affairs Department at 1-800-GILEAD-5
(1-800-445-3235)._

|**GILEAD SCIENCES, INC.**

**CONDENSED CONSOLIDATED STATEMENTS OF INCOME**

**(unaudited)**

**(in millions, except per share amounts)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**2016** |**2015** |**2016** |**2015** |
|Revenues: |
|Product sales |$ |7,405 |$ |8,211 |$ |22,737 |$ |23,742 |
|Royalty, contract and other revenues |95 |84 |333 |391 |
|Total revenues |7,500 |8,295 |23,070 |24,133 |
|Costs and expenses: |
|Cost of goods sold |1,129 |1,064 |3,186 |2,944 |
|Research and development expenses |1,141 |743 |3,890 |2,257 |
|Selling, general and administrative expenses |831 |903 |2,406 |2,360 |
|Total costs and expenses |3,101 |2,710 |9,482 |7,561 |
|Income from operations |4,399 |5,585 |13,588 |16,572 |
|Interest expense |(242 |) |(165 |) |(699 |) |(458 |) |
|Other income (expense), net |119 |52 |288 |108 |
|Income before provision for income taxes |4,276 |5,472 |13,177 |16,222 |
|Provision for income taxes |951 |880 |2,788 |2,801 |
|Net income |3,325 |4,592 |10,389 |13,421 |
|Net loss attributable to noncontrolling interest |(5 |) |(8 |) |(4 |) |(4 |) |
|Net income attributable to Gilead |$ |3,330 |$ |4,600 |$ |10,393 |$ |13,425 |
|Net income per share attributable to Gilead common stockholders -
basic |$ |2\.52 |$ |3\.14 |$ |7\.72 |$ |9\.11 |
|Shares used in per share calculation - basic |1,322 |1,463 |1,347 |1,474 |
|Net income per share attributable to Gilead common stockholders -
diluted |$ |2\.49 |$ |3\.06 |$ |7\.59 |$ |8\.73 |
|Shares used in per share calculation - diluted |1,339 |1,503 |1,369 |1,538 |
|Cash dividends declared per share |$ |0\.47 |$ |0\.43 |$ |1\.37 |$ |0\.86 |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION**

**(unaudited)**

**(in millions, except percentages and per share amounts)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**2016** |**2015** |**2016** |**2015** |
|**Cost of goods sold reconciliation:** |
|GAAP cost of goods sold |$ |1,129 |$ |1,064 |$ |3,186 |$ |2,944 |
|Acquisition related-amortization of purchased intangibles |(210 |) |(207 |) |(630 |) |(620 |) |
|Stock-based compensation expenses |(4 |) |(3 |) |(11 |) |(9 |) |
|Other (1) |3 |2 |9 |3 |
|Non-GAAP cost of goods sold |$ |918 |$ |856 |$ |2,554 |$ |2,318 |
|**Product gross margin reconciliation:** |
|GAAP product gross margin |84\.8 |% |87\.0 |% |86\.0 |% |87\.6 |% |
|Acquisition related-amortization of purchased intangibles |2\.8 |% |2\.5 |% |2\.8 |% |2\.6 |% |
|Non-GAAP product gross margin (2) |87\.6 |% |89\.6 |% |88\.8 |% |90\.2 |% |
|**Research and development expenses reconciliation:** |
|GAAP research and development expenses |$ |1,141 |$ |743 |$ |3,890 |$ |2,257 |
|Up-front collaboration expenses |(5 |) |— |(373 |) |— |
|Acquisition related expenses-acquired IPR&D |— |— |(400 |) |(66 |) |
|Acquisition related-IPR&D impairment |(117 |) |— |(231 |) |— |
|Stock-based compensation expenses |(44 |) |(44 |) |(129 |) |(128 |) |
|Other (1) |6 |14 |33 |3 |
|Non-GAAP research and development expenses |$ |981 |$ |713 |$ |2,790 |$ |2,066 |
|**Selling, general and administrative expenses reconciliation:** |
|GAAP selling, general and administrative expenses |$ |831 |$ |903 |$ |2,406 |$ |2,360 |
|Stock-based compensation expenses |(47 |) |(50 |) |(138 |) |(148 |) |
|Other (1) |(4 |) |(3 |) |(12 |) |(1 |) |
|Non-GAAP selling, general and administrative expenses |$ |780 |$ |850 |$ |2,256 |$ |2,211 |
|**Operating margin reconciliation:** |
|GAAP operating margin |58\.7 |% |67\.3 |% |58\.9 |% |68\.7 |% |
|Up-front collaboration expenses |0\.1 |% |— |% |1\.6 |% |— |% |
|Acquisition related-amortization of purchased intangibles |2\.8 |% |2\.5 |% |2\.7 |% |2\.6 |% |
|Acquisition related expenses-acquired IPR&D |— |% |— |% |1\.7 |% |0\.3 |% |
|Acquisition related-IPR&D impairment |1\.6 |% |— |% |1\.0 |% |— |% |
|Stock-based compensation expenses |1\.3 |% |1\.2 |% |1\.2 |% |1\.2 |% |
|Other (1) |(0.1 |)% |(0.2 |)% |(0.1 |)% |— |% |
|Non-GAAP operating margin (2) |64\.3 |% |70\.8 |% |67\.1 |% |72\.7 |% |
|Notes: |
|(1) Amounts related to consolidation of a contract
manufacturer, contingent consideration and/or other individually
insignificant amounts |
|(2) Amounts may not sum due to rounding |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION -
(Continued)**

**(unaudited)**

**(in millions, except percentages and per share amounts)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**2016** |**2015** |**2016** |**2015** |
|**Effective tax rate reconciliation:** |
|GAAP effective tax rate |22\.2 |% |16\.1 |% |21\.2 |% |17\.3 |% |
|Up-front collaboration expenses |— |% |— |% |(0.5 |)% |— |% |
|Acquisition related-amortization of purchased intangibles |(0.4 |)% |(0.2 |)% |(0.7 |)% |(0.4 |)% |
|Acquisition related expenses-acquired IPR&D |— |% |— |% |(0.5 |)% |— |% |
|Stock-based compensation expenses |— |% |0\.4 |% |— |% |0\.1 |% |
|Non-GAAP effective tax rate (1) |21\.8 |% |16\.3 |% |19\.5 |% |17\.0 |% |
|**Net income attributable to Gilead reconciliation:** |
|GAAP net income attributable to Gilead |$ |3,330 |$ |4,600 |$ |10,393 |$ |13,425 |
|Up-front collaboration expenses |5 |— |373 |— |
|Acquisition related-amortization of purchased intangibles |204 |202 |612 |605 |
|Acquisition related expenses-acquired IPR&D |— |— |400 |66 |
|Acquisition related-IPR&D impairment |74 |— |173 |— |
|Stock-based compensation expenses |70 |44 |203 |184 |
|Other (2) |(6 |) |(10 |) |(26 |) |5 |
|Non-GAAP net income |$ |3,677 |$ |4,836 |$ |12,128 |$ |14,285 |
|**Diluted earnings per share reconciliation:** |
|GAAP diluted earnings per share |$ |2\.49 |$ |3\.06 |$ |7\.59 |$ |8\.73 |
|Up-front collaboration expenses |— |— |0\.27 |— |
|Acquisition related-amortization of purchased intangibles |0\.15 |0\.13 |0\.45 |0\.39 |
|Acquisition related expenses-acquired IPR&D |— |— |0\.29 |0\.04 |
|Acquisition related-IPR&D impairment |0\.06 |— |0\.13 |— |
|Stock-based compensation expenses |0\.05 |0\.03 |0\.15 |0\.12 |
|Other (2) |— |(0.01 |) |(0.02 |) |0\.01 |
|Non-GAAP diluted earnings per share (1) |$ |2\.75 |$ |3\.22 |$ |8\.87 |$ |9\.29 |
|**Shares used in per share calculation (diluted) reconciliation:** |
|GAAP shares used in per share calculation (diluted) |1,339 |1,503 |1,369 |1,538 |
|Share impact of current stock-based compensation rules |(1 |) |(1 |) |(1 |) |(1 |) |
|Non-GAAP shares used in per share calculation (diluted) |1,338 |1,502 |1,368 |1,537 |
|**Non-GAAP adjustment summary:** |
|Cost of goods sold adjustments |$ |211 |$ |208 |$ |632 |$ |626 |
|Research and development expenses adjustments |160 |30 |1,100 |191 |
|Selling, general and administrative expenses adjustments |51 |53 |150 |149 |
|Other income (expense) adjustments |— |1 |— |1 |
|Total non-GAAP adjustments before tax |422 |292 |1,882 |967 |
|Income tax effect |(74 |) |(58 |) |(151 |) |(116 |) |
|Other (2) |(1 |) |2 |4 |9 |
|Total non-GAAP adjustments after tax |$ |347 |$ |236 |$ |1,735 |$ |860 |
|Notes: |
|(1) Amounts may not sum due to rounding |
|(2) Amounts related to consolidation of a contract
manufacturer, contingent consideration and/or other individually
insignificant amounts |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP 2016 FULL YEAR GUIDANCE**

**(unaudited)**

**(in millions, except percentages and per share amounts)** |
| --- | --- |
|**Updated July 25, 2016**

**Reiterated November 1, 2016** |
|**Projected product gross margin GAAP to non-GAAP reconciliation:** |
|GAAP projected product gross margin |85% - 87% |
|Acquisition-related expenses |3% - 3% |
|Non-GAAP projected product gross margin (1) |88% - 90% |
|**Projected research and development expenses GAAP to non-GAAP
reconciliation:** |
|GAAP projected research and development expenses |$4,700 - $4,945 |
|Acquisition-related expenses / up-front collaboration expenses |(915) - (945) |
|Stock-based compensation expenses |(185) - (200) |
|Non-GAAP projected research and development expenses |$3,600 - $3,800 |
|**Projected selling, general and administrative expenses GAAP to
non-GAAP reconciliation:** |
|GAAP projected selling, general and administrative expenses |$3,305 - $3,515 |
|Stock-based compensation expenses |(205) - (215) |
|Non-GAAP projected selling, general and administrative expenses |$3,100 - $3,300 |
|**Projected diluted EPS impact of acquisition-related, up-front
collaboration, stock-based compensation and other expenses:** |
|Acquisition-related expenses / up-front collaboration expenses |$1.26 - $1.30 |
|Stock-based compensation expenses |0\.21 - 0.23 |
|Projected diluted EPS impact of acquisition-related, up-front
collaboration, stock-based compensation and other expenses |$1.47 - $1.53 |
|Note: |
|(1) Stock-based compensation expenses have a less than
one percent impact on non-GAAP projected product gross margin |

|**GILEAD SCIENCES, INC.**

**CONDENSED CONSOLIDATED BALANCE SHEETS**

**(unaudited)**

**(in millions)** |
| --- | --- | --- | --- | --- |
|**September 30,** |**December 31,** |
|**2016** |**2015** **(1)** |
|Cash, cash equivalents and marketable securities |$ |31,611 |$ |26,208 |
|Accounts receivable, net |5,075 |5,854 |
|Inventories |1,900 |1,955 |
|Property, plant and equipment, net |2,714 |2,276 |
|Intangible assets, net |9,386 |10,247 |
|Goodwill |1,172 |1,172 |
|Other assets |4,751 |4,004 |
|Total assets |$ |56,609 |$ |51,716 |
|Current liabilities |$ |11,073 |$ |9,890 |
|Long-term liabilities |28,176 |22,711 |
|Equity component of currently redeemable convertible notes |— |2 |
|Stockholders’ equity (2) |17,360 |19,113 |
|Total liabilities and stockholders’ equity |$ |56,609 |$ |51,716 |
|Notes: |
|(1) Derived from the audited consolidated financial
statements as of December 31, 2015. Certain amounts have been
reclassified to conform to current year presentation |
|(2) As of September 30, 2016, there were 1,322 million
shares of common stock issued and outstanding |

|**GILEAD SCIENCES, INC.**

**PRODUCT SALES SUMMARY**

**(unaudited)**

**(in millions)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**2016** |**2015** |**2016** |**2015** |
|Antiviral products: |
|Harvoni – U.S. |$ |1,084 |$ |2,541 |$ |3,965 |$ |8,383 |
|Harvoni – Europe |380 |532 |1,447 |1,632 |
|Harvoni – Japan |309 |111 |1,644 |111 |
|Harvoni – Other International |87 |148 |385 |393 |
|1,860 |3,332 |7,441 |10,519 |
|Truvada – U.S. |573 |561 |1,780 |1,470 |
|Truvada – Europe |217 |268 |713 |846 |
|Truvada – Other International |68 |74 |205 |207 |
|858 |903 |2,698 |2,523 |
|Sovaldi – U.S. |363 |692 |1,783 |1,728 |
|Sovaldi – Europe |184 |337 |727 |1,342 |
|Sovaldi – Japan |143 |343 |516 |405 |
|Sovaldi – Other International |135 |94 |434 |254 |
|825 |1,466 |3,460 |3,729 |
|Atripla – U.S. |486 |597 |1,454 |1,640 |
|Atripla – Europe |129 |161 |412 |533 |
|Atripla – Other International |35 |60 |132 |161 |
|650 |818 |1,998 |2,334 |
|Epclusa – U.S. |593 |— |657 |— |
|Epclusa – Europe |40 |— |40 |— |
|Epclusa – Other International |7 |— |7 |— |
|640 |— |704 |— |
|Stribild – U.S. (1) |525 |422 |1,227 |1,068 |
|Stribild – Europe |78 |73 |243 |199 |
|Stribild – Other International |18 |16 |57 |47 |
|621 |511 |1,527 |1,314 |
|Genvoya – U.S. |407 |— |816 |— |
|Genvoya – Europe |46 |— |92 |— |
|Genvoya – Other International |8 |— |13 |— |
|461 |— |921 |— |
|Complera / Eviplera – U.S. (1) |254 |210 |675 |580 |
|Complera / Eviplera – Europe |143 |137 |445 |427 |
|Complera / Eviplera – Other International |14 |13 |40 |40 |
|411 |360 |1,160 |1,047 |
|Viread – U.S. |155 |151 |420 |385 |
|Viread – Europe |77 |76 |234 |233 |
|Viread – Other International |71 |70 |208 |184 |
|303 |297 |862 |802 |
|Odefsey – U.S. |95 |— |164 |— |
|Odefsey – Europe |10 |— |10 |— |
|105 |— |174 |— |
|Descovy – U.S. |65 |— |114 |— |
|Descovy – Europe |23 |— |35 |— |
|88 |— |149 |— |

|Note: |
| --- |
|(1) Amounts for the three and nine months ended September
30, 2016 include a favorable adjustment of rebate reserves of $223
million and $89 million for Stribild and Complera, respectively |

|**GILEAD SCIENCES, INC.**

**PRODUCT SALES SUMMARY - (Continued)**

**(unaudited)**

**(in millions)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**2016** |**2015** |**2016** |**2015** |
|Other Antiviral – U.S. |$ |14 |$ |8 |$ |36 |$ |30 |
|Other Antiviral – Europe |5 |6 |18 |20 |
|Other Antiviral – Other International |— |1 |2 |3 |
|19 |15 |56 |53 |
|Total antiviral products – U.S. |4,614 |5,182 |13,091 |15,284 |
|Total antiviral products – Europe |1,332 |1,590 |4,416 |5,232 |
|Total antiviral products – Japan |452 |454 |2,160 |516 |
|Total antiviral products – Other International |443 |476 |1,483 |1,289 |
|6,841 |7,702 |21,150 |22,321 |
|Other products: |
|Letairis |215 |181 |593 |508 |
|Ranexa |170 |161 |467 |419 |
|AmBisome |91 |88 |262 |276 |
|Zydelig |39 |36 |129 |92 |
|Other |49 |43 |136 |126 |
|564 |509 |1,587 |1,421 |
|Total product sales |$ |7,405 |$ |8,211 |$ |22,737 |$ |23,742 |

View source version on businesswire.com: <http://www.businesswire.com/news/home/20161101006646/en/>

Source: Gilead Sciences, Inc.

Gilead Sciences, Inc. **Investors** Robin
Washington, 650-522-5688Sung Lee, 650-524-7792 **Media** Amy
Flood, 650-522-5643

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2016 Financial Results&body=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2016 Financial Results&url=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results&via=Gilead)

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2016 Financial Results&body=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2016 Financial Results&url=https://www.gilead.com/news/news-details/2016/gilead-sciences-announces-third-quarter-2016-financial-results&via=Gilead)

## Other News

_Some of the content on this page is not intended for users outside the U.S._

View All

No Results Found

Loading Results...

### Discover More

##### Therapeutic Areas

##### Research

##### Giving@Gilead

This is our global website, intended for visitors seeking information on Gilead’s worldwide business. Some content on this site is not intended for people outside the United States. Visit our Global Operations page for links to our international corporate websites.

* [](https://twitter.com/GileadSciences)
* [](https://www.linkedin.com/company/gilead-sciences/)
* [](https://www.instagram.com/gileadsciences/)
* [](https://www.facebook.com/GileadSciences)
* [](https://www.youtube.com/channel/UCNSt7PtsfNGbezR9hmvRI1w)

### QUICK LINKS

* [Investors](https://investors.gilead.com/overview/default.aspx)
* [Find a Trial](https://www.gileadclinicaltrials.com)
* Pipeline
* [Search for Jobs](https://gilead.wd1.myworkdayjobs.com/gileadcareers)
* News
* Stories@Gilead

### GET IN TOUCH

* Contact Us
* Report an Adverse Event
* [Medical Information](https://www.askgileadmedical.com)
* Partnership Request

### LEGAL

* [Modern Slavery Act Statement](https://www.gilead.com/-/media/files/pdfs/company/policies-and-disclosures/modern-slavery-statement.pdf)
* Public Policy Engagement
* Social Media Guidelines
* Privacy Statement
* Consumer Health Data Privacy Policy
* Terms of Use
* Cookie Statement

* * *