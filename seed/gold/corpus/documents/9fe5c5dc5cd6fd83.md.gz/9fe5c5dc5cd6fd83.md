1. 
2. News Releases
3. Gilead-Sciences-Announces-Third-Quarter-2021-Financial-Results

October 28, 2021

# Gilead Sciences Announces Third Quarter 2021 Financial Results

Back

_2 Million Patients Received Veklury (remdesivir) or Licensed Generic Remdesivir in the Third Quarter_

_Biktarvy Sales Increased 20% Year-Over-Year to Record $2.3 Billion_

FOSTER CITY, Calif.--(BUSINESS WIRE)--
Gilead Sciences, Inc. (Nasdaq: GILD) announced today its results of operations for the third quarter 2021.

“This was a very strong third quarter with continued positive momentum for both our commercial performance and our pipeline progress,” said Daniel O’Day, Chairman and Chief Executive Officer, Gilead Sciences. “Veklury is making a significant impact as the COVID-19 pandemic continues to evolve. The dynamics of the HIV treatment market further improved and this contributed to record Biktarvy revenue. In oncology, our marketed portfolio continues to expand with four new country approvals for Trodelvy for metastatic triple-negative breast cancer, the approval of Tecartus in relapsed or refractory acute lymphoblastic leukemia and two new trial starts for magrolimab in solid tumors.”

**Third Quarter 2021 Financial Results**

* Total third quarter 2021 revenue of $7.4 billion increased 13% compared to the same period in 2020, due to increased demand for Veklury **®** (remdesivir 100 mg for injection).
* Diluted Earnings Per Share (“EPS”) increased to $2.05 for the third quarter 2021 compared to $0.29 for the same period in 2020. The increase was primarily driven by lower acquired in-process research and development (“IPR&D”) expenses, higher net sales and lower unrealized losses from our equity securities.
* Non-GAAP diluted EPS increased 26% to $2.65 for the third quarter 2021 compared to $2.11 for the same period in 2020, primarily due to higher operating income, partially offset by lower interest income.
* As of September 30, 2021, Gilead had $6.8 billion of cash, cash equivalents and marketable debt securities compared to $7.9 billion as of December 31, 2020.
* During the third quarter 2021, Gilead generated $3.3 billion in operating cash flow.
* During the third quarter 2021, Gilead made $2.5 billion in debt repayments, paid cash dividends of $900 million and utilized $145 million to repurchase common stock.

**Product Sales Performance**

Total third quarter 2021 product sales increased 13% to $7.4 billion compared to the same period in 2020. Total product sales excluding Veklury decreased 3% to $5.4 billion for the third quarter 2021 compared to the same period in 2020, primarily reflecting the expected loss of exclusivity of Truvada **®** (emtricitabine (“FTC”) 200 mg/tenofovir disoproxil fumarate 300 mg (“TDF”)) and Atripla **®** (efavirenz 600 mg/FTC 200 mg/TDF 300mg) in the United States, partially offset by continued increased demand for Biktarvy **®** (bictegravir 50 mg/FTC 200 mg/tenofovir alafenamide 25 mg (“TAF”)) and Trodelvy ® (sacituzumab govitecan-hziy).

HIV product sales decreased 8% to $4.2 billion for the third quarter 2021 compared to the same period in 2020, reflecting, as expected, the loss of exclusivity of Truvada and Atripla in the United States, as well as lower channel inventory as compared to the same period in 2020, primarily driven by pandemic-related stocking in the prior year, partially offset by higher Biktarvy demand and improved trends in the treatment market.

* **Biktarvy** sales increased 20% year-over-year in the third quarter 2021, reflecting higher treatment demand and net price.
* **Descovy ®** (FTC 200 mg/TAF 25 mg) sales decreased 15% year-over-year in the third quarter 2021, primarily driven by lower net price.
* **Truvada** and **Atripla** sales decreased 87% and 76% year-over-year, respectively, in the third quarter 2021, as expected, due to the loss of exclusivity in the United States in late 2020.

Hepatitis C virus (“HCV”) product sales decreased 8% to $429 million for the third quarter 2021 compared to the same period in 2020, primarily driven by a favorable settlement in the same period 2020 that did not repeat, fewer patient starts outside the United States, and timing of Department of Corrections purchases on a relative basis.

Hepatitis B virus (“HBV”) and hepatitis delta virus (“HDV”) product sales increased 17% to $247 million for the third quarter 2021 compared to the same period in 2020. **Vemlidy ®** (TAF 25 mg) sales increased 18% in the third quarter 2021 compared to the same period in 2020, driven primarily by uptake in geographies outside the United States. **Hepcludex ®** (bulevirtide) contributed $12 million in the third quarter 2021 as launch activities continued across Europe.

Cell Therapy product sales increased 51% to $222 million for the third quarter 2021 compared to the same period in 2020.

* **Yescarta ®** (axicabtagene ciloleucel) sales increased to $175 million in the third quarter 2021, driven by continued demand in relapsed or refractory large B-cell lymphoma (“LBCL”) and strong uptake in relapsed or refractory indolent follicular lymphoma in the United States and Europe.
* **Tecartus ®** (brexucabtagene autoleucel) sales were $47 million for the third quarter 2021, driven by increased adoption in mantle cell lymphoma in the United States and Europe.

**Trodelvy** sales for the third quarter 2021 were $101 million, reflecting increased use for the second-line treatment of metastatic triple-negative breast cancer (“TNBC”) and metastatic urothelial cancer in the United States.

**Veklury** sales were $1.9 billionfor the third quarter 2021. Sales of Veklury are generally affected by COVID-19 related rates of infections, hospitalizations and vaccinations.

**Third Quarter 2021 Product Gross Margin, Operating Expenses and Tax**

* Product gross margin was 83.4% for the third quarter 2021 compared to 82.4% in the same period in 2020, driven by the reversal of a previously recorded $175 million litigation reserve following a favorable court decision, as well as lower royalty expense and change in product mix, partially offset by higher amortization of intangibles acquired from Immunomedics, Inc. and MYR GmbH (“MYR”). Non-GAAP product gross margin was 90.0% for the third quarter 2021 compared to 86.5% in the same period in 2020, driven by the reversal of the aforementioned previously recorded litigation reserve following a favorable court decision, as well as lower royalty expense and change in product mix.
* Research and Development (“R&D”) expenses and non-GAAP R&D expenses for the third quarter 2021 were $1.1 billion compared to $1.2 billion in the same period in 2020. Lower R&D expenses reflect completion or wind-down of remdesivir and inflammation related clinical programs, partially offset by increases in Trodelvy and magrolimab clinical activities.
* Selling, General and Administrative (“SG&A”) expenses and non-GAAP SG&A expenses for the third quarter 2021 were $1.2 billion compared to $1.1 billion in the same period in 2020. The increase in SG&A expenses was driven by increased promotional and marketing activities across all geographies, primarily for Trodelvy.
* The GAAP effective tax rate (“ETR”) and non-GAAP ETR for the third quarter 2021 were 24.8% and 18.9%, respectively, compared to 57.2 % and 18.4%, respectively, for the same period in 2020.

**Key Updates Since Our Last Quarterly Release**

**_Viral Diseases_**

* Presented positive results at the IDWeek conference from the Phase 3 double-blind, placebo-controlled trial (PINETREE) of Veklury administered intravenously in non-hospitalized COVID-19 patients at high risk for disease progression. Results demonstrated statistically significant reduction in risk for COVID-19 related hospitalization with Veklury compared with placebo.
* Received Priority Review designations from FDA for the lenacapavir New Drug Applications (“NDAs”) for the treatment of HIV-1 infection in heavily treatment-experienced patients with multidrug resistance in combination with other antiretroviral agents. The NDAs have been granted a Prescription Drug User Fee Act action date of February 28, 2022.
* Announced that the Marketing Authorization Application (“MAA”) for lenacapavir, an investigational, long-acting HIV-1 capsid inhibitor, was fully validated by European Medicines Agency (“EMA”). The proposed indication is for the treatment of HIV-1 infection, in combination with other antiretroviral(s), in adults with multidrug resistant HIV-1 infection who are currently on a failing antiretroviral treatment regimen due to resistance, intolerance or safety considerations.
* Announced the initiation of the Phase 2 study evaluating an oral weekly combination of lenacapavir and islatravir in people who are living with HIV who are virologically suppressed on an antiretroviral therapy.
* Began enrollment into the Phase 3 PURPOSE 1 trial in cisgender girls and young women, the second Phase 3 study of lenacapavir for HIV pre-exposure prophylaxis. The first Phase 3 study (PURPOSE 2) was initiated in July and is enrolling cisgender men, transgender men and women, and gender non-binary individuals who have sex with men.
* Received FDA approval for the supplemental NDA of a new low-dose tablet form of Biktarvy (bictegravir 30mg/FTC 120mg/TAF 15mg), expanding the indication to include younger children weighing at least 14 kg to less than 25 kg who are virologically suppressed or new to antiretroviral therapy. Biktarvy (bictegravir 50mg/FTC 200mg/TAF 25mg) is approved for appropriate pediatric patients weighing at least 25 kg.

**_Oncology_**

* Announced the inclusion of Trodelvy into the National Comprehensive Cancer Network Guidelines for Breast Cancer as a preferred regimen for the treatment of adult patients with metastatic TNBC who received at least two prior therapies, with at least one for metastatic disease.
* Received a positive opinion from the Committee for Medicinal Products for Human Use of the EMA for Trodelvy for the treatment of adults with unresectable or metastatic TNBC who have received two or more prior systemic therapies, at least one of them for advanced disease. The final European Commission decision is anticipated later in 2021.
* Received approval from Health Canada for Trodelvy for the treatment of adult patients with unresectable locally advanced or metastatic TNBC who have received two or more prior therapies, at least one of them for metastatic disease. Canada represents the fifth approval for Trodelvy in metastatic TNBC under the Project Orbis Initiative, following approvals in Australia, Great Britain, Switzerland, and the United States.
* Presented sub-analyses data from the Phase 3 ASCENT study evaluating Trodelvy in patients with relapsed or refractory metastatic TNBC at the European Society of Medical Oncology annual meeting. Results showed significant and clinically-meaningful improvements in health-related quality of life, and, in patients whose initial diagnosis was not TNBC but changed to triple-negative, Trodelvy demonstrated similar positive outcomes to the overall metastatic TNBC population.
* Announced the submission of a supplemental Biologics License Application to FDA for Yescarta to expand its current indication to include the treatment of adults with relapsed or refractory LBCL in the second-line setting.
* Received FDA approval for Tecartus for the treatment of adult patients with relapsed or refractory B-cell precursor acute lymphoblastic leukemia.
* Announced a collaboration and license agreement with Appia Bio, Inc. to research and develop hematopoietic stem cells-derived cell therapies directed toward hematological malignancies.

**_Corporate_**

* Announced that the company’s Board of Directors has declared a quarterly dividend of $0.71 per share of common stock for the fourth quarter of 2021. The dividend is payable on December 30, 2021, to stockholders of record at the close of business on December 15, 2021. Future dividends will be subject to Board approval.
* Announced donation of 100,000 vials of Veklury to Indonesia and 3,000 vials to Armenia to help patients hospitalized with COVID-19.

**Guidance and Outlook**

Gilead has updated its full-year guidance, and now expects:

* Total product sales between $26.0 billion and $26.3 billion, compared to $24.4 billion and $25.0 billion previously, reflecting year-to-date results and our updated expectations for the fourth quarter 2021.
* Total product sales, excluding Veklury, of approximately $21.5 billion, compared to $21.7 billion and $21.9 billion previously, primarily reflecting the longer than expected pandemic impact on our business.
* Total Veklury sales between $4.5 billion and $4.8 billion, compared to $2.7 billion and $3.1 billion previously, primarily reflecting the surge in COVID-19 hospitalizations in the third quarter 2021, and our expectations for a significant step-down in hospitalization rates in the fourth quarter 2021.
* GAAP earnings per share between $5.50 and $5.70, compared to $4.70 and $5.05 previously.
* Non-GAAP earnings per share between $7.90 and $8.10, compared to $6.90 and $7.25 previously.

A reconciliation between GAAP and non-GAAP financial information for the 2021 guidance is provided in the accompanying tables. Also see the Forward-Looking Statements described below. The financial guidance is subject to a number of risks and uncertainties, including uncertainty around the duration and magnitude of the COVID-19 pandemic. While the pandemic can be expected to continue to impact Gilead’s business and broader market dynamics, the rate and degree of these impacts as well as the corresponding recovery from the pandemic may vary across Gilead’s business.

**Non-GAAP Financial Information**

The information presented in this document has been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), unless otherwise noted as non-GAAP. Management believes non-GAAP information is useful for investors, when considered in conjunction with Gilead’s GAAP financial information, because management uses such information internally for its operating, budgeting and financial planning purposes. Non-GAAP information is not prepared under a comprehensive set of accounting rules and should only be used to supplement an understanding of Gilead’s operating results as reported under GAAP. Non-GAAP financial information generally excludes acquisition-related expenses including amortization of acquired intangible assets and inventory step-up charges, acquired IPR&D expenses, and other items that are considered unusual or not representative of underlying trends of Gilead’s business, fair value adjustments of equity securities and discrete and related tax charges or benefits associated with changes in tax related laws and guidelines. Acquired IPR&D expenses reflect IPR&D impairments as well as the initial costs of externally developed IPR&D projects, acquired directly in a transaction other than a business combination, that do not have an alternative future use, including upfront and other payments related to various collaborations and the initial costs of rights to IPR&D projects. Although Gilead consistently excludes the amortization of acquired intangible assets from the non-GAAP financial information, management believes that it is important for investors to understand that such intangible assets were recorded as part of acquisitions and contribute to ongoing revenue generation.Non-GAAP measures may be defined and calculated differently by other companies in the same industry. Reconciliations of the non-GAAP financial measures to the most directly comparable GAAP financial measures are provided in the accompanying tables.

**Conference Call**

At 1:30 p.m. Pacific Time today, Gilead will host a conference call to discuss Gilead’s results. A live webcast will be available on [http://investors.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Finvestors.gilead.com&esheet=52517279&newsitemid=20211028006178&lan=en-US&anchor=http%3A%2F%2Finvestors.gilead.com&index=1&md5=5aa0ddd31067fbe660bd6d3079f912ce) and will be archived on [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=52517279&newsitemid=20211028006178&lan=en-US&anchor=www.gilead.com&index=2&md5=e8ddc4417c232c00e7f584a3d246a2d7) for one year.

**About Gilead Sciences**

Gilead Sciences, Inc. is a biopharmaceutical company that has pursued and achieved breakthroughs in medicine for more than three decades, with the goal of creating a healthier world for all people. The company is committed to advancing innovative medicines to prevent and treat life-threatening diseases, including HIV, viral hepatitis and cancer. Gilead operates in more than 35 countries worldwide, with headquarters in Foster City, California.

**Forward-Looking Statements**

Statements included in this press release that are not historical in nature are forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. Gilead cautions readers that forward-looking statements are subject to certain risks and uncertainties that could cause actual results to differ materially. These risks and uncertainties include those relating to: the impact of the COVID-19 pandemic on Gilead’s business, financial condition and results of operations; the development, manufacturing and distribution of Veklury as a treatment for COVID-19, including the uncertainty of the amount and timing of future Veklury sales, Gilead’s ability to recoup the expenses incurred to date and future expenses related to the development and production of Veklury, and Gilead’s ability to effectively manage the global supply and distribution of Veklury; Gilead’s ability to achieve its anticipated full year 2021 financial results, including as a result of potential adverse revenue impacts from COVID-19, increases in R&D expenses and potential revenues from Veklury; Gilead’s ability to make progress on any of its long-term ambitions or strategic priorities laid out in its corporate strategy; Gilead’s ability to accelerate or sustain revenues for its antiviral and other programs; Gilead’s ability to realize the potential benefits of acquisitions, collaborations or licensing arrangements, including those involving Appia Bio, Inc.; Gilead’s ability to initiate, progress or complete clinical trials within currently anticipated timeframes or at all, and the possibility of unfavorable results from ongoing and additional clinical trials, including those involving Trodelvy and Veklury; the risk that safety and efficacy data from clinical studies may not warrant further development of Gilead’s product candidates or the product candidates of Gilead’s strategic partners; Gilead’s ability to submit new drug applications for new product candidates in the currently anticipated timelines; Gilead’s ability to receive regulatory approvals in a timely manner or at all, including FDA approval of lenacapavir for treatment of HIV-1 infection in heavily treatment-experienced people with multi-drug resistant infection, EMA approval of lenacapavir for treatment of HIV-1 infection, in combination with other antiretroviral(s), in adults with multidrug resistant HIV-1 infection who are currently on a failing antiretroviral treatment regimen due to resistance, intolerance or safety considerations, EMA approval of Trodelvy for the treatment of adults with unresectable or metastatic TNBC who have received two or more prior systemic therapies, at least one of them for advanced disease, and FDA approval of Yescarta for treatment of adults with relapsed or refractory LBCL in the second-line setting, and the risk that any such approvals may be subject to significant limitations on use; Gilead’s ability to successfully commercialize its products; the risk of potential disruptions to the manufacturing and supply chain of Gilead’s products; pricing and reimbursement pressures from government agencies and other third parties, including required rebates and other discounts; a larger than anticipated shift in payer mix to more highly discounted payer segments; market share and price erosion caused by the introduction of generic versions of Gilead products; the risk that physicians and patients may not see advantages of these products over other therapies and may therefore be reluctant to prescribe the products; and other risks identified from time to time in Gilead’s reports filed with the SEC, including annual reports on Form 10-K, quarterly reports on Form 10-Q and current reports on Form 8-K. In addition, Gilead makes estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses and related disclosures. Gilead bases its estimates on historical experience and on various other market specific and other relevant assumptions that it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. There may be other factors of which Gilead is not currently aware that may affect matters discussed in the forward-looking statements and may also cause actual results to differ significantly from these estimates. Further, results for the quarter ended September 30, 2021 are not necessarily indicative of operating results for any future periods. Gilead directs readers to its press releases, annual reports on Form 10-K, quarterly reports on Form 10-Q and other subsequent disclosure documents filed with the SEC. Gilead claims the protection of the Safe Harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements.

The reader is cautioned that forward-looking statements are not guarantees of future performance and is cautioned not to place undue reliance on these forward-looking statements. All forward-looking statements are based on information currently available to Gilead and Gilead assumes no obligation to update or supplement any such forward-looking statements other than as required by law. Any forward-looking statements speak only as of the date hereof or as of the dates indicated in the statements.

Gilead owns or has rights to various trademarks, copyrights and trade names used in its business, including the following: GILEAD ® , GILEAD SCIENCES ® , AMBISOME ® , ATRIPLA ® , BIKTARVY ® , CAYSTON ® , COMPLERA ® , DESCOVY ® , DESCOVY FOR PREP ® , EMTRIVA ® , EPCLUSA ® , EVIPLERA ® , GENVOYA ® , HARVONI ® , HEPCLUDEX ® (BULEVIRTIDE), HEPSERA ® , JYSELECA ® , LETAIRIS ® , ODEFSEY ® , RANEXA ® , SOVALDI ® , STRIBILD ® , TECARTUS ® , TRODELVY ® , TRUVADA ® , TRUVADA FOR PREP ® , TYBOST ® , VEKLURY ® , VEMLIDY ® , VIREAD ® , VOSEVI ® , YESCARTA ® and ZYDELIG ® . This report may also refer to trademarks, service marks and trade names of other companies.

_For more information on Gilead Sciences, Inc., please visit [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=52517279&newsitemid=20211028006178&lan=en-US&anchor=www.gilead.com&index=3&md5=48273c6c09e572d0e3e6fd6c8bcd2b40) or call the Gilead Public Affairs Department at 1-800-GILEAD-5 (1-800-445-3235)._

|**GILEAD SCIENCES, INC.**

**CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions, except per share amounts)** |**2021** |**2020** |**2021** |**2020** |
|Revenues: |
|Product sales |$ |7,356 |$ |6,493 |$ |19,848 |$ |17,027 |
|Royalty, contract and other revenues |65 |84 |213 |241 |
|Total revenues |7,421 |6,577 |20,061 |17,268 |
|Costs and expenses: |
|Cost of goods sold |1,223 |1,141 |3,974 |3,174 |
|Research and development expenses |1,147 |1,158 |3,336 |3,461 |
|Acquired in-process research and development expenses |19 |1,171 |177 |5,792 |
|Selling, general and administrative expenses |1,190 |1,106 |3,596 |3,421 |
|Total costs and expenses |3,579 |4,576 |11,083 |15,848 |
|Income from operations |3,842 |2,001 |8,978 |1,420 |
|Interest expense |(250) |(236) |(763) |(717) |
|Other income (expense), net |(154) |(940) |(696) |(848) |
|Income (loss) before income taxes |3,438 |825 |7,519 |(145) |
|Income tax expense |(852) |(472) |(1,694) |(1,310) |
|Net income (loss) |2,586 |353 |5,825 |(1,455) |
|Net loss attributable to noncontrolling interest |6 |7 |18 |27 |
|Net income (loss) attributable to Gilead |$ |2,592 |$ |360 |$ |5,843 |$ |(1,428) |
|Net income (loss) per share attributable to Gilead common stockholders - basic |$ |2\.06 |$ |0\.29 |$ |4\.65 |$ |(1.14) |
|Shares used in per share calculation - basic |1,256 |1,255 |1,256 |1,257 |
|Net income (loss) per share attributable to Gilead common stockholders - diluted |$ |2\.05 |$ |0\.29 |$ |4\.63 |$ |(1.14) |
|Shares used in per share calculation - diluted |1,262 |1,261 |1,262 |1,257 |
|Cash dividends declared per share |$ |0\.71 |$ |0\.68 |$ |2\.13 |$ |2\.04 |

|**GILEAD SCIENCES, INC.**

**TOTAL REVENUE SUMMARY**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(In millions, except percentages)** |**2021** |**2020** |**Change** |**2021** |**2020** |**Change** |
|Product sales: |
|HIV |$ |4,189 |$ |4,547 |_(8)%_ |$ |11,777 |$ |12,681 |_(7)%_ |
|HCV |429 |464 |_(8)%_ |1,488 |1,641 |_(9)%_ |
|HBV/HDV (1) |247 |211 |_17%_ |704 |616 |_14%_ |
|Cell Therapy |222 |147 |_51%_ |632 |444 |_42%_ |
|Trodelvy |101 |— |_NM_ |262 |— |_NM_ |
|Other |245 |251 |_(2)%_ |777 |772 |_1%_ |
|Total product sales excluding Veklury |5,433 |5,620 |_(3)%_ |15,640 |16,154 |_(3)%_ |
|Veklury |1,923 |873 |_NM_ |4,208 |873 |_NM_ |
|Total product sales |7,356 |6,493 |_13%_ |19,848 |17,027 |_17%_ |
|Royalty, contract and other revenues |65 |84 |_(23)%_ |213 |241 |_(12)%_ |
|Total revenues |$ |7,421 |$ |6,577 |_13%_ |$ |20,061 |$ |17,268 |_16%_ |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

NM - Not Meaningful

(1) The nine months ended September 30, 2021 includes $25 million of Hepcludex sales recorded subsequent to Gilead’s acquisition of MYR. |

|**GILEAD SCIENCES, INC.**

**NON-GAAP FINANCIAL INFORMATION (1)**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(In millions, except percentages)** |**2021** |**2020** |**Change** |**2021** |**2020** |**Change** |
|Non-GAAP: |
|Cost of goods sold |$ |736 |$ |875 |_(16)%_ |$ |2,427 |$ |2,376 |_2%_ |
|Research and development expenses |$ |1,109 |$ |1,155 |_(4)%_ |$ |3,242 |$ |3,345 |_(3)%_ |
|Acquired in-process research and development expenses |$ |19 |$ |— |_NM_ |$ |19 |$ |— |_NM_ |
|Selling, general and administrative expenses |$ |1,178 |$ |1,095 |_8%_ |$ |3,332 |$ |3,335 |_—%_ |
|Other income (expense), net |$ |(12) |$ |29 |_NM_ |$ |(29) |$ |203 |_NM_ |
|Diluted EPS |$ |2\.65 |$ |2\.11 |_26%_ |$ |6\.60 |$ |4\.90 |_35%_ |
|Product gross margin |90\.0 |% |86\.5 |% |_350 bps_ |87\.8 |% |86\.0 |% |_180 bps_ |
|Research and development expenses as a % of revenues |14\.9 |% |17\.6 |% |_\-270 bps_ |16\.2 |% |19\.4 |% |_\-320 bps_ |
|Selling, general and administrative expenses as a % of revenues |15\.9 |% |16\.6 |% |_\-70 bps_ |16\.6 |% |19\.3 |% |_\-270 bps_ |
|Operating expenses as a % of revenues |31\.1 |% |34\.2 |% |_\-310 bps_ |32\.9 |% |38\.7 |% |_\-580 bps_ |
|Operating margin |59\.0 |% |52\.5 |% |_650 bps_ |55\.0 |% |47\.6 |% |_740 bps_ |
|Effective tax rate |18\.9 |% |18\.4 |% |_50 bps_ |19\.0 |% |19\.9 |% |_\-90 bps_ |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

NM - Not Meaningful

(1) A reconciliation between GAAP and non-GAAP financial information is provided in the tables on pages 10 - 11. |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions, except percentages and per share amounts)** |**2021** |**2020** |**2021** |**2020** |
|**Cost of goods sold reconciliation:** |
|GAAP cost of goods sold |$ |1,223 |$ |1,141 |$ |3,974 |$ |3,174 |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |(487) |(266) |(1,547) |(798) |
|Non-GAAP cost of goods sold |$ |736 |$ |875 |$ |2,427 |$ |2,376 |
|**Product gross margin reconciliation:** |
|GAAP product gross margin |83\.4 |% |82\.4 |% |80\.0 |% |81\.4 |% |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |6\.6 |% |4\.1 |% |7\.8 |% |4\.7 |% |
|Non-GAAP product gross margin (1) |90\.0 |% |86\.5 |% |87\.8 |% |86\.0 |% |
|**Research and development expenses reconciliation:** |
|GAAP research and development expenses |$ |1,147 |$ |1,158 |$ |3,336 |$ |3,461 |
|Acquisition-related – amortization of inventory step-up charges |(67) |. |— |(67) |— |
|Acquisition-related and other costs (2) |. |29 |. |(3) |(27) |(116) |
|Non-GAAP research and development expenses |$ |1,109 |$ |1,155 |$ |3,242 |$ |3,345 |
|**Acquired IPR&D expenses reconciliation:** |
|GAAP acquired IPR&D expenses |$ |19 |$ |1,171 |$ |177 |$ |5,792 |
|Acquired IPR&D expenses |— |(1,171) |(158) |(5,792) |
|Non-GAAP acquired IPR&D expenses |$ |19 |$ |— |$ |19 |$ |— |
|**Selling, general and administrative expenses reconciliation:** |
|GAAP selling, general and administrative expenses |$ |1,190 |$ |1,106 |$ |3,596 |$ |3,421 |
|Acquisition-related and other costs (2)(3) |(12) |. |(11) |(264) |(86) |
|Non-GAAP selling, general and administrative expenses |$ |1,178 |$ |1,095 |$ |3,332 |$ |3,335 |
|**Operating income reconciliation:** |
|GAAP operating income |$ |3,842 |$ |2,001 |$ |8,978 |$ |1,420 |
|Acquired IPR&D expenses |— |1,171 |158 |5,792 |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |554 |266 |1,614 |798 |
|Acquisition-related and other costs (2)(3) |(17) |. |14 |291 |202 |
|Non-GAAP operating income |$ |4,379 |$ |3,452 |$ |11,041 |$ |8,212 |
|**Operating margin reconciliation:** |
|GAAP operating margin |51\.8 |% |30\.4 |% |44\.8 |% |8\.2 |% |
|Acquired IPR&D expenses |— |% |17\.8 |% |0\.8 |% |33\.5 |% |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |7\.5 |% |4\.0 |% |8\.0 |% |4\.6 |% |
|Acquisition-related and other costs (2)(3) |(0.2) |% |0\.2 |% |1\.4 |% |1\.2 |% |
|Non-GAAP operating margin (1) |59\.0 |% |52\.5 |% |55\.0 |% |47\.6 |% |
|**Other income (expense), net reconciliation:** |
|GAAP other income (expense), net |$ |(154) |$ |(940) |$ |(696) |$ |(848) |
|Loss from equity securities, net |142 |969 |667 |1,051 |
|Non-GAAP other income (expense), net |$ |(12) |$ |29 |$ |(29) |$ |203 |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION - (Continued)**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions, except percentages and per share amounts)** |**2021** |**2020** |**2021** |**2020** |
|**Effective tax rate reconciliation:** |
|GAAP effective tax rate |24\.8 |% |57\.2 % |22\.5 |% |(903.4) |% |
|Income tax effect of above non-GAAP adjustments and discrete and related tax adjustments (4) |(5.9) |% |(38.8) |% |(3.5) |% |923\.3 |% |
|Non-GAAP effective tax rate (1) |18\.9 |% |18\.4 |% |19\.0 |% |19\.9 |% |
|**Net income attributable to Gilead reconciliation (after tax):** |
|GAAP net income (loss) attributable to Gilead |$ |2,592 |$ |360 |$ |5,843 |$ |(1,428) |
|Acquired IPR&D expenses |— |1,033 |125 |5,622 |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |446 |225 |1,301 |673 |
|Acquisition-related and other costs (2)(3) |(14) |. |11 |189 |157 |
|Loss from equity securities, net |154 |983 |687 |1,090 |
|Discrete and related tax charges (4) |165 |45 |179 |82 |
|Non-GAAP net income attributable to Gilead |$ |3,343 |$ |2,657 |$ |8,324 |$ |6,196 |
|**Diluted EPS reconciliation:** |
|GAAP diluted earnings (loss) per share |$ |2\.05 |$ |0\.29 |$ |4\.63 |$ |(1.14) |
|Acquired IPR&D expenses |— |0\.82 |0\.10 |4\.45 |
|Acquisition-related – amortization of acquired intangibles and inventory step-up charges |0\.35 |0\.18 |1\.03 |0\.53 |
|Acquisition-related and other costs (2)(3) |— |0\.01 |0\.16 |0\.13 |
|Loss from equity securities, net |0\.12 |0\.78 |0\.54 |0\.86 |
|Discrete and related tax charges (4) |0\.13 |0\.04 |0\.14 |0\.06 |
|Non-GAAP diluted EPS (1) |$ |2\.65 |$ |2\.11 |$ |6\.60 |$ |4\.90 |
|**Non-GAAP adjustment summary:** |
|Cost of goods sold adjustments |$ |487 |$ |266 |$ |1,547 |$ |798 |
|Research and development expenses adjustments |38 |3 |94 |116 |
|Acquired IPR&D expenses adjustments |— |1,171 |158 |5,792 |
|Selling, general and administrative expenses adjustments |12 |11 |264 |86 |
|Total non-GAAP adjustments before other income (expense), net, and income taxes |537 |1,451 |2,063 |6,792 |
|Other income (expense), net, adjustments |142 |969 |667 |1,051 |
|Total non-GAAP adjustments before income taxes |679 |2,420 |2,730 |7,843 |
|Income tax effect of non-GAAP adjustments above |(93) |(168) |(428) |(301) |
|Discrete and related tax charges (4) |165 |45 |179 |82 |
|Total non-GAAP adjustments after tax |$ |751 |$ |2,297 |$ |2,481 |$ |7,624 |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(1) Amounts may not sum due to rounding.

(2) Primarily includes employee-related expenses, contingent consideration fair value adjustments and other expenses associated with Gilead’s acquisitions of Immunomedics, Inc., Forty Seven, Inc. and MYR.

(3) Includes a donation of equity securities to the Gilead Foundation, a California nonprofit organization, during the second quarter of 2021.

(4) Represents discrete and related deferred tax charges or benefits primarily associated with acquired intangible assets and transfers of intangible assets from a foreign subsidiary to Ireland and the United States. |

|**GILEAD SCIENCES, INC.**

**RECONCILIATION OF GAAP TO NON-GAAP 2021 FULL YEAR GUIDANCE (1)**

**(unaudited)** |
| --- | --- | --- | --- | --- |
|**(in millions, except percentages and per share amounts)** |**Provided**

**February 4, 2021** |**Updated**

**April 29, 2021** |**Updated**

**July 29, 2021** |**Updated**

**October 28, 2021** |
|**Projected product sales GAAP to non-GAAP reconciliation:** |
|GAAP projected product sales |$23,700 - $25,100 |Unchanged |$24,400 - $25,000 |$26,000 - $26,300 |
|Less: Veklury sales |2,000 - 3,000 |2,700 - 3,100 |4,500 - 4,800 |
|Non-GAAP projected product sales excluding Veklury sales |$21,700 - $22,100 |$21,700 - $21,900 |~ $21,500 |
|**Projected product gross margin GAAP to non-GAAP reconciliation:** |
|GAAP projected product gross margin |78% - 79% |Unchanged |77% - 78% |~ 79% |
|Acquisition-related expenses |9% |9% |8% |
|Non-GAAP projected product gross margin |87% - 88% |86% - 87% |~ 87% |
|**Projected operating income GAAP to non-GAAP reconciliation:** |
|GAAP projected operating income |$9,300 - $10,700 |$9,000 - $10,400 |$9,200 - $9,900 |$10,900 - $11,200 |
|Acquisition-related, acquired IPR&D and other expenses |2,200 |2,500 |2,700 |2,700 |
|Non-GAAP projected operating income |$11,500 - $12,900 |$11,500 - $12,900 |$11,900 - $12,600 |$13,600 - $13,900 |
|**Projected effective tax rate GAAP to non-GAAP reconciliation:** |
|GAAP projected effective tax rate |~ 23% |Unchanged |Unchanged |~ 25% |
|Less: Income tax effect of non-GAAP adjustments and discrete and related tax adjustments |2% |4% |
|Non-GAAP projected effective tax rate |~ 21% |~ 21% |
|**Projected diluted EPS GAAP to non-GAAP reconciliation:** |
|GAAP projected diluted EPS |$5.25 - $5.95 |$4.75 - $5.45 |$4.70 - $5.05 |$5.50 - $5.70 |
|Acquisition-related, acquired IPR&D and other expenses, historical fair value adjustments of equity securities, related tax effects as well as discrete and related tax adjustments |1\.50 |2\.00 |2\.20 |2\.40 |
|Non-GAAP projected diluted EPS |$6.75 - $7.45 |$6.75 - $7.45 |$6.90 - $7.25 |$7.90 - $8.10 |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(1) The 2021 guidance non-GAAP financial information excludes the impact of any potential future acquisition-related, acquired IPR&D and other expenses, fair value adjustments of equity securities and discrete tax and related charges or benefits associated with changes in tax related laws and guidelines as Gilead is unable to project such amounts. |

|**GILEAD SCIENCES, INC.**

**CONDENSED CONSOLIDATED BALANCE SHEETS**

**(unaudited)** |
| --- | --- | --- | --- | --- |
|**September 30,** |**December 31,** |
|**(in millions)** |**2021** |**2020** |
|**Assets** |
|Cash, cash equivalents and marketable securities |$ |6,837 |$ |7,910 |
|Accounts receivable, net |4,566 |4,892 |
|Inventories |2,797 |3,014 |
|Property, plant and equipment, net |5,037 |4,967 |
|Intangible assets, net |33,900 |33,126 |
|Goodwill |8,332 |8,108 |
|Other assets |5,629 |6,390 |
|Total assets |$ |67,098 |$ |68,407 |
|**Liabilities and Stockholders’ Equity** |
|Current liabilities |$ |10,245 |$ |11,397 |
|Long-term liabilities |35,382 |38,789 |
|Stockholders’ equity (1) |21,471 |18,221 |
|Total liabilities and stockholders’ equity |$ |67,098 |$ |68,407 |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(1) As of September 30, 2021 and December 31, 2020, there were 1,255 and 1,254 shares of common stock issued and outstanding, respectively. |

|**GILEAD SCIENCES, INC.**

**SELECTED CASH FLOW INFORMATION**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions)** |**2021** |**2020** |**2021** |**2020** |
|Net cash provided by operating activities |$ |3,253 |$ |2,250 |$ |8,179 |$ |6,252 |
|Net cash used in investing activities |(234) |(271) |(2,853) |(5,638) |
|Net cash provided by (used in) financing activities |(3,527) |4,124 |(6,935) |639 |
|Effect of exchange rate changes on cash and cash equivalents |(23) |37 |(26) |2 |
|Net change in cash and cash equivalents |(531) |6,140 |(1,635) |1,255 |
|Cash and cash equivalents at beginning of period |4,893 |6,746 |5,997 |11,631 |
|Cash and cash equivalents at end of period |$ |4,362 |$ |12,886 |$ |4,362 |$ |12,886 |

|**Three Months Ended** |**Nine Months Ended** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**September 30,** |**September 30,** |
|**(in millions)** |**2021** |**2020** |**2021** |**2020** |
|Net cash provided by operating activities |$ |3,253 |$ |2,250 |$ |8,179 |$ |6,252 |
|Capital expenditures |(139) |(155) |(423) |(469) |
|Free cash flow |$ |3,114 |$ |2,095 |$ |7,756 |$ |5,783 |

|**GILEAD SCIENCES, INC.**

**PRODUCT SALES SUMMARY**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions)** |**2021** |**2020** |**2021** |**2020** |
|**HIV Products** |
|**Descovy (FTC/TAF) Based Products** |
|Biktarvy – U.S. |$ |1,875 |$ |1,584 |$ |4,926 |$ |4,346 |
|Biktarvy – Europe |254 |194 |707 |528 |
|Biktarvy – Other International |147 |113 |461 |314 |
|2,276 |1,891 |6,094 |5,188 |
|Descovy – U.S. |355 |424 |994 |1,124 |
|Descovy – Europe |42 |49 |128 |156 |
|Descovy – Other International |36 |35 |105 |103 |
|433 |508 |1,227 |1,383 |
|Genvoya – U.S. |576 |669 |1,633 |1,927 |
|Genvoya – Europe |100 |116 |306 |376 |
|Genvoya – Other International |68 |61 |184 |183 |
|744 |846 |2,123 |2,486 |
|Odefsey – U.S. |275 |309 |773 |851 |
|Odefsey – Europe |112 |116 |336 |341 |
|Odefsey – Other International |12 |12 |39 |36 |
|399 |437 |1,148 |1,228 |
|Revenue share – Symtuza (1) – U.S. |86 |82 |261 |244 |
|Revenue share – Symtuza (1) – Europe |41 |34 |125 |112 |
|Revenue share – Symtuza (1) – Other International |3 |2 |8 |6 |
|130 |118 |394 |362 |
|Total Descovy (FTC/TAF) Based Products – U.S. |3,167 |3,068 |8,587 |8,492 |
|Total Descovy (FTC/TAF) Based Products – Europe |549 |509 |1,602 |1,513 |
|Total Descovy (FTC/TAF) Based Products – Other International |266 |223 |797 |642 |
|3,982 |3,800 |10,986 |10,647 |
|**Truvada (FTC/TDF) Based Products** |
|Atripla – U.S. |21 |99 |96 |275 |
|Atripla – Europe |2 |5 |10 |17 |
|Atripla – Other International |4 |9 |12 |19 |
|27 |113 |118 |311 |
|Complera / Eviplera – U.S. |28 |26 |73 |77 |
|Complera / Eviplera – Europe |31 |35 |104 |124 |
|Complera / Eviplera – Other International |5 |9 |12 |17 |
|64 |70 |189 |218 |
|Stribild – U.S. |28 |27 |94 |100 |
|Stribild – Europe |11 |13 |33 |42 |
|Stribild – Other International |3 |2 |12 |12 |
|42 |42 |139 |154 |
|Truvada – U.S. |55 |492 |268 |1,245 |
|Truvada – Europe |5 |6 |18 |20 |
|Truvada – Other International |7 |11 |24 |37 |
|67 |509 |310 |1,302 |
|Total Truvada (FTC/TDF) Based Products – U.S. |132 |644 |531 |1,697 |
|Total Truvada (FTC/TDF) Based Products – Europe |49 |59 |165 |203 |
|Total Truvada (FTC/TDF) Based Products – Other International |19 |31 |60 |85 |
|200 |734 |756 |1,985 |

|**GILEAD SCIENCES, INC.**

**PRODUCT SALES SUMMARY - (Continued)**

**(unaudited)** |
| --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions)** |**2021** |**2020** |**2021** |**2020** |
|Other HIV (2) – U.S. |3 |10 |14 |24 |
|Other HIV (2) – Europe |4 |1 |9 |4 |
|Other HIV (2) – Other International |— |2 |12 |21 |
|7 |13 |35 |49 |
|Total HIV – U.S. |3,302 |3,722 |9,132 |10,213 |
|Total HIV – Europe |602 |569 |1,776 |1,720 |
|Total HIV – Other International |285 |256 |869 |748 |
|4,189 |4,547 |11,777 |12,681 |
|**HCV Products** |
|Ledipasvir / Sofosbuvir (3) – U.S. |14 |36 |63 |113 |
|Ledipasvir / Sofosbuvir (3) – Europe |5 |11 |24 |26 |
|Ledipasvir / Sofosbuvir (3) – Other International |26 |37 |76 |124 |
|45 |84 |163 |263 |
|Sofosbuvir / Velpatasvir (4) – U.S. |173 |170 |649 |646 |
|Sofosbuvir / Velpatasvir (4) – Europe |77 |74 |234 |253 |
|Sofosbuvir / Velpatasvir (4) – Other International |82 |86 |272 |330 |
|332 |330 |1,155 |1,229 |
|Other HCV (5) – U.S. |37 |35 |97 |100 |
|Other HCV (5) – Europe |12 |13 |64 |37 |
|Other HCV (5) – Other International |3 |2 |9 |12 |
|52 |50 |170 |149 |
|Total HCV – U.S. |224 |241 |809 |859 |
|Total HCV – Europe |94 |98 |322 |316 |
|Total HCV – Other International |111 |125 |357 |466 |
|429 |464 |1,488 |1,641 |
|**HBV/HDV Products** |
|Vemlidy – U.S. |103 |99 |266 |248 |
|Vemlidy – Europe |9 |8 |25 |22 |
|Vemlidy – Other International |96 |70 |298 |194 |
|208 |177 |589 |464 |
|Viread – U.S. |1 |3 |8 |10 |
|Viread – Europe |7 |8 |22 |27 |
|Viread – Other International |18 |21 |55 |100 |
|26 |32 |85 |137 |
|Other HBV/HDV (6) – U.S. |— |— |1 |9 |
|Other HBV/HDV (6) – Europe |13 |2 |29 |6 |
|13 |2 |30 |15 |
|Total HBV/HDV – U.S. |104 |102 |275 |267 |
|Total HBV/HDV – Europe |29 |18 |76 |55 |
|Total HBV/HDV – Other International |114 |91 |353 |294 |
|247 |211 |704 |616 |
|**Veklury** |
|Veklury – U.S. |1,527 |785 |2,763 |785 |
|Veklury – Europe |109 |60 |761 |60 |
|Veklury – Other International |287 |28 |684 |28 |
|1,923 |873 |4,208 |873 |

|**GILEAD SCIENCES, INC.**

**PRODUCT SALES SUMMARY - (Continued)**

**(unaudited)** |
| --- | --- | --- | --- | --- | --- | --- | --- |
|**Three Months Ended** |**Nine Months Ended** |
|**September 30,** |**September 30,** |
|**(in millions)** |**2021** |**2020** |**2021** |**2020** |
|**Cell Therapy Products** |
|Tecartus – U.S. |35 |5 |94 |5 |
|Tecartus – Europe |12 |4 |25 |5 |
|47 |9 |119 |10 |
|Yescarta – U.S. |100 |85 |300 |283 |
|Yescarta – Europe |66 |51 |188 |144 |
|Yescarta – Other International |9 |2 |25 |7 |
|175 |138 |513 |434 |
|Total Cell Therapy – U.S. |135 |90 |394 |288 |
|Total Cell Therapy – Europe |78 |55 |213 |149 |
|Total Cell Therapy – Other International |9 |2 |25 |7 |
|222 |147 |632 |444 |
|**Trodelvy** |
|Trodelvy – U.S. |100 |— |261 |— |
|Trodelvy– Europe |1 |— |1 |— |
|101 |— |262 |— |
|**Other Products** |
|AmBisome – U.S. |7 |18 |32 |46 |
|AmBisome – Europe |67 |58 |202 |166 |
|AmBisome – Other International |69 |35 |186 |113 |
|143 |111 |420 |325 |
|Letairis – U.S. |46 |78 |157 |241 |
|Ranexa – U.S. |— |— |5 |9 |
|Zydelig – U.S. |6 |8 |22 |24 |
|Zydelig – Europe |7 |9 |27 |30 |
|Zydelig – Other International |— |— |1 |1 |
|13 |17 |50 |55 |
|Other (7) – U.S. |28 |32 |82 |103 |
|Other (7) – Europe |10 |10 |41 |32 |
|Other (7) – Other International |5 |3 |22 |7 |
|43 |45 |145 |142 |
|Total Other – U.S. |87 |136 |298 |423 |
|Total Other – Europe |84 |77 |270 |228 |
|Total Other – Other International |74 |38 |209 |121 |
|245 |251 |777 |772 |
|Total product sales – U.S. |5,479 |5,076 |13,932 |12,835 |
|Total product sales – Europe |997 |877 |3,419 |2,528 |
|Total product sales – Other International |880 |540 |2,497 |1,664 |
|$ |7,356 |$ |6,493 |$ |19,848 |$ |17,027 |
|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(1) Represents Gilead’s revenue from cobicistat (“C”), emtricitabine (“FTC”) and tenofovir alafenamide (“TAF”) in Symtuza (darunavir/C/FTC/TAF), a fixed dose combination product commercialized by Janssen Sciences Ireland Unlimited Company.

(2) Includes Emtriva and Tybost.

(3) Amounts consist of sales of Harvoni and the authorized generic version of Harvoni sold by Gilead’s separate subsidiary, Asegua Therapeutics LLC.

(4) Amounts consist of sales of Epclusa and the authorized generic version of Epclusa sold by Gilead’s separate subsidiary, Asegua Therapeutics LLC.

(5) Includes Vosevi and Sovaldi.

(6) Includes Hepcludex and Hepsera. The nine months ended September 30, 2021 includes $25 million of Hepcludex sales recorded subsequent to Gilead’s acquisition of MYR.

(7) Includes Cayston and Jyseleca. |

View source version on [businesswire.com](http://businesswire.com) : <https://www.businesswire.com/news/home/20211028006178/en/>

**Investors:** Jacquie Ross, CFA
(650) 358-1054

**Media:** Chris Ridley
(908) 883-0478

Source: Gilead Sciences, Inc.

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2021 Financial Results&body=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2021 Financial Results&url=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results&via=Gilead)

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2021 Financial Results&body=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2021 Financial Results&url=https://www.gilead.com/news/news-details/2021/gilead-sciences-announces-third-quarter-2021-financial-results&via=Gilead)

## Other News

_Some of the content on this page is not intended for users outside the U.S._

View All

No Results Found

Loading Results...

### Discover More

##### Therapeutic Areas

##### Research

##### Giving@Gilead

This is our global website, intended for visitors seeking information on Gilead’s worldwide business. Some content on this site is not intended for people outside the United States. Visit our Global Operations page for links to our international corporate websites.

* [](https://twitter.com/GileadSciences)
* [](https://www.linkedin.com/company/gilead-sciences/)
* [](https://www.instagram.com/gileadsciences/)
* [](https://www.facebook.com/GileadSciences)
* [](https://www.youtube.com/channel/UCNSt7PtsfNGbezR9hmvRI1w)

### QUICK LINKS

* [Investors](https://investors.gilead.com/overview/default.aspx)
* [Find a Trial](https://www.gileadclinicaltrials.com)
* Pipeline
* [Search for Jobs](https://gilead.wd1.myworkdayjobs.com/gileadcareers)
* News
* Stories@Gilead

### GET IN TOUCH

* Contact Us
* Report an Adverse Event
* [Medical Information](https://www.askgileadmedical.com)
* Partnership Request

### LEGAL

* [Modern Slavery Act Statement](https://www.gilead.com/-/media/files/pdfs/company/policies-and-disclosures/modern-slavery-statement.pdf)
* Public Policy Engagement
* Social Media Guidelines
* Privacy Statement
* Consumer Health Data Privacy Policy
* Terms of Use
* Cookie Statement

* * *