10-Q 1 a07-10703\_110q.htm 10-Q **UNITED STATES**

**SECURITIES AND EXCHANGE COMMISSION**

**WASHINGTON,
D.C. 20549**

**FORM 10-Q**

**(Mark
One)**

**x** QUARTERLY
REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT
OF 1934.

**For
the quarterly period ended March 31, 2007**

**OR**

**o** TRANSITION
REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT
OF 1934.

**For
the transition period from
               to**

**Commission
file number 0-26301**

**United Therapeutics Corporation**

(Exact Name of Registrant
as Specified in Its Charter)

|**Delaware** | |**52-1984749** |
| --- | --- | --- |
|(State or Other
Jurisdiction of | |(I.R.S. Employer |
|Incorporation or
Organization) | |Identification
No.) |
|**1110 Spring Street, Silver Spring, MD** | |**20910** |
|(Address of
Principal Executive Offices) | |(Zip Code) |

**(301) 608-9292**

(Registrant’s Telephone
Number, Including Area Code)

(Former Name, Former
Address and Former Fiscal Year, If Changed Since Last Report)

Indicate by check mark whether the registrant: (1) has
filed all reports required to be filed by Section 13 or 15(d) of the
Securities Exchange Act of 1934 during the preceding 12 months (or for such
shorter period that the registrant was required to file such reports), and (2) has
been subject to such filing requirements for the past 90 days. Yes x No o

Indicate by check mark whether the registrant is a
large accelerated filer, an accelerated filer, or a non-accelerated filer. See
definition of “accelerated filer and large accelerated filer” in Rule 12b-2
of the Exchange Act. (Check One):

Large accelerated
filer x Accelerated
filer o Non-accelerated
filer o

Indicate by check mark whether the registrant is a
shell company (as defined in Rule 12b-2 of the Exchange Act).
Yes o No x

The number of shares outstanding of the issuer’s
common stock, par value $.01 per share, as of April 27, 2007 was
20,782,575.  
* * *  
**INDEX**

| | | |**Page** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|**Part I.** | |**FINANCIAL INFORMATION (UNAUDITED)** | | | | | |
|Item 1. | |Consolidated Financial Statements | | |1 | | |
| | |Consolidated Balance Sheets | | |1 | | |
| | |Consolidated Statements of Operations | | |2 | | |
| | |Consolidated Statements of Cash Flows | | |3 | | |
| | |Notes to Consolidated Financial Statements | | |4 | | |
|Item 2. | |Management’s Discussion and Analysis of Financial Condition and Results of Operations | | |13 | | |
|Item 3. | |Quantitative and Qualitative Disclosures About Market Risk | | |28 | | |
|Item 4. | |Controls and Procedures | | |29 | | |
|**Part II.** | |**OTHER INFORMATION** | | | | | |
|Item 1A. | |Risk Factors | | |30 | | |
|Item 2. | |Unregistered Sales of Equity Securities and Use of Proceeds | | |47 | | |
|Item 6. | |Exhibits | | |48 | | |
|**SIGNATURES** | | |49 | | |  
* * *  
**PART I.** FINANCIAL
INFORMATION

**Item
1\.** Consolidated
Financial Statements

**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED BALANCE SHEETS  
(In thousands, except share data)**

| | |**March 31,  
2007** | |**December 31,  
2006** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**(Unaudited)** | | | |
|**Assets** | | | | | | | | | |
|Current assets: | | | | | | | | | |
|Cash and cash equivalents | | |$ |67,851 | | | |$ |91,067 | | |
|Marketable investments | | |103,364 | | | |136,682 | | |
|Accounts receivable, net
of allowance of $1 for 2007 and $1 for 2006 | | |19,009 | | | |22,453 | | |
|Inventories, net | | |12,323 | | | |12,047 | | |
|Other receivable | | |2,009 | | | |1,581 | | |
|Interest receivable | | |2,000 | | | |1,545 | | |
|Due from affiliate | | |48 | | | |66 | | |
|Prepaid expenses | | |8,181 | | | |9,242 | | |
|Deferred tax assets | | |4,136 | | | |2,691 | | |
|Total current assets | | |218,921 | | | |277,374 | | |
|Marketable investments | | |42,963 | | | |36,414 | | |
|Marketable investments
and cash—restricted | | |38,232 | | | |38,988 | | |
|Goodwill, net | | |7,465 | | | |7,465 | | |
|Other intangible assets,
net | | |2,985 | | | |3,140 | | |
|Property, plant, and
equipment, net | | |42,071 | | | |34,681 | | |
|Investments in affiliates | | |5,091 | | | |4,700 | | |
|Notes receivable from
affiliate and employee | | |39 | | | |27 | | |
|Deferred tax assets | | |69,216 | | | |65,308 | | |
|Other assets | | |9,283 | | | |8,874 | | |
|Total assets | | |$ |436,266 | | | |$ |476,971 | | |
|**Liabilities and Stockholders’ Equity** | | | | | | | | | |
|Current liabilities: | | | | | | | | | |
|Accounts payable | | |$ |4,961 | | | |$ |2,843 | | |
|Accounts payable to
affiliates and related parties | | |6 | | | |250 | | |
|Accrued expenses | | |13,814 | | | |15,265 | | |
|Current portion of notes
and leases payable | | |11 | | | |10 | | |
|Other current liabilities | | |436 | | | |882 | | |
|Total current liabilities | | |19,228 | | | |19,250 | | |
|Notes and leases payable,
excluding current portion | | |250,011 | | | |250,015 | | |
|Other liabilities | | |4,675 | | | |3,100 | | |
|Total liabilities | | |273,914 | | | |272,365 | | |
|Common stock
subject to repurchase | | |10,882 | | | |— | | |
|Commitments and contingencies | | | | | | | | | |
|Stockholders’ equity: | | | | | | | | | |
|Preferred stock, par
value $.01, 10,000,000 shares authorized, no shares issued | | |— | | | |— | | |
|Series A junior
participating preferred stock, par value $.01, 100,000,000 authorized,
no shares issued | | |— | | | |— | | |
|Common stock, par value
$.01, 100,000,000 shares authorized, 25,126,356 and 24,632,153 shares issued
at March 31, 2007 and December 31, 2006, respectively, and
20,744,759 and 21,475,078 outstanding at March 31, 2007 and
December 31, 2006, respectively | | |251 | | | |246 | | |
|Additional paid-in
capital | | |425,799 | | | |408,804 | | |
|Accumulated other
comprehensive income | | |1,180 | | | |1,476 | | |
|Treasury stock at cost,
4,381,597 and 3,157,075 shares at March 31, 2007 and December 31,
2006, respectively | | |(231,619 |) | | |(164,560 |) | |
|Accumulated deficit | | |(44,141 |) | | |(41,360 |) | |
|Total stockholders’
equity | | |162,352 | | | |204,606 | | |
|Total liabilities and stockholders’ equity | | |$ |436,266 | | | |$ |476,971 | | |

See accompanying notes to consolidated financial statements.

1

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS OF OPERATIONS  
(In thousands, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |38,407 | |$ |31,620 | |
|Service sales | |1,762 | |1,544 | |
|Total revenues | |40,169 | |33,164 | |
|Operating
expenses: | | | | | |
|Research and
development, | |17,101 | |14,700 | |
|Research and development
expense related to issuance of stock | |11,013 | |— | |
|Selling, general and
administrative | |15,164 | |10,079 | |
|Impairment of HeartBar ® tradename | |— | |2,024 | |
|Cost of product sales | |3,815 | |3,346 | |
|Cost of service sales | |581 | |531 | |
|Total operating expenses | |47,674 | |30,680 | |
|Income (loss) from operations | |(7,505 |) |2,484 | |
|Other income
(expense): | | | | | |
|Interest income | |4,100 | |1,898 | |
|Interest expense | |(711 |) |— | |
|Equity loss in affiliate | |(114 |) |(207 |) |
|Other, net | |4 | |10 | |
|Total other income, net | |3,279 | |1,701 | |
|Income (loss) before income tax | |(4,226 |) |4,185 | |
|Income tax benefit
(expense) | |1,445 | |(1,878 |) |
|Net income (loss) | |$ |(2,781 |) |$ |2,307 | |
|Net income (loss) per common share: | | | | | |
|Basic | |$ |(0.13 |) |$ |0\.10 | |
|Diluted | |$ |(0.13 |) |$ |0\.09 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |21,303 | |23,374 | |
|Diluted | |21,303 | |25,609 | |

See accompanying notes to consolidated financial statements.

2

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS OF CASH FLOWS  
(In thousands)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
| | |**(Unaudited)** | |
|Cash flows from
operating activities: | | | | | |
|Net (loss) income | |$ |(2,781 |) |$ |2,307 | |
|Adjustments to reconcile net income (loss) to net
cash provided by operating activities: | | | | | |
|Depreciation and amortization | |825 | |568 | |
|Provision for bad debt and inventory obsolescence | |(23 |) |322 | |
|Deferred tax expense (benefit) | |(1,567 |) |1,783 | |
|Gain (loss) on disposals of equipment | |(77 |) |57 | |
|Options issued in exchange for services | |5,353 | |4,649 | |
|Write down of intangible asset | |— | |2,024 | |
|Amortization of deferred offering costs | |399 | |— | |
|Amortization of discount or premium on investments | |(1,053 |) |(31 |) |
|Equity loss in affiliate and unrealized foreign
translation loss | |120 | |206 | |
|Excess tax benefits from stock-based compensation | |(2,364 |) |— | |
|Issuance of stock for license | |11,013 | |— | |
|Changes in operating assets and liabilities: | | | | | |
|Accounts receivable | |3,440 | |(719 |) |
|Interest receivable | |(456 |) |210 | |
|Inventories | |(1,142 |) |387 | |
|Prepaid expenses | |1,289 | |1,851 | |
|Other assets | |(443 |) |(115 |) |
|Accounts payable | |2,120 | |656 | |
|Accrued expenses | |(1,449 |) |2,511 | |
|Due to (from) affiliates | |(238 |) |(154 |) |
|Other liabilities | |173 | |(29 |) |
|Net cash provided by operating activities | |13,139 | |16,483 | |
|Cash flows from investing activities: | | | | | |
|Purchases of property, plant and equipment | |(8,041 |) |(1,107 |) |
|Purchases of held-to-maturity investments | |(32,923 |) |(1,468 |) |
|Purchases of available-for-sale investments | |(28,349 |) |— | |
|Sales of available-for-sale investments | |56,750 | |1,000 | |
|Maturities of held-to-maturity investments | |32,933 | |— | |
|Net cash provided (used) by investing activities | |20,370 | |(1,575 |) |
|Cash flows from financing activities: | | | | | |
|Payments to repurchase common stock | |(67,059 |) |— | |
|Proceeds from the exercise of stock options | |7,972 | |3,492 | |
|Excess tax benefits from stock-based compensation | |2,364 | |44 | |
|Principal payments on notes payable and capital lease
obligations | |(2 |) |(5 |) |
|Net cash provided (used) by financing activities | |(56,725 |) |3,531 | |
|Net increase (decrease) in cash and cash equivalents | |(23,216 |) |18,439 | |
|Cash and cash equivalents, beginning of period | |91,067 | |69,180 | |
|Cash and cash equivalents, end of period | |$ |67,851 | |$ |87,619 | |
|Supplemental schedule of cash flow information: | | | | | |
|Cash paid for interest | |$ |4 | |$ |— | |
|Cash paid for
income taxes | |$ |654 | |$ |156 | |

See accompanying notes to consolidated financial statements.

3  
* * *  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS  
March 31, 2007  
(UNAUDITED)**

**1\. ORGANIZATION AND
BUSINESS DESCRIPTION**

United Therapeutics Corporation (United Therapeutics)
is a biotechnology company focused on the development and commercialization of
innovative therapeutic products for patients with chronic and life-threatening
cardiovascular, cancer and infectious diseases. We were incorporated on June 26,
1996, under the laws of the State of Delaware and we have the following wholly-owned
subsidiaries: Lung Rx, Inc. (Lung Rx), Unither Pharmaceuticals, Inc.
(UPI), Unither Telmed, Ltd. (Unither Telmed and formerly Unither Telemedicine
Services Corporation), Unither.com, Inc., United Therapeutics Europe,
Ltd., Unither Pharma, Inc., Medicomp, Inc., Unither Nutriceuticals, Inc.,
Lung Rx, Ltd. and Unither Biotech Inc.

Our lead product is Remodulin ® (treprostinil sodium). Remodulin was first
approved for use on May 21, 2002, by the United States Food and Drug
Administration (FDA) as a continuous subcutaneous infusion for the
treatment of pulmonary arterial hypertension (PAH) in patients with NYHA class
II-IV symptoms to diminish symptoms associated with exercise. On November 24,
2004, the FDA approved intravenous infusion of Remodulin, based on data
establishing intravenous bioequivalence with subcutaneous Remodulin, for
patients who are not able to tolerate a subcutaneous infusion. On March 21,
2006, the FDA expanded its approval of Remodulin to include patients requiring
transition from Flolan ® , the
only other FDA-approved intravenous prostacyclin. In addition to the United
States, Remodulin is approved for subcutaneous infusion in most of Europe,
Canada, Israel, Australia and several countries in South America. It is
approved for intravenous infusion in Canada, Israel, Mexico, Argentina and
Peru. Other international applications for the approval of Remodulin are
pending.

We have generated
pharmaceutical revenues from sales of Remodulin and arginine products in the
United States, Canada, Europe, South America and Asia. In addition, we have
generated non-pharmaceutical revenues from telemedicine products and services
in the United States.

**2\. BASIS OF
PRESENTATION**

The consolidated financial statements included herein
have been prepared, without audit, pursuant to Regulation S-X of the Securities
and Exchange Commission. Certain information and footnote disclosures normally
included in consolidated financial statements prepared in accordance with
accounting principles generally accepted in the United States have been
condensed or omitted pursuant to such rules and regulations. These
consolidated financial statements should be read in conjunction with the
audited financial statements and notes thereto contained in our Annual Report
on Form 10-K for the year ended December 31, 2006, as filed
with the Securities and Exchange Commission.

In the opinion of our
management, any adjustments contained in the accompanying unaudited
consolidated financial statements are of a normal recurring nature, necessary
to present fairly the financial position as of March 31, 2007, and results
of operations and cash flows for the three-month periods ended March 31,
2007 and 2006. Interim results are not necessarily indicative of results for an
entire year.

4

  
* * *

  
**3\. INVENTORIES**

We
manufacture certain compounds, such as the treprostinil-based compounds, and
purchase medical supplies, for use in our product sales and ongoing clinical
trials. We subcontract the manufacture of cardiac monitoring equipment. We
contract with a third-party manufacturer to make arginine products and for the
formulation of Remodulin and for clinical trial materials for the inhaled and
oral treprostinil clinical trials. Clinical trial materials are expensed as
incurred as research and development expense. These inventories are accounted
for under the first-in, first-out method and are carried at the lower of cost
or market. Inventories consisted of the following, net of reserves of
approximately $486,000 and $440,000 at March 31, 2007 and December 31,
2006, respectively (in thousands):

| | |**March 31,  
2007** | |**December 31,  
2006** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Remodulin: | | | | | | | | | |
|Raw materials | | |$ |351 | | | |$ |149 | | |
|Work-in-progress | | |7,144 | | | |7,807 | | |
|Finished goods | | |4,080 | | | |3,355 | | |
|Remodulin
delivery pumps and other medical supplies | | |559 | | | |661 | | |
|Cardiac
monitoring equipment components | | |85 | | | |38 | | |
|Arginine products | | |104 | | | |37 | | |
|Total inventories | | |$ |12,323 | | | |$ |12,047 | | |

**4\. GOODWILL AND
OTHER INTANGIBLE ASSETS**

Goodwill
and other intangible assets were comprised as follows (in thousands):

| | |**As of March 31, 2007** | |**As of December 31, 2006** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |
|Goodwill | |$ |7,465 | | |$ |— | | |$ |7,465 | |$ |7,465 | | |$ |— | | |$ |7,465 | |
|Intangible assets: | | | | | | | | | | | | | | | | | |
|Technology and
patents | |$ |6,164 | | |$ |(3,179 |) | |$ |2,985 | |$ |6,164 | | |$ |(3,024 |) | |$ |3,140 | |

The HeartBar product was discontinued in January 2006
and is no longer sold. As a result, an impairment related to the HeartBar
product tradename totaling approximately $2.0 million was recorded during the
three months ended March 31, 2006.

Total
amortization expense for the three-month periods ended March 31, 2007 and
2006 was approximately $155,000 and $81,000, respectively. The aggregate
amortization expense related to these intangible assets for each of the five
succeeding years is estimated as follows (in thousands):

|**Years ending December 31,** | | | | | |
| --- | --- | --- | --- | --- | --- |
|2007 | |$ |620 | |
|2008 | |620 | |
|2009 | |620 | |
|2010 | |620 | |
|2011 | |620 | |

**5\. SUPPLEMENTAL
EXECUTIVE RETIREMENT PLAN**

In May 2006, the Compensation Committee of our
Board of Directors approved the United Therapeutics Corporation Supplemental
Executive Retirement Plan (the SERP). The SERP is administered by the
Compensation Committee. Only a member of a “select group of management or

5

  
* * *

  
highly compensated
employees” within the meaning of ERISA section 201(2) may be eligible
to participate in the SERP. During the three months ending March 31, 2007,
a normal revaluation of the SERP was performed as a result of finalization of
the 2007 salary levels for the SERP participants. The revaluation process
includes updating any assumptions and inputs into the actuarial calculations. During
the revaluation process, the discount rate changed to 5.7% from 6.2% used in
2006\. For the three months ending March 31, 2007, we recognized
approximately $612,200 and $37,000, respectively, in service and interest costs
for the SERP.

In accordance with SFAS 158, _Employers’
Accounting for Defined Benefit Pension and Other Postretirement Plans_ ,
we record as part of the projected benefit obligation the unfunded actuarial
loss and unamortized prior period service costs. These amounts are recorded net
of tax in other comprehensive income (loss). See footnote No. 8
Comprehensive Income (loss) for the details.

The
reconciliation of the beginning and ending balances in benefit obligations and
fair value of plan assets, as well as the funded status of our plans, is as
follows (in thousands):

| | |**Three months ended  
March 31, 2007** | |
| --- | --- | --- | --- | --- | --- | --- |
|Projected benefit
obligation at December 31, 2006 | | |$ |1,572 | | |
|Service cost | | |612 | | |
|Interest cost | | |37 | | |
|Actuarial loss | | |254 | | |
|Prior period
service costs | | |758 | | |
|Projected benefit
obligation at March 31, 2007 | | |$ |3,233 | | |

**6\. STOCKHOLDERS’
EQUITY**

**_Earnings (Loss) per Common Share_**

Basic earnings (loss) per common share are computed by
dividing net income (loss) by the weighted average number of shares of common
stock outstanding during the respective periods. Diluted earnings per common
share are computed by dividing net income by the weighted average number of
shares of common stock outstanding during the period plus the number of shares
issuable upon the exercise of outstanding stock options and warrants using the
treasury stock method. The effects of outstanding stock options and other
potential stock issuances were not included in the computation of diluted loss
per share for the three months ended March 31, 2007, because to do so
would have been antidilutive for the period presented.

At March 31,
2007, the holders of the components of basic and dilutive earnings (loss) per
share were as follows (in thousands, except per share amounts):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Net income (loss)
(numerator) | |$ |(2,781 |) |$ |2,307 | |
|Shares (denominator): | | | | | |
|Weighted average outstanding shares for basic EPS | |21,303 | |23,374 | |
|0\.50% Senior Convertible Note | |— | |— | |
|Dilutive effect of stock options | |— | |2,235 | |
|Adjusted weighted average shares for diluted EPS | |21,303 | |25,609 | |
|Earnings (loss)
per share | | | | | |
|Basic | |$ |(0.13 |) |$ |0\.10 | |
|Diluted | |$ |(0.13 |) |$ |0\.09 | |

6

  
* * *

  
Stock options and warrants
to purchase approximately 5.3 million weighted-average shares of our common
stock were also outstanding during the three-month period ended March 31,
2007, but were not included in the computation of earnings (loss) per share
because the exercise prices of these options and warrants were greater than the
average market price of our common stock during this period; therefore their
effect was antidilutive. Due to our net loss for the three month period ended March 31,
2007, outstanding options to purchase approximately 1.1 million
weighted-average shares of our common stock were not included in the
computation of diluted net loss per share because their inclusion would have
been antidilutive.

**_Stock Option Plan_**

Effective January 1, 2006, we adopted the
provisions of FASB Statement No. 123 (revised 2004), _Share-Based
Payment_ , (SFAS 123(R)) and interpretative literature within SEC
Staff Accounting Bulletin No. 107, _Share-Based
Payment_ , (SAB 107). We utilize the Black-Scholes-Merton valuation
model for estimating the fair value of stock options granted. Option valuation
models, including Black-Scholes-Merton, require the input of highly subjective
assumptions. Changes in the assumptions used can materially affect the grant
date fair value of an award. These assumptions include the risk-free rate of
interest, expected dividend yield, expected volatility, and the expected life
of the award.

The
following are the weighted-average assumptions used in valuing the stock
options granted to employees during the three-month periods ended March 31,
2007 and 2006:

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Expected
volatility | |40\.13% | |47\.43% | |
|Risk-free
interest rate | |4\.5% | |4\.5% | |
|Expected term of
options | |6\.0 years | |6\.0 years | |
|Expected dividend
yield | |0\.0% | |0\.0% | |
|Forfeiture rate | |7\.1% | |11\.7% | |

A
summary of the status of our employee stock options as of March 31, 2007,
and changes during the three months ended is presented below:

|**All Employee Options** | | | |**Number of  
Shares** | |**Weighted  
Average  
Exercise  
Price** | |**Weighted Average  
Remaining  
Contractual  
Term** | |**Aggregate  
Intrinsic  
Value  
($ in 000s)** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Outstanding at
January 1, 2007 | |5,503,765 | | |$ |43\.83 | | | | | | | | |
|Granted | |613,112 | | |55\.80 | | | | | | | | |
|Exercised | |(291,203 |) | |27\.28 | | | | | | | | |
|Forfeited | |(13,155 |) | |52\.93 | | | | | | | | |
|Outstanding at
March 31, 2007 | |5,812,519 | | |$ |45\.90 | | | |7\.2 | | |$ |266,808 | |
|Expected to vest
at March 31, 2007 | |2,039,753 | | |$ |56\.53 | | | |9\.2 | | |$ |125,958 | |
|Exercisable at
March 31, 2007 | |3,584,255 | | |$ |39\.30 | | | |6\.0 | | |$ |140,850 | |

The weighted-average grant-date fair value of options
granted during the three months ended March 31, 2007 and 2006, was $25.77
and $33.33, respectively.

7

  
* * *

  
Total
employee share-based compensation expense recognized for the three months ended
March 31, 2007 and 2006, is as follows (in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Cost of service
sales | |$ |32 | |$ |27 | |
|Research and
development | |2,139 | |1,624 | |
|Selling, general
and administrative | |2,823 | |2,141 | |
|Share-based compensation expense before taxes | |4,994 | |3,792 | |
|Related income
tax benefits | |(1,708 |) |(1,653 |) |
|Share-based compensation expense, net of taxes | |$ |3,286 | |$ |2,139 | |

Equity-based compensation costs capitalized as
part of inventory during the three months ended March 31, 2007 and 2006,
were approximately $78,000 and $158,000, respectively.

A
summary of option exercises under all share-based payment is as follows (dollars
in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Number of options
exercised | |294,203 | |200,780 | |
|Cash received | |$ |7,972 | |$ |3,492 | |

**_Stock Repurchases_**

On October 17, 2006, our
Board of Directors approved a stock repurchase program to repurchase up to 4.0
million shares of our common stock over a two-year period. As of December 31,
2006, a total of approximately 1.9 million shares had been repurchased at a
cost of approximately $115.5 million in the stock repurchase program.
Approximately 1.2 million shares of our common stock were repurchased at cost
of approximately $67.1 million during the three months ended March 31,
2007\. As of March 31, 2007, 911,669 shares remained eligible for
repurchase under this program.

**7\. NOTES PAYABLE**

**_Convertible Senior Notes_**

On October 30, 2006,
we issued $250.0 million of 0.50% Convertible Senior Notes due October 2011
(the Convertible Senior Notes). In connection with the issuance of the
Convertible Senior Notes, we also entered into a call spread option. The
Convertible Senior Notes were issued at par value and pay interest in cash
semi-annually in arrears on April 15 and October 15 of each year,
beginning on April 15, 2007. The Convertible Senior Notes are unsecured
unsubordinated obligations and rank equally with all other unsecured and
unsubordinated indebtedness. The Convertible Senior Notes have an initial
conversion price of $75.2257 per share. The Convertible Senior Notes may only
be converted: (i) anytime after July 15, 2011; (ii) during any
calendar quarter commencing after the date of original issuance of the notes,
if the closing sale price of our common stock for at least 20 trading days in
the period of 30 consecutive trading days ending on the last trading day of the
calendar quarter preceding the quarter in which the conversion occurs is more
than 120% of the conversion price of the notes in effect on that last trading
day; (iii) during the ten consecutive trading-day period following any
five consecutive trading-day period in which the trading price for the notes
for each such trading day was less than 95% of the closing sale price of our
common stock on such date multiplied by the then current conversion rate; or (iv) if
specified significant distributions to holders of our common stock are made,
specified corporate transactions occur, or our

8

  
* * *

  
common
stock ceases to be approved for listing on The NASDAQ Global Select Market and
is not listed for trading on another U.S. national or regional securities
exchange. Upon conversion, a holder will receive: (i) cash equal to the
lesser of the principal amount of the note or the conversion value; and (ii) to
the extent the conversion value exceeds the principal amount of the note,
shares of our common stock. In addition, upon a change in control, as defined
in the indenture under which the Convertible Senior Notes have been issued, the
holders may require us to purchase all or a portion of their Convertible Senior
Notes for 100% of the principal amount plus accrued and unpaid interest, if
any, plus a number of additional shares of our common stock  As of March 31, 2007, the fair value of
the $250.0 million Convertible Senior Notes outstanding was approximately
$242.6 million, based on the quoted market price.

**8\. COMPREHENSIVE
INCOME (LOSS)**

SFAS No. 130, _Reporting Comprehensive Income,_ establishes standards for the reporting and display of comprehensive income and
its components. SFAS No. 130 requires, among other things, that unrealized
gains and losses on available-for-sale securities, certain unrecognized and
unfunded pension costs and foreign currency translation adjustments be included
in other comprehensive income (loss). The following statement presents
comprehensive income (loss) for the three months ended March 31, 2007 and
2006 (in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Net income (loss) | |$ |(2,781 |) |$ |2,307 | |
|Other
comprehensive income (loss): | | | | | |
|Foreign currency translation gain adjustment | |15 | |4 | |
|Unrecognized prior period pension service cost, net
of tax | |(484 |) |— | |
|Unrecognized actuarial pension loss, net of tax | |(167 |) |— | |
|Unrealized gain (loss) on available-for-sale
securities | |341 | |(336 |) |
|Comprehensive income
(loss) | |$ |(3,076 |) |$ |1,975 | |

**9\. INCOME TAXES**

Significant
components of the provision for income taxes attributable to operations consist
of the following (in thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Current: | | | | | |
|Federal | |$ |(1,199 |) |$ |40 | |
|State | |(246 |) |55 | |
|Total current | |(1,445 |) |95 | |
|Deferred | | | | | |
|Federal | |— | |1,674 | |
|State | |— | |109 | |
|Total deferred | |— | |1,783 | |
|Total provision
(benefit) for income taxes | |$ |(1,445 |) |$ |1,878 | |

We recognized a benefit for income taxes as a result
of incurring a loss for the three months ended March 31, 2007.

The income tax provision (benefit) for the three
months ended March 31, 2007 and 2006, respectively, is based on the
estimated annual effective tax rate for the entire year. The estimated
effective tax rate is

9

  
* * *

  
subject to adjustment in
subsequent quarterly periods as the estimates of pretax income for the year are
increased or decreased. The effective tax rate for the three months ended March 31,
2007 and 2006, was approximately 34 percent and 44 percent, respectively. Until
legislation to retroactively reinstate federal tax credits for qualified
research expenditures was enacted in October 2006, no benefit from the
federal research credit generated during the three months ended March 31,
2006, was included in estimating the 2006 effective tax rate.

As of March 31, 2007, we had available
approximately $48.3 million in net operating loss carryforwards and
approximately $48.3 million in business tax credit carryforwards for federal
income tax purposes, which expire at various dates through 2024. We have
conducted a study to determine whether any limitations under Section 382
of the Internal Revenue Code have been triggered through December 31,
2006\. Results of this study indicate that multiple limitations occurred through
November 2004. As a result, portions of these carryforward items that were
generated prior to November 2004 will be subject to certain limitations on
their use. We do not believe that these potential limitations will cause the
net operating loss and general business credit carryforwards to expire unused.

In June 2006, the FASB issued Interpretation No. 48, _Accounting for Uncertainty in Income Taxes, an
interpretation of FASB Statement 109_ (FIN 48). This statement
clarifies the criteria that an individual tax position must satisfy for some or
all of the benefits of that position to be recognized in a company’s financial
statements. FIN 48 prescribes a recognition threshold of more-likely-than-not,
and a measurement attribute for all tax positions taken or expected to be taken
on a tax return, in order for those tax positions to be recognized in the
financial statements. Effective January 1, 2007, we adopted the provisions
of FIN 48 and there was no material effect on the financial statements. As a
result, there was no cumulative effect related to adopting FIN 48.

We file income tax returns in the U.S. federal
jurisdiction and various state and foreign jurisdictions. All of our U.S.
federal tax returns remain open for examination since we have not utilized any
of our business credits. State jurisdictions that remain subject to examination
range from 2001 to 2005. We do not believe there will be any material changes
in our unrecognized tax positions over the next 12 months.

Our policy is that we
recognize interest and penalties accrued on any unrecognized tax benefits as a
component of income tax expense. As of the date of adoption of FIN 48, we did
not have any accrued interest or penalties associated with any unrecognized tax
benefits, nor was any interest expense recognized during the quarter.

**10\. LICENSE
AGREEMENT**

In March 2007, Lung Rx entered into an agreement
with Toray Industries, Inc. (Toray) to assume and amend the rights and
obligations of the agreement entered into between Toray and us in June 2000
concerning the commercialization of modified release formulations of beraprost
(beraprost-MR). Under our original agreement with Toray, we had exclusive North
American rights to commercialize beraprost-MR in the United States for
cardiovascular disease. Under the amended agreement, we received additional exclusive
rights to commercialize beraprost-MR in Europe, broadens the indication to
vascular disease (excluding renal disease) and includes other revisions. While
an earlier clinical trial of an immediate release form of beraprost in PAH
demonstrated efficacy at 12 weeks but not at 36 weeks, a number of patients did
respond positively to the drug. We feel that the development of beraprost-MR as
combination therapy with drugs featuring different mechanisms of action presents
a desirable clinical opportunity given what we understand about how the human
body interacts with beraprost and how beraprost, in turn, affects the body. Since
there is considerable variability in how PAH patients respond to the same class
of molecules, we believe it is beneficial to offer a variety of treatments
within that family of molecules. In addition, we are in the early stages of exploring
the development of beraprost-MR for the treatment of congestive heart failure.

10

  
* * *

  
In accordance with the terms of the agreement, in March 2007,
we issued 200,000 shares of our common stock to Toray in exchange for the
cancellation of Toray’s existing right to receive an option grant to purchase
500,000 shares of our common stock (the Option Grant). Under the June 2000
Agreement, Toray’s right to receive the Option Grant was conditioned on Toray’s
delivery to us of adequate documentation of beraprost-MR in humans and its
transfer of clinical trial material to us, neither of which has yet to occur. Had
the Option Grant been made, the exercise price of the options would have been
set at the average closing price of our common stock for the period one month
prior to the delivery date. Under the terms of the assumed and amended
agreement, Toray has the right to request that we repurchase the newly-issued
200,000 shares of common stock upon 30 days prior written notice at the price
of $54.41 per share, which was the average closing price of our stock between January 11,
2007, and February 23, 2007. Based on the average closing price of our
stock for the two trading days prior to and the two trading days after March 16,
2007, we recognized a research and development expense of approximately $11.0
million in March relating to the issuance of the 200,000 shares, since
beraprost-MR has not yet obtained regulatory approval for commercial sales. In
accordance with the provision of SFAS No. 133, _Accounting
for Derivative Instruments and Hedging Activities_ , EITF 00-19, _Accounting for Derivative Financial Instruments Indexed to, and
Potentially Settled in, a Company’s Own Stock_ , and EITF Topic No. D-98, _Classification and Measurement of Redeemable
Securities_ , these shares of stock are reflected in mezzanine equity
as common stock subject to repurchase valued at the repurchase price. If Toray
requests that we repurchase these shares, then the value of these shares will
be transferred to a liability account until the repurchase is completed.

The amended license agreement
also specifies that we make certain milestone payments to Toray during the
development period and upon U.S. or European Union approval. Upon execution of
the amended agreement, we made a $3.0 million payment to Toray in addition to
the issuance of the 200,000 shares of our common stock discussed above. Additional
annual milestone payments are specified in the agreement of $2.0 million
commencing in 2008 and increasing by $1.0 million per year through 2011. These
payments will be expensed when incurred. These payments are contingent upon the
receipt of clinical trial material and commercial drug from Toray that meet all
of the regulatory standards and requirements, including those relating to chemistry,
manufacturing and controls, and are characterized and documented to the
satisfaction of the U.S. and European Union regulatory authorities. In
addition, if Toray elects to terminate production of beraprost-MR, no further
payments would be due under the amended agreement. Conversely, if we elect to
terminate development of beraprost-MR, then all remaining milestone payments
would be due to Toray, unless certain regulatory standards and requirements
have not been met, or material problems have been identified with respect to
manufacture and regulatory compliance.

**11\. SEGMENT
INFORMATION**

We have two reportable business segments,
pharmaceutical and telemedicine. The pharmaceutical segment includes all
activities associated with the research, development, manufacture and
commercialization of therapeutic products. The telemedicine segment includes
all activities associated with the development and manufacture of patient
monitoring products and the delivery of patient monitoring services. The
telemedicine segment is managed separately because diagnostic services require
different technology, manufacturing and marketing strategies than therapeutic
products require.

11

  
* * *

  
Segment
information as of and for the three months ended March 31, 2007 and 2006,
was as follows (in thousands):

| | |**Three Months Ended March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from
external customers | | |$ |38,283 | | | |$ |1,886 | | | |$ |40,169 | | | |$ |31,414 | | | |$ |1,750 | | | |$ |33,164 | | |
|Income (loss)
before income tax | | |(4,278 |) | | |52 | | | |(4,226 |) | | |4,343 | | | |(158 |) | | |4,185 | | |
|Interest income | | |4,040 | | | |60 | | | |4,100 | | | |1,894 | | | |4 | | | |1,898 | | |
|Interest expense | | |(711 |) | | |— | | | |(711 |) | | |— | | | |— | | | |— | | |
|Depreciation and
amortization | | |(736 |) | | |(89 |) | | |(825 |) | | |(446 |) | | |(122 |) | | |(568 |) | |
|Equity loss in
affiliate | | |(114 |) | | |— | | | |(114 |) | | |(207 |) | | |— | | | |(207 |) | |
|Total investment
in equity method investees | | |1,454 | | | |— | | | |1,454 | | | |1,852 | | | |— | | | |1,852 | | |
|Expenditures for
long-lived assets | | |(8,025 |) | | |(16 |) | | |(8,041 |) | | |(845 |) | | |(262 |) | | |(1,107 |) | |
|Goodwill, net | | |1,287 | | | |6,178 | | | |7,465 | | | |1,287 | | | |6,178 | | | |7,465 | | |
|Total assets | | |418,511 | | | |17,755 | | | |436,266 | | | |294,641 | | | |10,110 | | | |304,751 | | |

The segment information shown above equals the
consolidated totals. These consolidated totals equal the amounts reported in
the consolidated financial statements without further reconciliation for those
categories that are reported in the consolidated financial statements. There
are no inter-segment transactions.

For the three-month periods ended March 31, 2007
and 2006, approximately 85 percent and 87 percent, respectively, of our
revenues were earned from customers located in the United States.

12  
* * *  
**Item 2.** Management’s
Discussion and Analysis of Financial Condition and Results of Operations

The following discussion
should be read in conjunction with the consolidated financial statements and
related notes appearing in our Annual Report on Form 10-K for the
year ended December 31, 2006. The following discussion contains
forward-looking statements made pursuant to the safe harbor provisions of Section 21E
of the Securities Exchange Act of 1934 and the Private Securities Litigation
Reform Act of 1995 including the statements listed under the section entitled “ _Part II, Item 1A—Risk Factors”_ below. These
statements are based on our beliefs and expectations as to future outcomes and
are subject to risks and uncertainties that could cause our results to differ
materially from anticipated results. Factors that could cause or contribute to
such differences include those discussed below and as described in our Annual
Report on Form 10-K for the year ended December 31, 2006, under
the section entitled _“Part II, Item 1A—Risk
Factors—Forward-Looking Statements”,_ and the other cautionary
statements, cautionary language and risk factors set forth in other reports and
documents filed with the Securities and Exchange Commission. We undertake no
obligation to publicly update forward-looking statements, whether as a result
of new information, future events or otherwise.

**Overview**

We are a biotechnology
company focused on the development and commercialization of innovative
therapeutic products for patients with chronic and life-threatening
cardiovascular, cancer and infectious diseases. We commenced operations in June 1996
and, since our inception, have devoted substantially all of our resources to
acquisitions and research and development programs.

**_United Therapeutics
Products and Services_**

Our lead product is Remodulin, a prostacyclin analog.
Our prostacyclin analog acts as a stable synthetic form of prostacyclin, an
important molecule produced by the body that has powerful effects on
blood-vessel health and function. On May 21, 2002, the United States Food
and Drug Administration (FDA) approved subcutaneous (injection under the
skin) use of Remodulin (treprostinil sodium) for the treatment of PAH in
patients with NYHA class II-IV symptoms to diminish symptoms associated with exercise.
PAH is a life-threatening condition characterized by elevated blood pressures
between the heart and lungs. In November 2004, the FDA approved
intravenous (through a vein or artery) infusion of Remodulin for patients who
are not able to tolerate subcutaneous infusion. This approval was based on data
establishing the bioequivalence of intravenous with subcutaneous Remodulin. On March 21,
2006, the FDA expanded its approval of Remodulin to include patients requiring
transition from Flolan.

Remodulin is approved for subcutaneous use in 33
countries throughout the world. The mutual recognition process to obtain
approvals from European Union member countries for subcutaneous use of
Remodulin was completed in August 2005, with positive decisions received
from most European Union countries. We withdrew applications in Ireland, Spain
and the United Kingdom. We anticipate resubmitting these applications following
intravenous Remodulin approval in Europe. Licenses and pricing approvals have
been received in most European Union countries, with the remainder expected
during 2007. We have filed a variation to our license for approval of
intravenous Remodulin through the mutual recognition process. Currently, our
application is under review in France, our reference member state in the mutual
recognition process. Remodulin has been approved for intravenous use in Canada,
Israel, Mexico, Argentina and Peru. Marketing authorization applications are
currently under review in other countries.

We have generated revenues
from sales of Remodulin and arginine royalties and products (which deliver an
amino acid that is necessary for maintaining cardiovascular function) in the
United States and other countries. In addition, we have generated revenues from
telemedicine products and services, primarily designed for patients in the
United States with abnormal heart rhythms, called cardiac

13

  
* * *

  
arrhythmias,
and ischemic heart disease, a condition that causes poor blood flow to the
heart. We currently fund our operations from revenues generated from the sales
of our products and services.

**_Remodulin Marketing
and Sales_**

Remodulin is currently marketed by our own staff of
approximately 24 employees who market directly to physicians specialized in
treating PAH, comprised mainly of cardiologists and pulmonologists. Our staff
is augmented by the marketing resources of our distributors. We face stiff
competition from several other companies that market and sell competing
therapies and expect the competition to continue growing.

Remodulin is sold to patients in the United States by
Accredo Therapeutics, Inc. (a wholly-owned subsidiary of Medco Health
Solutions, Inc.), CuraScript, Inc. (a wholly owned subsidiary of
Express Scripts, Inc.), and Caremark, Inc., (a wholly-owned
subsidiary of CVS Corp.), and outside of the United States by various
international distributors. We sell Remodulin in bulk shipments to our
distributors. Our U.S.-based distributors typically place one order per month,
usually in the first half of the month. The timing and magnitude of our sales
of Remodulin are impacted by the timing and volume of these bulk orders from
distributors. Bulk orders placed by our distributors are based on their
estimates of the amount of drug required for existing and newly starting
patients, as well as maintaining an inventory that can meet approximately
thirty days’ demand as a contingent supply. Effective January 1, 2007,
Curascript’s minimum inventory requirement was reduced from 60 days to 30 days
to make their agreement consistent with our two other U.S. distributors. This
inventory reduction resulted in a decrease in our first quarter 2007 revenues of
approximately $2 million. Because discontinuation of therapy can be
life-threatening to patients, we require our distributors to maintain inventory
levels as specified in our distribution agreements. Due to these contractual
requirements, sales of Remodulin to distributors in any given quarter may not
be indicative of patient demand during that quarter. In addition, inventory
levels reported by distributors are impacted by the timing of their sales
around the end of each reporting period. Sales of Remodulin and associated
pumps and supplies are recognized as revenue when delivered to our
distributors.

On March 27, 2007, we entered into an exclusive
agreement with Mochida Pharmaceutical Co., Ltd. (Mochida), for subcutaneous and
intravenous Remodulin distribution in Japan. Mochida will be responsible for
obtaining Japanese marketing authorization for Remodulin with our assistance,
including conducting necessary bridging studies. We will supply study drug at
no charge to Mochida. Due to these bridging studies and required Japanese
regulatory reviews, commercial activities in Japan are not expected to commence
until 2010 or later. Upon receipt of marketing authorization and pricing
approval, Mochida will purchase Remodulin from us for at an agreed-upon transfer price. In
addition, Mochida has agreed to pay us certain exclusive distribution rights
payments. The first payment of $4.0 million will be paid within fifteen days
following their receipt of a tax certificate from the U.S. Treasury Department,
which is expected during the 2 nd quarter of 2007. Certain other distribution
rights payments are due as follows:  (1) upon
Remodulin receiving orphan drug status in Japan or February 1, 2008,
whichever first occurs, $4.0 million; (2) upon filing a New Drug
Application (NDA) in Japan, $2.0 million; and (3) upon marketing approval
in Japan, $2.0 million. Payments for distribution rights received through the
filing of the NDA will be recognized ratably over a three-year period
representing the estimated period of time until marketing authorization is
received.

Effective July 1,
2006, we increased the selling price of Remodulin to our U.S.-based
distributors. The price was increased approximately 3.5% to $67.25 per
milligram, and applies to sales of Remodulin made on or after July 1,
2006\.

14

  
* * *

  
**_Future Prospects_**

We believe it is likely
that many patients now being treated with non-prostacyclin therapies for PAH
will require prostacyclin therapy in the near future due to disease progression.
As they do, we believe our subcutaneous and intravenous formulations of
Remodulin will capture a significant number of these patients. We have two
Phase III trials, VIVETA and OvaRex, the results of which should be known
during the later half of 2007. If either or both of these trials are
successful, we will be working on obtaining regulatory approvals for these
products and developing our commercial strategy and foundation. Future profitability
will depend on many factors, including the price, level of sales, level of
reimbursement by public and private insurance payers, the impact of competitive
products, and the number of patients using Remodulin and other currently
commercialized products and services, as well as the results and costs of
research and development projects, as discussed in the section entitled _“Actual consolidated revenues and net income may be different from
published securities analyst projections. In addition, we have a history of
losses and may not continue to be profitable”_ under Part II—Items
1\.A. “Risk Factors” below.

**Major Research and
Development Projects**

Our major research and
development projects are focused on the use of Remodulin to treat
cardiovascular diseases, immunotherapeutic monoclonal antibodies (antibodies
that activate a patient’s immune response) to treat a variety of cancers and
glycobiology antiviral agents (a novel class of small molecules that may be
effective as oral therapies) to treat infectious diseases, such as the
hepatitis C virus.

**_Cardiovascular
Disease Projects_**

Subcutaneous use of
Remodulin was approved by the FDA in May 2002. Material net cash inflows
from the sales of Remodulin for PAH commenced in May 2002 after FDA
approval was received. In November 2004, the FDA approved intravenous
(through a vein or artery) infusion of Remodulin for patients who are not able
to tolerate subcutaneous infusion. This approval was based on data establishing
the bioequivalence of intravenous with subcutaneous Remodulin.

TRIUMPH-1, **Tr** eprostinil **In** halation **U** sed
in the **M** anagement of **P** ulmonary **H** ypertension, a clinical trial, is
currently being conducted at approximately 42 centers in the United States and
Europe. In May 2006, the FDA agreed to permit the inclusion of patients
with PAH who are also being treated with Revatio, to expand the trial size to
at least 200 patients, and to permit the assessment of efficacy after 150
patients have completed the trial. We did not conduct this interim efficacy
assessment. As a result, the TRIUMPH-1 trial is expected to conclude when
200 evaluable patients have completed the study, when approximately 215
patients have been enrolled. As of March 31, 2007, approximately 175
patients had been enrolled in this trial. As of April 30, 2007,
approximately 190 patients have been enrolled in this trial.

We are developing an oral formulation of treprostinil,
treprostinil diethanolamine. Two multi-national placebo-controlled clinical
trials of oral treprostinil in patients with PAH commenced in October 2006.
These trials are a combination of Phase II and Phase III trials, in which both
dosing and efficacy are being studied. One trial, FREEDOM-C, is a 16-week
study of up to 300 patients, with an interim assessment at 150 patients,
currently on background therapy using a PDE5-inhibitor, such as Revatio ® , or an endothelin antagonist,
such as Tracleer ® , or a
combination of both. The second trial, FREEDOM-M, is a 12-week
study of up to 150 patients, who are not on any background therapy, with an
interim assessment at 90 patients. Both trials will be conducted at
approximately 50 centers in the United States and the rest of the world. As of March 31,
2007, there were 70 and 35 patients enrolled in FREEDOM-C and FREEDOM-M,
respectively. As of April 30, 2007, there were 85 and 40 patients enrolled
in FREEDOM-C and FREEDOM-M, respectively.

15

  
* * *

  
We are also developing beraprost-MR for PAH. Beraprost-MR
is an oral analog of prostacyclin. In March 2007, Lung Rx entered into an
agreement with Toray Industries, Inc. (Toray) to assume and amend the
rights and obligations of the agreement entered into between Toray and us in June 2000
concerning the commercialization of a modified release formulation of beraprost.
This agreement is discussed in greater detail in the section entitled “ _License Agreement”_ below. In accordance with the terms of
the agreement, we paid Toray $3.0 million in cash and issued 200,000 shares of
our stock in March 2007. As a result, we recognized a $14.0 million
expense during the first quarter of 2007 for these transactions. We are
currently awaiting delivery of beraprost-MR clinical trial material from Toray.

We incurred expenses of
approximately $6.8 million and $8.9 million during the three months ended March 31,
2007 and 2006, respectively, on Remodulin development. Approximately $200.7
million from inception to date has been incurred on Remodulin development.

**_Cancer Disease
Projects_**

We licensed our monoclonal
antibody immunotherapies in April 2002 from AltaRex Medical Corp. OvaRex ® is our lead product and is currently being
studied in two identical Phase III clinical trials in advanced ovarian cancer
(Stage III and IV) patients. In January 2003, we initiated these Phase III
pivotal clinical trials of OvaRex called IMPACT I and II. Patients enrolled in
these studies have successfully completed front-line therapy, consisting of
surgery and chemotherapy. We are conducting these studies at approximately 60
centers throughout the United States. In June 2006, these trials were
fully enrolled with 367 patients. The primary endpoint for these trials is the difference in time to disease relapse between patients
treated with OvaRex and patients receiving a placebo. The trials will be
analyzed when each study has reached at least 118 relapse events. Following
relapse, patients will also be followed to assess survival rate. As of March 31,
2007, the reported number of relapse events was 127 and 104, respectively, in
each of the trials. We are also developing the manufacturing processes to
manufacture OvaRex ourselves. OvaRex had previously been supplied by a contract
manufacturer. We incurred expenses of approximately $2.9 million and $2.1
million during the three months ended March 31, 2007 and 2006,
respectively, on OvaRex development. Approximately $45.8 million from inception
to date has been incurred on OvaRex development.

**_Infectious Disease
Projects_**

Our infectious disease
program includes glycobiology antiviral drug candidates in the preclinical and
clinical stages of testing. The drugs in this program are being developed for a
wide variety of viruses. We completed acute and chronic Phase I clinical dosing
studies using UT-231B, for the treatment of hepatitis C, to assess safety
in healthy volunteers in early 2003. We initiated Phase II clinical studies in
patients infected with hepatitis C and completed those studies in October 2004.
In that trial, UT-231B did not demonstrate efficacy against hepatitis C
in a population of patients that had previously failed conventional treatments.
We are now conducting preclinical testing of new glycobiology drug candidates. We
incurred expenses of approximately $145,000 and $200,000 during the three
months ended March 31, 2007 and 2006, respectively, for our infectious
disease programs. Approximately $35.9 million from inception to date has been
incurred for infectious disease programs.

16

  
* * *

  
**_Project Risks_**

Due to the inherent
uncertainties involved in the drug development, regulatory review and approval
processes, the anticipated completion dates, the cost of completing the
research and development and the period in which material net cash inflows from
these projects are expected to commence are not known or estimable. There are
many risks and uncertainties associated with completing the development of the
unapproved products discussed above, including the following:

· Products
may fail in clinical studies;

· Hospitals,
physicians and patients may not be willing to participate in clinical studies;

· Hospitals,
physicians and patients may not properly adhere to clinical study procedures;

· The
drugs may not be safe and effective or may not be perceived as safe and
effective;

· Other
approved or investigational therapies may be viewed as safer, more effective or
more convenient;

· Patients
may experience severe side effects during treatment;

· Patients
may die during the clinical study because their disease is too advanced or
because they experience medical problems that are not related to the drug being
studied;

· Other
ongoing or new clinical trials sponsored by other drug companies or ourselves
may reduce the number of patients available for our studies;

· Patients
may not enroll in the studies at the rate we expect;

· The
FDA, international regulatory authorities or local internal review boards may
delay or withhold approvals to commence clinical trials or to manufacture
drugs;

· The
FDA or international regulatory authorities may request that additional studies
be performed;

· Higher
than anticipated costs may be incurred due to the high cost of contractors for
drug manufacture, research and clinical trials;

· Drug
supplies may not be sufficient to treat the patients in the studies; and

· The
results of preclinical testing may cause delays in clinical trials.

If these projects are not
completed in a timely manner, regulatory approvals could be delayed and our
operations, liquidity and financial position could suffer. Without regulatory
approvals, we cannot commercialize and sell these products and, therefore,
potential revenues and profits from these products could be delayed or
impossible to achieve.

**License Agreement**

In March 2007, Lung Rx entered into an agreement
with Toray to assume and amend the rights and obligations of the agreement
entered into between Toray and us in June 2000 concerning the
commercialization of modified release formulation of beraprost (beraprost-MR). Under
our original agreement with Toray, we had exclusive North American rights to
commercialize beraprost-MR in the United States for all cardiovascular disease.
The amended agreement provides, among other things, that we also have the
exclusive rights to commercialize beraprost-MR in Europe, broadens the
indication to vascular disease (excluding renal disease) and includes other
revisions. While an earlier clinical trial of an immediate release form of
beraprost as monotherapy in PAH demonstrated efficacy at 12 weeks but not at 36
weeks, a number of patients did respond positively to the drug. We feel that
the development of beraprost-MR as combination therapy with drugs featuring
different mechanisms of action presents a

17

  
* * *

  
desirable clinical opportunity
given what we understand about how the human body interacts with beraprost and
how beraprost, in turn, affects the body. Since there is considerable variability
in how PAH patients respond to the same class of molecules, we believe it is
beneficial to offer a variety of treatments within that family of molecules. In
addition, we are in the early stages of exploring the development of
beraprost-MR for the treatment of congestive heart failure.

In accordance with the terms of the amended license
agreement, in March 2007, we issued 200,000 shares of our common stock to
Toray in exchange for the cancellation of Toray’s existing right to receive an
option grant to purchase 500,000 shares of our common stock (the Option Grant).
Under the June 2000 Agreement, Toray’s right to receive the Option Grant
was conditioned on Toray’s delivery to us of adequate documentation of
beraprost-MR in humans and its transfer of clinical trial material to us,
neither which had yet to occur. Had the Option Grant been made, the exercise
price of the options would have been set at the average closing price of our
common stock for the period one month prior to the delivery date. Under the
terms of the assumed and amended agreement, Toray has the right to request that
we repurchase the newly-issued 200,000 shares of common stock upon 30 days’
prior written notice at the price of $54.41 per share, which is the average
closing price of our stock between January 11, 2007, and February 23,
2007\. Based on the average closing price of our stock for the two trading days
prior to and the two trading days after March 16, 2007, we recognized a
research and development expense of approximately $11.0 million in March relating
to the issuance of the 200,000 shares, since beraprost-MR has not yet obtained
regulatory approval for commercial sales. In accordance with the provision of
SFAS No. 133, _Accounting for Derivative
Instruments and Hedging Activities_ , and EITF Topic No. D-98, _Classification and Measurement of Redeemable
Securities_ , these shares of stock are reflected in mezzanine equity
as common stock subject to repurchase valued at the repurchase price. If Toray
requests that we repurchase these shares, then the value of these shares will
be transferred to a liability account until the repurchase is completed.

The new amended license
agreement also specifies that we make certain milestone payments to Toray
during the development period and upon U.S. or European Union approval. Upon
execution of the amended agreement, we made a $3.0 million milestone payment to
Toray in addition to the issuance of the 200,000 shares of our common stock
discussed above. The amended license agreement 
provides for additional milestone payments of $2.0 million commencing in
2008 and increasing by $1.0 million per year through 2011. These payments will
be expensed when incurred. These payments are contingent upon the receipt of
clinical trial material and commercial drug from Toray that meets all the
regulatory standards and requirements, including chemistry, manufacturing and
controls, and that are characterized and documented to the satisfaction of the
U.S. and European Union regulatory authorities. In addition, if Toray elects to
terminate production of beraprost-MR, no further payments will become be due
under the amended license agreement. Conversely, if we elect to terminate
development of beraprost-MR, then all remaining milestone payments would be due
to Toray, unless certain regulatory standards and requirements have not been
met, and material problems have been identified with respect to manufacture and
regulatory compliance. In addition to these milestone payments, the amended
agreement provides that we will become obligated to make additional payments to
Toray if certain specified events occur. Please see the section entitled _“Certain license and assignment agreements relating to our products may
restrict our ability to develop products in certain countries and/or for
particular diseases and impose other restrictions on our freedom to develop and
market our products”_ under Part II—Item 1.A. “Risk Factors” below
for more information about the license agreement with Toray.

**Financial Position**

Cash, cash equivalents and marketable investments
(including all unrestricted and restricted amounts) at March 31, 2007,
were approximately $252.4 million, as compared to approximately $303.2 million
at December 31, 2006. The decrease of approximately $50.8 million is due
primarily to the repurchase of

18

  
* * *

  
approximately $67.1
million worth of our common stock which was offset by cash provided by
operating activities and investing activities of approximately $13.1 million
and $20.4 million, respectively. Restricted cash and marketable investments
pledged to secure our obligations under the synthetic operating lease discussed
in the section entitled “ _Off Balance Sheet
Arrangement”_ at March 31, 2007, totaled approximately $38.2
million, as compared with approximately $39.0 million at December 31,
2006\.

Property, plant and equipment at March 31, 2007,
were approximately $42.1 million, as compared to approximately $34.7 million at
December 31, 2006. The increase was primarily due the acquisition of an
office building adjacent to our legal and governmental affairs office that we
lease in Washington, DC for $5.7 million.

Investments in affiliates at March 31, 2007, were
approximately $5.1 million, as compared to approximately $4.7 million at December 31,
2006\. The increase was due primarily to an increase in the fair value of our
investment in ViRexx Medical Corp., based on quoted market prices.

Accounts payable at March 31, 2007, were
approximately $5.0 million, as compared to approximately $2.8 million at December 31,
2006\. The increase was due generally to the timing of payments to vendors.

Accrued expenses at March 31, 2007, was
approximately $13.8 million, as compared to approximately $15.3 million at December 31,
2006\. The decrease was due primarily to the payout of employee year-end bonuses
in March of 2007.

Total stockholders’ equity
at March 31, 2007, were approximately $162.4 million, as compared to
approximately $204.6 million at December 31, 2006. For the three-month
period ended March 31, 2007, we repurchased approximately 1.2 million
shares of our common stock for $67.1 million which was offset by $8.0 million
from the proceeds from stock option exercises, $5.5 million from the
recognition of stock option expense and $3.4 million in tax benefits
recognized.

**Results Of
Operations**

**_Three months ended March 31,
2007 and 2006_**

Revenues for the three months ended March 31,
2007, were approximately $40.2 million, as compared to approximately $33.2
million for the three months ended March 31, 2006.

19  
* * *  
The
following sets forth our revenues by source for the periods presented (in
thousands).

| | |**Revenues for the  
Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |**% Change** | |
|Remodulin | |$ |38,150 | |$ |31,304 | | |21\.9 |% | |
|Telemedicine
services and products | |1,886 | |1,749 | | |7\.8 |% | |
|Other products | |133 | |111 | | |19\.8 |% | |
|Total revenues | |$ |40,169 | |$ |33,164 | | |21\.1 |% | |

Effective January 1, 2007, CuraScript’s minimum
inventory requirement was reduced from 60 days to 30 days to make their
agreement consistent with our other two U.S. distributors. This inventory
reduction resulted in a reduction in our first quarter 2007 revenues of
approximately $2 million.

For the three months ended
March 31, 2007 and, 2006, approximately 85 percent and 87 percent of our
revenues, respectively, were earned from our three distributors located in the
United States.

Total revenues are
reported net of estimated government rebates, prompt pay discounts and fees due
to distributors for services. We pay government rebates to state Medicaid
agencies that pay for Remodulin. We estimate our liability for such rebates
based on the historical level of government rebates invoiced by state Medicaid
agencies relative to U.S. sales of Remodulin. Prompt pay discounts are offered
on sales of Remodulin if the related invoices are paid in full generally within
60 days from the date of sale. We estimated our liability for prompt pay
discounts based on historical payment patterns. Fees paid to distributors for
services are estimated based on contractual rates for specific services applied
to estimated units of service provided by the distributors for the period.

A roll
forward of the liability accounts associated with estimated government rebates,
prompt pay discounts, and fees paid to distributors as well as the net amount
of reductions to revenues for these items are presented as follows (in
thousands):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |
|Liability
accounts, at beginning of period | |$ |2,366 | |$ |1,590 | |
|Additions to liability
attributed to sales in: | | | | | |
|Current period | |2,463 | |2,034 | |
|Prior period | |264 | |— | |
|Payments or reductions
attributed to sales in: | | | | | |
|Current period | |(432 |) |(361 |) |
|Prior period | |(2,352 |) |(1,503 |) |
|Liability
accounts, at end of period | |$ |2,309 | |$ |1,760 | |
|Net reductions to
revenues | |$ |2,727 | |$ |2,034 | |

20

  
* * *

  
Research
and development expenses consist primarily of salaries and related expenses,
costs to acquire pharmaceutical products and product rights for development,
and amounts paid to contract research organizations, hospitals and laboratories
for the provision of services and materials for drug development and clinical
trials. The table below summarizes research and development by major project
and non-project components (dollars in thousands):

| | |**Three Months Ended March 31,** | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |**Percentage  
Change** | |
|**Program:** | | | | | | | | | |
|Cardiovascular | |$ |9,781 | |$ |8,931 | | |9\.5 |% | |
|Cancer | |2,891 | |2,055 | | |40\.7 |% | |
|Infectious disease | |145 | |188 | | |(22.9 |)% | |
|Stock option | |2,572 | |2,321 | | |10\.8 |% | |
|Other | |1,712 | |1,205 | | |42\.1 |% | |
|Subtotal | |17,101 | |14,700 | | |16\.3 |% | |
|R&D expense from issuance of common stock | |11,013 | |— | | |N/A | | |
|Total research
and development expense | |$ |28,114 | |$ |14,700 | | |91\.3 |% | |

The increase in cardiovascular expenses was primarily
due to expensing a $3.0 million milestone payment to Toray in connection with
the amended beraprost-MR license, offset by a reduction in spending in the oral
treprostinil program . D uring the first
quarter of 2006, we purchased and expensed advanced chemical intermediates for
the manufacture of oral treprostinil. There were no such purchases in the first
quarter of 2007. The increase in expenses for the cancer program is related to
the development of our OvaRex manufacturing processes.

The research and development expense from issuance of
common stock pertains to the 200,000 shares of our common stock issued to Toray
in connection with the amended beraprost-MR license.

Selling,
general and administrative expenses consist primarily of salaries, travel,
office expenses, insurance, professional fees, provision for doubtful accounts
receivable, depreciation and amortization. The table below summarizes selling,
general and administrative expenses by major categories (dollars in thousands):

| | |**Three Months Ended  
March 31,** | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2007** | |**2006** | |**Percentage  
Change** | |
|**Category:** | | | | | | | | | |
|General and administrative | |$ |7,640 | |$ |5,064 | | |50\.9 |% | |
|Sales and marketing | |4,702 | |2,874 | | |63\.6 |% | |
|Stock option | |2,822 | |2,141 | | |31\.8 |% | |
|Total selling,
general and administrative expense | |$ |15,164 | |$ |10,079 | | |50\.5 |% | |

The increase in general and administrative expenses
was due primarily to increased expenses of approximately (1) $817,000 of
salaries and related expenses from headcount growth to support expanding
operations; (2) $432,400 of rent expense due to rent on our laboratory
facility in Silver Spring, Maryland, which began operations in May 2006;
and (3) $458,300 of other operating expenses supporting the growth in our
operations. The increase in sales and marketing related expenses is the result
of an increase in salaries and related expenses of $1.3 million due to an
increase in headcount and travel expenses of approximately $382,000.

21

  
* * *

  
A write down of intangible assets related to the
HeartBar product tradename totaling approximately $2.0 million was recorded
during the three months ended March 31, 2006. This write down was required
since the HeartBar product was discontinued in January 2006 and is no
longer sold.

Cost of sales consists of the cost to manufacture or
acquire products that are sold to customers. Cost of service sales consists of
the salaries and related overhead necessary to provide telemedicine services to
customers. Cost of product sales was approximately 10% of net product sales for
the three months ended March 31, 2007, which is consistent with
approximately 11% for the three months ended March 31, 2006. Cost of
service sales was approximately 33% of service sales for the three months ended
March 31, 2007, which is consistent with approximately 34% for the three
months ended March 31, 2006.

Interest income for the three months ended March 31,
2007, was approximately $4.1 million, as compared to interest income of
approximately $1.9 million for the three months ended March 31, 2006. The
increase was due primarily to an increase in cash invested during 2007 and
increased market interest rates.

Equity loss in affiliate represents our share of
Northern Therapeutics, Inc.’s losses. The equity loss in affiliate was
approximately $114,000 for the three months ended March 31, 2007, as
compared to approximately $207,000 for the three months ended March 31,
2006\. Northern Therapeutics, Inc.’s loss was due primarily to expenditures
for its autologous (non-viral vector) gene therapy research for PAH.

An income tax benefit of approximately $1.4 million
was recognized for the three months ended March 31, 2007, as compared to
an expense of approximately $1.9 million recognized for the three months ended March 31,
2006\. We recognized a benefit for income taxes as a result of incurring a loss for
the three months ended March 31, 2007.

The income tax provision
(benefit) is based on the estimated annual effective tax rate for the entire
year. The estimated effective tax rate is subject to adjustment in subsequent
quarterly periods as the estimates of pre-tax income for the year are increased
or decreased. The effective tax rate for the three months ended March 31,
2007 and 2006, was approximately 34 percent and 44 percent, respectively. Until
legislation to retroactively reinstate federal tax credits for qualified
research expenditures was enacted in October 2006, no benefit from the
federal research credit generated during the three months ended March 31,
2006, was included in estimating the 2006 effective tax rate. The cumulative
effect of the legislation was recorded in the fourth quarter 2006.

**Liquidity and
Capital Resources**

Until June 1999, we financed our operations
principally through private placements of common stock. On June 17, 1999,
we completed our initial public offering. Our net proceeds from the initial
public offering and sale of the over-allotment shares, after deducting
underwriting commissions and offering expenses, were approximately $56.4
million. In 2000, we issued common stock in two private placements and received
aggregate net proceeds of approximately $209.0 million. Until 2002, we funded
the majority of our operations from such net proceeds of equity. Since 2004, we
funded the majority of our operations from revenues, mainly Remodulin-related,
and this is expected to continue.

Our working capital at March 31, 2007 was
approximately $199.7 million, as compared to approximately $258.1 million at December 31,
2006\. The decrease is primarily due to our purchase of approximately $67.1
million worth of our common stock during the three months ended March 31,
2007\.

At March 31, 2007, restricted cash and marketable
investments pledged to secure our obligations under the synthetic operating
lease (discussed below under _Off Balance Sheet
Arrangement_ ) totaled approximately $38.2 million, as compared with
approximately $39.0 million at December 31, 2006.

22

  
* * *

  
Net cash provided by operating activities was
approximately $13.1 million for the three months ended March 31, 2007, as
compared to approximately $16.5 million for the three months ended March 31,
2006\. The decrease in cash provided by operating activities is due primarily to
the $3.0 million milestone payment to Toray under the amended license agreement.
During the three months ended March 31, 2007, we paid approximately $2.0
million for year-end 2006 incentive bonus payments and recognized an excess tax
benefit on stock-based compensation of approximately $2.4 million which were
not present during the three-month period ending March 31, 2006. For the
three months ended March 31, 2007, we invested approximately $8.0 million
in cash for property, plant and equipment, as compared to approximately $1.1
million in the three months ended March 31, 2006. In January 2007, we
purchased an office building adjacent to our legal and governmental affairs
office which we lease in Washington, DC for $5.7 million. For the three months
ended March 31, 2007, we also received approximately $8.0 million in stock
option exercise proceeds as compared to $3.5 million in the three months ended March 31,
2006\. In addition, during the three months ended March 31, 2007, we
repurchased approximately 1.2 million shares of our common stock for $67.1
million, as compared to no shares for the three months ended March 31,
2006\.

We are currently in the planning phase for building an
approximately 200,000 square foot facility in Research Triangle Park, North
Carolina, which will consist of a manufacturing operation and offices. The
manufacturing operation will primarily be for oral treprostinil, although it is
expected to support other programs, and the offices will be used by our
clinical development and sales and marketing staff, which currently occupy a
leased facility in the area. Construction of this facility is expected to begin
during the second quarter of 2007 and may take up to two years to complete. The
project may cost up to $100 million, and we expect to fund the construction of
this facility from our working capital or other financing arrangements.

Effective March 9, 2007, we entered into a
construction management agreement with DPR Construction, Inc. (DPR) based
in Falls Church, Virginia. DPR will manage the construction of our
manufacturing and office facility in Research Triangle Park, North Carolina. The
agreement has a guaranteed maximum price clause in which DPR agrees that the
construction cost of the facility will not exceed approximately $78.0 million,
which amount is subject to change based on agreed-upon changes to the scope of
work. DPR will be responsible for covering any costs in excess of the
guaranteed maximum price. If the ultimate cost of the project is less than the
guaranteed maximum, we will share a portion of these savings with DPR. In
addition, DPR must pay us penalties if the construction is not completed by February 2009,
which date is subject to change based on agreed-upon changes to the scope of
work. DPR has no material relationship with us or any of our affiliates.

In addition, we are in the planning phase for a new
office and laboratory building which will connect to our current laboratory
facility in Silver Spring, Maryland. The building of this facility is
anticipated to begin in the latter half of 2007. The costs are still being
estimated due to continuing design and related estimation work. We anticipate
that the construction of this facility will be financed though a synthetic
operating lease.

We made milestone payments totaling $20,000 pursuant
to existing license agreements during each of the three months ended March 31,
2007 and 2006. We are obligated to make royalty payments on sales of Remodulin
that exceed annual net sales of $25.0 million and on all arginine products.
Royalties on sales of all products currently marketed range up to 10 percent of
sales of those products.

We believe that our existing revenues, together with
existing capital resources (comprised primarily of unrestricted cash, cash
equivalents and marketable investments), will be adequate to fund our
operations. However, any projections of future cash needs and cash flows are
subject to substantial uncertainty. See the section entitled _“Part II, Item 1A—Risk Factors—Actual consolidated revenues and
net income may be different from published securities analyst projections. In
addition, we have a history of losses and may not continue to be profitable”_ below _._

23

  
* * *

  
At March 31, 2007, we had, for federal income tax
purposes, net operating loss carryforwards of approximately $48.3 million and
business tax credit carryforwards of approximately $48.3 million which expire
at various dates from 2012 through 2025. The remaining net operating loss
carryforwards are attributable to exercised stock options, the benefit of
which, when realized, directly increases additional paid-in-capital. Business
tax credits can offset future tax liabilities and arise from qualified research
expenditures. We have been and may continue to be subject to federal
alternative minimum tax and state income taxes, even though we have significant
net operating loss and credit carryforwards.

Section 382 of the
Internal Revenue Code limits the utilization of net operating losses when
ownership changes occur as defined by that section. We have reviewed our
ownership change position pursuant to Section 382 through December 31,
2006 and have determined that ownership changes occurred in December 1997,
June 1999, and November 2004 and, as a result, the utilization of
certain of our net operating loss carryforwards may be limited. However, we do
not expect any significant portion of our net operating loss carryforwards or
business tax credits will expire unused. A portion of the net operating loss
carryforwards continues to be reserved through a valuation allowance as of March 31,
2007\.

**_Convertible Senior
Notes_**

On October 30, 2006, we issued $250.0 million of
0\.50% Convertible Senior Notes due October 2011 (the Convertible Senior
Notes). Proceeds from the offering, after deducting the initial purchaser’s,
Deutsche Bank Securities Inc. (Deutsche Bank), discount and commission and
estimated expenses were approximately $242.0 million. The Convertible Senior
Notes were issued at par value and pay interest in cash semi-annually in
arrears on April 15 and October 15 of each year, beginning on April 15,
2007\. The Convertible Senior Notes are unsecured unsubordinated obligations and
rank equally with all other unsecured and unsubordinated indebtedness. The
Convertible Senior Notes have an initial conversion price of $75.2257 per
share. The Convertible Senior Notes may only be converted: (i) anytime
after July 15, 2011; (ii) during any calendar quarter commencing
after the date of original issuance of the notes, if the closing sale price of
our common stock for at least 20 trading days in the period of 30 consecutive
trading days ending on the last trading day of the calendar quarter preceding
the quarter in which the conversion occurs is more than 120% of the conversion
price of the notes in effect on that last trading day; (iii) during the
ten consecutive trading-day period following any five consecutive trading-day
period in which the trading price for the notes for each such trading day was
less than 95% of the closing sale price of our common stock on such date
multiplied by the then current conversion rate; or (iv) if specified
significant distributions to holders of our common stock are made, specified
corporate transactions occur, or our common stock ceases to be approved for
listing on The NASDAQ Global Select Market and is not listed for trading on
another U.S. national or regional securities exchange. Upon conversion, a
holder will receive: (i) cash equal to the lesser of the principal amount
of the note or the conversion value; and (ii) to the extent the conversion
value exceeds the principal amount of the note, shares of our common stock. In
addition, upon a change in control, as defined in the indenture under which the
Convertible Senior Notes have been issued, the holders may require us to
purchase all or a portion of their Convertible Senior Notes for 100% of the
principal amount plus accrued and unpaid interest, if any, plus a number of
additional shares of our common stock, as set forth in the related indenture.
The indenture under which the Convertible Senior Notes were issued contains
customary covenants.

Concurrent with the issuance of the Convertible Senior
Notes, we purchased call options on our common stock in a private transaction.
The call options allow us to receive up to approximately 3.3 million shares of
our common stock from counterparties, equal to the amount of common stock
related to the excess conversion value that we would pay to the holders of the
Convertible Senior Notes upon conversion. These call options will terminate
upon the earlier of the maturity dates of the related Convertible Senior Notes
or the first day all of the related Convertible Senior Notes are no longer outstanding
due to conversion or otherwise. The call options, which cost approximately
$80.8 million, were recorded as a

24

  
* * *

  
reduction of shareholders’
equity. The cost of call options for tax purposes creates a tax deduction since
it is classified as an Original Issue Discount (OID). The deduction is
considered a permanent difference and, as such, does not create a deferred tax
asset. The benefit of the deduction is recorded as an increase to additional
paid-in-capital.

In a separate transaction,
we sold warrants to issue shares of our common stock at an exercise price of
$105.689 per share. Pursuant to this transaction, warrants for approximately
3\.3 million shares of our common stock were issued. If the average price of our
common stock during a defined period, ending on or about the respective
settlement dates, exceeds the exercise price of the warrants, the warrants will
be settled in shares of our common stock. Proceeds received from the issuance
of the warrants totaled approximately $45.4 million and were recorded as an
increase to additional paid-in-capital.

We also used approximately
$112.4 million of the proceeds from the issuance of the Convertible Senior
Notes to repurchase approximately 1.8 million outstanding shares of our common
stock as part of this transaction. We intend to use the remainder of the net
proceeds for working capital or other general corporate purposes, which may
include acquisitions, strategic investments or joint venture arrangements. Including
the shares of common stock repurchased as part of the Convertible Senior Note
transaction, we have repurchased a total of approximately 3.1 million shares of
our common stock for approximately $182.5 million through March 31, 2007.

**Off Balance Sheet Arrangement**

In June 2004, we
entered into a synthetic operating lease and related agreements with Wachovia
Development Corporation and its affiliates (Wachovia) to fund the construction
of a laboratory facility in Silver Spring, Maryland. Under these agreements,
Wachovia funded $32.0 million towards the construction of the laboratory
facility on land owned by us. The construction phase commenced in 2004 and was
completed in May 2006. Following construction, Wachovia leased the
laboratory facility to us with a term ending in May 2011. Under the 99-year
ground lease, Wachovia will pay fair value rent to us for use of the land both
during the construction phase and after the laboratory lease is terminated.
During the term of the laboratory lease, Wachovia will pay $1 per year to us
for use of the land.

Wachovia receives rent
from us, generally based on applying the 30-day LIBOR rate plus
approximately 55 basis points to the amount funded by Wachovia towards the
construction of the laboratory. This monthly rent commenced when the laboratory
construction was completed and will continue until the termination of the lease
in May 2011. Upon termination of the lease, we will generally have the
option of renewing the lease (subject to approval of both parties), purchasing
the laboratory at a price approximately equal to the funded construction cost,
or selling it and repaying Wachovia the cost of its construction. We have
guaranteed that if the laboratory is sold, Wachovia will receive at least
86% of the amount it funded towards the construction.

We pledged a portion of
our marketable investments as collateral to secure our lease obligations. At March 31,
2007, approximately $38.2 million of marketable investments and cash were
pledged as collateral and are reported as restricted marketable investments and
cash in our consolidated balance sheet.

This arrangement enabled
us to construct our laboratory facility without using our own working capital.
There will not be any depreciation expense associated with the laboratory
facility, since these improvements are owned by Wachovia. The amount of rent to
be paid to Wachovia during the term of the laboratory lease will vary as it is
tied to the then current 30-day LIBOR rate plus approximately 55 basis
points. As this rate increases, so will the rent to be paid. Similarly, if this
rate decreases, so will the amount of rent to be paid to Wachovia.

Rent payments under the
laboratory lease commenced in May 2006 and will continue through
termination of the lease in May 2011. Upon the completion of the building
in May 2006, Wachovia

25

  
* * *

  
advanced
to us approximately $5.2 million, which constituted the remaining funds
available for construction due to the lengthy process involved in finalizing
construction costs. At March 31, 2007, the remaining construction advance
totaled approximately $436,000 and is classified as other current liability in our
balance sheet. When the final construction costs have been agreed upon, any
remaining funds that were advanced will be returned to Wachovia. Upon the return
of unspent funds, the remaining rent payments will be based on the actual
funded costs of the building.

Based on construction
costs of approximately $32.0 million and the current effective rate of
approximately 5.9% (equivalent to the current 30-day LIBOR rate plus
approximately 55 basis points at March 31, 2007), the rents to be paid are
approximately $1.9 million annually. In addition, Wachovia paid us ground rent
of approximately $307,000 in June 2004 covering the period through May 2011.
This amount is being recognized as income ratably through May 2011.

We guaranteed a minimum
residual value of the laboratory facility. This guaranteed residual is
generally equal to 86% of the amount funded by Wachovia towards construction.
If, at the end of the lease term, we do not renew the lease or purchase the
improvements, then the building will be sold to a third party. In that event,
we have guaranteed that Wachovia will receive at least this residual value
amount. The maximum potential amount of this guarantee is approximately
$27.5 million, equivalent to 86% of total expected construction costs
of $32.0 million. We have reported this guarantee as a non-current asset
(prepaid rent) and non-current liability (other liability). We have estimated
the fair value of this guarantee liability and the corresponding asset at
approximately $692,000, net of accumulated amortization at March 31, 2007.

The laboratory lease and
other agreements require, among other things, that we maintain a consolidated
net worth of at least $70.0 million. The agreements contain other covenants and
conditions with which we must comply throughout the lease periods and upon
termination of the lease. If we were unable to comply with these covenants and
conditions, if the noncompliance went uncured, and if the parties could not
agree otherwise, the agreements could terminate. A termination of these
agreements could result in our acquisition of the improvements from Wachovia or
the loss of our liquid collateral.

**Contractual Obligations**

At March 31,
2007, we had contractual obligations coming due approximately as follows
(in thousands):

| | |**Payment Due In** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Total** | |**  
 2007** | |**2008  
to  
2009** | |**2010  
to  
2011** | |**2012  
and  
Later** | |
|Notes payable and
capital lease obligations(1) | |$ |256,237 | |$ |1,215 | |$ |2,522 | |$ |252,500 | |$ |— | |
|Operating lease
obligations | |11,530 | |2,333 | |5,828 | |3,264 | |105 | |
|Construction
agreement(2) | |436 | |436 | |— | |— | |— | |
|Purchase
obligations(3) | |4,566 | |566 | |2,000 | |2,000 | |— | |
|Other long-term
liabilities reflected in the  
statement of financial position(4) | |692 | |— | |— | |692 | |— | |
|Milestone
payments(5) | |25,545 | |2,170 | |10,340 | |10,015 | |3,020 | |
| | |$ |299,006 | |$ |6,720 | |$ |20,690 | |$ |268,471 | |$ |3,125 | |

* * *

(1) In
October 2006, we issued $250.0 million aggregate principal amount of
Convertible Senior Notes. The principal balance of the notes is repaid in cash
with any increase of our stock price above $75.22 paid in our stock. While the
notes can be redeemed by the bondholder once our stock price exceeds $75.22, we
have assumed that the bondholders will hold the bonds until maturity.

26

  
* * *

  
(2) Upon
the completion of our laboratory in May 2006, Wachovia advanced to us the
remaining funds available for construction due to the lengthy process involved
in finalizing construction costs. When the final construction costs have been
agreed upon, any remaining funds that were advanced will be returned to
Wachovia. At March 31, 2007, the remaining construction advance totaled
approximately $436,000 and is classified as other current liability in our
balance sheet _._

(3) Includes
specified payments to Toray for clinical trial material.

(4) Upon
termination of the lease with Wachovia for the laboratory facility, we will
generally have the option of renewing the lease, purchasing the laboratory or
selling it and repaying Wachovia the cost of its construction. We guaranteed
that if the laboratory is sold, Wachovia will receive at least 86% of the
amount it funded towards the construction. We estimate that the laboratory will
cost approximately $32.0 million to construct and the guarantee is estimated at
approximately $27.5 million. The estimated fair value of the guarantee is
included in other long-term liabilities reflected in the statement of financial
position. See the section entitled “ _Off Balance Sheet
Arrangement”_ above for additional information.

(5) We
licensed certain products from other companies under certain license
agreements. These agreements generally include milestone payments to be paid in
cash by us upon the achievement of certain product development and
commercialization goals set forth in each license agreement. Total milestone
payments under these license agreements have been estimated based on the
assumption that the products will be successfully developed and on the
estimated timing of these development and commercialization goals.

**Summary of Critical
Accounting Policies**

The preparation of our
consolidated financial statements in conformity with U.S. generally accepted
accounting principles requires management to make estimates and assumptions
that affect the amounts reported in our consolidated financial statements and
accompanying notes. On an ongoing basis, we evaluate our estimates and
judgments, which are based on historical and anticipated results and trends and
on various other assumptions that we believe are reasonable under the
circumstances, including assumption as to future events. By their nature,
estimates are subject to an inherent degree of uncertainty and, as such, actual
results may differ from our estimates. We discuss accounting policies and
assumptions that involve a higher degree of judgment and complexity than others
in our Management’s Discussion and Analysis of Financial Condition and Results
of Operations in our Annual Report to shareholders on Form 10-K for
the year ended December 31, 2006.

**Recent Accounting
Pronouncements**

**_Fair Value
Measurements_**

In September 2006,
the FASB issued SFAS 157, _Fair Value Measurements_ .
SFAS 157 defines fair value, establishes a framework for measuring fair value
under generally accepted accounting principles, and expands disclosures about
fair value measurements. SFAS 157 is effective for financial statements issued
for fiscal years beginning after November 15, 2007, and interim periods
within those fiscal years. We are currently evaluating the impact the adoption
of this statement could have on our financial condition, results of operations
or cash flows.

27  
* * *  
**_Uncertain Tax
Positions_**

In July 2006, the
FASB issued FIN 48, _Accounting for Uncertainty
in Income Taxes,_ an interpretation of Statement of Financial
Accounting Standards No. 109, _Accounting for Income
Taxes_ . FIN 48 clarifies the accounting for income taxes by
prescribing the minimum recognition threshold a tax position is required to
meet before being recognized in the financial statements. FIN 48 also provides
guidance on derecognition, measurement, classification, interest and penalties,
accounting in interim periods, disclosure and transition. The interpretation
applies to all tax positions related to income taxes subject to SFAS 109. FIN
48 is effective for fiscal years beginning after December 15, 2006. We
adopted this interpretation without a significant impact on our financial
condition, results of operations or cash flows.

**_Hybrid Financial
Instruments_**

In February 2006, the
FASB issued SFAS 155, _Accounting for Certain
Hybrid Financial Instruments_ which amends SFAS 133, _Accounting for Derivative Instruments and Hedging Activities_ and SFAS 140, _Accounting for Transfers and Servicing of
Financial Assets and Extinguishments of Liabilities_ . SFAS 155
simplifies the accounting for certain derivatives embedded in other financial
instruments by allowing them to be accounted for as a whole if the holder
elects to account for the whole instrument on a fair value basis. SFAS 155 also
clarifies and amends certain other provisions of SFAS 133 and SFAS 140. SFAS
155 is effective for all financial instruments acquired, issued or subject to a
remeasurement event occurring in fiscal years beginning after September 15,
2006\. We do not believe the adoption of this statement will have a material
impact on our financial condition, results of operations or cash flows.

**Item 3.** Quantitative
and Qualitative Disclosures about Market Risk

At March 31, 2007, a substantial portion of our
assets consisted of federally-sponsored agencies and corporate debt securities.
The market value of these investments fluctuates with changes in current market
interest rates. In general, as rates increase, the market value of a debt
investment would be expected to decrease. Likewise, as rates decrease, the
market value of a debt investment would be expected to increase. To minimize
such market risk, we hold such instruments to maturity at which time these
instruments will be redeemed at their stated or face value. At March 31,
2007, we had approximately $166.0 million in debt securities issued by
federally-sponsored agencies and corporate issuers with a weighted average
stated interest rate of approximately 4.7 percent maturing through March 2012
and callable annually. The fair market value of this held-to-maturity portfolio
at March 31, 2007 was approximately $164.4 million.

At March 31, 2007, a portion of our assets was
comprised of auction rate debt securities issued by state-sponsored agencies.
While these securities have long term maturities, their interest rates are
reset approximately every 7-28 days through an auction process. As a
result, the interest income from these securities is subject to market risk
since the rate is adjusted to accommodate market conditions on each reset date.
However, since the interest rates are reflective of current market conditions,
the fair value of these securities typically does not fluctuate from par or
cost. At March 31, 2007, we had approximately $15.8 million in these debt
securities with a weighted average stated interest rate of approximately 5.3
percent. The fair market value of these available-for-sale debt securities as
of March 31, 2007, was approximately $15.8 million.

In June 2004, we
entered into a synthetic operating lease and related agreements with Wachovia
to fund the construction of a laboratory facility in Silver Spring, Maryland.
Under these agreements, we pay rent to Wachovia generally based on applying the
30-day LIBOR rate plus approximately 55 basis points to the amount funded
by Wachovia towards the construction of the laboratory. The total amount of
construction is estimated to be approximately $32.0 million. This rent,
therefore, is subject to the risk that the LIBOR rate will increase or decrease
during the period until termination in May 2011. At March 31, 2007,
the 30-day LIBOR rate was approximately 5.3%. For every movement of 100
basis points (1%) in the

28

  
* * *

  
30-day
LIBOR rate, the rent under this lease could increase or decrease by
approximately $320,000 on an annualized basis.

**Item 4.** Controls
and Procedures

Based on their evaluation, as of March 31, 2007,
the Chief Executive Officer and Chief Financial Officer have concluded that our
disclosure controls and procedures (as defined in Rule 13a-15(e) and
15d-15(e) under the Securities Exchange Act of 1934, as amended) are
effective to provide reasonable assurance that information required to be
disclosed by us in reports that we file or submit under the Securities Exchange
Act of 1934, as amended, is recorded, summarized, processed and reported within
the time periods specified in the Securities and Exchange Commission’s rules and
forms and to provide reasonable assurance that such information is accumulated
and communicated to our management, including the Chief Executive Officer and
Chief Financial Officer, as appropriate to allow timely decisions regarding
required disclosure. There have been no changes in our internal control over
financial reporting that occurred during the period covered by this report that
have materially affected, or are reasonably likely to materially affect, such
internal control over financial reporting.

29  
* * *  
**Part II.** OTHER
INFORMATION

**ITEM 1A.** RISK
FACTORS

**Forward-Looking
Statements**

This Quarterly
Report on Form 10-Q contains forward-looking statements made
pursuant to the safe harbor provisions of Section 21E of the Securities
Exchange Act of 1934 (the Exchange Act) and the Private Securities Litigation
Reform Act of 1995 which are based on our beliefs and expectations as to future
outcomes. These statements include, among others, statements relating to the
following:

· Expectations
of revenues and profitability;

· The
timing and outcome of clinical studies and regulatory filings;

· The
achievement and maintenance of regulatory approvals;

· The
availability of drug product;

· The
ability to find alternate sources of supply and manufacturing for our products;

· The
existence and activities of competitors;

· The
expectation not to pay dividends on common stock in the foreseeable future;

· The
pricing of Remodulin;

· The
dosing and rate of patient consumption of Remodulin;

· The
expectation of reimbursement by third-party payers for intravenous Remodulin
and the impact of any regulatory changes to the level of reimbursement;

· The
expected levels and timing of bulk purchases of chemicals used to manufacture
the various forms of treprostinil, the active ingredient of Remodulin and our
inhaled and oral formulations;

· The
expected impact of CuraScript’s inventory reduction from 60 days to 30 days;

· The
outcome of potential future regulatory actions from the FDA and other
international regulatory agencies and any actions that may or may not be taken
by the FDA and other international regulatory agencies as a result of any such
regulatory actions;

· The
rate of physician and patient acceptance of our products as safe and effective;

· The
development and sale of products covered by licenses and assignments;

· The
adequacy of our intellectual property protections and their expiration dates;

· The
outcome of any litigation in which we are or become involved;

· The
ability of third parties to develop, market, distribute and sell our products;

· The
composition of our management team;

· The
adequacy of our insurance coverage;

· The
ability to obtain financing in the future;

· The
value of our common stock;

· The
expectation of future repurchases of our common stock, including those shares
subject to repurchase from Toray;

· The
funding of operations from future revenues;

30

  
* * *

  
· The
expectation of continued profits or losses;

· Expectations
concerning milestone and royalty payments in 2007 and beyond;

· Expectations
of receiving clinical trial matter and related documentation from Toray prior
to the end of 2007;

· Expectations
concerning payments of contractual obligations in all future years and their
amounts;

· The
use of net operating loss carryforwards and business tax credit carryforwards,
the tax impact of our hedging contracts entered into in connection with the
convertible debt offering and the impact of Section 382 of the Internal
Revenue Code on their use;

· Income
tax expenses and benefits in current and future periods;

· The
completion of in-process research and development projects and their impact on
our business;

· The
pace and timing of enrollment in clinical trials;

· The
expectation, outcome and timing of new and continuing regulatory approvals;

· The
timing, resubmission, completion and outcome of the applications for approval
of subcutaneous Remodulin in Ireland, Spain and the United Kingdom;

· The
timing, completion and outcome of pricing approvals in European Union countries
that approve subcutaneous Remodulin;

· The
expectation, outcome and timing of marketing approvals in European Union
countries for intravenous Remodulin;

· The
expected timing of milestone payments from Mochida and commercial activities in
Japan;

· The
expected revenue recognition of milestone payments from Mochida;

· The
expected levels and timing of Remodulin sales;

· The
adequacy of our resources to fund operations;

· The
expectation, outcome and timing of validation of, and level of spending to
validate, our newly-constructed laboratory production facility in Silver
Spring, Maryland;

· The
potential amount of the minimum residual value guarantee under our synthetic
lease agreement with Wachovia Bank, N.A. and Wachovia Development Corporation
relating to our facility in Silver Spring, Maryland;

· The
expected amounts and timing of resources for the construction of facility
projects in Research Triangle Park, North Carolina and the expectation to
finance the construction of our new facility in Silver Spring, Maryland;

· Events
that could occur upon termination of the Wachovia synthetic lease and related
agreements;

· The
potential impacts of new accounting standards;

· Our
intent and ability to hold certain marketable investments until maturity;

· Any
statements preceded by, followed by or that include the words “believes,” “expects,”
“predicts,” “anticipates,” “intends,” “estimates,” “should,” “may” or similar
expressions; and

· Other
statements contained or incorporated by reference in this Quarterly Report on Form 10-Q
that are not historical facts.

31

  
* * *

  
The statements identified as forward-looking
statements may exist in the section entitled “ _Item 7—Management’s
Discussion and Analysis of Financial Condition and Results of Operations”_ above or elsewhere in this Quarterly Report on Form 10-Q. These statements
are subject to risks and uncertainties and our actual results may differ
materially from anticipated results. Factors that may cause such differences
include, but are not limited to, those discussed below. We undertake no
obligation to publicly update forward-looking statements, whether as a result
of new information, future events or otherwise.

Unless the context
requires otherwise or unless otherwise noted, all references in this section to
“United Therapeutics” and to the “company”, “we”, “us” or “our” are to United
Therapeutics Corporation and its subsidiaries.

**_Actual consolidated
revenues and net income (loss) may be different from published securities
analyst projections. In addition, we have a history of losses and may not
continue to be profitable._**

Many independent securities analysts have published
quarterly and annual projections of our revenues and profits. These projections
were made independently by the securities analysts based on their own analysis.
Such estimates are inherently subject to a degree of uncertainty. As a result,
the actual revenues and net income may be greater or less than projected by
such securities analysts. Even small variations in reported revenues and
profits as compared to securities analysts’ expectations can lead to
significant changes in our stock price.

Although we were profitable for every quarter ended
after March 31, 2004, during the three months ending March 31, 2007,
we paid Toray approximately $14.0 million in cash and stock for a license fee. These
amounts were expensed since the licensed product does not have economical
viability. If it were not for the expensing of these payments, we would have
been profitable for the quarter. At March 31, 2007, our accumulated
deficit was approximately $44.1 million.

Factors that could
affect consolidated revenues and profitability and cause our quarterly and
annual operating results to fluctuate include the following:

· Extent
and timing of sales of Remodulin to distributors;

· Levels
of Remodulin inventory held by our distributors, their compliance with
contractual inventory requirements and changes to those levels from quarter to
quarter;

· Level
of patient demand for Remodulin and other products;

· Status
and impact of other approved competitive products such as Ventavis ® , Revatio, Tracleer and Flolan and investigational
competitive products such as ambrisentan, Thelin™, Cialis ® , Gleevec ® and
other potential investigational competitive products;

· Changes
in prescribers’ opinions about Remodulin;

· Impact
of medical and scientific opinion about our products;

· Levels
of research and development, selling, general and administrative expenses;

· Timing
of payments to licensors and corporate partners;

· Retention
and growth of patients treated with Remodulin;

· Remodulin
side effects, including impact of infusion site pain and reaction from
subcutaneous use of Remodulin;

· Changes
in the current pricing and dosing of Remodulin;

· Changes
in the length of time that Remodulin vials may be used by patients;

32

  
* * *

  
· Changes
in the pricing of other therapies approved for PAH, including possible generic
formulations of other approved therapies, such as Flolan, which may be sold in
generic form beginning in May 2007;

· The
ability of our distributors to transition to the use of other infusion pumps
currently available on the market due to Medtronic’s discontinuance of the 407C
infusion pump;

· Willingness
of private insurance companies, Medicare and Medicaid to reimburse Remodulin at
current pricing levels;

· Impacts
of new legislation and regulations and changes to the Medicare and Medicaid
programs;

· Our
ability to maintain regulatory approval of Remodulin in the United States and
other countries;

· Additional
regulatory approvals for Remodulin in countries other than where it is
currently sold;

· Continued
performance by current Remodulin distributors under existing agreements;

· Size,
scope and outcome of development efforts for existing and additional products;

· Future
milestone and royalty payments under license and other agreements;

· Cost,
timing and outcomes of regulatory reviews;

· Rate
of technological advances;

· Our
ability to establish, defend and enforce intellectual property rights;

· Development
of manufacturing resources or the establishment, continuation or termination of
third-party manufacturing arrangements;

· Establishment,
continuation or termination of third-party clinical trial arrangements;

· Development
of sales and marketing resources or the establishment, continuation or
termination of third-party sales and marketing arrangements;

· Impact
of any regulatory restrictions on our marketing and promotional activities;

· Recovery
of goodwill, intangible assets and investments in affiliates;

· Collection
of accounts receivable and realization of inventories;

· Risks
associated with acquisitions, including the ability to integrate acquired
businesses;

· Unforeseen
expenses;

· Actual
growth in sales of telemedicine and arginine products;

· Actual
expenses incurred in future periods; and

· Completion
of additional acquisitions and execution of license agreements.

Most of our pharmaceutical products are in clinical
studies. We might not maintain or obtain regulatory approvals for our
pharmaceutical products and may not be able to sell our pharmaceutical products
commercially. Even if we sell our products, we may not be profitable and may
not be able to sustain any profitability we achieve.

For the treatment
of PAH, we compete with many approved products in the United States and
worldwide, including the following:

· Flolan
was the first product approved by the FDA for treating PAH and has been
marketed by GlaxoSmithKline PLC since 1996 and, beginning in the second quarter
of 2006, by Myogen, Inc. On

33

  
* * *

  
November 17, 2006,
Myogen was acquired by Gilead Sciences, Inc., which is regarded as a large
and successful biotechnology company in the United States. Generic formulations
of Flolan could be available for commercial sale as early as May 2007.
Flolan is delivered by intravenous infusion and considered to be an effective
treatment by most PAH experts.

· Ventavis
was approved in December 2004 in the United States and in September 2003
in Europe. Ventavis is the only prostacyclin that has been approved for
inhalation, whereas Remodulin is only currently approved to be delivered
through intravenous or subcutaneous infusion. Ventavis was initially marketed
by CoTherix, Inc. in the United States and Schering AG in Europe. In January 2007,
CoTherix was acquired by Actelion Ltd, the manufacturer and distributor of
Tracleer, which is regarded as a successful biotechnology company.

· Tracleer,
the first oral drug to be approved for PAH, is also the first drug in its
class, known as endothelin receptor antagonists. Tracleer was approved in December 2001
in the United States and May 2002 in Europe. Tracleer is marketed by
Actelion Ltd worldwide. As an oral therapy, Tracleer is a very convenient
therapy; and

· Revatio
was approved in June 2005 in the United States. Revatio is also an oral
therapy and is marketed by Pfizer, Inc. Revatio is a different formulation
of the very successful drug Viagra and is the first drug in its class, known as
PDE-5 inhibitors, to be approved for PAH.

Doctors may reduce the dose of Remodulin they give to
their patients if they prescribe our competitors’ products in combination with
Remodulin. In addition, certain of our competitors’ products are less invasive
than Remodulin and the use of these products may delay or prevent initiation of
Remodulin therapy. Finally, as a result of Actelion’s recent acquisition of
CoTherix, Actelion now controls two of the five therapies approved for PAH in
the United States. In addition to reducing competition through this
consolidation, because Actelion is dominant in the sales and marketing of oral
PAH therapies, it may bring its considerable influence with prescribers to the
sales and marketing of Ventavis.

Many companies are
marketing and developing products containing arginine that compete with our
product line. Many local and regional competitors and a few national
competitors provide cardiac Holter and event monitoring services and systems
that compete with our telemedicine products. A number of drug companies are
pursuing treatments for ovarian and other cancers and hepatitis that will
compete with any products we may develop from our immunotherapeutic monoclonal
antibody platform and glycobiology antiviral agents’ platform.

**Discoveries or
developments of new technologies by others may make our products obsolete or
less useful.**

Other companies may make
discoveries or introduce new products that render all or some of our technologies
and products obsolete or not commercially viable. Researchers are continually
making new discoveries that may lead to new technologies that treat the
diseases for which our products are intended. In addition, alternative
approaches to treating chronic diseases, such as gene therapy, may make our
products obsolete or noncompetitive. Other investigational therapies for PAH
could be used in combination with Remodulin. If this happens, doctors may
reduce the dose of Remodulin they give to their patients. This could result in
less Remodulin being used by such patients and, hence, reduced sales of
Remodulin.

34

  
* * *

  
**We are aware of investigational products being
developed for the treatment of PAH with which our products may have to compete.**

Remodulin and our other
treprostinil-based products may have to compete with investigational products
currently being developed by other companies, including:

· Sitaxsentan
(Thelin) is being developed by Encysive Pharmaceuticals, Inc. (Encysive)
worldwide for the treatment of PAH. Encysive has completed testing of Thelin,
an oral tablet, and, based on favorable results, has filed for approval with
the FDA in the United States. In July 2006, Encysive announced that the
FDA determined that Thelin was approvable with one substantive item remaining
unresolved. In December 2006, Encysive announced that the FDA had accepted
for review its complete response to its FDA’s July 2006 approvable letter.
In August 2006, Encysive announced that Thelin received marketing
authorization in all nations in the European Union. If approved in the United
States, Thelin would become the second drug available in the class known as
endothelin receptor antagonists;

· Ambrisentan
is being developed by Gilead Sciences, Inc. for the treatment of PAH.
Ambrisentan, an oral tablet, has completed pivotal clinical testing and is also
an endothelin receptor antagonist. In February 2007, Gilead Sciences
announced that its New Dug Application for ambrisentan was accepted by the FDA
for six-month priority review. Gilead Sciences is regarded as a large and
successful biotechnology company in the United States;

· Cialis
is an approved oral treatment for erectile dysfunction and is currently
marketed by Lilly ICOS LLC, a joint venture of Eli Lilly and Company and ICOS Corporation.
Cialis is currently being studied in patients with PAH, and is in the same
class of drugs as Revatio. On October 17, 2006, ICOS Corporation announced
that it signed a merger agreement to be acquired by Eli Lilly and Company,
which is a large and successful pharmaceutical company in the United States;

· Gleevec
is an approved oral treatment for chronic myeloid leukemia (a cancer of the
blood and bone marrow) and is currently marketed by Novartis Pharmaceuticals
Corporation. Recently, researchers experienced in PAH have conducted studies of
Gleevec and believe that it may be effective in treating PAH;

· Aviptadil,
an inhaled formulation of vasoactive intestinal peptide, is being developed by
mondoBIOTECH Holding SA, for the treatment of PAH. In September 2006,
mondoBIOTECH announced that it had outlicensed Aviptadil for the treatment of
PAH to Biogen-Idec Inc., which is regarded as a large and successful
biotechnology company in the United States;

· PRX-08066,
a serotonin receptor 5-HT2B antagonist, is being developed by Predix
Pharmaceuticals Holdings, Inc., as an oral tablet for the treatment of
PAH. Two Phase I clinical trials of PRX-08066 are being conducted in
healthy volunteers;

· PulmoLAR™
is being developed by PR Pharmaceuticals, Inc. It is a once-a-month
injectible therapy which contains a metabolite of estradiol and has been shown
in animal and cell models to address certain processes associated with PAH;

· Oral
and inhaled formulations of Fasudil, a rho-kinase inhibitor, are being
developed by Actelion Ltd for the treatment of PAH. Fasudil is currently
approved in Japan as an intravenous drug to treat a disease unrelated to PAH;

· Sorafenib,
marketed by Bayer AG as Nexavar ® for advanced renal cell cancer, is a small
molecule which inhibits Raf kinase and which may interfere with the thickening
of blood vessel walls associated with PAH. A Phase 1 clinical trial in PAH has
been proposed; and

35

  
* * *

  
· Recombinant
Elafin, being developed by PROTEO Biotech AG, is a protein that is produced
naturally in the body that may inhibit inflammatory reactions. In February 2007,
Elafin recently was granted orphan product status in the European Union for the
treatment of PAH and chronic thromboembolic pulmonary hypertension.

There may be additional
drugs in development for PAH and there may also be currently approved drugs
that may be effective in treating the disease. If any of these drugs in
development or other currently approved drugs are used to treat PAH, sales of
Remodulin may fall.

**If third-party payers will not reimburse patients for
our drug products or if third-party payers limit the amount of reimbursement,
our sales will suffer.**

Our commercial success
depends heavily on third-party payers, such as Medicare, Medicaid and private
insurance companies, agreeing to reimburse patients for the costs of our
pharmaceutical products. These third-party payers frequently challenge the
pricing of new and expensive drugs, and it may be difficult for distributors
selling Remodulin to obtain reimbursement from these payers. Remodulin and the
associated infusion pump and supplies are very expensive. We believe our
investigational products, if approved, will also be very expensive. Presently,
most third-party payers, including Medicare and Medicaid, reimburse patients
for the cost of Remodulin therapy. In the past, Medicare has not reimbursed the
full cost of the therapy for some patients. Beginning on January 1, 2007,
the Medicare Modernization Act requires that we and the Centers for Medicare
and Medicaid Services negotiate a new price for Remodulin. Third-party payers
may not approve our new products for reimbursement or may not continue to
approve Remodulin for reimbursement, or may seek to reduce the amount of
reimbursement for Remodulin based on changes in pricing of other therapies for
PAH, including possible generic formulations of other approved therapies, such
as Flolan, which may be sold in generic form beginning in May 2007. If
third-party payers do not approve a product of ours for reimbursement or limit
the amount of reimbursement, sales will suffer, as patients could opt for a
competing product that is approved for reimbursement.

**We rely on third parties to develop, market,
distribute and sell most of our products and those third parties may not
perform.**

We are currently marketing products in three of our
five therapeutic platforms: Remodulin in our prostacyclin analog platform,
products in our arginine formulations platform, and CardioPAL ® cardiac event monitors and Holter monitors in
our telemedicine platform. We do not have the ability to independently conduct
clinical studies, obtain regulatory approvals, market, distribute or sell most
of our products and intend to rely substantially on experienced third parties
to perform all of those functions. We may not locate acceptable contractors or
enter into favorable agreements with them. If third parties do not successfully
carry out their contractual duties or meet expected deadlines, we might not be
able to obtain marketing approvals and sell our products.

Until November 14, 2006, Medtronic MiniMed was
our exclusive partner for the subcutaneous delivery of Remodulin using the
MiniMed microinfusion device for PAH. Medtronic had advised us that it intended
to discontinue making infusion pumps for subcutaneous delivery of Remodulin
after first giving us and our distributors the opportunity to purchase desired
quantities. On November 14, 2006, we mutually agreed with MiniMed to
terminate our contract. We relied on Medtronic MiniMed’s experience, expertise
and performance in supplying the infusion pumps. Any disruption in the supply
to PAH patients of infusion devices could delay or prevent patients from
initiating or continuing Remodulin therapy, which could adversely affect our
revenues. Doctors and patients may not be able to obtain acceptable substitute
delivery devices to replace the MiniMed microinfusion devises when the
available supply held by our distributors has been depleted.

36

  
* * *

  
Similarly, we rely on Accredo Therapeutics, Inc.
(a wholly-owned subsidiary of Medco Health Solutions, Inc.), CuraScript (a
wholly-owned subsidiary of Express Scripts, Inc. and formerly Priority
Healthcare Corporation) and Caremark, Inc. (which has merged with CVS
Corporation) to market, distribute, and sell Remodulin in the United States.
Accredo, CuraScript and Caremark are also responsible for convincing
third-party payers to reimburse patients for the cost of Remodulin, which is
very expensive. If our distribution partners and contractors do not achieve
acceptable profit margins, they may not continue to distribute our products. If
our distribution partners in the United States and internationally are
unsuccessful in their efforts, our revenues will suffer.

During 2005 and early
2007, all of our Remodulin distributors in the United States were sold to
larger companies. When these distributors were independently managed, the
Remodulin franchise was a more significant business to them, because they were
much smaller. As divisions or subsidiaries of much larger companies, however,
Remodulin could be much less significant to these distributors. There can be no
assurance that a merger among our distributors will not adversely affect
Remodulin distribution. In addition, we have been informed that, effective January 1,
2007, Accredo is the exclusive U.S. distributor for Flolan. It is possible that
our distributors may devote fewer resources to the distribution of Remodulin.
If so, this may negatively impact our sales.

**If we cannot maintain regulatory approvals for our
products, we cannot sell those products and our revenues will suffer.**

The process of obtaining and maintaining regulatory
approvals for new drugs is lengthy, expensive and uncertain. The manufacture,
distribution, advertising and marketing of these products are subject to
extensive regulation. Any new product approvals we receive in the future could
include significant restrictions on the use or marketing of the product.
Product approvals, if granted, can be withdrawn for failure to comply with
regulatory requirements, including those relating to misleading advertising or
upon the occurrence of adverse events following commercial introduction of the
products. We received one warning letter from the FDA related to advertising in
2005, which was resolved satisfactorily.

We rely heavily on sales
of Remodulin. During the three months ended March 31, 2007, our Remodulin
sales accounted for 95% of our total revenues. If approvals are withdrawn for
Remodulin or any other product, we cannot sell that product and our revenues
will suffer. In addition, if product approvals are withdrawn, governmental
authorities could seize our products or force us to recall our products.

**Our products may
not be commercially successful because physicians and patients may not accept
them.**

Even if regulatory
authorities approve our products, they may not be commercially successful. We
expect that most of our products, including Remodulin, which is already
approved by the FDA, will be very expensive. Patient acceptance of and demand
for our products will depend largely on the following factors:

· Acceptance
by physicians and patients of our products as safe and effective therapies;

· Willingness
of payers to reimburse and the level of reimbursement of drug and treatment
costs by third-party payers such as Medicare, Medicaid and private insurance
companies;

· Safety,
efficacy, pricing and convenience of alternative products;

· Convenience
and ease of administration of our products; and

· Prevalence and severity of
side effects associated with our products, including the infusion site pain and
reaction associated with the use of subcutaneous Remodulin and the risk of line
infections or sepsis associated with the use of intravenous Remodulin.

37  
* * *  
**Reports
of side effects, such as sepsis, associated with intravenous Remodulin could
cause physicians and patients to not accept Remodulin or to cease to use
Remodulin in favor of alternative treatments.**

Sepsis is a serious and
potentially life-threatening infection of the bloodstream caused by a wide
variety of bacteria. Intravenous prostacyclins are infused continuously through
a catheter placed in patients’ chests, and sepsis is an expected consequence of
this type of delivery. As a result, sepsis is included as a risk in both the
Remodulin and Flolan package inserts. The Flolan package insert specifically
documents the risk rate of sepsis at 0.32 events per patient per year, meaning
one patient out of every three taking the drug is expected to have a sepsis
infection each year. Or, each patient on Flolan is expected to have one sepsis
infection every three years. The Remodulin package insert notes that two out of
38 patients experienced catheter-related infections in an open-label 12-week
study, but does not provide any data relating to expected risk rate. Historical
data on intravenous prostacyclin administration does not identify the specific
types of bacteria responsible for these infections.

In February 2007, the
Scientific Leadership Committee (SLC) of the Pulmonary Hypertension Association
announced new guidance relating to the treatment of PAH patients on long-term
intravenous therapy. The SLC guidance was issued in response to the release of
a slide presentation prepared by researchers with the U.S. Centers for Disease
Control and Prevention (CDC) entitled “ _Bloodstream infections
among patients treated with intravenous epoprostenol and intravenous
treprostinil for pulmonary arterial hypertension, United States 2004–2006_ ”.
These slides accompanied a presentation to the SLC and were subsequently
published as a report in the CDC’s _Morbidity and Mortality
Weekly Report_ on March 2, 2007. The slides and report were
prepared in connection with a CDC retrospective inquiry at seven centers
regarding a report of increased blood stream infections, particularly
gram-negative blood stream infections, among PAH patients treated with
intravenous Remodulin as compared to intravenous Flolan. The SLC guidance
statement noted that the CDC observations were hypothesis-generating and did
not permit definitive or specific conclusions. The SLC reminded physicians of
the need to be aware of the range of possible gram negative and gram positive
infectious organisms in patients with long-term central catheters and to treat
them appropriately. In response to the SLC guidance statement, we are planning
to commence a multi-center, multi-national, multi-year and multi-agent
prospective study to scientifically test the hypothesis of whether there are
differences in the risk of sepsis and sepsis sub-types among
parenterally-delivered prostanoids. We anticipate this study to enroll several
hundred patients, which enrollment could commence later this year. We also plan
to coordinate a working group with the Pulmonary Hypertension Association and
physicians and nurses, along with its network of specialty distributors and
home health care providers, to develop unified best practice recommendations
related to the chronic administration of IV prostanoids via central venous
catheters. Finally, we have submitted revised Remodulin package labeling to
more fully describe the known infection risk and appropriate technique that
should be practiced when preparing and administering Remodulin intravenously.

Although the risk of
sepsis is currently included in the Remodulin label, and the occurrence of
sepsis is familiar to physicians who treat PAH patients, concern about
bloodstream infections may adversely impact physicians’ prescribing practices
in regard to Remodulin. If that occurs, Remodulin sales could suffer and our
profitability could be adversely impacted.

**We
have limited experience with production and manufacturing and depend on third
parties, who may not perform, to synthesize and manufacture many of our
products.**

Prior to our 1999
acquisition of SynQuest, Inc., a company that manufactured treprostinil,
the bulk active ingredient in Remodulin, we had no experience with
manufacturing. Presently, commercial treprostinil is being manufactured only by
us with reliance on third parties for certain raw and advanced intermediate
materials.

The OvaRex material that
is currently being used in our studies was made by a contract manufacturer and
will expire in early 2008. In 2007, we plan to make the OvaRex antibody for the
first time ourselves, in

38

  
* * *

  
our new Silver
Spring laboratory. Biological drugs are generally the most complex drugs to
manufacture, and we have never attempted to manufacture them in-house before.
After we manufacture our own OvaRex, we must then demonstrate that it is
comparable to the drug used in the Phase III clinical trials. Even if our
OvaRex trials are successful, we will not be able to obtain approval for OvaRex
unless we can demonstrate that the OvaRex antibody we manufacture is comparable
to the drug used in the trials. If we cannot demonstrate the comparability
prior to the expiration date, then we may have to repeat the OvaRex trials with
the new drug that we manufacture. Although our laboratory is completed and is
occupied by our personnel, we are still performing test runs and finalizing
procedures for our developmental production runs prior to our process scale-up
and validation production runs of OvaRex. In addition, we are working with our
builders to complete or repair certain aspects of our laboratory. We have
commenced process scale-up and are pursuing FDA validation production of this
facility.

We rely on third parties
for the manufacture of all our products other than treprostinil. We rely on
Baxter Healthcare Corporation for the formulation of Remodulin from treprostinil.
We rely on Cardinal Health, Inc. for conducting stability studies on
Remodulin, formulating treprostinil for inhalation use, formulating tablets for
the oral clinical trials, and analyzing other products that we are developing.
We rely on MSI of Central Florida, Inc. to manufacture our telemedicine
devices. We rely on other manufacturers to make our investigational drugs and
devices for use in trials.

Although there are few
companies that could replace each of these suppliers, we believe that other
suppliers could provide similar services and materials. A change in suppliers,
however, could cause a delay in distribution of Remodulin and other products,
and in the conduct of clinical trials and commercial launch, which would
adversely affect our research and development efforts and future sales efforts.

Our
manufacturing strategy presents the following risks:

· The
manufacturing processes for some of our products have not been tested in
quantities needed for commercial sales;

· Delays
in scale-up to commercial quantities and process validation could delay
clinical studies, regulatory submissions and commercialization of our products;

· A
long lead time is needed to manufacture treprostinil and Remodulin, and the
manufacturing process is complex;

· We
and the manufacturers and formulators of our products are subject to the FDA’s
and international drug regulatory authorities’ good manufacturing practices
regulations and similar international standards, and although we control
compliance issues with respect to synthesis and manufacturing conducted
internally, we do not have control over compliance with these regulations by
our third-party manufacturers;

· Even
if we and the manufacturers and formulators of our products comply with the FDA’s
and international drug regulatory authorities’ good manufacturing practices
regulations and similar international standards, the sterility and quality of
the products being manufactured and formulated may be deficient. If this
occurred, such products would not be available for sale or use;

· If
we have to change to another manufacturing or formulation contractor for any
reason or abandon our own manufacturing operations, the FDA and international
drug regulators would require new testing and compliance inspections, and the
new manufacturer would have to be educated in the processes necessary for the
validation and production of the affected product. We were recently notified
that Cardinal Health intends to sell its formulation business and there can be
no assurances that a purchaser of this business will continue formulating
treprostinil for both our inhalation and oral clinical trials;

39

  
* * *

  
· We
may not be able to develop or commercialize our products, other than Remodulin,
as planned or at all and may have to rely solely on internal manufacturing
capacity;

· We
are transferring our entire drug laboratory operations to the Silver Spring,
Maryland facility we recently built, and such transfer could result in
manufacturing inefficiencies or delays because the building, equipment and many
products. Additionally, the FDA and international drug regulators will require
new testing and compliance inspections for approval of the facility, and this
could result in delays;

· The
supply of raw and advanced intermediate materials and components used in the
manufacture and packaging of treprostinil, Remodulin and other products may be
interrupted, which could delay the manufacture and subsequent sale of such products.
Any proposed substitute materials and components are subject to approval by the
FDA and international drug regulators before any manufactured product can be
sold. The timing of such FDA and international drug regulatory approval is
difficult to predict and approvals may not be timely obtained;

· Without
substantial experience in operating our new production facility, we may not be
able to successfully produce treprostinil without a third-party manufacturer;
and

· We
may not have intellectual property rights, or may have to share intellectual
property rights, to many of the improvements in the manufacturing processes or
new manufacturing processes for our new products.

Any of these factors could
delay clinical studies or commercialization of our products, entail higher
costs, and result in our inability to effectively sell our products.

**If
our products fail in clinical studies, we will not be able to obtain or
maintain FDA and international approvals and will not be able to sell those
products.**

In order to sell our
pharmaceutical products, we must receive regulatory approvals. To obtain those
approvals, we must conduct clinical studies demonstrating that the drug
product, including its delivery mechanism, is safe and effective. If we cannot
obtain approval from the FDA and international drug regulators for a product,
that product cannot be sold, and our revenues will suffer.

We are conducting a Phase
III clinical study of Viveta, an inhaled formulation of treprostinil, and Phase
II/III clinical studies of an oral formulation of treprostinil. Our lead
glycobiology antiviral agent, UT-231B, completed a Phase II,
proof-of-concept study in late 2004. In that trial, UT-231B did not
demonstrate efficacy against hepatitis C in a population of patients that
previously failed conventional treatments. We are now conducting preclinical
testing of additional glycobiology drug candidates. We are also currently
conducting two identical Phase III pivotal studies of OvaRex for the treatment
of advanced ovarian cancer. We are still completing or planning pre-clinical
studies for our other products.

In the past, several of
our product candidates have failed or been discontinued at various stages in
the product development process, including, but not limited to: immediate release
beraprost, which failed in Phase III testing for early stage peripheral
vascular disease; Ketotop, which failed in Phase III testing for osteoarthritis
of the knee; and UT-77, which failed in Phase II testing for chronic
obstructive pulmonary disease. Also, the length of time that it takes for us to
complete clinical trials and obtain regulatory approval for product marketing
has in the past varied by product and by the intended use of a product. We
expect that this will likely be the case with future product candidates and we
cannot predict the length of time to complete necessary clinical trials and
obtain regulatory approval.

Our
ongoing and planned clinical studies might be delayed or halted for various
reasons, including:

· The
drug is not effective, or physicians think that the drug is not effective;

· Patients
do not enroll in the studies at the rate we expect;

40

  
* * *

  
· Patients
experience severe side effects during treatment;

· Other
investigational or approved therapies are viewed as more effective or convenient
by physicians or patients;

· Patients
die during the clinical study because their disease is too advanced or because
they experience medical problems that are not related to the drug being
studied;

· Drug
supplies are not available or suitable for use in the studies; and

· The
results of preclinical testing cause delays in clinical trials.

In addition, the FDA and
international regulatory authorities have substantial discretion in the
approval process. The FDA and international regulatory authorities may not
agree that we have demonstrated that our products are safe and effective.

**Our
corporate compliance program cannot guarantee that we are in compliance with
all potentially applicable federal, state and international regulations.**

The development,
manufacture, distribution, pricing, sales, marketing, and reimbursement of our
products, together with our general operations, are subject to extensive
federal, state and international regulation. While we have developed and
instituted corporate compliance programs, we cannot ensure that we or our
employees are or will be in compliance with all potentially applicable federal,
state and international regulations. If we fail to comply with any of these
regulations, a range of actions could result, including, but not limited to,
the termination of clinical trials, the failure to approve a product candidate,
restrictions on our products or manufacturing processes, including withdrawal
of our products from the market, significant fines, exclusion from government
healthcare programs, or other sanctions or litigation.

**If
the licenses, assignments and alliance agreements we depend on are breached or
terminated, we would lose our right to develop and sell the products covered by
the licenses, assignments and alliance agreements.**

Our
business depends upon the acquisition, assignment and license of drugs and
other products which have been discovered and initially developed by others,
including Remodulin and all of the other products in the prostacyclin platform,
all of the products in the immunotherapeutic monoclonal antibody platform, all
of the products in the glycobiology antiviral agents platform, and all arginine
based products. Under our product license agreements, we are granted certain
rights to existing intellectual property owned by third parties subject to the
terms of each license agreement, whereas assignment agreements transfer all
right, title and ownership of the intellectual property to us, subject to the
terms of each assignment agreement. We have also obtained licenses to other
third-party technology to conduct our business. In addition, we may be required
to obtain licenses to other third-party technology to commercialize our
early-stage products. This dependence has the following risks:

· We
may not be able to obtain future licenses, assignments and agreements at a
reasonable cost or at all;

· If
any of our licenses or assignments are terminated, we will lose our rights to
develop and market the products covered by such licenses or assignments;

· The
licenses and assignments that we hold generally provide for termination by the
licensor or assignor in the event we breach the license or assignment
agreement, including failing to pay royalties and other fees on a timely basis;

· In
the event that GlaxoSmithKline terminates its assignment agreement or Pfizer
terminates its license agreement, we will have no further rights to utilize the
assigned patents or trade secrets to develop and commercialize Remodulin. For
the three months ended March 31, 2007, sales of

41

  
* * *

  
Remodulin accounted
for approximately 95% of our total revenues. GlaxoSmithKline or Pfizer could
seek to terminate the assignment or license, respectively, in the event that we
fail to pay royalties based on sales of Remodulin; and

· If licensors fail to
maintain the intellectual property licensed or assigned to us as required by
most of our license and assignment agreements, we may lose our rights to
develop and market some or all of our products and may be forced to incur
substantial additional costs to maintain the intellectual property ourselves or
force the licensor or assignor to do so.

**Certain
license and assignment agreements relating to our products may restrict our
ability to develop products in certain countries and/or for particular diseases
and impose other restrictions on our freedom to develop and market our
products.**

When we acquire, license
or receive assignments of drugs and other products that have been discovered
and initially developed by others, we may receive rights only to develop such
drugs or products in certain territories and not throughout the world. For
example, we do not have the right to market OvaRex and all our other monoclonal
antibody immunotherapies for sale in most of Europe and the Middle East, and we
only have the rights to market beraprost-MR for sale in North America and
Europe.

In addition, provisions in
our license and assignment agreements impose other restrictions on our freedom
to develop and market our products. For example, in assigning Remodulin to us,
GlaxoSmithKline retained an exclusive option and right of first refusal to
negotiate a license agreement with us if we ever decide to license any aspect
of the commercialization of Remodulin anywhere in the world. Similarly, in
connection with its licenses of beraprost-MR to us, Toray obtained a right of
first refusal from us to develop and sell in Japan up to two compounds that we
develop. We also agreed to provisions establishing a conditional restricted
non-competition clause in Toray’s favor, giving them the right to be our
exclusive provider of beraprost-MR and requiring that we make certain minimum
annual sales in order to maintain our exclusive rights to beraprost-MR. The
restrictions that we have accepted in our license and assignment agreements
affect our freedom to develop and market our products in the future.

**If
our, or our suppliers’, patent and other intellectual property protection is
inadequate, our sales and profits could suffer or competitors could force our
products completely out of the market.**

Our United States patent
for the method of treating PAH with Remodulin is currently set to expire in
October 2014. The patent for OvaRex and its method of use are the subject
of a combination of issued patents and pending applications in the United
States and around the world. The issued patents for OvaRex have expiration
dates ranging from 2016 to 2022. We believe that some of the patents to which
we have rights may be eligible for extensions of up to five years based upon
patent term restoration procedures in Europe and under the Hatch-Waxman Act in
the United States. Competitors may develop products based on the same active
ingredients as our products, including Remodulin, and market those products
after the patents expire, or may design around our existing patents. If this
happens, our sales would suffer and our profits could be severely impacted. In
addition, if our suppliers’ intellectual property protection is inadequate, our
sales and profits could be adversely affected.

Patents may be issued to
others that prevent the manufacture or sale of our products. We may have to
license those patents and pay significant fees or royalties to the owners of
the patents in order to keep marketing our products. This would cause profits
to suffer. We have been granted patents in the United States for the synthesis
of Remodulin, but patent applications that have been or may be filed by us may
not result in the issuance of additional patents. The scope of any patent
issued may not be sufficient to protect our technology. The laws of
international jurisdictions in which we intend to sell our products may not
protect our rights to the same extent as the laws of the United States.

42  
* * *  
In addition to patent protection, we also rely on
trade secrets, proprietary know-how and technology advances. We enter into
confidentiality agreements with our employees and others, but these agreements
may not be effective in protecting our proprietary information. Others may
independently develop substantially equivalent proprietary information or
obtain access to our know-how.

Litigation, which is very
expensive, may be necessary to enforce or defend our patents or proprietary
rights and may not end favorably for us. While we have recently settled pending
litigation against two parties related to our arginine patents, we may in the
future choose to initiate litigation against other parties who we come to
believe have violated our patents or other proprietary rights. If such
litigation is unsuccessful or if the patents are invalidated or canceled, we
may have to write off the related intangible assets which could significantly
reduce our earnings. Any of our licenses, patents or other intellectual property
may be challenged, invalidated, canceled, infringed or circumvented and may not
provide any competitive advantage to us.

**If our highly
qualified management and technical personnel leave us, our business may suffer.**

We are dependent on our
current management, particularly our founder and Chief Executive Officer,
Martine Rothblatt, Ph.D.; our President and Chief Operating Officer, Roger
Jeffs, Ph.D.; our Chief Financial Officer and Treasurer, John Ferrari; and our
Executive Vice President for Strategic Planning, General Counsel and Corporate
Secretary, Paul Mahon. While these individuals are employed by us pursuant to
multi-year employment agreements, employment agreements do not ensure the
continued retention of employees. We do not maintain key person life insurance
on these officers, although we do incentivize them to remain employed by us
until at least age 60 through our Supplemental Executive Retirement Plan. Our
success will depend in part on retaining the services of our existing
management and key personnel and attracting and retaining new highly qualified
personnel. Few individuals possess expertise in the field of cardiovascular
medicine, infectious disease and oncology, and competition for qualified
management and personnel is intense.

**We may not have adequate insurance and may have
substantial exposure to payment of product liability claims.**

The testing, manufacture,
marketing, and sale of human drugs involve product liability risks. Although we
currently have product liability insurance covering claims up to $20 million
per occurrence and in the aggregate for our products, we may not be able to
maintain this product liability insurance at an acceptable cost, if at all. In
addition, this insurance may not provide adequate coverage against potential
losses. If claims or losses exceed our liability insurance coverage, we may go
out of business.

**We may not have, or may have to share rights to,
future inventions arising from our license, assignment and alliance agreements
and may lose potential profits or savings.**

Pursuant to our agreements
with certain business partners, any new inventions or intellectual properties
that arise from our activities will be owned jointly by us and these partners.
If we do not have rights to new developments or inventions that arise during
the terms of these agreements, or we have to share the rights with others, we
may lose some or all of the benefit of these new rights, which may mean a loss
of future profits or savings generated from improved technology.

**If we need
additional financing and cannot obtain it, product development and sales may be
limited.**

We may need to spend more
money than currently expected because we may need to change our product
development plans or product offerings to address difficulties with clinical
studies, to prepare for commercial sales or to continue sales of Remodulin. We
may not be able to obtain additional funds on commercially reasonable terms or
at all. If additional funds are not available, we may be compelled to

43

  
* * *

  
delay
clinical studies, curtail operations or obtain funds through collaborative
arrangements that may require us to relinquish rights to certain products or
potential markets.

**Our activities involve hazardous materials, and
improper handling of these materials could expose us to significant
liabilities.**

Our research and
development and manufacturing activities involve the controlled use of
chemicals and hazardous materials and we are expanding these activities to new
locations. As a consequence, we are subject to numerous federal, state, and
local environmental and safety laws and regulations, including those governing
the management, storage and disposal of hazardous materials. We may be required
to incur significant costs in order to comply with current or future environmental
laws and regulations, and substantial fines and penalties for failure to comply
with those laws and regulations. While we believe that we are currently in
substantial compliance with laws and regulations governing these materials, the
risk of accidental contamination or injury from these materials cannot be
eliminated. In the event of such an accident, we could be liable for civil
damages that result or for costs associated with the cleanup of any release of
hazardous materials, which could be substantial. Any such liability could
exceed our resources and could have a material adverse effect on our business,
financial condition and results of operations.

**Risks Related to
Our Common Stock**

**Our stock price
could be volatile and could decline.**

The
market prices for securities of drug and biotechnology companies are highly
volatile, and there are significant price and volume fluctuations in the market
that may be unrelated to particular companies’ operating performances. The
table below sets forth the high and low closing prices for our common stock for
the periods indicated:

| | |**High** | |**Low** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|January 1,
2005 – December 31, 2005 | |$ |77\.82 | |$ |41\.37 | |
|January 1,
2006 – December 31, 2006 | |$ |71\.33 | |$ |47\.96 | |
|January 1, 2007 – March 31,
2007 | |$ |59\.13 | |$ |47\.87 | |

Our stock price
could decline suddenly due to the following factors, among others:

· Quarterly
and annual financial and operating results;

· Failure
to meet estimates or expectations of securities analysts or our projections;

· The
pace of enrollment in and the results of clinical trials;

· Physician,
patient, investor or public concerns as to the efficacy and/or safety of
products marketed or being developed by us or by others;

· Changes
in or new legislation and regulations affecting reimbursement of Remodulin by
Medicare or Medicaid and changes in reimbursement policies of private health
insurance companies;

· Announcements
by us or others of technological innovations or new products or announcements
regarding our existing products;

· Developments
in patent or other proprietary rights;

· Future
sales of substantial amounts of common stock by us or our existing
stockholders;

· Future
sales of common stock by our directors and officers;

· Failure
to maintain approvals to sell Remodulin;

44

  
* * *

  
· The
adoption of significant short positions in our common stock by hedge funds or
other significant investors or the accumulation of our stock by hedge funds or
other institutional investors with investment strategies that may lead to
short-term holdings;

· Timing
and outcome of additional regulatory approvals; and

· General market conditions.

**Future sales of
shares of our common stock may depress our stock price.**

If we issue common stock to raise capital, or our
stockholders transfer their ownership of our common stock or sell a substantial
number of shares of common stock in the public market, or investors become
concerned that substantial sales might occur, the market price of our common
stock could decrease. Three of our four executive officers have announced their
adoption of 10b5-1 prearranged trading plans. In accordance with these
plans, these executives periodically sell a specified number of our shares of
common stock either owned by them or acquired through the exercise of stock
options. However, our executives and directors may choose to sell additional
shares outside of 10b5-1 trading plans and one executive and five
directors have done so. A decrease in our common stock price could make it
difficult for us to raise capital by selling stock or to pay for acquisitions using
stock. To the extent outstanding options are exercised or additional shares of
capital stock are issued, existing stockholders may incur additional dilution.

Furthermore, the
conversion of some or all of our 0.50% convertible secured notes due 2011 (Convertible
Notes) after our stock price reaches $105.67 per share will dilute the
ownership interests of our existing stockholders. We have filed a resale
registration statement covering sales of such shares. The Convertible Notes
initially are convertible into an aggregate of 3.3 million shares of our common
stock. Any sales in the public market of our common stock issuable upon such
conversion could adversely affect prevailing market prices of our common stock.
In addition, the existence of the Convertible Notes may
encourage short selling by market participants because the conversion of the
Convertible Notes could depress the price of our
common stock.

**The Convertible Note Purchase Call Option and call
warrant transactions we entered into in connection with the sale of the
Convertible Notes may affect the trading price of our common stock.**

In connection with the
issuance of the Convertible Notes, we entered into a privately-negotiated
convertible note hedge transaction with Deutsche Bank AG London, which is
expected to reduce the potential dilution to our common stock upon any
conversion of the Convertible Notes. We also entered into a warrant transaction
with Deutsche Bank AG London with respect to our common stock pursuant to which
we may issue shares of our common stock. In connection with hedging these
transactions, Deutsche Bank AG London or its affiliates were expected to enter
into various over-the-counter derivative transactions with respect to our
common stock at, and possibly after, the pricing of the Convertible Notes and may have purchased or may purchase shares of our common
stock in secondary market transactions following the pricing of the Convertible
Notes. These activities could have had, or could have, the effect of increasing
the price of our common stock. Deutsche Bank AG London or its affiliates are
likely to modify their hedge positions from time to time prior to conversion or
maturity of the Convertible Notes by purchasing
and selling shares of our common stock, other of our securities or other
instruments it may wish to use in connection with such hedging. The effect, if
any, of any of these transactions and activities on the market price of our
common stock or the Convertible Notes will depend in
part on market conditions and cannot be ascertained at this time, but any of
these activities could adversely affect the value of our common stock
(including during any period used to determine the amount of consideration
deliverable upon conversion of the Convertible Notes).

45

  
* * *

  
**The fundamental change purchase feature of the
Convertible Notes may delay or prevent an otherwise beneficial attempt to take
over our company.**

The terms of the
Convertible Notes require us to purchase the
Convertible Notes for cash in the event of a
fundamental change. A takeover of our company would trigger the requirement
that we purchase the Convertible Notes. This may have the effect of delaying or
preventing a takeover of our company that would otherwise be beneficial to
investors.

**Provisions of Delaware law and our certificate of
incorporation, by-laws and shareholder rights plan could prevent or delay a
change of control or change in management that could be beneficial to us and
our public stockholders.**

Certain provisions
of Delaware law and our certificate of incorporation, by-laws and shareholder
rights plan may prevent, delay or discourage:

· A
merger, tender offer or proxy contest;

· The
assumption of control by a holder of a large block of our securities; and

· The
replacement or removal of current management by our stockholders.

For example, our
certificate of incorporation divides the board of directors into three classes,
with members of each class to be elected for staggered three-year terms. This
provision may make it more difficult for stockholders to change the majority of
directors and may hinder accumulations of large blocks of common stock by
limiting the voting power of such blocks. This may further result in
discouraging a change of control or change in current management.

**We will need cash to pay at least a portion of the
conversion value of the Convertible Notes, as required by the indenture
governing the notes.**

At least a portion of the
repayment of the Convertible Notes will be required to be made in cash. Our
product development plans and product offerings could be negatively impacted if
we do not have sufficient financial resources, or are not able to arrange
suitable financing, to pay required amounts upon conversion or tender of the
notes and fund our operations.

**Our existing directors and executive officers own a
substantial block of our stock and might be able to influence the outcome of
matters requiring stockholder approval.**

Our directors and named
executive officers beneficially owned approximately 10.6% of our outstanding
common stock as of March 31, 2007, including stock options that could be
exercised by those directors and executive officers within 60 days of that
date. Accordingly, these stockholders as a group might be able to influence the
outcome of matters requiring approval by our stockholders, including the
election of our directors. Such stockholder influence could delay or prevent a
change of control with respect to us.

**If stockholders do not receive dividends, stockholders
must rely on stock appreciation for any return on their investment in us.**

We have never declared or
paid cash dividends on any of our capital stock. We currently intend to retain
our earnings for future growth and therefore do not anticipate paying cash
dividends in the future.

46

  
* * *

  
**Item 2.** Unregistered
Sales of Equity Securities and use of Proceeds

**Sales of
Unregistered Equity Securities**

On March 17, 2007, we
issued in a private placement in reliance on the exemption from registration
provided under Regulation D  under the
Securities Act of 1933, 200,000 shares of our common stock to Toray in exchange
for the cancellation of Toray’s then-existing option to purchase 500,000 shares
of our common stock. Toray has the right to request that we repurchase the
newly-issued 200,000 shares of common stock upon thirty-days prior notice at
the price of $54.41 per share, which is the average closing price of our stock
between January 11, 2007 and February 23, 2007. Based on the average
closing price of our stock for the two trading days prior to and the two
trading days after March 16, 2007, we recognized a research and
development expense of approximately $11.0 million in March 2007 relating
to the issuance of the 200,000 shares, since beraprost-MR has not yet obtained
regulatory approval for commercial sales. In accordance with the provision of
SFAS No. 133, _Accounting for Derivative
Instruments and Hedging Activities_ , and EITF Topic No. D-98, _Classification and Measurement of Redeemable
Securities_ , these shares of stock are reflected in mezzanine equity
as common stock subject to repurchase valued at the repurchase price. If Toray
request that we repurchase these shares, then the value of these shares will
retransferred to a liability account until the repurchase is completed.

**Stock Repurchases**

|**Period** | | | |**Total Number  
of Shares  
Purchased(1)** | |**Average Price  
Paid per Share** | |**Total Number of Shares  
Purchased as Part of  
Publicly Announced  
Program** | |**Maximum Number of  
Shares That May yet be  
Purchased Under the  
Program(1)** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|January 1 – January 31 | | |99,100 | | | |$ |55\.71 | | | |99,100 | | | |2,037,091 | | |
|February 1 –
February 28 | | |147,282 | | | |$ |52\.03 | | | |147,282 | | | |1,889,809 | | |
|March 1 – March 31 | | |978,140 | | | |$ |55\.04 | | | |978,140 | | | |911,669 | | |
|Total | | |1,224,522 | | | |$ |54\.73 | | | |1,224,522 | | | |N/A | | |

* * *

(1) On October 17,
2006, our Board of Directors authorized the repurchase up to 4.0 million shares
prior to October 17, 2008. As of March 31, 2007, 911,669 shares
remained eligible for repurchase under the program.

47  
* * *  
**Item
6\.** Exhibits

|Exhibit No. | |**Description** | | |
| --- | --- | --- | --- | --- |
|12\.1 | |Ratio of Earnings to
Fixed Charges (unaudited) |
|3\.1 | |Amended and
Restated Certificate of Incorporation of the Registrant, incorporated by
reference to Exhibit 3.1 of the Registrant’s Registration Statement on
Form S-1 (Registration No. 333-76409) |
|3\.2 | |Amended and
Restated Bylaws of the Registrant, incorporated by reference to
Exhibit 3.2 of the Registrant’s Registration Statement on Form S-1
(Registration No. 333-76409) |
|10\.1 | |Standard
Form of Agreement between the Registrant and DPR
Construction, Inc., dated March 9, 2007, as amended by Amendment
No. 1, dated April 19, 2007 \*\* |
|12\.1 | |Ratio of Earnings
to Fixed Charges |
|31\.1 | |Certification of
Chief Executive Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
|31\.2 | |Certification of
Chief Financial Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934 |
|32\.1 | |Certification of
Chief Executive Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |
|32\.2 | |Certification of
Chief Financial Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002 |

* * *

\*\* Confidential
treatment has been requested for portions of this document. The omitted
portions of this document have been filed with the Securities and Exchange
Commission.

48  
* * *  
**SIGNATURES**

Pursuant
to the requirements of the Securities Exchange Act of 1934, the registrant has
duly caused this report to be signed on its behalf by the undersigned thereunto
duly authorized.

| |UNITED THERAPEUTICS CORPORATION | |
| --- | --- | --- | --- | --- |
|Date: May 3, 2007 | |/s/ MARTINE A. ROTHBLATT |
| | |By: | |Martine A. Rothblatt |
| | |Title: | |_Chairman and Chief Executive Officer_ |
| | |/s/ JOHN M. FERRARI |
| | |By: | |John M. Ferrari |
| | |Title: | |_Chief Financial Office and Treasurer_ |

49  
* * *