# Medicines for Life

### ®

### United Therapeutics Corporation 2003 Annual Report

# Corporate Profile

Subcutaneous Remodulin ® for PAH

Arginine Supplements

CardioPAL ® and Decipher ® Recorder Services

CardioPAL ® AI\*

Intravenous Remodulin for PAH\*

OvaRex ® for Ovarian Cancer\*

Intermittent Remodulin ® for CLI\*

UT-231B for Hepatitis C\*

BrevaRex ® for Multiple Myeloma\*

Beraprost ® SR for PVD\*

Oral UT-15 for PVD\*

Glycobiology Antiviral Agents\*

OncoRex ® for Various Cancers\*

ProstaRex ® for Prostate Cancer\*

GivaRex ® for Gastrointestinal Cancer\*

Preclinical Phase I Phase II Phase III Commercialized

**\* Investigational Product**

**The successful development of this Product Pipeline is subject to risks and uncertainties such as those described in United Therapeutics'**

**periodic reports filed with the Securities and Exchange Commission.**

**Cardiovascular**

**Oncology**

**Infectious**

**List of Abbreviations**

PAH = pulmonary arterial hypertension

CLI = critical limb ischemia

PVD = peripheral vascular disease

The medical artwork on the cover is a thousand-word picture of what United Therapeutics is all about. We are a cardiovascular company. We have begun the necessary spade-work to one day also offer medicines that combat cancer and infectious diseases. For now, though, our revenue-generating products are all in the field of cardiovascular medicine.

Our lead product and largest revenue earner is Remodulin ® for the treatment of pulmonary arterial hyper- tension. This life-threatening disease results from the pulmonary arteries becoming dysfunctional, causing right heart failure if not adequately treated. In 2002, Remodulin was approved in the United States, Canada and Israel. Significant progress has been made toward approval in Australia, Switzerland and France while other country reviews are in progress. In 2004, we applied for FDA approval for the intravenous use of Remodulin and we are currently in the early stages of developing newer formulations of Remodulin for use in other diseases.

Telecardiology services approved for health care reimbursement for patients with an array of possible cardiac arrhythmias are our next largest revenue earner. Our CardioPAL ® product is the most technologically advanced portable heart monitor in the industry. Our EpiCardia service provides cardiologists with a printed ECG report on their patients anywhere in the United States as quickly as one hour after the patient connects our device to a telephone receiver. We are working on developing yet more sophisticated telecardiology technology, including devices that can provide valuable information on atrial as well as ventricular fibrillation and devices that automatically detect silent arrhythmias.

A third revenue earner for us in the field of cardiovascular health is our arginine supplementation business. Arginine is one of the twenty amino acids necessary for life. In our bodies, enzymes convert arginine into nitric oxide. This conversion is crucial for maintaining circulatory function along our 100,000 kilometers of blood vessels and capillaries. United Therapeutics is the exclusive licensee of several Stanford University patents covering the use of arginine for the promotion of vascular function.

## Product Pipeline – 15 Products

Cardiovascular medicine is a good place for United Therapeutics to be. There are two reasons why we believe we can provide more benefits in this therapeutic area than in any other market segment. First, our products are strong leaders in this market. Most doctors who treat significant numbers of pulmonary hypertension patients now prescribe Remodulin. Our telecardiology devices are the smartest, smallest products in the industry. The strength of our arginine intellectual property portfolio was demonstrated this past year when the United States Patent and Trademark office issued a patent to us that solidified our existing coverage. More people succumb to cardiovascular disease than to any other illness in America, as well as in Europe, China, and India.

While building our company’s business value in the cardiovascular field, we are also laying important foundations for future franchises in oncology and infectious diseases. We are undertaking the largest ever placebo-controlled pivotal trials of a potential medicine for preventing the recurrence of ovarian cancer. In addition, this medicine is part of a family of similar therapies to which United Therapeutics owns the rights and which are designed to combat prostate, breast, lung, pancreatic, gastrointestinal and multiple myeloma cancers.

In the field of infectious disease, we are targeting hepatitis C and other diseases with unique glycobiology antiviral agents discovered by the field’s founder, Professor Raymond Dwek of Oxford University. While this work is at an early stage, with proof-of-concept testing in patients underway, it holds immense promise. The diseases being targeted afflict over a billion people worldwide, and the compounds are part of an entire new class of pharmacological agents.

United Therapeutics has been singularly successful at developing therapies with a comparatively low cash burn rate as compared to other public biotechnology companies. We accomplish this by working efficiently and by outsourcing our pre-clinical research efforts to major academic centers whenever feasible. Another major factor in our success has been our control over manufacturing, with a company-owned facility that produces our lead product. We are also efficient in the sales and marketing arena by virtue of partnerships with half a dozen drug distribution and detailing firms. These partnerships are complemented by in-house commercialization professionals and our commitment to providing doctors and patients with accurate information and ongoing research related to our products.

The heart and lungs are remarkable organs. Perhaps more than any other word, “balance” describes what they do. Their excellence at balancing blood flow and gas exchange is far more marvelous than any machine man has yet devised. As a company, we, too, aspire to balance. Our balanced approach to cardiovascular medicine includes a pharmaceutical (Remodulin), a diagnostic (telecardiology) and a nutriceutical (arginine). Our cardiovascular drug development strategy is balanced with a commercialized use (PAH), a well-understood but not yet approved use (CLI), and a novel use (CHF). And our overall company strategy is balanced among mature programs (cardiovascular), pivotal development (oncology), and early-stage pipeline activities (infectious disease).

In addition to balance, the heart also symbolizes vitality and caring. At United Therapeutics, we find tremendous inspiration for our work and view our products as being “new beginnings” for patients and doctors, with quality of life as our utmost therapeutic goal.

**1**

**2**

# To Our Shareholders

**Senior Management** (Pictured left to right)

**David Walsh, Ph.D.,** Executive Vice President and Chief Operating Officer, Production

**Yu-Lun Lin,** President and Chief Executive Officer, Unither Pharma

**Roger Jeffs, Ph.D.,** President and Chief Operating Officer

**Shola Oyewole,** Chief Information Officer

**Martine Rothblatt, Ph.D.,** Chairman and Chief Executive Officer

**Paul Mahon,** Executive Vice President, Strategic Planning and General Counsel

**Fred Hadeed,** Executive Vice President, Business Development and Chief Financial Officer

**Ricardo Balda,** Chief Executive Officer, Medicomp

**Peter Gonze,** Chief Operating Officer, Unither Pharmaceuticals

### 2003 was the best year yet in

United Therapeutics’ history. We achieved over $50 million in revenues, slashed our loss by more than 50%, and helped more patients than ever before.

Soon after United Therapeutics was formed, we began to augment our pulmonary hypertension mission by acquiring the rights to other technologies for chronic, life-threatening conditions. In this way we would leverage the expertise we gained with Remodulin into new therapeutic areas, while heightening the upside potential for our shareholders and reducing the risk inherent in a one-drug business. 2003 was also a great year for this strategy of focused diversity. Our potential medicine for ovarian cancer, OvaRex, is one-third enrolled in its Phase 3 trials, while a lead glycobiology molecule began Phase 2 testing for hepatitis C.

U n i t e d T h e r a p e u t i c s ’ strategy of focused diversity can be summa- rized with the fol- lowing key points:

**• One Mission – chronic therapy for life-threaten- ing conditions**

**• Three Market Segments – cardio- v a s c u l a r , oncology, and infec- tious diseases**

**• Five Technology Platforms – prostacyclin analogs, arginine formula- tions, telemedicine, immuno- therapeutic antibodies, and glycobiology**

**• Fifteen Products and Product Candidates – from a recently commercialized product such as Remodulin to an early stage product candidate such as ProstaRex for prostate cancer**

This focused diversity strategy enables us to concentrate our staff resources and capital in areas that are our core competencies, such as clinical development of pharmaceuticals for chronic, life-threatening conditions. This strategy also enables us to benefit from intra-corporate synergies.

For example, our cardiac monitoring customers can be entry points for our Remodulin and arginine sales efforts, while other Remodulin and arginine prescribers can be introduced to our industry-leading cardiac Holter monitors.

2003 was also a very positive year for United Therapeutics in terms of financial performance. Revenues rose 77%, from $30 million to $53 million, while the loss from operations fell by more than 50% to its lowest level since we went public in 1999. We ended the year with no long-term debt and over $115 million in cash and investments.

The ability of United Therapeutics to accomplish such an outstanding year is due to the extraordinary efforts of its senior management, including:

**• Roger Jeffs, President and Chief Operating Officer, heads our Clinical Development Group in Research Triangle Park, NC**

**• David Walsh, Executive Vice President and Chief Operating Officer, Production, heads our Pharmaceutical Production Group in Chicago, IL**

**• Fred Hadeed, Executive Vice President, Business Development and Chief Financial Officer, heads our Corporate and Financial Group in Silver Spring, MD**

**• Paul Mahon, Executive Vice President, Strategic Planning and General Counsel, heads our Legal and Governmental Affairs Group in Washington, DC**

**• Yu-Lun Lin, President and Chief Executive Officer of our Unither Pharma subsidiary, heads our Arginine Group in Satellite Beach, FL**

**• Ricardo Balda, Chief Executive Officer of our Medicomp subsidiary heads our Telemedicine Group in Melbourne, FL**

**• Peter Gonze, Chief Operating Officer of our Unither Pharmaceuticals subsidiary, heads our Oncology Group in Wellesley Hills, MA**

The efforts of these teams are seamlessly sewn together using state-of-the-art networking technology managed by Shola Oyewole, our Chief Information Officer. Ultimately, we are all working to support our

company’s various sales and marketing efforts, especially those of our lead product, which are led worldwide by Robert Roscigno, Vice President of Commercial Development, and from our UK office, by Carl Sterritt, Director of European Commercial Development.

While 2003 was a great year for United Therapeutics, as we look toward 2004 we feel that the best is yet to come. We still have major challenges ahead of us, such as growing Remodulin sales in pulmonary arterial hypertension, successfully completing a Phase IV post-approval study of Remodulin in pulmonary arterial hypertension, further development of Remodulin in new territories and new uses, and proof of safety and efficacy in our oncological and infectious disease programs. Of paramount importance is demonstrating our ability to operate the company profitably. However, we are making steady progress towards all of these goals. We feel confident that major milestones will be achieved in 2004.

The robust United Therapeutics pipeline, if successfully developed, has enough compounds and product candidates to push revenues and earnings ever higher for many years to come. It is to the realization of this potential to which all of us at United Therapeutics are steadfastly committed.

We are honored to work with our best efforts for our shareholders, the medical community and the patients who rely upon our therapies.

Sincerely,

Martine Rothblatt, Ph.D. Chairman and CEO

**3**

4

# What Do We Know About

**by Dr. Stuart Rich, Chief Medical Officer, United Therapeutics**

**Introduction –** The causes of pulmonary arterial hypertension include primary pulmonary hypertension, and pulmonary hypertension associated with the collagen vascular diseases, congenital systemic to pulmonary shunts, portal hypertension, HIV infection, anorexigen use, and persistent pulmonary hypertension of the newborn. Afflicted patients share a common histopathology that includes pulmonary vascular abnormalities involving the endothelium, smooth muscle cells, and extracellular matrix. The most common features are medial hypertrophy, eccentric and concentric intimal fibrosis, recanalized thrombi appearing as fibrous webs, and plexiform lesions.

**Pathobiology –** There are likely several pathobiologic processes that result in pulmonary arterial hypertension as a final common pathway. These include inhibition of the voltage regulated potassium channel producing vasoconstriction of the pulmonary artery smooth muscle cells, reduced expression of nitric oxide synthase in the endothelium of the pulmonary arterial bed, increased expression of endothelin and basic fibroblast growth factor, and thrombin deposition related to a procoagulant state. The types of abnormalities that occur are likely influenced by the patient’s genotype and exposure to risk factors that serve to trigger these processes.

**PRIMARY PULMONARY HYPERTENSION** Primary pulmonary hypertension (PPH) is uncommon, with an estimated incidence of two cases per million. There is a strong female predominance, with most patients presenting in the fourth and fifth decades, although the age range is from infancy to greater than 60 years.

**Genetic considerations –** Familial primary pulmonary hypertension accounts for 12-20% of cases of PPH, and is characterized by autosomal dominant inheritance, variable age of onset, and incomplete penetrance. The clinical and pathologic features of familial and sporadic PPH are identical. Heterozygous germline mutations that involve the gene coding the Type II bone morphogenetic protein receptor (BMPR II), a member of the transforming growth factor beta superfamily, have been found to underlie many cases of familial PPH and has been designated as the PPH I gene located on chromosome 2q31. An interruption in the BMP-mediated signaling pathway will predispose the cells within the small pulmonary arteries to proliferation rather than apoptosis. These observations support the concept that pulmonary arterial hypertension is a result of abnormal proliferation of pulmonary vascular endothelial and smooth muscle cells.

**Natural history –** The natural history of pulmonary arterial hypertension is uncertain because initially the disease can be asymptomatic. Because the predominant symptom is dyspnea, which can have an insidious onset, the disease is typically diagnosed late in its course. Prior to current

therapies, series have reported a mean survival of 2-3 years for patients with primary pulmonary hypertension from the time of diagnosis. It appears that the survival of patients with pulmonary hypertension associated with congenital heart disease is longer, and the survival of patients with associated scleroderma is shorter. Functional class remains a strong predictor of survival, with patients who are Functional Class IV having a mean survival of less than six months. The cause of death is usually right ventricular failure, which is manifested by progressive hypoxemia, tachycardia, hypotension, and edema.

**Diagnosis –** A thorough diagnostic evaluation to look at all potential causes for pulmonary hypertension should be undertaken. The most common symptom attributable to pulmonary hypertension is shortness of breath with effort, which is non-specific. Other common symptoms are fatigue, angina pectoris that may represent right ventricular ischemia, syncope, near syncope, and peripheral edema.

The chest x-ray generally shows enlarged central pulmonary arteries. The lung fields may or may not reveal other pathology. The electrocardiogram usually reveals right axis deviation and right ventricular hypertrophy. The echocardiogram will demonstrate right ventricular enlargement, a reduction in left ventricular cavity size, and a tricuspid regurgitant jet that reflects right ventricular systolic pressure. Pulmonary function tests are helpful to document underlying obstructive airways disease, or severe restrictive lung disease. Hypoxemia and an abnormal diffusing capacity for carbon monoxide are common findings of pulmonary hypertension of most causes. A perfusion lung scan will almost always be abnormal in patients with thromboembolic pulmonary hypertension. However, diffuse patchy filling defects of a non-segmental nature can often be seen in longstanding pulmonary hypertension in the absence of thromboemboli.

Cardiac catheterization is mandatory to accurately measure pulmonary artery pressure and cardiac output, exclude an underlying cardiac shunt, and precisely determine left ventricular filling pressures. Because of the difficulty in obtaining accurate pulmonary capillary wedge pressures in these patients, it is desirable that a left heart catheterization be performed to determine left ventricular end diastolic pressure as the cause of the pulmonary hypertension. It is also recommended that patients with pulmonary arterial hypertension undergo drug testing with a short-acting pulmonary vasodilator at the time of cardiac catheterization to determine the extent of pulmonary vasodilator reactivity (see Figure 1). Inhaled nitric oxide, intravenous adenosine, and intravenous epoprostenol appear to have similar effects in reducing pulmonary artery pressure acutely with little effect on the systemic vascular bed. Maximal physiologic effectiveness of the drug is determined at the highest tolerated dose. Laboratory tests should also be performed, including antinuclear antibody and HIV testing.

# Pulmonary Hypertension And How Do We Treat It?

**5**

On occasion, a patient may have marked elevations in pulmonary artery pressure in association with obstructive or interstitial lung disease, essential hypertension, ischemic heart disease, or valvular heart disease. Although it may appear that the pulmonary hypertension is out of proportion to the underlying associated condition, it likely represents a pulmonary vasoconstrictive response to the associated condition, which is serving as a trigger of the pulmonary arteriopathy. The distinction is important because the treatment of pulmonary hypertension should always include treating the underlying associated cause.

**Treatment –** Because the pulmonary vascular resistance can increase dramatically with exercise, patients should be cautioned against participating in activities that demand increased physical stress. Digoxin may increase cardiac out- put and lower circulating levels of norepinephrine. Diuretic therapy relieves peripheral edema and may be useful in reducing right ventricular volume overload in the presence of tricuspid regurgitation. Resting and exercise pulse oximetry should be measured, as oxygen supplementation will help alleviate dyspnea and right ventricular ischemia in patients whose arterial oxygen saturation is reduced. Anticoagulant therapy is advocated for all patients on the basis that throm- bin deposition occurs in the pulmonary circulation, which can serve as a growth factor to promote the disease process. One retrospective study and one prospective study demon- strated that the anticoagu- lant warfarin increases sur- vival of patients with primary pulmonary hypertension. The dose of warfarin is gen- erally titrated to achieve an INR of 2.0 - 3.0 of control.

**Calcium channel blockers –** Patients who have substantial reductions in pulmonary arterial pressure from short-acting vasodilators at the time of catheterization may be candidates to receive oral calcium channel blockers. Typically, patients will require high doses (e.g., nifedipine 240 mg/day or amlodipine 20 mg/day). Patients who respond favorably will usually have dramatic reductions in pulmonary artery pressure and pulmonary vascular resistance associated with improved symptoms, regression of right ventricular hypertrophy, and improved survival with chronic therapy. Less than 20% of the patients appear to respond to calcium channel blockers in the long term. These drugs can be particularly hazardous when given in patients who are unresponsive, as they can result in hypotension, hypoxemia, tachycardia, and worsening right heart failure.

**Prostacyclins –** Prostacyclin raises cAMP levels in vascular smooth muscle cells and works via vasodilation, growth inhibition, inhibition of platelet aggregation, and cardiac inotropic effects. Epoprostenol (Flolan) is the best characterized approved treatment of pulmonary arterial hypertension for patients who are Functional Class III or IV and unresponsive to other therapies. Clinical trials have demonstrated an improvement in symptoms and exercise tolerance, and a reduction in mortality even if no acute hemodynamic response to drug challenge occurs. Recent reports have documented sustained benefits for more than

ten years in some patients. The drug can only be administered intravenously and requires placement of a permanent central venous catheter and infusion through an ambulatory infusion pump system. It generally takes several months to gradually up titrate the dose to optimal clinical efficacy, which is usually between 25-50 ng/kg/min. Side effects include flushing, jaw pain, and diarrhea, which are generally tolerated by most patients. The major problem with this therapy has been infection related to the venous catheter, which requires close monitoring and diligence on behalf of the patient.

Recently, treprostinil (Remodulin®) has been approved for patients with pulmonary arterial hypertension who are Functional Class II-IV to diminish symptoms associated with execise. An analog of epoprostenol, treprostinil has a longer half-life and is stable at room temperature, allowing for it to be administered subcutaneously through a small infusion pump that was originally developed for insulin. Clinical trials have demonstrated an increase in exercise capacity using a six-minute walk test and a reduction of symptoms of dyspnea. The major side effect with this treatment has been local pain at the infusion site. Patients who are stable on intravenous epoprostenol can be transitioned to subcutaneous treprostinil, eliminating the need for a chronic indwelling intra- venous catheter.

**Endothelin receptor antagonists –** Endothelin levels are increased in pul- monary hypertension and cause vasoconstriction and smooth muscle cell prolifer- ation. The non-selective endothelin receptor antagonist bosentan (Tracleer®) was recently approved as an oral treat- ment of pulmonary arterial hypertension for patients who are Functional Class III and IV to diminish symptoms associated with exercise. In random- ized clinical trials, bosentan was shown to improve exercise tolerance as measured by an increase in six-minute walk distance, improve functional class, and extend time until clinical worsening versus placebo. Therapy is initiated at a low dose (62.5 mg BID) for the first month and then increased to 125 mg BID thereafter. Because of the high frequency of abnormal hepatic function tests associated with drug use, primarily an increase in transaminases, it is recommended that patients have liver function tests monitored monthly throughout the duration of use. Bosentan is also contraindicated in patients who are currently on cyclosporine A or glyburide. There are no data to support the use of bosentan for some forms of pulmonary hypertension.

**Sildenafil –** There have been several case reports on the use of sildenafil (Viagra), an oral phosphodiesterase-5 inhibitor, as a treatment of pulmonary hypertension. Phosphodiesterase 5 is responsible for the hydrolysis of cGMP in the lung, the mediator through which nitric oxide lowers pulmonary artery pressure and inhibits pulmonary vascular growth. These reports suggest that oral sildenafil has a similar efficacy to inhaled nitric oxide. Large randomized clinical trials using sildenafil as a treatment of pulmonary hypertension are being proposed.

**6**

_Remodulin® (treprostinil sodium) Injection is approved as a continuous subcutaneous infusion for the treatment of pulmonary arterial hypertension in patients with NYHA Class II-IV symptoms to diminish symptoms associated with exercise._

**Transplantation –** Because of the dramatic effects that intravenous epoprostenol has in stabilizing and improving the clinical course of patients with advanced disease, transplantation is considered for patients who, while on epoprostenol, continue to manifest right heart failure. Acceptable results have been achieved with heart-lung,

bilateral lung, and single lung transplant. The availability of donor organs often influences the choice of procedure. The re-occurrence of primary pulmonary hypertension has never been reported in a patient who has undergone lung transplantation.

**7**

_“These patients share a common histopathology that includes pulmonary vascular abnormalities involving the endothelium, smooth muscle cells, and extracellular matrix.”_

_“Patients who are stable on intravenous epoprostenol can be transitioned to subcutaneous treprostinil, eliminating the need for a chronic indwelling intravenous catheter.”_

_“An analog of epoprostenol, treprostinil has a longer half-life and is stable at room temperature, allowing for it to be administered through a small infusion pump.”_

_Figure 1: An algorithm for the selection of optimal drug treatment of a patient with pulmonary arterial hypertension. Although treprostinil is approved for Functional Class IV patients, most experts would initiate therapy with intravenous epoprostenol and consider transitioning to treprostinil once the patient has stabilized, or in circumstances where epoprostenol therapy results in intolerable side effects or recurrent catheter infections._

**Marked Reduction in Pulmonary Artery Pressure**

**Minimal Reduction in Pulmonary Artery Pressure**

**Trial with Oral CA Channel Blockers**

# OvaRex ®

Pivotal trials are underway of OvaRex ® for prevention of the recurrence of ovarian cancer after initial therapy. If this medicine proves to be successful, it will pave the way for similar therapies at an earlier stage of development. United Therapeutics owns the rights to similar potential therapies for the treatment of prostate, breast, lung, pancreatic, gastro- intestinal and multiple myeloma cancers.

# HeartBar ®

The HeartBar ® is a 6-gram formulation of arginine, an essential amino acid patented by Stanford University (and exclusively licensed to United Therapeutics) for the promotion of vascular function. HeartBar ® is a convenient source of supplemental arginine\* required by the body to produce nitric oxide, which is critical for maintaining circulatory function. Multi-gram arginine supplementation increases vasodilation.

# Multiple Market Segments

**8**

# Telemedicine

Cardiac monitors are small portable devices taken home by patients to check for irregular heart rhythms over a period of days or weeks. United Therapeutics offers doctors the smallest such monitors in the industry equipped with a software algorithm that can recognize 39 different kinds of arrhythmias. Ultimately this technology could be used by millions of healthy people with a consumer-driven desire to monitor their hearts’ performance on an ongoing basis.

_\* Arginine is an essential part of a healthy diet. People with sufficient arginine in their diet may not require arginine supplementation and HeartBar ® is not intended to diagnose, treat, cure, or prevent any disease._

**Sir John Vane, D.Sc. F.R.S. Robyn J. Barst, M.D. Professor Baruch S. Blumberg, Ph.D.**

**Professor Raymond A. Dwek, F.R.S.**

**Professor Victor J. Dzau, M.D. Urban Ramstedt, Ph.D. Louis W. Sullivan, M.D.**

**Professor Sir Magdi Yacoub, M.D., F.A.C.S.**

# Scientific Advisory Board

We are proud of our Scientific Advisory Board. It is chaired by Sir John Vane, D.Sc., F.R.S. a Nobel Laureate who co-discovered the molecule prostacyclin, upon which much of our business is based. His knowledge is of immense value to us as we explore the use of prostacyclin-like molecules (such as Remodulin) in cardiovascular conditions. The Scientific Advisory Board member who helps us pilot the use of variants of the prostacyclin molecule in the field of pulmonary hypertension is a globally recognized expert in this condition, clinician-scientist Robyn J. Barst, M.D.

As we extended our business into infectious diseases, we strengthened our Board with Nobel Laureate Baruch S. Blumberg, Ph.D., who discovered the hepatitis B virus and created the hepatitis B vaccine, an innovation that has saved millions of lives. Professor Blumberg works closely with another of our Board members, Raymond A. Dwek, F.R.S., who discovered our iminosugar-based anti-infective platform of molecules (such as our lead drug candidate for treating hepatitis C, UT-231B). Professor Dwek is also able to share with us some of the brilliance that permeates University of Oxford’s Biochemistry Department, which he chairs, and its Glycobiology Institute, which he founded. The anti-infectives expertise of Professors Blumberg and Dwek is further complemented on our Scientific Advisory Board by Urban Ramstedt, Ph.D., Head of Tumor Immunology at Genitrix, LLC, and an expert on retroviruses, particularly HIV and hepatitis C.

It is also important to have individuals on a Scientific Advisory Board who have operational responsibility and vast expertise overseeing the appropriateness of how scientific breakthroughs are translated into clinical protocols, and how medical discoveries are integrated into clinical practice. For us, we are honored to have as these individuals Sir Magdi Yacoub, M.D., F.A.C.S., one of the world’s foremost transplant surgeons and cardiopulmonary scientists, Victor J. Dzau, M.D., Chairman of Medicine at Harvard University’s Brigham & Women’s Hospital, and the Hon. Louis W. Sullivan, M.D., founding President and now President Emeritus of Morehouse School of Medicine and former Secretary of the United States Department of Health and Human Services.

The Scientific Advisory Board at United Therapeutics plays an important role. Fortunately for us, the caliber of the scientists on our Board are second to none in our missions of developing prostacyclin-like molecules and arginine supplementation for cardiovascular medicine and proving the usefulness of iminosugar compounds for safely treating serious infectious disease.

**$60**

**$50**

**$40**

**$30**

**$20**

**$10**

**$0 $0**

**$(10)**

**$(20)**

**$(30)**

**$(40)**

**$(50)**

**$(60)**

**$(70)**

**$(80)**

**1999 2000 2001 2002 2003**

**Revenue Growth (in millions)**

**Net Losses (in millions)**

**2003 Revenue Sources** Total $53.3 million

**Arginine sales $2,337,000**

**Telemedicine services $4,161,000**

**Sales of Remodulin** **®** **pumps and supplies $1,722,000**

**Remodulin** **®** **drug sales $45,121,000**

**Revenues –** United Therapeutics revenues grew to over $53 million in 2003. This 77% growth from the prior year was fueled by demand for Remodulin ® which was launched in May 2002 in the United States. Demand for United Therapeutics' other products grew in 2003 as well. Consequently, annual net losses have fallen significantly from their highest level in 2000.

# Selected Financial Highlights

**10**

**Cash and Investments –** United Therapeutics had cash, cash equivalents and investments totaling approximately $117.3 million at December 31, 2003.

# Company Summary

Raymond Dwek, F.R.S., Professor of Biochemistry, Director of the Glycobiology Institute, and Chairman of the Department of Biochemistry at University of Oxford, holds a model of a sugar molecule related to United Therapeutics' glycobiology program. Professor Dwek is a member of both the United Therapeutics Board of Directors and Scientific Advisory Board.

United Therapeutics is a biotechnology company focused on developing chronic therapies for life-threatening conditions in three therapeutic areas: cardiovascular, oncology, and infectious diseases. In these segments, United Therapeutics is actively developing five technology platforms: prostacyclin analogs, immunothera- peutic monoclonal antibodies, glycobiology, arginine formulations and telemedicine.

At United Therapeutics, we find tremendous inspiration for our work and view our products as being new beginnings for patients and doctors, with quality of life as our utmost therapeutic goal. The theme of United Therapeutics is "Medicines for Life" because all of our therapeutics address life-threatening illnesses.

Much of United Therapeutics' resources are focused on cardiovascular health, including developing analogs of the endogenous hormone prostacyclin for the treatment of pulmonary arterial hypertension and critical limb ischemia, telemedicine services for patients with an array of possible cardiac arrhythmias, and arginine supplementation therapy. United Therapeutics' second principal focus is oncology, and the company is undertaking the largest ever place- bo-controlled pivotal trial of a potential medicine for preventing the recurrence of ovarian can- cer. This medicine is part of a family of similar immunotherapeutic monoclonal antibody ther- apies licensed to United Therapeutics which are designed to combat prostate, breast, lung, pancreatic, gastrointestinal and multiple myeloma cancers. United Therapeutics’ third focus is in the field of infectious disease, where the company is targeting hepatitis C and other diseases with unique glycobiology compounds. While this work is at an early stage, it holds immense promise. The diseases being targeted afflict over a billion people worldwide, and the com- pounds are part of an entire new class of p h a r m a c o l o g i c a l agents.

The company's mis- sion is carried out using corporate partners for product sales and aca- demic centers for research whenever fea- sible, complemented by in- house commercialization pro- fessionals and our commitment to providing doctors and patients with accurate information and ongoing research related to our products. This strategy stream- lines company overhead and enables company employees to concentrate on clinical trials, regulatory approvals and business development. United Therapeutics gen- erally retains all rights to the products it devel- ops.

# Corporate Information

**Management** Ricardo Balda Chief Executive Officer Medicomp, Inc.

Peter C. Gonze Chief Operating Officer Unither Pharmaceuticals, Inc.

Fred T. Hadeed Executive Vice President, Business Development and Chief Financial Officer

Roger Jeffs, Ph.D. President and Chief Operating Officer

Yu-Lun Lin President and Chief Executive Officer Unither Pharma, Inc.

Paul A. Mahon, J.D. Executive Vice President, Strategic Planning and General Counsel

Shola Oyewole, MSc., M.C.S.E.+1 Chief Information Officer

Martine Rothblatt, Ph.D, J.D., M.B.A. Chairman and Chief Executive Officer

David Walsh, Ph.D. Executive Vice President and Chief Operating Officer, Production

**Board of Directors** Ricardo Balda\*

Professor Raymond A. Dwek, F.R.S. Professor of Biochemistry Director of the Glycobiology Institute Chairman of the Department of Biochemistry University of Oxford

R. Paul Gray Founding Member, Core Concepts, LLC Chief Financial Officer and Director, Power ³ Medical Products, Inc.

Henry Beecher Hicks, III, M.B.A. Principal Equilibrium Growth Advisors, LLC

Christopher Causey, M.B.A. Principal Causey Consortium

Roger Jeffs, Ph.D.\*

Raymond Kurzweil Founder, Chairman, and Chief Executive Officer Medical Learning Company, Inc.

Christopher Patusky, J.D., M.G.A. Deputy Director, Chief Operating Officer, and Member of the Faculty Fels Institute of Government University of Pennsylvania

Martine Rothblatt, Ph.D, J.D., M.B.A.\*

\* United Therapeutics’ Management

Hon. Louis W. Sullivan, M.D. Founding President and President Emeritus of Morehouse School of Medicine Former Secretary of United States Department of Health and Human Services

**Scientific Advisory Board United Therapeutics** Sir John Vane, D.Sc., F.R.S. 1982 Nobel Laureate in Physiology or Medicine Chairman of the United Therapeutics Scientific Advisory Board

Robyn Barst, M.D. Columbia University, New York Professor of Pediatrics, Columbia University College of Physicians & Surgeons Director, Pulmonary Hypertension Center, New York Presbyterian Hospital

Professor Baruch S. Blumberg, Ph.D. 1976 Nobel Laureate in Physiology or Medicine Fox Chase Distinguished Scientist, Fox Chase Cancer Center

Professor Raymond A. Dwek, F.R.S. Professor of Biochemistry Director of the Glycobiology Institute Chairman of the Department of Biochemistry University of Oxford

Professor Victor J. Dzau, M.D. Chairman, Department of Medicine Brigham & Women’s Hospital Harvard Medical School

Urban Ramstedt, Ph.D. Head of Tumor Immunology Genitrix, LLC Cambridge, Massachusetts

Hon. Louis W. Sullivan, M.D. Founding President and President Emeritus of Morehouse School of Medicine Former Secretary of United States Department of Health and Human Services

Professor Sir Magdi Yacoub, M.D., F.A.C.S. England’s National Heart and Lung Institute

**Investor Relations** Andrew Fisher, J.D. Deputy General Counsel and Vice President, Investor Relations

**Transfer Agent and Registrar** The Bank of New York Shareholder Relations Department P.O. Box 11258 Church Street Station New York, New York 10286 (800) 524-4458 (610) 382-7833 (outside the United States) e-mail: shareowners@bankofny.com Stock Transfer Website: www.stockbny.com

**Attorneys** Akin Gump Strauss Hauer & Feld LLP Robert S. Strauss Building 1333 New Hampshire Avenue, N.W. Washington, D.C. 20036 Tel. (202) 887-4000 Fax. (202) 887-4288

**Auditors** Ernst & Young LLP 8484 Westpark Drive McLean, Virginia 22102 Tel. (703) 747-1000 Fax. (703) 747-0100

**Corporate Headquarters** 1110 Spring Street Silver Spring, Maryland 20910 Tel. (301) 608-9292 Fax. (301) 608-9291

**Research and Development** One Park Drive P.O. Box 14186 Research Triangle Park, North Carolina 27709 Tel. (919) 485-8350 Fax. (919) 485-8352

**Manufacturing** 2225 W. Harrison Street Chicago, Illinois 60612 Tel. (312) 421-1819 Fax. (312) 421-8177

**Legal and Governmental Affairs** 1735 Connecticut Avenue, N.W. Washington, D.C. 20009 Tel. (202) 483-7000 Fax. (202) 483-4005

**Subsidiaries** Medicomp, Inc. 7845 Ellis Road Melbourne, Florida 32904 Tel. (321) 676-0010 Fax. (321) 676-2282 www.medicompinc.com

Unither Pharma, Inc. 1077 Highway A1A Satellite Beach, Florida 32937 Tel. (321) 779-1441 Fax. (321) 779-1645 www.unitherpharma.com

Unither Pharmaceuticals, Inc. 15 Walnut Street Wellesley Hills, Massachusetts 02481 Tel. (781) 235-7412 Fax. (781) 235-7241

**Common Stock** Listed on Nasdaq National Market symbol “UTHR”

**Annual Meeting** June 25, 2004

**Internet Access** www.unither.com

**12**

### Medicines for Life ®

Corporate Headquarters 1110 Spring Street Silver Spring, Maryland 20910 Tel. (301) 608-9292 Fax. (301) 608-9291

## www.unither.com