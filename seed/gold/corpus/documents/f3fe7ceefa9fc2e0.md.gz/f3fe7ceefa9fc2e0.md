1. 
2. News Releases
3. Gilead-Sciences-Announces-Second-Quarter-2019-Financial-Results

July 30, 2019

# Gilead Sciences Announces Second Quarter 2019 Financial Results

Back

**_\- Product Sales of $5.6 billion \-
\-_** **_Diluted EPS of $1.47 per share -_** **_\- Non-GAAP Diluted EPS of $1.82 per share -_** **_\- Revised Full Year 2019 Guidance -_**

FOSTER CITY, Calif. \--(BUSINESS WIRE)--Jul. 30, 2019-- Gilead Sciences, Inc. (Nasdaq: GILD) announced today its results of operations for the second quarter ended June 30, 2019 . The financial results that follow represent a year-over-year comparison of the second quarter of 2019 to the second quarter of 2018. Total revenues were $5.7 billion in 2019 compared to $5.6 billion in 2018. Net income was $1.9 billion or $1.47 per diluted share in 2019 compared to $1.8 billion or $1.39 per diluted share in 2018. Non-GAAP net income was $2.3 billion or $1.82 per diluted share in 2019 compared to $2.5 billion or $1.91 per diluted share in 2018.

“I am very pleased with Gilead ’s performance and our ability to continue to reach patients around the world with our medicines. I am also very excited about the progress we are making to strengthen our pipeline, including the recently announced Galapagos collaboration, to bring forward our next generation of products,” said Daniel O’Day, Chairman and Chief Executive Officer, Gilead Sciences . “We saw strong revenue growth quarter-over-quarter, primarily driven by our HIV medicines and the rapid adoption of Biktarvy. Based on this momentum and our confidence in the outlook for the coming months, we are raising our full-year product sales guidance for 2019.”

|**Three Months Ended** |**Six Months Ended** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**June 30,** |**June 30,** |
|**(In millions, except per share amounts)** |**2019** |**2018** |**2019** |**2018** |
|Product sales |$ |5,607 |$ |5,540 |$ |10,807 |$ |10,541 |
|Royalty, contract and other revenues |78 |108 |159 |195 |
|Total revenues |$ |5,685 |$ |5,648 |$ |10,966 |$ |10,736 |
|Net income attributable to Gilead |$ |1,880 |$ |1,817 |$ |3,855 |$ |3,355 |
|Non-GAAP net income |$ |2,331 |$ |2,494 |$ |4,589 |$ |4,452 |
|Diluted earnings per share |$ |1\.47 |$ |1\.39 |$ |3\.01 |$ |2\.55 |
|Non-GAAPdiluted earnings per share |$ |1\.82 |$ |1\.91 |$ |3\.58 |$ |3\.39 |

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

_Note: Non-GAAP financial information excludes acquisition-related, up-front collaboration and licensing, stock-based compensation and other expenses, fair value adjustments of equity securities and discrete tax charges or benefits associated with changes in tax related laws and guidelines. A reconciliation between GAAP and non-GAAP financial information is provided in the tables on pages 9 through 11._

**Product Sales**

Total product sales for the second quarter of 2019 were $5.6 billion compared to $5.5 billion for the same period in 2018. For the second quarter of 2019, product sales in the United States , Europe and other locations were $4.1 billion , $1.0 billion and $512 million , respectively. For the second quarter of 2018, product sales in the United States , Europe and other locations were $4.1 billion , $1.0 billion and $466 million , respectively. Product sales in Europe for the second quarter of 2019 benefited from approximately $160 million of adjustments for statutory rebates related primarily to HCV and HIV sales made in prior years.

* **HIV product sales** were $4.0 billion for the second quarter of 2019 compared to $3.7 billion for the same period in 2018. The increase was primarily driven by higher sales volume as a result of the continued uptake of Biktarvy ® (bictegravir 50 mg/emtricitabine 200 mg/tenofovir alafenamide 25 mg).
* **Chronic hepatitis C virus (HCV) product sales** were $842 million for the second quarter of 2019 compared to $1.0 billion for the same period in 2018. The decline was primarily due to competitive dynamics, including a decline in U.S. Medicare prices, and lower patient starts.
* **Yescarta ®** (axicabtagene ciloleucel) generated $120 million in sales during the second quarter of 2019 compared to $68 million for the same period in 2018. The increase was driven by an increase in the number of therapies provided to patients.
* Other product sales, which include products from chronic hepatitis B virus (HBV), cardiovascular, oncology and other categories inclusive of Vemlidy ® (tenofovir alafenamide 25 mg), Viread ® (tenofovir disoproxil fumarate 300 mg), Letairis ® (ambrisentan 5 mg and 10 mg), Ranexa ® (ranolazine 500 mg and 1000 mg), Zydelig ® (idelalisib 150 mg), AmBisome ® (amphotericin B liposome for injection 50 mg/vial) and Cayston ® (aztreonam for inhalation solution 75 mg/vial), were $604 million for the second quarter of 2019 compared to $807 million for the same period in 2018. The decrease was primarily due to the expected declines in Ranexa and Letairis sales after generic entries in 2019.

**Operating Expenses**

|**Three Months Ended** |**Six Months Ended** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**June 30,** |**June 30,** |
|**(In millions)** |**2019** |**2018** |**2019** |**2018** |
|Research and development expenses (R&D) |$ |1,160 |$ |1,192 |$ |2,217 |$ |2,129 |
|Non-GAAP R&D expenses |$ |916 |$ |921 |$ |1,787 |$ |1,735 |
|Selling, general and administrative expenses (SG&A) |$ |1,095 |$ |980 |$ |2,125 |$ |1,977 |
|Non-GAAP SG&A expenses |$ |1,015 |$ |840 |$ |1,977 |$ |1,724 |

During the second quarter of 2019, compared to the same period in 2018:

* R&D expenses decreased slightly, primarily due to the 2018 impacts of Gilead’s purchase of a U.S. Food and Drug Administration ( FDA ) Priority Review Voucher and stock-based compensation expense following the acquisition of Kite Pharma, Inc. , largely offset by higher investments in 2019 to support Gilead’s cell therapy programs.
* Non-GAAP R&D expenses decreased slightly, primarily due to the 2018 impact of Gilead’s purchase of an FDA Priority Review Voucher, largely offset by higher investments in 2019 to support Gilead’s cell therapy programs.
* SG&A expenses increased primarily due to higher promotional expenses in the United States and expenses associated with the expansion of Gilead’s business in Japan and China , partially offset by lower stock-based compensation expense. Stock-based compensation expense was higher for the second quarter of 2018 following the acquisition of Kite Pharma, Inc.
* Non-GAAP SG&A expenses increased primarily due to higher promotional expenses in the United States and expenses associated with the expansion of Gilead’s business in Japan and China .

**Effective Tax Rate**

The effective tax rate and non-GAAP effective tax rate in the second quarter of 2019 were 22.2% and 21.5%, respectively, compared to 12.8% and 13.4% for the same period in 2018, respectively. The increases were primarily due to the 2018 impact of a favorable settlement of a tax examination.

**Cash, Cash Equivalents and Marketable Debt Securities**

As of June 30, 2019 , Gilead had $30.2 billion of cash, cash equivalents and marketable debt securities, compared to $31.5 billion as of December 31, 2018 . During the second quarter of 2019, Gilead generated $2.2 billion in operating cash flow, repaid $500 million of debt, paid cash dividends of $800 million and utilized $588 million on stock repurchases.

**Revised Full Year 2019 Guidance**

Gilead revised its full year 2019 guidance, initially provided on February 4, 2019 . The updated guidance for product sales reflects favorable demand trends observed in the first half of 2019 across Gilead’s product portfolio, the adjustments for statutory rebates related to Europe sales made in prior years, a greater impact from generic versions of Letairis in the second half of 2019 and the full year impact from generic products containing tenofovir disoproxil fumarate in certain European countries. The guidance for diluted EPS impact of acquisition-related, up-front collaboration and licensing, stock-based compensation and other expense was updated as a result of the collaboration agreement with Galapagos NV (Galapagos).

|**(In millions, except percentages and per share amounts)** |**Initially Provided
February 4, 2019
Reiterated
May 2, 2019** |**Updated
July 30, 2019** |
| --- | --- | --- |
|Product Sales |$21,300 - $21,800 |$21,600 - $22,100 |
|Non-GAAP |
|Product Gross Margin |85% - 87% |85% - 87% |
|R&D Expenses |$3,600 - $3,800 |$3,600 - $3,800 |
|SG&A Expenses |$3,900 - $4,100 |$3,900 - $4,100 |
|Effective Tax Rate |20\.0% - 21.0% |20\.0% - 21.0% |
|Diluted EPS Impact of Acquisition-related, Up-front Collaboration and Licensing, Stock-based Compensation and Other Expenses |$1.40 - $1.50 |$3.90 - $4.00 |

**Corporate Highlights, Including the Announcement of:**

* A global research and development collaboration with Galapagos under which Gilead will make a $3.95 billion up-front payment and an equity investment of approximately $1.1 billion . Through this agreement, Gilead will gain access to a proven drug discovery platform and an innovative portfolio of compounds, including six molecules currently in clinical trials, and more than 20 preclinical programs.
* Collaboration and/or licensing agreements with Novartis AG ( Novartis ), Carna Biosciences Inc. (Carna), Nurix Therapeutics, Inc. (Nurix), Humanigen, Inc. ( Humanigen ), Goldfinch Bio, Inc. (Goldfinch), Insitro, Inc. (Insitro), and Novo Nordisk A/S ( Novo Nordisk ).
* Senior leadership changes, including: the appointment of Christi L. Shaw as Chief Executive Officer of Kite, a Gilead Company ; the appointment of Johanna Mercier as Chief Commercial Officer; the departures of John G. McHutchison , A.O., M.D., Chief Scientific Officer and Head of Research and Development, Gregg H. Alton , Chief Patient Officer, and Katie L. Watson , Executive Vice President, Human Resources; and the planned retirement of Robin L. Washington from her role as Executive Vice President and Chief Financial Officer effective March 1, 2020 .
* Louisiana’s launch of an innovative payment model for HCV treatment with Gilead’s separate subsidiary, Asegua Therapeutics LLC , aiming to eliminate the disease.
* The donation of TruvadaforPrEP® (emtricitabine 200 mg and tenofovir disoproxil fumarate 300 mg) to the U.S. Centers for Disease Control and Prevention (CDC) in support of national efforts to help prevent HIV and end the epidemic. Gilead will provide to CDC up to 2.4 million bottles of Truvada® (emtricitabine 200 mg and tenofovir disoproxil fumarate 300 mg) annually for uninsured Americans at risk for HIV. The donation, which extends until 2030, will transition to Descovy® (emtricitabine 200 mg and tenofovir alafenamide 25 mg), if it is approved for use as prevention.
* Plans for a new facility in Frederick County, Maryland , to significantly expand Kite’s ability to manufacture Yescarta, Kite’s first commercially available CAR T cancer therapy, and a variety of investigational cell therapies.

**Product and Pipeline Updates, Including the Announcement of:**

**HIV and Liver Diseases Programs**

* The presentation of data at the 10th International AIDS Society Conference on HIV Science , which included:
  
    + Results from a sub-analysis of the DISCOVER trial evaluating an investigational use of Descovy for HIV pre-exposure prophylaxis (PrEP), which demonstrated that Descovy reached intracellular drug concentration levels above the estimated protective threshold significantly more quickly than Truvada and that these drug concentration levels persist longer than Truvada.
    + Results from two studies of investigational toll-like receptor (TLR7) agonists as part of an HIV cure research program. The Phase 1 and preclinical study results demonstrate that TLR7 agonists have a potential role to play in scalable strategies for achieving sustained viral remission in humans.
    + Results from two Phase 3 trials demonstrating the effectiveness of Biktarvy for the treatment of HIV in women and in virologically suppressed patients with known resistance.
    + Results from a Phase 1b study of GS-6207, an investigational, novel, selective capsid inhibitor, in people living with HIV. The Phase 1b data demonstrated the first proof of concept that HIV capsid inhibition can lead to significant declines in viral load _in vivo_ and that resistance to GS-6207 _in vitro_ did not lead to resistance to other classes of drugs used in the treatment of HIV.

* Data from STELLAR-3, a Phase 3 study evaluating the safety and efficacy of selonsertib, an investigational, once daily, oral inhibitor of apoptosis signal-regulating kinase 1 (ASK1), for patients with bridging fibrosis (F3) due to NASH, did not meet the pre-specified week 48 primary endpoint of a ≥ 1-stage histologic improvement in fibrosis without worsening of NASH.

* The presentation of data at the International Liver Congress™ 2019, which included:
  
    + Safety and efficacy data on Vemlidy in patients with HBV previously treated with tenofovir disoproxil fumarate and data on Epclusa ® (sofosbuvir 400mg/velpatasvir 100mg) and Harvoni ® (ledipasvir 90mg/sofosbuvir 400mg) in difficult-to-cure HCV patient populations.
    + Results from Gilead’s clinical research program in NASH, including a combination study of the investigational, selective, non-steroidal farnesoid X receptor agonist cilofexor (GS-9674) and the acetyl-CoA carboxylase inhibitor firsocostat (GS-0976). The data support Gilead’s efforts to develop combination therapies to target different aspects of NASH, evaluate the utility of noninvasive tests for the identification of patients living with the disease and advance overall understanding of the complexities and burden of NASH.
* The launch of five new global grant programs to continue to support investigator-sponsored research in HCV and HBV, HCV and HIV co-infection, NASH and primary sclerosing cholangitis.
* The submission of a supplemental new drug application to FDA for Descovy for PrEP to reduce the risk of sexually acquired HIV-1 infection among individuals who are HIV-negative and at risk for HIV. A priority review voucher was submitted with the filing, leading to an anticipated review time of six months.

**Inflammation Program**

* The intent to submit a new drug application to FDA for filgotinib this year, an investigational, oral, selective JAK1 inhibitor, as a treatment for rheumatoid arthritis (RA).
* The presentation of data at the Annual European Congress of Rheumatology 2019, which included data on filgotinib. Among the abstracts presented were 24-week, interim results from the ongoing FINCH 1 and FINCH 3 Phase 3 studies evaluating filgotinib in adults with RA.

**Cell Therapy Program**

* The presentation of data at the 2019 American Society of Clinical Oncology Annual Meeting, which included:
  
    + Results from a safety management analysis of early use of steroids from the ZUMA-1 trial of Yescarta in adult patients with diffuse large B-cell lymphoma (DLBCL).
    + Results from a sub-population analysis from the ZUMA-1 trial of Yescarta in adult patients with DLBCL.
    + Results from the completed Phase 1 of the ZUMA-3 study evaluating KTE-X19, an investigational CD19 CAR T cell therapy. ZUMA-3 is a single-arm Phase 1/2 study in adult patients with relapsed or refractory acute lymphoblastic leukemia.

**Non-GAAP Financial Information**

The information presented in this document has been prepared in accordance with U.S. generally accepted accounting principles (GAAP), unless otherwise noted as non-GAAP. Management believes non-GAAP information is useful for investors, when considered in conjunction with Gilead’s GAAP financial information, because management uses such information internally for its operating, budgeting and financial planning purposes. Non-GAAP information is not prepared under a comprehensive set of accounting rules and should only be used to supplement an understanding of Gilead’s operating results as reported under GAAP. Non-GAAP measures may be defined and calculated differently by other companies in the same industry. A reconciliation between GAAP and non-GAAP financial information is provided in the tables on pages 9 through 11.

**Conference Call**

The live webcast of the call can be accessed at Gilead’s Investors page at [http://investors.gilead.com/](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Finvestors.gilead.com%2F&esheet=52020232&newsitemid=20190730005933&lan=en-US&anchor=http%3A%2F%2Finvestors.gilead.com%2F&index=1&md5=ecd24ab751db851947608960949f8236) . Please connect to the website at least 15 minutes prior to the start of the call to allow adequate time for any software download that may be required to listen to the webcast. Alternatively, please call 877-359-9508 (U.S.) or 224-357-2393 (international) and dial the conference ID 8696029 to access the call. Telephone replay will be available approximately two hours after the call through 8:00 p.m. Eastern Time , August 1, 2019 . To access the replay, please call 855-859-2056 (U.S.) or 404-537-3406 (international) and dial the conference ID 8696029. The webcast will be archived on [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=52020232&newsitemid=20190730005933&lan=en-US&anchor=www.gilead.com&index=2&md5=e9df6ccc01347783c26f97429ebdd1da) for one year.

**About Gilead Sciences**

Gilead Sciences, Inc. is a research-based biopharmaceutical company that discovers, develops and commercializes innovative medicines in areas of unmet medical need. The company strives to transform and simplify care for people with life-threatening illnesses around the world. Gilead has operations in more than 35 countries worldwide, with headquarters in Foster City, California .

**Forward-Looking Statement**

Statements included in this press release that are not historical in nature are forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. Gilead cautions readers that forward-looking statements are subject to certain risks and uncertainties that could cause actual results to differ materially. These risks and uncertainties include: Gilead’s ability to achieve its anticipated full year 2019 financial results; Gilead’s ability to sustain growth in revenues for its antiviral and other programs; the risk that private and public payers may be reluctant to provide, or continue to provide, coverage or reimbursement for new products; austerity measures in European countries that may increase the amount of discount required on Gilead’s products; an increase in discounts, chargebacks and rebates due to ongoing contracts and future negotiations with commercial and government payers; a larger than anticipated shift in payer mix to more highly discounted payer segments and geographic regions and decreases in treatment duration; availability of funding for state AIDS Drug Assistance Programs (ADAPs); continued fluctuations in ADAP purchases driven by federal and state grant cycles as well as purchases by retail pharmacies and other non-wholesaler locations with whom Gilead has no inventory management agreements may not mirror patient demand and may cause fluctuations in Gilead’s earnings; market share and price erosion caused by the introduction of generic versions of our products; an uncertain global macroeconomic environment; potential amendments to the Affordable Care Act or other government action that could have the effect of lowering prices or reducing the number of insured patients; Gilead’s ability to initiate clinical trials in its currently anticipated timeframes; the levels of inventory held by wholesalers and retailers which may cause fluctuations in Gilead’s earnings; Gilead’s ability to realize the potential benefits of collaborations or licensing arrangements, including with Galapagos, Novartis , Carna, Nurix, Humanigen , Goldfinch, Insitro and Novo Nordisk ; Gilead’s ability to submit new drug applications for new product candidates in the timelines currently anticipated, including a new drug application to FDA for filgotinib for the treatment of rheumatoid arthritis; Gilead’s ability to receive regulatory approvals in a timely manner or at all, for new and current products, including FDA approval for Descovy for PrEP; Gilead’s ability to successfully commercialize its products, including Yescarta; the risk that physicians and patients may not see advantages of these products over other therapies and may therefore be reluctant to prescribe the products; safety and efficacy data from clinical studies may not warrant further development of Gilead’s product candidates, including filgotinib, selonsertib, GS-9674, GS-0976 and KTE-X19; Gilead’s ability to pay dividends or complete its share repurchase program due to changes in its stock price, corporate or other market conditions; fluctuations in the foreign exchange rate of the U.S. dollar that may cause an unfavorable foreign currency exchange impact on Gilead’s future revenues and pre-tax earnings; and other risks identified from time to time in Gilead’s reports filed with the U.S. Securities and Exchange Commission (the SEC ). In addition, Gilead makes estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses and related disclosures. Gilead bases its estimates on historical experience and on various other market specific and other relevant assumptions that it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. There may be other factors of which Gilead is not currently aware that may affect matters discussed in the forward-looking statements and may also cause actual results to differ significantly from these estimates. Further, results for the quarter ended June 30, 2019 are not necessarily indicative of operating results for any future periods. You are urged to consider statements that include the words may, will, would, could, should, might, believes, estimates, projects, potential, expects, plans, anticipates, intends, continues, forecast, designed, goal or the negative of those words or other comparable words to be uncertain and forward-looking. Gilead directs readers to its press releases, Quarterly Report on Form 10-Q for the quarter ended March 31, 2019 and other subsequent disclosure documents filed with the SEC . Gilead claims the protection of the Safe Harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements.

All forward-looking statements are based on information currently available to Gilead and Gilead assumes no obligation to update or supplement any such forward-looking statements other than as required by law. Any forward-looking statements speak only as of the date hereof or as of the dates indicated in the statements.

Gilead owns or has rights to various trademarks, copyrights and trade names used in its business, including the following: GILEAD ® , GILEAD SCIENCES ® , AMBISOME ® , ATRIPLA ® , BIKTARVY ® , CAYSTON ® , COMPLERA ® , DESCOVY ® , EMTRIVA ® , EPCLUSA ® , EVIPLERA ® , GENVOYA ® , HARVONI ® , HEPSERA ® , LETAIRIS ® , ODEFSEY ® , RANEXA ® , SOVALDI ® , STRIBILD ® , TRUVADA ® , TRUVADAFORPREP ® , TYBOST ® , VEMLIDY ® , VIREAD ® , VOSEVI ® , YESCARTA ® and ZYDELIG ® .

LEXISCAN ® is a registered trademark of Astellas U.S. LLC . MACUGEN ® is a registered trademark of Eyetech, Inc. SYMTUZA ® is a registered trademark of Janssen Sciences Ireland UC. TAMIFLU ® is a registered trademark of Hoffmann-La Roche Inc.

_For more information on Gilead Sciences, Inc. , please visit [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=52020232&newsitemid=20190730005933&lan=en-US&anchor=www.gilead.com&index=3&md5=86b3e26ab323357f839a54be8accbbf4) or call the Gilead Public Affairs Department at 1-800-GILEAD-5 (1-800-445-3235)._

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**CONDENSED CONSOLIDATED STATEMENTS OF INCOME** |
|**(unaudited)** |
|**(in millions, except per share amounts)** |
|**Three Months Ended** |**Six Months Ended** |
|**June 30,** |**June 30,** |
|**2019** |**2018** |**2019** |**2018** |
|Revenues: |
|Product sales |$ |5,607 |$ |5,540 |$ |10,807 |$ |10,541 |
|Royalty, contract and other revenues |78 |108 |159 |195 |
|Total revenues |5,685 |5,648 |10,966 |10,736 |
|Costs and expenses: |
|Cost of goods sold |1,000 |1,196 |1,957 |2,197 |
|Research and development expenses |1,160 |1,192 |2,217 |2,129 |
|Selling, general and administrative expenses |1,095 |980 |2,125 |1,977 |
|Total costs and expenses |3,255 |3,368 |6,299 |6,303 |
|Income from operations |2,430 |2,280 |4,667 |4,433 |
|Interest expense |(248 |) |(266 |) |(502 |) |(556 |) |
|Other income (expense), net |228 |72 |595 |242 |
|Income before provision for income taxes |2,410 |2,086 |4,760 |4,119 |
|Provision for income taxes |535 |267 |917 |761 |
|Net income |1,875 |1,819 |3,843 |3,358 |
|Net income (loss) attributable to noncontrolling interest |(5 |) |2 |(12 |) |3 |
|Net income attributable to Gilead |$ |1,880 |$ |1,817 |$ |3,855 |$ |3,355 |
|Net income per share attributable to Gilead common stockholders - basic |$ |1\.48 |$ |1\.40 |$ |3\.03 |$ |2\.58 |
|Shares used in per share calculation - basic |1,270 |1,298 |1,273 |1,302 |
|Net income per share attributable to Gilead common stockholders - diluted |$ |1\.47 |$ |1\.39 |$ |3\.01 |$ |2\.55 |
|Shares used in per share calculation - diluted |1,277 |1,308 |1,280 |1,314 |
|Cash dividends declared per share |$ |0\.63 |$ |0\.57 |$ |1\.26 |$ |1\.14 |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION** |
|**(unaudited)** |
|**(in millions, except percentages and per share amounts)** |
|**Three Months Ended** |**Six Months Ended** |
|**June 30,** |**June 30,** |
|**2019** |**2018** |**2019** |**2018** |
|**Cost of goods sold reconciliation:** |
|GAAP cost of goods sold |$ |1,000 |$ |1,196 |$ |1,957 |$ |2,197 |
|Acquisition-related – amortization of purchased intangibles |(273 |) |(300 |) |(556 |) |(601 |) |
|Stock-based compensation expenses (1) |(13 |) |(21 |) |(27 |) |(34 |) |
|Non-GAAP cost of goods sold |$ |714 |$ |875 |$ |1,374 |$ |1,562 |
|**Product gross margin reconciliation:** |
|GAAP product gross margin |82\.2 |% |78\.4 |% |81\.9 |% |79\.2 |% |
|Acquisition-related – amortization of purchased intangibles |4\.9 |% |5\.4 |% |5\.1 |% |5\.7 |% |
|Stock-based compensation expenses |0\.2 |% |0\.4 |% |0\.2 |% |0\.3 |% |
|Non-GAAP product gross margin (4) |87\.3 |% |84\.2 |% |87\.3 |% |85\.2 |% |
|**Research and development expenses reconciliation:** |
|GAAP research and development expenses |$ |1,160 |$ |1,192 |$ |2,217 |$ |2,129 |
|Up-front collaboration and licensing expenses |(165 |) |(160 |) |(291 |) |(160 |) |
|Acquisition-related – other costs |— |(9 |) |— |(25 |) |
|Stock-based compensation expenses (1) |(80 |) |(102 |) |(141 |) |(205 |) |
|Other (2) |1 |— |2 |(4 |) |
|Non-GAAP research and development expenses |$ |916 |$ |921 |$ |1,787 |$ |1,735 |
|**Selling, general and administrative expenses reconciliation:** |
|GAAP selling, general and administrative expenses |$ |1,095 |$ |980 |$ |2,125 |$ |1,977 |
|Acquisition-related – other costs |— |(9 |) |— |(15 |) |
|Stock-based compensation expenses (1) |(81 |) |(129 |) |(149 |) |(233 |) |
|Other (2) |1 |(2 |) |1 |(5 |) |
|Non-GAAP selling, general and administrative expenses |$ |1,015 |$ |840 |$ |1,977 |$ |1,724 |
|**Operating margin reconciliation:** |
|GAAP operating margin |42\.7 |% |40\.4 |% |42\.6 |% |41\.3 |% |
|Up-front collaboration and licensing expenses |2\.9 |% |2\.8 |% |2\.7 |% |1\.5 |% |
|Acquisition-related – amortization of purchased intangibles |4\.8 |% |5\.3 |% |5\.1 |% |5\.6 |% |
|Acquisition-related – other costs |— |% |0\.3 |% |— |% |0\.4 |% |
|Stock-based compensation expenses |3\.1 |% |4\.5 |% |2\.9 |% |4\.4 |% |
|Other (2) |— |% |— |% |— |% |0\.1 |% |
|Non-GAAP operating margin (4) |53\.5 |% |53\.3 |% |53\.1 |% |53\.2 |% |
|**Other income (expense), net reconciliation:** |
|GAAP other income (expense), net |$ |228 |$ |72 |$ |595 |$ |242 |
|Unrealized (gains) losses from equity securities, net |(57 |) |64 |(254 |) |19 |
|Non-GAAP other income (expense), net |$ |171 |$ |136 |$ |341 |$ |261 |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION - (Continued)** |
|**(unaudited)** |
|**(in millions, except percentages and per share amounts)** |
|**Three Months Ended** |**Six Months Ended** |
|**June 30,** |**June 30,** |
|**2019** |**2018** |**2019** |**2018** |
|**Effective tax rate reconciliation:** |
|GAAP effective tax rate |22\.2 |% |12\.8 |% |19\.3 |% |18\.5 |% |
|Up-front collaboration and licensing expenses |— |% |0\.7 |% |0\.2 |% |0\.1 |% |
|Acquisition-related – amortization of purchased intangibles |(1.5 |)% |(0.8 |)% |(1.2 |)% |(1.5 |)% |
|Acquisition-related – other costs |— |% |0\.1 |% |— |% |— |% |
|Stock-based compensation expenses (1) |— |% |0\.7 |% |0\.1 |% |0\.5 |% |
|Unrealized (gains) losses from equity securities, net |0\.8 |% |(0.4 |)% |1\.1 |% |(0.1 |)% |
|Tax Reform adjustments (3) |— |% |0\.5 |% |— |% |0\.2 |% |
|Non-GAAP effective tax rate (4) |21\.5 |% |13\.4 |% |19\.2 |% |17\.8 |% |
|**Net income attributable to Gilead reconciliation:** |
|GAAP net income attributable to Gilead |$ |1,880 |$ |1,817 |$ |3,855 |$ |3,355 |
|Up-front collaboration and licensing expenses |128 |125 |226 |125 |
|Acquisition-related – amortization of purchased intangibles |252 |281 |512 |562 |
|Acquisition-related – other costs |— |14 |— |32 |
|Stock-based compensation expenses (1) |135 |202 |252 |362 |
|Unrealized (gains) losses from equity securities, net |(63 |) |63 |(254 |) |18 |
|Tax Reform adjustments (3) |— |(10 |) |— |(10 |) |
|Other (2) |(1 |) |2 |(2 |) |8 |
|Non-GAAP net income attributable to Gilead |$ |2,331 |$ |2,494 |$ |4,589 |$ |4,452 |
|**Diluted earnings per share reconciliation:** |
|GAAP diluted earnings per share |$ |1\.47 |$ |1\.39 |$ |3\.01 |$ |2\.55 |
|Up-front collaboration and licensing expenses |0\.10 |0\.10 |0\.18 |0\.10 |
|Acquisition-related – amortization of purchased intangibles |0\.20 |0\.21 |0\.40 |0\.43 |
|Acquisition-related – other costs |— |0\.01 |— |0\.02 |
|Stock-based compensation expenses (1) |0\.11 |0\.15 |0\.20 |0\.28 |
|Unrealized (gains) losses from equity securities, net |(0.05 |) |0\.05 |(0.20 |) |0\.01 |
|Tax Reform adjustments (3) |— |(0.01 |) |— |(0.01 |) |
|Other (2) |— |— |— |0\.01 |
|Non-GAAP diluted earnings per share (4) |$ |1\.82 |$ |1\.91 |$ |3\.58 |$ |3\.39 |
|**Non-GAAP adjustment summary:** |
|Cost of goods sold adjustments |$ |286 |$ |321 |$ |583 |$ |635 |
|Research and development expenses adjustments |244 |271 |430 |394 |
|Selling, general and administrative expenses adjustments |80 |140 |148 |253 |
|Other income (expense), net adjustments |(57 |) |64 |(254 |) |19 |
|Total non-GAAP adjustments before tax |553 |796 |907 |1,301 |
|Income tax effect |(102 |) |(109 |) |(173 |) |(194 |) |
|Tax Reform adjustments (3) |— |(10 |) |— |(10 |) |
|Total non-GAAP adjustments after tax |$ |451 |$ |677 |$ |734 |$ |1,097 |

|Notes: |
| --- | --- |
|(1) |The decreases were primarily due to stock-based compensation expenses incurred in 2018 following Gilead’s acquisition of Kite Pharma, Inc. |
|(2) |Amounts represent restructuring, contingent consideration and/or other individually insignificant amounts |
|(3) |Amounts represent measurement period adjustments relating to the enactment of the 2017 Tax Cuts and Jobs Act (Tax Reform) |
|(4) |Amounts may not sum due to rounding |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP 2019 FULL YEAR GUIDANCE** |
|**(unaudited)** |
|**(in millions, except percentages and per share amounts)** |
|**Initially Provided
February 4, 2019
Reiterated
May 2, 2019** |**Updated
July 30, 2019** |
|**Projected product gross margin GAAP to non-GAAP reconciliation:** |
|GAAP projected product gross margin |80% - 81% |80% - 81% |
|Acquisition-related expenses |5% - 6% |5% - 6% |
|Non-GAAP projected product gross margin (1) |85% - 87% |85% - 87% |
|**Projected research and development expenses GAAP to non-GAAP reconciliation:** |
|GAAP projected research and development expenses (2) |$4,195 - $4,480 |$8,290 - $8,595 |
|Stock-based compensation expenses |(345) - (380) |(290) - (325) |
|Up-front collaboration and licensing expenses (2) |(250) - (300) |(4,400) - (4,470) |
|Non-GAAP projected research and development expenses |$3,600 - $3,800 |$3,600 - $3,800 |
|**Projected selling, general and administrative expenses GAAP to non-GAAP reconciliation:** |
|GAAP projected selling, general and administrative expenses |$4,255 - $4,490 |$4,205 - $4,440 |
|Stock-based compensation expenses |(355) - (390) |(305) - (340) |
|Non-GAAP projected selling, general and administrative expenses |$3,900 - $4,100 |$3,900 - $4,100 |
|**Projected effective tax rate GAAP to non-GAAP reconciliation:** |
|GAAP projected effective tax rate (3) |21\.5% - 22.5% |21\.5% - 22.5% |
|Tax rate effect of adjustments noted above (3) |(1.5%) - (1.5%) |(1.5%) - (1.5%) |
|Non-GAAP projected effective tax rate |20\.0% - 21.0% |20\.0% - 21.0% |
|**Projected diluted EPS impact of acquisition-related, up-front collaboration and licensing, stock-based compensation and other expenses (2)(3) :** |
|Acquisition-related expenses / up-front collaboration and licensing expenses (2) |$0.93 - $0.97 |$3.47 - $3.51 |
|Stock-based compensation expenses |$0.47 - $0.53 |$0.43 - $0.49 |
|Projected diluted EPS impact of acquisition-related, up-front collaboration and licensing, stock-based compensation and other expenses (2)(3) |$1.40 - $1.50 |$3.90 - $4.00 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- |
|Notes: |
|(1) |Total stock-based compensation expenses have a less than one percent impact on non-GAAP projected product gross margin |
|(2) |Updates made primarily for the collaboration with Galapagos, which is expected to close late in the third quarter of 2019, subject to a number of closing conditions, including antitrust clearances required by the U.S. Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the rules and regulations promulgated thereunder and receipt of merger control approval from the Austrian Federal Competition Authority. |
|(3) |Excludes fair value adjustments of equity securities and the associated income tax effect, as Gilead is unable to project future fair value adjustments, and other discrete tax charges or benefits |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- |
|**CONDENSED CONSOLIDATED BALANCE SHEETS** |
|**(unaudited)** |
|**(in millions)** |
|**June 30,** |**December 31,** |
|**2019** |**2018** |
|Cash, cash equivalents and marketable securities |$ |30,234 |$ |31,512 |
|Accounts receivable, net |3,396 |3,327 |
|Inventories |884 |814 |
|Property, plant and equipment, net |4,249 |4,006 |
|Intangible assets, net |15,152 |15,738 |
|Goodwill |4,117 |4,117 |
|Other assets |5,178 |4,161 |
|Total assets |$ |63,210 |$ |63,675 |
|Current liabilities |$ |8,961 |$ |10,605 |
|Long-term liabilities |31,498 |31,536 |
|Stockholders’ equity (1) |22,751 |21,534 |
|Total liabilities and stockholders’ equity |$ |63,210 |$ |63,675 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- |
|Note: |
|(1) |As of June 30, 2019, there were 1,267 million shares of common stock issued and outstanding |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**PRODUCT SALES SUMMARY** |
|**(unaudited)** |
|**(in millions)** |
|**Three Months Ended** |**Six Months Ended** |
|**June 30,** |**June 30,** |
|**2019** |**2018** |**2019** |**2018** |
|Atripla – U.S. |$ |122 |$ |274 |$ |255 |$ |502 |
|Atripla – Europe |26 |39 |42 |90 |
|Atripla – Other International |4 |36 |26 |71 |
|152 |349 |323 |663 |
|Biktarvy – U.S. |1,023 |183 |1,762 |218 |
|Biktarvy – Europe |73 |2 |121 |2 |
|Biktarvy – Other International |20 |— |26 |— |
|1,116 |185 |1,909 |220 |
|Complera / Eviplera – U.S. |42 |82 |86 |149 |
|Complera / Eviplera – Europe |72 |103 |134 |212 |
|Complera / Eviplera – Other International |9 |14 |18 |28 |
|123 |199 |238 |389 |
|Descovy – U.S. |246 |311 |479 |585 |
|Descovy – Europe |69 |78 |137 |153 |
|Descovy – Other International |43 |14 |84 |26 |
|358 |403 |700 |764 |
|Genvoya – U.S. |733 |904 |1,461 |1,757 |
|Genvoya – Europe |177 |207 |370 |393 |
|Genvoya – Other International |70 |49 |164 |92 |
|980 |1,160 |1,995 |2,242 |
|Odefsey – U.S. |266 |303 |548 |582 |
|Odefsey – Europe |111 |77 |217 |135 |
|Odefsey – Other International |10 |5 |19 |10 |
|387 |385 |784 |727 |
|Stribild – U.S. |78 |144 |145 |277 |
|Stribild – Europe |24 |34 |42 |63 |
|Stribild – Other International |6 |9 |17 |21 |
|108 |187 |204 |361 |
|Truvada – U.S. |657 |649 |1,208 |1,156 |
|Truvada – Europe |41 |86 |74 |183 |
|Truvada – Other International |20 |30 |42 |78 |
|718 |765 |1,324 |1,417 |
|Other HIV (1) – U.S. |9 |11 |20 |20 |
|Other HIV (1) – Europe |1 |3 |2 |4 |
|Other HIV (1) – Other International |5 |5 |10 |8 |
|15 |19 |32 |32 |
|Revenue share – Symtuza (2) – U.S. |55 |— |97 |— |
|Revenue share – Symtuza (2) – Europe |29 |13 |53 |20 |
|Revenue share – Symtuza (2) – Other International |— |— |— |— |
|84 |13 |150 |20 |
|Total HIV – U.S. |3,231 |2,861 |6,061 |5,246 |
|Total HIV – Europe |623 |642 |1,192 |1,255 |
|Total HIV – Other International |187 |162 |406 |334 |
|4,041 |3,665 |7,659 |6,835 |
|AmBisome – U.S. |10 |14 |18 |31 |
|AmBisome – Europe |60 |55 |117 |111 |
|AmBisome – Other International |35 |34 |63 |68 |
|105 |103 |198 |210 |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**PRODUCT SALES SUMMARY - (Continued)** |
|**(unaudited)** |
|**(in millions)** |
|**Three Months Ended** |**Six Months Ended** |
|**June 30,** |**June 30,** |
|**2019** |**2018** |**2019** |**2018** |
|Ledipasvir/Sofosbuvir (3) – U.S. |$ |86 |$ |230 |$ |203 |$ |464 |
|Ledipasvir/Sofosbuvir (3) – Europe |22 |22 |49 |78 |
|Ledipasvir/Sofosbuvir (3) – Other International |85 |79 |166 |137 |
|193 |331 |418 |679 |
|Letairis – U.S. |204 |244 |401 |448 |
|Ranexa – U.S. |19 |208 |174 |403 |
|Sofosbuvir/Velpatasvir (4) – U.S. |219 |239 |449 |508 |
|Sofosbuvir/Velpatasvir (4) – Europe |156 |168 |310 |366 |
|Sofosbuvir/Velpatasvir (4) – Other International |118 |93 |225 |162 |
|493 |500 |984 |1,036 |
|Vemlidy – U.S. |71 |59 |136 |106 |
|Vemlidy – Europe |5 |3 |9 |6 |
|Vemlidy – Other International |40 |14 |72 |22 |
|116 |76 |217 |134 |
|Viread – U.S. |9 |16 |21 |23 |
|Viread – Europe |28 |32 |42 |62 |
|Viread – Other International |38 |34 |84 |94 |
|75 |82 |147 |179 |
|Vosevi – U.S. |53 |86 |98 |172 |
|Vosevi – Europe |15 |20 |31 |36 |
|Vosevi – Other International |7 |3 |9 |8 |
|75 |109 |138 |216 |
|Yescarta – U.S. |99 |68 |189 |108 |
|Yescarta – Europe |21 |— |27 |— |
|Yescarta – Other International |— |— |— |— |
|120 |68 |216 |108 |
|Zydelig – U.S. |12 |17 |23 |31 |
|Zydelig – Europe |14 |22 |29 |40 |
|Zydelig – Other International |— |— |1 |1 |
|26 |39 |53 |72 |
|Other (5) – U.S. |41 |27 |77 |56 |
|Other (5) – Europe |97 |41 |117 |56 |
|Other (5) – Other International |2 |47 |8 |109 |
|140 |115 |202 |221 |
|Total product sales – U.S. |4,054 |4,069 |7,850 |7,596 |
|Total product sales – Europe |1,041 |1,005 |1,923 |2,010 |
|Total product sales – Other International |512 |466 |1,034 |935 |
|$ |5,607 |$ |5,540 |$ |10,807 |$ |10,541 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- |
|Notes: |
|(1) |Includes Emtriva and Tybost |
|(2) |Represents Gilead’s revenue from cobicistat (C), emtricitabine (FTC) and tenofovir alafenamide (TAF) in Symtuza (darunavir/C/FTC/TAF), a fixed dose combination product commercialized by Janssen Sciences Ireland UC |
|(3) |Amounts consist of sales of Harvoni and the authorized generic version of Harvoni sold by Gilead’s separate subsidiary, Asegua Therapeutics LLC |
|(4) |Amounts consist of sales of Epclusa and the authorized generic version of Epclusa sold by Gilead’s separate subsidiary, Asegua Therapeutics LLC |
|(5) |Includes Cayston, Hepsera and Sovaldi. In Europe, the increase for both the three and six months ended June 30, 2019 was primarily due to approximately $80 million of favorable adjustments for statutory rebates related to sales of Sovaldi made in prior years |

View source version on businesswire.com: <https://www.businesswire.com/news/home/20190730005933/en/>

Source: Gilead Sciences, Inc.

**Investors** Robin Washington
(650) 522-5688
Sung Lee
(650) 524-7792

**Media** Amy Flood
(650) 522-5643

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Second Quarter 2019 Financial Results&body=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Second Quarter 2019 Financial Results&url=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results&via=Gilead)

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Second Quarter 2019 Financial Results&body=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Second Quarter 2019 Financial Results&url=https://www.gilead.com/news/news-details/2019/gilead-sciences-announces-second-quarter-2019-financial-results&via=Gilead)

## Other News

_Some of the content on this page is not intended for users outside the U.S._

View All

No Results Found

Loading Results...

### Discover More

##### Therapeutic Areas

##### Research

##### Giving@Gilead

This is our global website, intended for visitors seeking information on Gilead’s worldwide business. Some content on this site is not intended for people outside the United States. Visit our Global Operations page for links to our international corporate websites.

* [](https://twitter.com/GileadSciences)
* [](https://www.linkedin.com/company/gilead-sciences/)
* [](https://www.instagram.com/gileadsciences/)
* [](https://www.facebook.com/GileadSciences)
* [](https://www.youtube.com/channel/UCNSt7PtsfNGbezR9hmvRI1w)

### QUICK LINKS

* [Investors](https://investors.gilead.com/overview/default.aspx)
* [Find a Trial](https://www.gileadclinicaltrials.com)
* Pipeline
* [Search for Jobs](https://gilead.wd1.myworkdayjobs.com/gileadcareers)
* News
* Stories@Gilead

### GET IN TOUCH

* Contact Us
* Report an Adverse Event
* [Medical Information](https://www.askgileadmedical.com)
* Partnership Request

### LEGAL

* [Modern Slavery Act Statement](https://www.gilead.com/-/media/files/pdfs/company/policies-and-disclosures/modern-slavery-statement.pdf)
* Public Policy Engagement
* Social Media Guidelines
* Privacy Statement
* Consumer Health Data Privacy Policy
* Terms of Use
* Cookie Statement

* * *