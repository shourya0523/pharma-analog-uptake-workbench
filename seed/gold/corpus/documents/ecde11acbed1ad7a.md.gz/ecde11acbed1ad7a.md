EX-99.1 2 a11-21733\_1ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: Andrew Fisher

(202) 483-7000

Afisher@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**SECOND QUARTER 2011 FINANCIAL RESULTS**

· **Total Revenues of $183.8 million**

· **Earnings per Share of $1.27 per Basic Share or $1.18 per Diluted Share**

· **Earnings Before Non-Cash Charges of $1.61 per Basic Share, or $1.49 per Diluted Share**

Silver Spring, MD, July 28, 2011: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the quarter ended June 30, 2011.

“I’m pleased with the successful unblinding of the FREEDOM-M study this quarter, as well as the very good operating results we achieved,” remarked Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “We remain on track to reach our 2011 forecast for revenues of $750 million, with a plus/minus margin of 5 percent.”

Total revenues for the quarter ended June 30, 2011 were $183.8 million, up from $134.7 million for the quarter ended June 30, 2010.  Net income for the quarter ended June 30, 2011, was $73.9 million, or $1.27 per basic share, compared to $37.7 million, or $0.67 per basic share, for the same quarter in 2010. Gross margin from sales was $162.4 million for the quarter ended June 30, 2011, compared to $119.2 million for the same quarter last year. Earnings before non-cash charges(1) for the quarter ended June 30, 2011 were $93.5 million, compared to $65.7 million for the quarter ended June 30, 2010.

Results for the three- and six-month periods ended June 30, 2011 and June 30, 2010 do not include the results of Medicomp, Inc., our former telemedicine subsidiary, which we sold during the first quarter of 2011. The results of Medicomp, Inc. have been reported within discontinued operations on our consolidated statements of operations below.

* * *

(1) See definition of earnings before non-cash charges, a non-GAAP financial measure, and a reconciliation of net income to earnings before non-cash charges below.

* * *  
**Financial Results for the Three Months Ended June 30, 2011**

_Revenues_

The table below summarizes the components of net revenues (dollars in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
| | | | | | | | |
|Cardiopulmonary products: | | | | | | | |
|Remodulin | |$ |104,894 | |$ |96,367 | |8\.8 |% |
|Tyvaso | |61,809 | |29,483 | |109\.6 |% |
|Adcirca | |16,843 | |8,589 | |96\.1 |% |
|Other | |205 | |282 | |(27.3 |)% |
|Total net revenues | |$ |183,751 | |$ |134,721 | |36\.4 |% |

Revenues for the quarter ended June 30, 2011 increased by $49.0 million, compared to the quarter ended June 30, 2010. The growth in revenues primarily reflects the increase in the number of patients being prescribed our products.

_Expenses_

The table below summarizes research and development expense by major project and non-project components (dollars in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
| | | | | | | | |
|**Project and non-project component:** | | | | | | | |
|Cardiopulmonary | |$ |24,490 | |$ |18,619 | |31\.5 |% |
|Share-based compensation | |(9,555 |) |1,420 | |(772.9 |)% |
|Other | |9,305 | |8,548 | |8\.9 |% |
|Total research and development expense | |$ |24,240 | |$ |28,587 | |(15.2 |)% |

_Cardiopulmonary._ The increase in expenses related to our cardiopulmonary projects for the quarter ended June 30, 2011 was attributable largely to increases in expenses related to our FREEDOM-C 2 and FREEDOM-M clinical trials and our development of beraprost-MR.

_Share-based compensation._ The decrease in share-based compensation for the quarter ended June 30, 2011, compared to the same quarter in 2010, corresponded to a reduction in share-based compensation recognized in connection with our share tracking awards plans as a result of the decrease in our stock price.

* * *  
The table below summarizes selling, general and administrative expense by major categories (in thousands):

| | |**Three Months Ended  
June 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
|**Category:** | | | | | | | |
|General and administrative | |$ |24,268 | |$ |18,754 | |29\.4 |% |
|Sales and marketing | |17,072 | |12,900 | |32\.3 |% |
|Share-based compensation | |(17,484 |) |(2,000 |) |(774.2 |)% |
|Total selling, general and administrative expense | |$ |23,856 | |$ |29,654 | |(19.6 |)% |

_General and administrative._ The increase in general and administrative expenses for the quarter ended June 30, 2011, compared to the same quarter in 2010, corresponded principally to increases in professional fees in connection with various completed and prospective transactions, and travel expenses, as a result of our growth and increase in business development activities.

_Sales and marketing._ The increase in sales and marketing expenses for the quarter ended June 30, 2011, compared to the quarter ended June 30, 2010, was attributable to an increase in salaries, as we recently expanded our sales force, and an increase in professional fees in connection with our marketing and advertising initiatives.

_Share-based compensation._ The decrease in share-based compensation for the quarter ended June 30, 2011, compared to the same quarter in 2010, reflects a reduction in share-based compensation recognized in connection with our share tracking awards plans as a result of the decrease in our stock price.

**2011 Revenue Guidance**

We reaffirm our full-year revenue guidance for our three commercial products (Remodulin, Tyvaso and Adcirca), and we continue to expect related revenues to fall within a range of 5% above or below $750 million for 2011.

* * *  
**Earnings Before Non-Cash Charges**

Earnings before non-cash charges is defined as net income, adjusted for the following non-cash charges, as applicable: (1) interest; (2) income taxes; (3) license fees; (4) depreciation and amortization; (5) impairment charges; and (6) share-based compensation (stock option and share tracking award expense).

A reconciliation of net income to earnings before non-cash charges is presented below (in thousands, except per share data):

| | |**Three Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |
| | | | | | |
|Net income, as reported | |$ |73,891 | |$ |37,707 | |
|Adjust for non-cash charges: | | | | | |
|Interest expense | |5,431 | |4,759 | |
|Income tax expense | |35,723 | |19,212 | |
|License fees | |— | |— | |
|Depreciation and amortization | |4,837 | |4,582 | |
|Impairment charges | |609 | |— | |
|Share-based compensation | |(27,037 |) |(574 |) |
|Earnings before non-cash charges | |$ |93,454 | |$ |65,686 | |
| | | | | | |
|Earnings before non-cash charges per share: | | | | | |
|Basic | |$ |1\.61 | |$ |1\.17 | |
|Diluted | |$ |1\.49 | |$ |1\.09 | |
| | | | | | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |58,180 | |56,047 | |
|Diluted | |62,756 | |60,393 | |

* * *  
**Conference Call**

We will host a half-hour teleconference on Thursday, July 28, 2011, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-800-642-1687, with international callers dialing 1-706-645-9291 and using access code 80689472.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of unique products to address the unmet medical needs of patients with chronic and life-threatening conditions.

**Non-GAAP Financial Information**

This press release contains a financial measure, earnings before non-cash charges, that does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use earnings before non-cash charges to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) evaluating our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure enhances investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. In addition, we have historically reported earnings before non-cash charges to investors, and believe the inclusion of this non-GAAP financial measure provides investors with a consistent method of comparison to historical periods. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to earnings before non-cash charges can be found in the table above under the heading, _Earnings Before Non-Cash Charges_ .

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, our expectations about future operating results and the demand for our products, including our guidance for annual revenues. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K.  We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of July 28, 2011, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason. [uthr-g]

Remodulin and Tyvaso are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In thousands, except per share data)**

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**2011** | |**2010** | |
| | |**(Unaudited)** | |**(Unaudited)** | |
|Revenues: | | | | | | | | | |
|Net product sales | |$ |183,546 | |$ |134,439 | |$ |345,764 | |$ |260,071 | |
|License fees | |205 | |282 | |499 | |564 | |
|Total revenues | |183,751 | |134,721 | |346,263 | |260,635 | |
|Operating expenses: | | | | | | | | | |
|Research and development | |24,240 | |28,587 | |71,947 | |63,055 | |
|Selling, general and administrative | |23,856 | |29,654 | |82,118 | |75,106 | |
|Cost of product sales | |21,162 | |15,261 | |40,900 | |28,984 | |
|Total operating expenses | |69,258 | |73,502 | |194,965 | |167,145 | |
|Operating income | |114,493 | |61,219 | |151,298 | |93,490 | |
|Other (expense) income: | | | | | | | | | |
|Interest income | |839 | |802 | |1,504 | |1,746 | |
|Interest expense | |(5,431 |) |(4,759 |) |(10,841 |) |(9,446 |) |
|Equity loss in affiliate | |(30 |) |(44 |) |(67 |) |(91 |) |
|Other, net | |(257 |) |93 | |(1,023 |) |318 | |
|Total other (expense) income, net | |(4,879 |) |(3,908 |) |(10,427 |) |(7,473 |) |
|Income from continuing operations before income taxes | |109,614 | |57,311 | |140,871 | |86,017 | |
|Income tax expense | |(35,723 |) |(19,345 |) |(47,622 |) |(29,106 |) |
|Income from continuing operations | |73,891 | |37,966 | |93,249 | |56,911 | |
|Discontinued operations: | | | | | | | | | |
|(Loss) income from discontinued operations, net of tax | |— | |(259 |) |76 | |(275 |) |
|Loss on disposal of discontinued operations, net of tax | |— | |— | |(3,044 |) |— | |
|Loss from discontinued operations | |— | |(259 |) |(2,968 |) |(275 |) |
|Net income | |$ |73,891 | |$ |37,707 | |$ |90,281 | |$ |56,636 | |
|Net income per common share: | | | | | | | | | |
|Basic | | | | | | | | | |
|Continuing operations | |$ |1\.27 | |$ |0\.68 | |$ |1\.61 | |$ |1\.03 | |
|Discontinued operations | |$ |0\.00 | |$ |(0.01 |) |$ |(0.05 |) |$ |(0.01 |) |
|Net income per basic common share | |$ |1\.27 | |$ |0\.67 | |$ |1\.56 | |$ |1\.02 | |
|Diluted | | | | | | | | | |
|Continuing operations | |$ |1\.18 | |$ |0\.63 | |$ |1\.49 | |$ |0\.96 | |
|Discontinued operations | |$ |0\.00 | |$ |(0.01 |) |$ |(0.05 |) |$ |(0.01 |) |
|Net income per diluted common share | |$ |1\.18 | |$ |0\.62 | |$ |1\.44 | |$ |0\.95 | |
|Weighted average number of common shares outstanding: | | | | | | | | | |
|Basic | |58,180 | |56,047 | |57,968 | |55,411 | |
|Diluted | |62,756 | |60,393 | |62,525 | |59,548 | |

* * *  
**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**June 30, 2011**

**(Unaudited, In thousands)**

|Cash, cash equivalents and marketable securities (excluding restricted amounts of $5.1 million) | |$ |887,417 | |
| --- | --- | --- | --- | --- |
|Total assets | |1,578,740 | |
|Total liabilities and common stock subject to repurchase | |576,397 | |
|Total stockholders’ equity | |1,002,343 | |

* * *