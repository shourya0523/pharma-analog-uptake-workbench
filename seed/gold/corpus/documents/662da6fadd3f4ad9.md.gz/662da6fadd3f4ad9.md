EX-99.1 2 a11-10880\_2ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: Andrew Fisher

(202) 483-7000

Afisher@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**FIRST QUARTER 2011 FINANCIAL RESULTS**

· **Total Revenues of $165.6 million**

· **Earnings per Share of $0.28 per Basic Share or $0.26 per Diluted Share**

· **Earnings Before Non-Cash Charges of $1.40 per Basic Share, or $1.29 per Diluted Share**

Silver Spring, MD, April 28, 2011: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the first quarter ended March 31, 2011.

“I’m very pleased that we are cruising at a two-thirds of a billion dollar revenue run rate, up almost 30% from a year ago,” remarked Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “As we now have a year’s experience with our product launches, we feel comfortable providing top line guidance for the first time.  Specifically, we are forecasting $750 million, $875 million and $1 billion in revenues for calendar years 2011, 2012 and 2013, respectively, with a plus/minus margin of 5% in each case.  Although we are excited about the upcoming unblinding of our FREEDOM M and C-Squared oral treprostinil studies, this guidance conservatively excludes any revenue contribution from that highly promising treatment.”

Total revenues for the quarter ended March 31, 2011, were $165.6 million, up from $128.9 million for the quarter ended March 31, 2010.  Net income for the quarter ended March 31, 2011, was $16.4 million or $0.28 per basic share, compared to $18.9 million or $0.35 per basic share for the same quarter in 2010. Gross margin from sales was $143.9 million for the quarter ended March 31, 2011, compared to $113.7 million for the same quarter last year. Earnings before non-cash charges(1) for the quarter ended March 31, 2011, were $80.7 million, compared to $68.1 million for the quarter ended March 31, 2010.

* * *

(1)  See definition of earnings before non-cash charges, a non-GAAP financial measure, and a reconciliation of net income to earnings before non-cash charges below.

* * *  
**Financial Results for the Three Months Ended March 31, 2011**

**_Revenues_**

The table below summarizes the components of net revenues (dollars in thousands):

| | |**Three Months Ended** **  
** **March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
| | | | | | | | |
|Cardiopulmonary products: | | | | | | | |
|Remodulin | |$ |103,205 | |$ |95,769 | |7\.8 |% |
|Tyvaso | |47,695 | |24,884 | |91\.7 |% |
|Adcirca | |11,318 | |4,979 | |127\.3 |% |
|Telemedicine services and products | |3,107 | |2,966 | |4\.8 |% |
|Other | |294 | |282 | |4\.3 |% |
|Total net revenues | |$ |165,619 | |$ |128,880 | |28\.5 |% |

Revenues for the quarter ended March 31, 2011, increased by $36.7 million, compared to the quarter ended March 31, 2010. The growth in revenues predominately reflects the increase in the number of patients being prescribed our products.

The table below summarizes research and development expense by major project and non-project components (dollars in thousands):

| | |**Three Months Ended** **  
** **March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
| | | | | | | | |
|**Project and non-project component:** | | | | | | | |
|Cardiopulmonary | |$ |23,744 | |$ |17,400 | |36\.5 |% |
|Share-based compensation | |14,841 | |10,536 | |40\.9 |% |
|Other | |9,445 | |6,935 | |36\.2 |% |
|Total research and development expense | |$ |48,030 | |$ |34,871 | |37\.7 |% |

_Cardiopulmonary._ The increase in expenses related to our cardiopulmonary projects for the quarter ended March 31, 2011 compared to the quarter ended March 31, 2010, was attributable largely to activities related to our FREEDOM-C 2 and FREEDOM-M clinical trials.

_Share-based compensation._ The increase in share-based compensation for the quarter ended March 31, 2011, compared to the same quarter in 2010, corresponded to the increase in share-based compensation recognized in connection with our share tracking awards plans.

_Other._ The increase in other research and development expenses for the quarter ended March 31, 2011, compared to the same quarter in 2010, primarily reflects increases in costs related to our monoclonal antibody development and overhead supporting our various research projects.

* * *  
The table below summarizes selling, general and administrative expense by major categories (in thousands):

| | |**Three Months Ended** **  
** **March 31,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |**Change** | |
| | | | | | | | |
|**Category:** | | | | | | | |
|General and administrative | |$ |22,268 | |$ |17,113 | |30\.1 |% |
|Sales and marketing | |15,061 | |10,293 | |46\.3 |% |
|Share-based compensation | |21,906 | |19,471 | |12\.5 |% |
|Total selling, general and administrative expense | |$ |59,235 | |$ |46,877 | |26\.4 |% |

_General and administrative._ The increase in general and administrative expenses for the quarter ended March 31, 2011, compared to the same quarter in 2010, corresponded principally to increases in head count and travel expenses, as a result of the growth of our business and increase in business development activities.

_Sales and marketing._ The increase in sales and marketing expenses for the quarter ended March 31, 2011, compared to the quarter ended March 31, 2010, was attributable to an increase in salaries as we recently expanded our sales force in the fourth quarter of 2010.

_Share-based compensation._ The increase in share-based compensation for the quarter ended March 31, 2011, compared to the same quarter in 2010, reflects the increase in share-based compensation recognized in connection with our share tracking awards plans.

**2011-2013 Revenue Guidance**

We currently expect full-year revenues from our three commercial products (Remodulin, Tyvaso and Adcirca) to fall within a range of 5% above or below $750 million in 2011, $875 million in 2012 and $1 billion in 2013.

These expectations do not include projected revenues from oral treprostinil or our other investigative products.  Guidance for 2012 and 2013 is subject to greater variability and uncertainty than the guidance for 2011. As a result, we anticipate reaffirming or updating all of these expectations on an annual basis when we present full-year results, and reaffirming or updating current-year guidance when we present our quarterly results.

* * *  
**Earnings Before Non-Cash Charges**

Earnings before non-cash charges is defined as net income, adjusted for the following non-cash charges, as applicable: (1) interest; (2) income taxes; (3) license fees; (4) depreciation and amortization; (5) impairment charges; and (6) share-based compensation (stock option and share tracking award expense).

A reconciliation of net income to earnings before non-cash charges is presented below (in thousands, except per share data):

| | |**Three Months Ended** **  
** **March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |
| | | | | | |
|Net income, as reported | |$ |16,390 | |$ |18,929 | |
|Adjust for non-cash charges: | | | | | |
|Interest expense | |5,413 | |4,687 | |
|Income tax expense | |10,436 | |9,752 | |
|License fees | |— | |— | |
|Depreciation and amortization | |5,809 | |4,570 | |
|Impairment charges (1) | |5,814 | |— | |
|Share-based compensation | |36,856 | |30,125 | |
|Earnings before non-cash charges | |$ |80,718 | |$ |68,063 | |
| | | | | | |
|Earnings before non-cash charges per share: | | | | | |
|Basic | |$ |1\.40 | |$ |1\.24 | |
|Diluted | |$ |1\.29 | |$ |1\.13 | |
| | | | | | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |57,753 | |54,769 | |
|Diluted | |62,623 | |60,019 | |

* * *

(1) Includes a $5.3 million non-cash loss recognized in connection with the sale of Medicomp, Inc., our wholly owned telemedicine subsidiary, on March 31, 2011.

* * *  
**Conference Call**

We will host a half-hour teleconference on Thursday, April 28, 2011, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-800-642-1687, with international callers dialing 1-706-645-9291 and using access code 56250172.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of unique products to address the unmet medical needs of patients with chronic and life-threatening conditions.

**Non-GAAP Financial Information**

This press release contains a financial measure, earnings before non-cash charges, that does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use earnings before non-cash charges to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) evaluating our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure enhances investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. In addition, we have historically reported earnings before non-cash charges to investors, and believe the inclusion of this non-GAAP financial measure provides investors with a consistent method of comparison to historical periods. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by other companies. The presentation of this non-GAAP financial measure should not to be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to earnings before non-cash charges can be found in the table above under the heading, _Earnings Before Non-Cash Charges_ .

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, our expectations about future operating results and the demand for our products, including specifically, our guidance for annual revenues in 2011, 2012 and 2013, as well as statements regarding our progress toward the development of an oral prostacyclin therapy and the timing of unblinding our FREEDOM-M and FREEDOM-C 2 studies. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K.  We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of April 28, 2011, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason. [uthr-g]

Remodulin and Tyvaso are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In thousands, except per share data)**

| | |**Three Months Ended** **  
** **March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2011** | |**2010** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |162,243 | |$ |125,675 | |
|Service sales | |3,082 | |2,923 | |
|License fees | |294 | |282 | |
|Total revenues | |165,619 | |128,880 | |
|Operating expenses: | | | | | |
|Research and development | |48,030 | |34,871 | |
|Selling, general and administrative | |59,235 | |46,877 | |
|Cost of product sales | |19,754 | |13,736 | |
|Cost of service sales | |1,717 | |1,150 | |
|Total operating expenses | |128,736 | |96,634 | |
|Income from operations | |36,883 | |32,246 | |
|Other income (expense): | | | | | |
|Interest income | |666 | |944 | |
|Interest expense | |(5,413 |) |(4,687 |) |
|Equity loss in affiliate | |(37 |) |(47 |) |
|Other, net | |(5,273 |) |225 | |
|Total other (expense) income, net | |(10,057 |) |(3,565 |) |
|Income before income tax | |26,826 | |28,681 | |
|Income tax expense | |(10,436 |) |(9,752 |) |
|Net income | |$ |16,390 | |$ |18,929 | |
|Net income per common share: | | | | | |
|Basic | |$ |0\.28 | |$ |0\.35 | |
|Diluted | |$ |0\.26 | |$ |0\.32 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |57,753 | |54,769 | |
|Diluted | |62,623 | |60,019 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**March 31, 2011**

**(Unaudited, In thousands)**

|Cash, cash equivalents and marketable securities (excluding restricted amounts of $5.1 million) | |$ |824,622 | |
| --- | --- | --- | --- | --- |
|Total assets | |1,485,404 | |
|Total liabilities and common stock subject to repurchase | |561,195 | |
|Total stockholders’ equity | |924,209 | |

* * *