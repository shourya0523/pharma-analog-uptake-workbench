10-Q 1 a05-12577\_110q.htm 10-Q **SECURITIES AND EXCHANGE COMMISSION**

**WASHINGTON,
D.C. 20549**

**FORM 10-Q**

|**(Mark One)** | | |
| --- | --- | --- |
|x | |**QUARTERLY REPORT PURSUANT TO
SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934.** |
|**For the
quarterly period ended June 30, 2005** |
|**OR** |
|o | |**TRANSITION REPORT PURSUANT TO SECTION 13 OR
15(d) OF THE SECURITIES EXCHANGE ACT OF 1934.** |

**For
the transition period from
                  to**

**Commission
file number 0-26301**

**United Therapeutics Corporation**

(Exact Name of Registrant
as Specified in Its Charter)

|**Delaware** | |**52-1984749** |
| --- | --- | --- |
|(State
or Other Jurisdiction of | |(I.R.S.
Employer |
|Incorporation
or Organization) | |Identification
No.) |
|**1110
Spring Street, Silver Spring, MD** | |**20910** |
|(Address
of Principal Executive Offices) | |(Zip
Code) |

**(301)
608-9292**

Registrant’s Telephone
Number, Including Area Code

(Former Name, Former
Address and Former Fiscal Year, If Changed Since Last Report)

Indicate by check mark
whether the registrant: (1) has filed all reports required to be filed by Section 13
or 15(d) of the Securities Exchange Act of 1934 during the preceding 12
months (or for such shorter period that the registrant was required to file
such reports), and (2) has been subject to such filing requirements for
the past 90 days.   Yes x No o

Indicate by check mark
whether the registrant is an accelerated filer (as defined in Rule 12b-2
of the Exchange Act).   Yes x No o

The number of shares
outstanding of the issuer’s common stock, par value $.01 per share, as of July 29,
2005 was 22,816,364.  
* * *  
| | | |**Page** |
| --- | --- | --- | --- | --- |
|**Part I. FINANCIAL INFORMATION (UNAUDITED)** | | |
|Item 1. | |Financial Statements | |1 |
| | |Consolidated Balance Sheets | |1 |
| | |Consolidated Statements of Operations | |2 |
| | |Consolidated Statements of Cash Flows | |3 |
| | |Notes to Consolidated Financial Statements | |4 |
|Item 2. | |Management’s Discussion and Analysis of Financial Condition and Results of Operations | |11 |
|Item 3. | |Quantitative and Qualitative Disclosures About Market Risk | |30 |
|Item 4. | |Controls and Procedures | |30 |
|**Part II. OTHER INFORMATION** | | |
|Item 4. | |Submission of Matters to a Vote of Security Holders | |31 |
|Item 6. | |Exhibits and Reports on Form 8-K | |31 |
|**SIGNATURES** | |32 |  
* * *  
**PART I. FINANCIAL INFORMATION**

**Item 1.        Financial
Statements**

**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED BALANCE SHEETS  
(In thousands, except share and per share data)**

| | |**June 30,  
2005** | |**December 31,  
2004** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**Assets** | |**(Unaudited)** | | | |
|Current assets: | | | | | | | | | |
|Cash and cash
equivalents | | |$ |56,533 | | | |$ |82,586 | | |
|Marketable
investments | | |38,690 | | | |200 | | |
|Accounts
receivable, net of allowance of $15 for 2005 and $23 for 2004 | | |15,448 | | | |13,743 | | |
|Interest
receivable | | |618 | | | |499 | | |
|Due from
affiliates | | |538 | | | |524 | | |
|Prepaid expenses | | |3,357 | | | |3,230 | | |
|Inventories, net | | |9,812 | | | |8,014 | | |
|Other current
assets | | |1,635 | | | |1,696 | | |
|Total current
assets | | |126,631 | | | |110,492 | | |
|Marketable
investments | | |56,268 | | | |46,233 | | |
|Marketable
investments and cash—restricted | | |10,290 | | | |10,121 | | |
|Goodwill, net | | |7,465 | | | |7,465 | | |
|Other intangible
assets, net | | |5,727 | | | |5,967 | | |
|Property, plant
and equipment, net | | |20,409 | | | |17,799 | | |
|Investments in
affiliates | | |6,279 | | | |7,444 | | |
|Notes receivable
from employees | | |— | | | |446 | | |
|Other assets | | |1,155 | | | |1,191 | | |
|Total assets | | |$ |234,224 | | | |$ |207,158 | | |
|**Liabilities and Stockholders’ Equity** | | | | | | | | | |
|Current liabilities: | | | | | | | | | |
|Accounts payable | | |$ |3,817 | | | |$ |6,098 | | |
|Accounts payable
to affiliates and related parties | | |64 | | | |29 | | |
|Accrued expenses | | |11,007 | | | |7,689 | | |
|Due to affiliates
and related parties | | |72 | | | |32 | | |
|Current portion of
notes and leases payable | | |795 | | | |16 | | |
|Total current
liabilities | | |15,755 | | | |13,864 | | |
|Notes and leases
payable, excluding current portion | | |14 | | | |10 | | |
|Other liabilities | | |1,657 | | | |1,648 | | |
|Total liabilities | | |17,426 | | | |15,522 | | |
|Commitments and contingencies | | | | | | | | | |
|Stockholders’ equity: | | | | | | | | | |
|Preferred stock,
par value $.01, 10,000,000 shares authorized, no shares issued | | |— | | | |— | | |
|Series A
junior participating preferred stock, par value $.01, 100,000 authorized, no
shares issued | | |— | | | |— | | |
|Common stock, par
value $.01, 100,000,000 shares authorized, 23,317,541 and 22,955,129 shares
issued at June 30, 2005 and December 31, 2004, respectively, and
22,790,851 and 22,428,529 outstanding at June 30, 2005 and
December 31, 2004, respectively | | |233 | | | |229 | | |
|Additional paid-in
capital | | |382,111 | | | |375,945 | | |
|Accumulated other
comprehensive income | | |1,826 | | | |2,677 | | |
|Treasury stock at
cost, 526,600 shares | | |(6,874 |) | | |(6,874 |) | |
|Accumulated
deficit | | |(160,498 |) | | |(180,341 |) | |
|Total
stockholders’ equity | | |216,798 | | | |191,636 | | |
|Total liabilities
and stockholders’ equity | | |$ |234,224 | | | |$ |207,158 | | |

See accompanying notes to consolidated financial statements.

1  
* * *  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS
OF OPERATIONS  
(In thousands, except per share data)  
(Unaudited)**

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Revenues: | | | | | | | | | |
|Net product sales | |$ |28,713 | |$ |17,329 | |$ |50,580 | |$ |29,975 | |
|Service sales | |1,279 | |970 | |2,487 | |2,007 | |
|License fees | |65 | |— | |197 | |— | |
|Total revenues | |30,057 | |18,299 | |53,264 | |31,982 | |
|Operating expenses: | | | | | | | | | |
|Research and development | |8,694 | |7,327 | |17,166 | |15,890 | |
|Selling, general and
administrative | |7,025 | |5,358 | |12,365 | |11,057 | |
|Cost of product sales | |2,653 | |1,603 | |4,673 | |2,942 | |
|Cost of service sales | |522 | |440 | |1,057 | |896 | |
|Total operating expenses | |18,894 | |14,728 | |35,261 | |30,785 | |
|Income from operations | |11,163 | |3,571 | |18,003 | |1,197 | |
|Other income (expense): | | | | | | | | | |
|Interest income | |1,201 | |674 | |2,182 | |1,323 | |
|Interest expense | |(1 |) |— | |(1 |) |(2 |) |
|Equity loss in affiliate | |(195 |) |(111 |) |(375 |) |(238 |) |
|Other, net | |13 | |6 | |34 | |13 | |
|Total other income, net | |1,018 | |569 | |1,840 | |1,096 | |
|Income before income tax | |12,181 | |4,140 | |19,843 | |2,293 | |
|Income tax expense | |— | |— | |— | |— | |
|Net income | |$ |12,181 | |$ |4,140 | |$ |19,843 | |$ |2,293 | |
|Net income per common share: | | | | | | | | | |
|Basic | |$ |0\.54 | |$ |0\.19 | |$ |0\.88 | |$ |0\.11 | |
|Diluted | |$ |0\.49 | |$ |0\.18 | |$ |0\.80 | |$ |0\.10 | |
|Weighted average
number of common shares outstanding: | | | | | | | | | |
|Basic | |22,694 | |21,391 | |22,593 | |21,360 | |
|Diluted | |24,997 | |23,146 | |24,849 | |23,070 | |

See accompanying notes to consolidated financial statements.

2  
* * *  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS
OF CASH FLOWS  
(In thousands)  
(Unaudited)**

| | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
|Cash flows from operating
activities: | | | | | |
|Net income | |$ |19,843 | |$ |2,293 | |
|Adjustments to
reconcile net income to net cash provided by operating activities: | | | | | |
|Depreciation and amortization | |1,260 | |1,137 | |
|Provision for bad debt | |39 | |40 | |
|Provision for inventory obsolescence | |(55 |) |172 | |
|Loss on disposals of equipment | |5 | |— | |
|Options issued in exchange for services | |332 | |207 | |
|Amortization of discount or premium on investments | |(56 |) |(52 |) |
|Equity loss in affiliate | |375 | |238 | |
|Changes in
operating assets and liabilities: | | | | | |
|Accounts receivable | |(1,744 |) |408 | |
|Interest receivable | |(119 |) |(5 |) |
|Inventories | |(1,743 |) |572 | |
|Prepaid expenses | |650 | |136 | |
|Other assets | |96 | |2,459 | |
|Accounts payable | |(2,281 |) |(1,680 |) |
|Accrued expenses | |3,319 | |2,134 | |
|Due to (from) affiliates | |507 | |48 | |
|Other liabilities | |(22 |) |(283 |) |
|Net cash provided by operating activities | |20,406 | |7,824 | |
|Cash flows from
investing activities: | | | | | |
|Purchases of property, plant and equipment | |(3,650 |) |(3,663 |) |
|Proceeds from disposals of property, plant &
equipment | |— | |816 | |
|Purchases of held-to-maturity investments | |(11,138 |) |— | |
|Purchases of available-for-sale investments | |(37,700 |) |— | |
|Maturities of held-to-maturity investments | |— | |(29,813 |) |
|Sales of available-for-sale investments | |200 | |30,000 | |
|Net cash used in investing activities | |(52,288 |) |(2,660 |) |
|Cash flows from
financing activities: | | | | | |
|Proceeds from the exercise of stock options | |5,839 | |1,517 | |
|Principal payments on notes payable and capital lease
obligations | |(10 |) |(762 |) |
|Net cash provided by financing activities | |5,829 | |755 | |
|Net increase (decrease) in cash and cash equivalents | |(26,053 |) |5,919 | |
|Cash and cash equivalents, beginning of period | |82,586 | |68,562 | |
|Cash and cash equivalents, end of period | |$ |56,533 | |$ |74,481 | |
|Supplemental
schedule of cash flow information: | | | | | |
|Cash paid for interest | |$ |1 | |$ |1 | |

See accompanying notes to consolidated financial statements.

3  
* * *  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED
FINANCIAL STATEMENTS  
June 30, 2005  
(Unaudited)**

**1\.
ORGANIZATION AND BUSINESS DESCRIPTION**

United Therapeutics Corporation (United Therapeutics)
is a biotechnology company focused on the development and commercialization of
unique products for patients with chronic and life-threatening cardiovascular,
cancer and infectious diseases. United Therapeutics was incorporated on June 26,
1996 under the laws of the State of Delaware and has the following wholly owned
subsidiaries: Lung Rx, Inc., Unither Pharmaceuticals, Inc. (UPI),
Unither Telemedicine Services Corp. (UTSC), Unither.com, Inc., United
Therapeutics Europe, Ltd., Unither Pharma, Inc., Medicomp, Inc.,
Unither Nutriceuticals, Inc. and Lung Rx, Ltd.

United Therapeutics’ lead product is Remodulin®. On May 21,
2002, the United States Food and Drug Administration (FDA) approved
Remodulin (treprostinil sodium) Injection for the treatment of pulmonary
arterial hypertension in patients with NYHA class II-IV symptoms to diminish
symptoms associated with exercise. United Therapeutics was required by the FDA
to perform a post-marketing Phase IV clinical study to further assess the
clinical benefits of Remodulin. Continued FDA approval of Remodulin is subject
to the diligent and timely completion of the Phase IV trial, as well as its
outcome. On November 24, 2004, the FDA approved intravenous infusion of
Remodulin, based on data establishing its bioequivalence with the subcutaneous
administration of Remodulin, for patients who are not able to tolerate a
subcutaneous infusion. This approval was also conditioned upon the diligent and
timely completion of the Phase IV trial, as well as its outcome. Several
international applications for the approval of Remodulin have been granted and
others are pending.

United Therapeutics has
generated pharmaceutical revenues from sales of Remodulin and arginine products
in the United States, Europe and Asia. In addition, United Therapeutics has
generated non-pharmaceutical revenues from telemedicine products and services
in the United States.

**2\. BASIS OF PRESENTATION**

The consolidated financial statements included herein
have been prepared, without audit, pursuant to Regulation S-X of the Securities
and Exchange Commission. Certain information and footnote disclosures normally
included in consolidated financial statements prepared in accordance with
accounting principles generally accepted in the United States have been
condensed or omitted pursuant to such rules and regulations. These consolidated
financial statements should be read in conjunction with the audited financial
statements and notes thereto contained in United Therapeutics’ Annual Report on
Form 10-K for the year ended December 31, 2004 as filed with the
Securities and Exchange Commission.

In the opinion of United Therapeutics’ management, any
adjustments contained in the accompanying unaudited consolidated financial
statements are of a normal recurring nature, necessary to present fairly the
financial position as of June 30, 2005 and results of operations and cash
flows for the three and six-month periods ended June 30, 2005 and 2004.
Interim results are not necessarily indicative of results for an entire year.

Certain amounts in the
2004 statement of operations were reclassified to conform to the 2005
presentation.

4

  
* * *

  
**3\. STOCKHOLDERS’ EQUITY**

**_Earnings per Common Share_**

Basic
earnings per common share is computed by dividing net income by the weighted
average number of shares of common stock outstanding during the respective
periods. Diluted earnings per common share is computed by dividing net income
by the weighted average number of shares of common stock outstanding during the
period plus the effects of outstanding stock options that could potentially
dilute earnings per share in the future. The effects of potentially dilutive
stock options were calculated using the treasury stock method. The components
of basic and dilutive earnings per share are as follows (in thousands, except
per share amounts):

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income
(Numerator) | |$ |12,181 | |$ |4,140 | |$ |19,843 | |$ |2,293 | |
|Shares
(Denominator): | | | | | | | | | |
|Weighted average outstanding shares for basic EPS | |22,694 | |21,391 | |22,593 | |21,360 | |
|Dilutive effect of stock options | |2,303 | |1,755 | |2,256 | |1,710 | |
|Adjusted weighted average shares for diluted EPS | |24,997 | |23,146 | |24,849 | |23,070 | |
|Earnings per
share | | | | | | | | | |
|Basic | |$ |0\.54 | |$ |0\.19 | |$ |0\.88 | |$ |0\.11 | |
|Diluted | |$ |0\.49 | |$ |0\.18 | |$ |0\.80 | |$ |0\.10 | |

**_Stock Option Plan_**

United Therapeutics accounts for its stock-based
compensation under the intrinsic value method in accordance with the provisions
of APB No. 25, _Accounting for Stock
Issued to Employees_ , and has provided the pro forma disclosures of
net income (loss) and net income (loss) per share in accordance with SFAS No. 123, _Accounting for Stock-Based Compensation_ ,
using the fair value method. Under APB No. 25, compensation expense for
stock options granted to employees is based on the difference, if any, on the
date of the grant between the fair value of United Therapeutics’ stock and the
exercise price of the option and is recognized ratably over the vesting period
of the option. United Therapeutics accounts for equity instruments issued to
consultants in accordance with SFAS No. 123 and Emerging Issues Task Force
Issue No. 96-18, _Accounting for Equity
Instruments that are Issued to Other than Employees for Acquiring, or in
Conjunction with Selling Goods or Services_ .

5

  
* * *

  
In
accordance with SFAS No. 148, _Accounting for Stock-Based
Compensation—Transition and Disclosure_ , the effect on net income
(loss) and net income (loss) per share if United Therapeutics had applied the
fair value recognition provisions of SFAS No. 123 to stock-based employee
compensation is as follows (in thousands, except per share amounts):

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income, as
reported | |$ |12,181 | |$ |4,140 | |$ |19,843 | |$ |2,293 | |
|Less total
stock-based employee compensation expense determined under fair value based
method for all awards | |(3,279 |) |(1,774 |) |(6,558 |) |(3,548 |) |
|Pro forma net
income (loss) | |$ |8,902 | |$ |2,366 | |$ |13,285 | |$ |(1,255 |) |
|Basic net income
(loss) per common share: | | | | | | | | | |
|As reported | |$ |0\.54 | |$ |0\.19 | |$ |0\.88 | |$ |0\.11 | |
|Pro forma | |$ |0\.39 | |$ |0\.11 | |$ |0\.59 | |$ |(0.06 |) |
|Diluted net
income (loss) per common share: | | | | | | | | | |
|As reported | |$ |0\.49 | |$ |0\.18 | |$ |0\.80 | |$ |0\.10 | |
|Pro forma | |$ |0\.36 | |$ |0\.10 | |$ |0\.53 | |$ |(0.05 |) |

The effect of applying SFAS No. 123 on 2005 and
2004 pro forma net income (loss) and net income (loss) per share as stated
above, is not necessarily representative of the effects on reported net income
for future years due to, among other things, the vesting period of the stock
options and the fair value of additional stock options that may be granted in
future years.

The Financial Accounting Standards Board has issued a
revision to SFAS No. 123 (SFAS 123(R)). SFAS 123(R) was initially
required to be implemented by July 1, 2005, but its effectiveness has been
delayed until January 1, 2006 by the Securities and Exchange Commission.
Accordingly, United Therapeutics will adopt SFAS 123(R) on January 1,
2006\. SFAS 123(R) is expected to have significant impacts on the
accounting and disclosure of employee stock options and future operating
results since, among other things, it will require that stock-based employee
compensation be expensed in the statement of operations.

During the six-months
ended June 30, 2005, options to purchase 362,322 shares were exercised.

6

  
* * *

  
**4\. INVENTORIES**

United
Therapeutics manufactures certain compounds and purchases medical supplies for
use in its product sales and ongoing clinical trials. United Therapeutics
subcontracts the manufacture of cardiac monitoring equipment. United
Therapeutics contracts with a third-party manufacturer to make the HeartBar®
and related products. These inventories are accounted for under the first-in,
first-out method and are carried at the lower of cost or market. Inventories
consisted of the following, net of reserves of approximately $406,000 and
$447,000 at June 30, 2005 and December 31, 2004, respectively (in
thousands):

| | |**June 30,  
2005** | |**December 31,  
2004** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Remodulin: | | | | | | | | | |
|Raw materials | | |$ |640 | | | |$ |553 | | |
|Work-in-progress | | |6,462 | | | |5,428 | | |
|Finished goods | | |1,587 | | | |960 | | |
|Remodulin
delivery pumps and medical supplies | | |758 | | | |804 | | |
|Cardiac
monitoring equipment components | | |114 | | | |— | | |
|HeartBar and
related product lines | | |251 | | | |269 | | |
|Total inventories | | |$ |9,812 | | | |$ |8,014 | | |

**5\.
GOODWILL AND OTHER INTANGIBLE ASSETS**

Goodwill
and other intangible assets were comprised as follows (in thousands):

| | |**As of June 30, 2005** | |**As of December 31, 2004** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |
|Goodwill | |$ |9,072 | | |$ |(1,607 |) | |$ |7,465 | |$ |9,072 | | |$ |(1,607 |) | |$ |7,465 | |
|Intangible
assets: | | | | | | | | | | | | | | | | | |
|Noncompete agreements | |$ |273 | | |$ |(273 |) | |$ |— | |$ |273 | | |$ |(273 |) | |$ |— | |
|Trademarks | |2,802 | | |(1,107 |) | |1,695 | |2,802 | | |(984 |) | |1,818 | |
|Technology and patents | |6,164 | | |(2,132 |) | |4,032 | |6,164 | | |(2,015 |) | |4,149 | |
|Total intangible
assets | |$ |9,239 | | |$ |(3,512 |) | |$ |5,727 | |$ |9,239 | | |$ |(3,272 |) | |$ |5,967 | |

Total
amortization expense for each of the three-month periods ended June 30,
2005 and 2004 was approximately $120,000. Total amortization expense for each
of the six-month periods ended June 30, 2005 and 2004 was approximately
$240,000. As of December 31, 2004, the aggregate amortization expense
related to these intangible assets for each of the five succeeding years was
estimated as follows (in thousands):

|**Year ending December 31,** | | | | | |
| --- | --- | --- | --- | --- | --- |
|2005 | |$ |479 | |
|2006 | |479 | |
|2007 | |432 | |
|2008 | |432 | |
|2009 | |432 | |

7  
* * *  
**6\. SEGMENT INFORMATION**

United Therapeutics has two reportable business
segments. The pharmaceutical segment includes all activities associated with
the research, development, manufacture and commercialization of therapeutic
products. The telemedicine segment includes all activities associated with the
development and manufacture of patient monitoring products and the delivery of
patient monitoring services. The telemedicine segment is managed separately
because diagnostic services require different technology and marketing
strategies.

Segment
information as of and for the three and six-months ended June 30, 2005 and
2004 was as follows (in thousands):

| | |**Three Months Ended June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from
external customers | | |$ |28,672 | | | |$ |1,385 | | | |$ |30,057 | | | |$ |16,979 | | | |$ |1,320 | | | |$ |18,299 | | |
|Income (loss)
before income tax | | |12,606 | | | |(425 |) | | |12,181 | | | |4,286 | | | |(146 |) | | |4,140 | | |
|Interest income | | |1,198 | | | |3 | | | |1,201 | | | |672 | | | |2 | | | |674 | | |
|Interest expense | | |— | | | |(1 |) | | |(1 |) | | |— | | | |— | | | |— | | |
|Depreciation and
amortization | | |(420 |) | | |(208 |) | | |(628 |) | | |(395 |) | | |(133 |) | | |(528 |) | |
|Equity loss in
affiliate | | |(195 |) | | |— | | | |(195 |) | | |(111 |) | | |— | | | |(111 |) | |
|Total investment
in equity method investees | | |2,438 | | | |— | | | |2,438 | | | |3,344 | | | |— | | | |3,344 | | |
|Expenditures for
long-lived assets | | |3,097 | | | |89 | | | |3,186 | | | |3,059 | | | |140 | | | |3,199 | | |
|Goodwill, net | | |1,287 | | | |6,178 | | | |7,465 | | | |1,287 | | | |6,178 | | | |7,465 | | |
|Total assets | | |224,664 | | | |9,560 | | | |234,224 | | | |173,593 | | | |9,657 | | | |183,250 | | |

| | |**Six Months Ended June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from
external customers | | |$ |50,499 | | | |$ |2,765 | | | |$ |53,264 | | | |$ |29,495 | | | |$ |2,487 | | | |$ |31,982 | | |
|Income (loss)
before income tax | | |20,496 | | | |(653 |) | | |19,843 | | | |2,971 | | | |(678 |) | | |2,293 | | |
|Interest income | | |2,176 | | | |6 | | | |2,182 | | | |1,319 | | | |4 | | | |1,323 | | |
|Interest expense | | |— | | | |(1 |) | | |(1 |) | | |(1 |) | | |(1 |) | | |(2 |) | |
|Depreciation and
amortization | | |(832 |) | | |(428 |) | | |(1,260 |) | | |(756 |) | | |(381 |) | | |(1,137 |) | |
|Equity loss in
affiliate | | |(375 |) | | |— | | | |(375 |) | | |(238 |) | | |— | | | |(238 |) | |
|Total investment
in equity method investees | | |2,438 | | | |— | | | |2,438 | | | |3,344 | | | |— | | | |3,344 | | |
|Expenditures for
long-lived assets | | |3,403 | | | |247 | | | |3,650 | | | |3,365 | | | |298 | | | |3,663 | | |
|Goodwill, net | | |1,287 | | | |6,178 | | | |7,465 | | | |1,287 | | | |6,178 | | | |7,465 | | |
|Total assets | | |224,664 | | | |9,560 | | | |234,224 | | | |173,593 | | | |9,657 | | | |183,250 | | |

8

  
* * *

  
The segment information shown above equals the
consolidated totals when combined. These consolidated totals equal the amounts
reported in the consolidated financial statements without further
reconciliation for those categories which are reported in the consolidated
financial statements. There are no inter-segment transactions.

For the three-month
periods ended June 30, 2005 and 2004 approximately 91 percent and 86
percent of United Therapeutics revenues were earned from customers located in
the United States, respectively. For the six-month periods ended June 30,
2005 and 2004 approximately 90 percent and 85 percent of United Therapeutics
revenues were earned from customers located in the United States, respectively.

**7\. COMPREHENSIVE INCOME**

SFAS No. 130, _Reporting Comprehensive Income,_ establishes standards for the reporting and display of comprehensive income and
its components. SFAS No. 130 requires, among other things, that unrealized
gains and losses on available-for-sale securities and foreign currency
translation adjustments be included in other comprehensive income (loss). The
following statement presents comprehensive income for the three and six-months
ended June 30, 2005 and 2004 (in thousands):

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income | |$ |12,181 | |$ |4,140 | |$ |19,843 | |$ |2,293 | |
|Other
comprehensive income (loss): | | | | | | | | | |
|Foreign currency translation adjustment | |(50 |) |(6 |) |(61 |) |(80 |) |
|Unrealized gain (loss) on available-for-sale
securities | |(2,165 |) |394 | |(790 |) |(1,118 |) |
|Comprehensive income | |$ |9,966 | |$ |4,528 | |$ |18,992 | |$ |1,095 | |

**8\. INCOME TAXES**

United Therapeutics did
not incur income tax expense for the three-month and six-month periods ended June 30,
2005 and 2004 generally due to the availability of deductions for tax purposes
and the availability of net operating loss carryforwards which will offset any
taxable income for these periods. As of June 30, 2005, United Therapeutics
had available approximately $101.3 million in net operating loss carryforwards
and approximately $27.7 million in business tax credit carryforwards for
federal income tax purposes that expire at various dates through 2024. United
Therapeutics is currently conducting a study to determine whether any
limitations under Section 382 of the Internal Revenue Code have been
triggered. Preliminary results of this study indicate that multiple limitations
occurred through the middle of 2004. As a result, portions of these
carryforward items that were generated prior to the middle of 2004 will be
subject to certain limitations on their use. United Therapeutics does not
believe that the potential limitations will cause the net operating loss and
general business credit carryforwards to expire unused.

**9\. NORTHERN THERAPEUTICS**

Northern Therapeutics, Inc.
is a Canadian affiliate of United Therapeutics. The CEO of United Therapeutics
served as Chairman of the Board and acting CEO of Northern Therapeutics since
2001\. In March 2005, the CEO of United Therapeutics ceased serving in
these capacities for Northern Therapeutics.

**10\. LICENSE FEES**

In March 2005, United
Therapeutics entered into an agreement providing a third-party with a one-year
exclusivity period in which to perform due diligence with respect to certain glycobiology
intellectual

9

  
* * *

  
property
rights controlled by United Therapeutics, in exchange for approximately
$325,000. The fee is payable in installments over the one-year period. Amounts
paid to United Therapeutics by the licensee during the three and six months
ended June 30, 2005 are nonrefundable and were recognized as revenues in
that period. At any time during the one-year period the third-party has the
right to enter into negotiations with United Therapeutics to acquire an
exclusive license to commercialize products under such intellectual property
rights for a field of use outside of United Therapeutics’ core therapeutic
areas. The agreement may be terminated by the third party at any time. If
terminated by the third party, subsequent installments would no longer be due.

**11\. PHASE IV CLINICAL STUDY**

During the six months ended June 30, 2005,
Remodulin drug sales accounted for approximately 94% of total revenues. Upon
FDA approval in 2002, United Therapeutics was required by the FDA to perform a
post-marketing Phase IV clinical study to confirm the clinical benefits of
Remodulin. Continued FDA approval of Remodulin is subject to the diligent and
timely completion of the Phase IV trial, as well as its outcome.

The Phase IV clinical trial was required to be
one-half enrolled by June 2004 and fully enrolled by June 2005;
however, the FDA has permitted an interim assessment and opportunity to
terminate the Phase IV study after only 21 patients have completed the
study. The final study report is required to be submitted in December 2005.
To date, 22 patients have been enrolled in this 39-patient Phase IV
trial. Enrolling patients in this study is difficult, in part because it
involves randomizing some of the patients to placebo despite the fact that approved
drugs are available for these patients.

United Therapeutics did not enroll the Phase IV trial
within the time frame specified by the FDA, and therefore is at risk of the FDA
at any time instituting a public hearing to withdraw marketing approval for
Remodulin. In late 2004, United Therapeutics began discussions with the FDA
about its due diligence in enrolling the Phase IV trial and made a proposal
which United Therapeutics believes would ensure interpretable results of this
trial by the December 2005 final study report delivery deadline. Specifically,
United Therapeutics proposed that the FDA evaluate the results of the Phase IV
trial based on the number of patients enrolled through September 15, 2005.
The FDA began its review of this proposal in early 2005.

Subsequent to submission of the proposal described
above, United Therapeutics achieved enrollment of 22 patients in the Phase IV
study.  In July 2005, the first 21
patients completed the study and United Therapeutics chose to perform the
interim assessment. The results of the interim assessment from these first 21
patients, as analyzed by an independent statistician are positive (p=.0006). Specifically,
13 of 14 patients (93%) in the Remodulin arm were able to successfully
transition from Flolan® and complete the study without the need to institute
rescue therapy, compared to only 1 of 7 patients (14%) in the placebo arm.
Based on this positive outcome, United Therapeutics has submitted the interim study
results to the FDA and has requested permission to end the Phase IV
clinical study in satisfaction of its Phase IV commitments. By agreement
with the FDA, enrollment in the Phase IV clinical study will be suspended
pending FDA review and acceptance of the interim study results. United
Therapeutics can give no assurances as to timing and outcomes of this FDA
review.

If the FDA does not accept the interim study results,
does not otherwise agree with United Therapeutics’ assessment of the interim
results, or rejects the proposal described above, United Therapeutics would
still be required to comply with the FDA-approved protocol for the Phase IV
clinical study, including enrolling 39 patients in the study and submitting the
final study report by December 2005. In addition, the FDA could, among
other things, grant an extension of time to continue to enroll the trial, or
institute a public hearing to withdraw marketing approval for Remodulin. If a
withdrawal hearing were instituted by the FDA, United Therapeutics would pursue
the opportunity to participate, as it believes that it has exercised good faith
due diligence in pursuing enrollment of this trial.

10

  
* * *

  
**12\.
LABORATORY CONSTRUCTION AGREEMENT**

In March 2005, United
Therapeutics entered into a construction management agreement with Turner
Construction Company (“Turner”). Turner will manage the construction of the new
laboratory facility in Silver Spring, Maryland. Under the terms of the
agreement, Turner will be responsible for the construction of the facility. The
agreement has a guaranteed maximum price clause in which Turner agrees that the
construction cost of the facility will not exceed approximately $27.0 million,
which amount is subject to change based on agreed-upon changes to the scope of
work. Turner will be responsible for covering any costs in excess of the guaranteed
maximum price guarantee. If the ultimate cost of the project is less than the
guaranteed maximum price of $27.0 million, then a portion of the costs savings
will be shared with Turner. In addition, Turner must pay penalties to United
Therapeutics if the construction is not completed by April 2006, which
date is subject to change based on agreed-upon changes to the scope of work.
Construction costs to be incurred under this agreement will be reimbursed to
United Therapeutics by Wachovia Development Corporation in accordance with the
synthetic operating lease and related agreements.

**13\. RECEIVABLE FROM EMPLOYEE**

In April 2002, United
Therapeutics loaned $1.3 million to Dr. Roger Jeffs, its President and
Chief Operating Officer, to purchase his primary residence. The loan and
accrued interest were due at the end of five years or earlier, in part or in
full, if Dr. Jeffs obtained a mortgage on the property, exercised and sold
any United Therapeutics stock options, sold any United Therapeutics stock, or sold
the property. Interest of 6.5 percent per year accrued on the note. At December 31,
2004, the outstanding balance was approximately $445,000. In May 2005, Dr. Jeffs
paid off the remaining balance of this note.

**Item 2.** Management’s
Discussion and Analysis of Financial Condition and Results of Operations

The following discussion
should be read in conjunction with the consolidated financial statements and
related notes appearing in United Therapeutics’ Annual Report on Form 10-K
for the year ended December 31, 2004. The following discussion contains
forward-looking statements made pursuant to the safe harbor provisions of Section 21E
of the Securities Exchange Act of 1934 and the Private Securities Litigation
Reform Act of 1995 concerning, among other things, the pricing of Remodulin,
the dosing and rate of patient consumption of Remodulin, the impacts of price
changes and changes in patient consumption of Remodulin on future revenues,
acceptance by the FDA of the Phase IV clinical trial interim study report
following the 21-patient interim assessment, the timing and outcome of
the Phase IV clinical trial, any actions that may or may not be taken by the
FDA as a result of the timing and outcome of the Phase IV clinical trial, the
timing, completion and outcome of the mutual recognition process to facilitate
local approvals of subcutaneous Remodulin in most European Union countries, the
timing, completion and outcome of pricing approvals in European Union countries
that approve subcutaneous Remodulin, the outcome of the receipt of a warning
letter and potential future warning letters from the FDA and any actions that
may or may not be taken by the FDA as a result of such warning letter or
letters, the funding of operations from future revenues, the expectation of
continued profits or losses, expectations concerning milestone and royalty
payments in 2005, the use of net operating loss carryforwards and business tax
credit carryforwards, income tax expenses and benefits in future periods, the
completion of in-process research and development products and their impact on
United Therapeutics, the pace and timing of enrollment in clinical trials, the
expectation, outcome and timing of new and continuing regulatory approvals, the
expected levels and timing of Remodulin sales, the adequacy of United
Therapeutics’ resources to fund operations, the timing and level of spending to
construct a laboratory production facility, the potential amount of the minimum
residual value guarantee to Wachovia, events that could occur upon termination
of the Wachovia agreements, expectations concerning payments of contractual
obligations in all future years and their amounts, the potential impacts of new
accounting standards, the sale of common stock at favorable terms under the
primary registration statement filed with the SEC in February 2005, as

11

  
* * *

  
well as
statements preceded by, followed by or that include the words “believes”, “expects”,
“anticipates”, “intends”, “estimates”, “may” or similar expressions. These
statements are based on the beliefs and expectations of United Therapeutics as
to future outcomes and are subject to risks and uncertainties that could cause
United Therapeutics’ results to differ materially from anticipated results.
Factors that could cause or contribute to such differences include those
discussed below and the risks described in United Therapeutics’ Annual Report
on Form 10-K for the year ended December 31, 2004 and the other
cautionary statements, cautionary language and risk factors set forth in United
Therapeutics’ other reports and documents filed with the Securities and
Exchange Commission. United Therapeutics undertakes no obligation to publicly
update forward-looking statements, whether as a result of new information,
future events or otherwise.

**Overview**

United Therapeutics is a
biotechnology company focused on the development and commercialization of
unique products for patients with chronic and life-threatening cardiovascular,
cancer and infectious diseases. United Therapeutics commenced operations in June 1996
and, since its inception, has devoted substantially all of its resources to
acquisitions and research and development programs.

**_United Therapeutics Products and Services_**

United Therapeutics’ lead product is Remodulin. On May 21,
2002, the United States Food and Drug Administration (FDA) approved
subcutaneous use of Remodulin (treprostinil sodium) Injection for the treatment
of pulmonary arterial hypertension in patients with NYHA class II-IV symptoms
to diminish symptoms associated with exercise. Pulmonary arterial hypertension
is a life-threatening condition characterized by elevated blood pressures
between the heart and lungs. United Therapeutics was required to perform a
post-marketing Phase IV clinical study to confirm the clinical benefits of
Remodulin. Continued FDA approval of Remodulin is subject to the diligent and
timely completion of that Phase IV trial, as well as its outcome. The study was
originally to have been completed by May 2004 and involve 100 patients. In
mid-2003, the FDA agreed to amend the due date of the final study report
and make other changes to the trial design including reducing the number of
patients to 39.

The amended Phase IV clinical trial was required to be
one-half enrolled by June 2004 and fully enrolled by June 2005;
however, the FDA has permitted an interim assessment and opportunity to
terminate the Phase IV study after only 21 patients have completed the study.
The final study report is required to be submitted in December 2005. To
date, 22 patients have been enrolled in this 39-patient
Phase IV trial. Enrolling patients in this study is difficult, in part because
it involves randomizing some of the patients to placebo despite the fact that
approved drugs are available for these patients.

United Therapeutics did not enroll the Phase IV trial
within the time frame specified by the FDA, and therefore is at risk of the FDA
at any time instituting a public hearing to withdraw marketing approval for
Remodulin. In late 2004, United Therapeutics began discussions with the FDA
about its due diligence in enrolling the Phase IV trial and made a proposal
which United Therapeutics believes would ensure interpretable results of this
trial by the December 2005 final study report delivery deadline. Specifically,
United Therapeutics proposed that the FDA evaluate the results of the Phase IV
trial based on the number of patients enrolled through September 15, 2005.
The FDA began its review of this proposal in early 2005.

Subsequent to submission of the proposal described
above, United Therapeutics achieved enrollment of 22 patients in the Phase IV
study.  In July 2005, the first 21
patients completed the study and United Therapeutics chose to perform the
interim assessment. The results of the interim assessment from these first 21
patients, as analyzed by an independent statistician are positive (p=.0006). Specifically,
13 of 14 patients (93%) in the Remodulin arm were able to successfully
transition from Flolan and complete the study without the need to institute
rescue therapy, compared to only 1 of 7 patients (14%) in the placebo

12

  
* * *

  
arm. Based on this
positive outcome, United Therapeutics has submitted the interim study results to
the FDA and has requested permission to end the Phase IV clinical study in
satisfaction of its Phase IV commitments. By agreement with the FDA,
enrollment in the Phase IV clinical study will be suspended pending FDA
review and acceptance of the interim study results. United Therapeutics can
give no assurances as to timing and outcomes of this FDA review.

If the FDA does not accept the interim study results,
does not otherwise agree with United Therapeutics’ assessment of the interim
results, or rejects the proposal described above, United Therapeutics would
still be required to comply with the FDA-approved protocol for the Phase IV
clinical study, including enrolling 39 patients in the study and submitting the
final study report by December 2005. In addition, the FDA could, among
other things, grant an extension of time to continue to enroll the trial, or
institute a public hearing to withdraw marketing approval for Remodulin. If a
withdrawal hearing were instituted by the FDA, United Therapeutics would pursue
the opportunity to participate as it believes that it has exercised good faith
due diligence in pursuing enrollment of this trial.

On November 24, 2004, the FDA approved
intravenous infusion of Remodulin, based on data establishing its
bioequivalence with the previously approved subcutaneous administration of
Remodulin, for patients who are not able to tolerate a subcutaneous infusion.
This approval was also conditioned upon the diligent and timely completion of
the Phase IV trial, as well as its outcome. Remodulin is also approved for
subcutaneous use in France, Canada, Israel, Australia, Switzerland and
Argentina. Marketing authorization applications are currently under review in
other countries. United Therapeutics and France initiated the mutual
recognition process in May 2005 to facilitate local approvals in most
European Union countries. The mutual recognition process is expected to be
completed around mid-August 2005 with decisions expected in most European
Union countries, unless an application is withdrawn in any individual country
prior to August 10, 2005. Although these decisions will be made around mid-August 2005,
formal action letters and pricing approvals required for the commercial sales
of Remodulin may take as long as one to two years, or longer, to be received.
United Therapeutics can give no assurances as to the timing and outcomes of the
mutual recognition process. Marketing authorization applications are currently
under review in other countries.

On April 13, 2005, the FDA issued a warning
letter to United Therapeutics citing a professional journal advertisement for
Remodulin and a medical frequently asked questions booklet for Remodulin which
the FDA considered to be false or misleading because they minimize risk
information, make unsubstantiated effectiveness and comparative claims, and
omit material facts. In addition, the FDA-approved product labeling for
Remodulin did not accompany the booklet, and these materials were not submitted
to the FDA for review prior to dissemination and at the time of initial
dissemination as required under the accelerated approval regulations. The FDA
warning letter requested that United Therapeutics immediately cease the dissemination
of the violative promotional materials, provide a written response confirming
United Therapeutics’ compliance with the request, provide a list of all
materials to be discontinued, explain its plan for discontinuing use of such
materials, and include a comprehensive plan of action to disseminate truthful,
non-misleading and complete corrective messages to the audiences that received
the violative promotional materials.

On April 27, 2005, United Therapeutics responded
to the actions the FDA requested in the warning letter and proposed corrective
measures for its consideration, which measures were accepted by the FDA on July 14,
2005\. These measures include publication of a corrective advertisement in three
issues of a scientific journal, posting of a “Dear Healthcare Provider” letter
and a “Dear Patient” letter on the Remodulin.com website, and dissemination of
these letters to affected Remodulin prescribers. United Therapeutics and the
FDA have been working collaboratively to finalize the corrective actions and
their implementation.

While United Therapeutics is committed to keeping an
open dialog with the FDA, and to improving its processes and procedures to
ensure compliance with its pre-submission obligations, there can be no

13

  
* * *

  
assurances that the FDA
will not issue additional warning letters with respect to promotional materials
disseminated following the 2002 approval of Remodulin. In addition, in
accordance with the accelerated approval regulations under which Remodulin was
approved, United Therapeutics is at risk that the FDA may at any time request
United Therapeutics to attend a public hearing to withdraw marketing approval
for Remodulin on the basis of the dissemination of false or misleading
promotional materials. Nevertheless, United Therapeutics is committed to
ensuring that all of its advertising and promotional materials are in
compliance with all applicable regulatory requirements and to working with the
FDA to address any issues that arise in connection with its advertising and
labeling materials.

United Therapeutics has
generated revenues from sales of Remodulin and arginine products in the United
States and other countries. In addition, United Therapeutics has generated
revenues from telemedicine products and services, primarily designed for
patients with cardiac arrhythmias and ischemic heart disease, in the United
States. United Therapeutics has funded its operations from the proceeds of
sales of its common stock and from revenues from the sales of its products and
services.

**_Remodulin Marketing and Sales_**

Remodulin is sold and
marketed to patients in the United States by Accredo Therapeutics, Inc.,
Priority Healthcare Corporation and Caremark, Inc. and outside of the
United States by international distributors. United Therapeutics sells Remodulin
in bulk shipments to these distributors. The timing and extent of United
Therapeutics’ sales of Remodulin are impacted by the timing and extent of these
bulk orders from distributors. Bulk orders placed by distributors are
determined by them, based on their estimates of the amount of drug required for
current and newly starting patients, as well as an inventory equivalent to
approximately thirty to sixty days demand as a contingent supply since
discontinuation of therapy can be life-threatening to patients. Therefore,
sales of Remodulin to distributors in any given quarter may not be indicative
of patient demand in that quarter. Sales of Remodulin and Remodulin delivery
pumps and supplies are recognized as revenue when delivered to the distributors.

14  
* * *  
**_Future Prospects_**

While United Therapeutics
was profitable in each quarter since April 1, 2004, it incurred net losses
for all quarters from inception through March 31, 2004. At June 30,
2005, United Therapeutics had an accumulated deficit of approximately $160.5
million. United Therapeutics may again incur net losses and cannot provide
assurances that, in the future, it will be profitable. Future profitability
will depend on many factors, including timely and successful completion of the
Remodulin Phase IV study discussed above under _United
Therapeutics Products and Services_ , the price, level of sales, level
of reimbursement by public and private insurance payers, the impacts of
competitive products and the number of patients using Remodulin and other
currently commercialized products and services, as well as the results and
costs of research and development projects.

**Major
Research and Development Projects**

The major research and development projects of United
Therapeutics are the use of Remodulin to treat cardiovascular diseases,
immunotherapeutic monoclonal antibodies (antibodies that activate a patient’s
immune response) to treat a variety of cancers and glycobiology antiviral
agents (a novel class of small molecules that may be effective as oral
therapies) to treat infectious diseases.

**_Cardiovascular Disease Projects_**

Subcutaneous use of Remodulin was approved by the FDA
in May 2002 for the treatment of pulmonary arterial hypertension in NYHA Class II-IV
patients to diminish symptoms associated with exercise. A condition of
continued FDA approval is that a Phase IV clinical study must be completed in a
timely and diligent manner as discussed above under _United
Therapeutics Products and Services_ . Material net cash inflows from
the sales of Remodulin for pulmonary arterial hypertension commenced in May 2002
after FDA approval was received.

Remodulin was also approved in France, Canada, Israel,
Australia, Switzerland and Argentina for similar uses. United Therapeutics is
currently undertaking the mutual recognition process to facilitate local
approvals of subcutaneous Remodulin in most European Union countries. The
mutual recognition process is expected to be completed around mid-August 2005,
with decisions expected in most European Union countries, unless an application
is withdrawn in any individual country prior to August 10, 2005. Although these
decisions will be made around mid-August 2005, formal action letters and
pricing approvals required for the commercial sales of Remodulin may take as
long as one to two years, or longer, to be received. United Therapeutics can
give no assurances as to the timing and outcomes of the mutual recognition
process. Marketing authorization applications are currently under review in
other countries.

On March 29, 2005, the manufacturer of the
Medtronic 407C infusion pump which is used for the subcutaneous administration
of Remodulin received FDA approval for intravenous use of the pump. It was
previously approved for subcutaneous use only. United Therapeutics is currently
evaluating the Medtronic 407C infusion pump for use with intravenous Remodulin
in patients with pulmonary arterial hypertension. Studies are underway in adult
and pediatric patients to explore logistics associated with use of this pump
and to expand clinical information.

In March 2005, United Therapeutics commenced a
12-week placebo-controlled trial of intravenous Remodulin in patients with
pulmonary arterial hypertension to further access the clinical benefits of
Remodulin. The trial is being conducted in India and will enroll up to 126
patients. Interim results of this trial may be assessed after 33, 66 and 99
patients have completed 12 weeks. As of June 30, 2005, approximately 35
patients have been enrolled in the study.

United Therapeutics is in the early stages of
developing oral and inhaled formulations of treprostinil. During 2004, United
Therapeutics completed dosage studies of oral formulations of treprostinil in
healthy volunteers and filed an Investigational New Drug Application (“IND”) on
January 28, 2005 to perform an

15

  
* * *

  
additional Phase I healthy
volunteer study. During 2004, independent clinical investigators performed
small uncontrolled trials of inhaled formulations of treprostinil in patients
with pulmonary arterial hypertension. On July 21, 2005, the European
Medicines Agency announced that oral treprostinil had been granted orphan
product status in the European Union. In June 2005, Lung Rx, Inc., a
subsidiary of United Therapeutics, commenced a 12-week placebo-controlled trial
of inhaled treprostinil in patients with pulmonary arterial hypertension who
are also being treated with Tracleer ® . The trial is being
conducted at 14 centers in the United States and in Europe and will include 150
patients. As of July 29, 2005, approximately 11 patients have been
enrolled in this trial.

United Therapeutics
incurred expenses of approximately $4.6 million and $3.9 million during the
three-month periods ended June 30, 2005 and 2004, respectively, on
Remodulin development. United Therapeutics incurred expenses of approximately
$9.0 million during each of the six-month periods ended June 30, 2005 and
2004, respectively, on Remodulin development. Approximately $149.8 million from
inception to date has been incurred on Remodulin development.

**_Cancer Disease Projects_**

United Therapeutics’
monoclonal antibody immunotherapies were licensed in April 2002 from
AltaRex Medical Corp. OvaRex® MAb is the lead product and is currently being
studied in two identical Phase III clinical trials in advanced ovarian cancer
(Stage III and IV) patients. These studies, which commenced in January 2003,
are being conducted at approximately 60 centers throughout the United States
and are approximately 80% enrolled. These studies could take up to two years to
complete following full enrollment, depending on trial patients’ relapse rates.
United Therapeutics incurred expenses of approximately $1.9 million during each
of the three-month periods ended June 30, 2005 and 2004, on OvaRex
development. United Therapeutics incurred expenses of approximately $3.7
million during each of the six-month periods ended June 30, 2005 and 2004,
on OvaRex development. Approximately $27.4 million from inception to date has
been incurred on OvaRex development.

**_Infectious Disease Projects_**

United Therapeutics’
infectious disease program includes glycobiology antiviral drug candidates in
the preclinical and clinical stages of testing. The drugs in this program are
being developed for hepatitis C, hepatitis B and other infectious diseases. The
first candidate for hepatitis C, UT-231B, completed acute and chronic Phase I
clinical dosing studies to assess safety in healthy volunteers in early 2003.
Phase II clinical studies in patients infected with hepatitis C were initiated
in July 2003 and were completed in October 2004. In that trial,
UT-231B did not demonstrate efficacy against hepatitis C in a population of
patients that previously failed conventional treatments. United Therapeutics is
now performing preclinical testing to help determine the feasibility of a trial
of UT-231B in patients who responded positively to conventional treatments for
hepatitis C in order to prevent relapse. United Therapeutics incurred expenses
of approximately $1.4 million and $773,000 during the three-month periods ended
June 30, 2005 and 2004, respectively, for its infectious disease programs.
United Therapeutics incurred expenses of approximately $2.6 million and $1.4
million during the six-month periods ended June 30, 2005 and 2004,
respectively, for its infectious disease programs. Approximately $34.3 million
from inception to date has been incurred for infectious disease programs.

16

  
* * *

  
**_Project Risks_**

Due to the inherent
uncertainties involved in the drug development, regulatory review and approval
processes, the anticipated completion dates, the cost of completing the
research and development and the period in which material net cash inflows from
these projects are expected to commence are not known or estimable. There are
many risks and uncertainties associated with completing the development of the
unapproved products discussed above, including the following:

· Products
may fail in clinical studies;

· Hospitals,
physicians and patients may not be willing to participate in clinical studies;

· The
drugs may not be safe and effective or may not be perceived as safe and
effective;

· Other
approved or investigational therapies may be viewed as safer, more effective or
more convenient;

· Patients
may experience severe side effects during treatment;

· Patients
may die during the clinical study because their disease is too advanced or
because they experience medical problems that are not related to the drug being
studied;

· Patients
may not enroll in the studies at the rate United Therapeutics expects;

· The
FDA and foreign regulatory authorities may delay or withhold approvals to
commence clinical trials or to manufacture drugs;

· The
FDA and foreign regulatory authorities may request that additional studies be
performed;

· Higher
than anticipated costs may be incurred due to the high cost of contractors for
drug manufacture, research and clinical trials;

· Drug
supplies may not be sufficient to treat the patients in the studies; and

· The
results of preclinical testing may cause delays in clinical trials.

If these projects are not
completed in a timely manner, regulatory approvals would be delayed and United
Therapeutics’ operations, liquidity and financial position could suffer.
Without regulatory approvals, United Therapeutics could not commercialize and
sell these products and, therefore, potential revenues and profits from these
products would be delayed or impossible to achieve.

**Financial Position**

Cash, cash equivalents and marketable investments
(including all unrestricted and restricted amounts) at June 30, 2005 were
approximately $161.8 million, as compared to approximately $139.1 million at December 31,
2004\. The increase of approximately $22.7 million is due primarily to cash
provided by operating activities of approximately $20.4 million and proceeds
from the exercise of stock options totaling approximately $5.8 million.
Restricted cash and marketable investments pledged to secure United
Therapeutics’ obligations under the synthetic operating lease discussed below
under _Off Balance Sheet Arrangement_ at June 30,
2005 totaled approximately $10.3 million, as compared with approximately $10.1
million at December 31, 2004.

Accounts receivable, net of allowances, at June 30,
2005 were approximately $15.4 million, as compared to approximately $13.7
million at December 31, 2004. The increase was due to increased sales of
Remodulin.

17

  
* * *

  
Inventories, net of reserves for obsolescence, at June 30,
2005 were approximately $9.8 million, as compared to approximately $8.0 million
at December 31, 2004. The increase was due primarily to increased levels
of Remodulin finished goods and work-in-process.

Investments in affiliates at June 30, 2005 were
approximately $6.3 million, as compared to approximately $7.4 million at December 31,
2004\. The decrease was due primarily to a decrease in the fair value of United
Therapeutics’ investment in ViRexx Medical Corporation, based on quoted market
prices.

Property, plant and equipment at June 30, 2005
were approximately $20.4 million, as compared to $17.8 million at December 31,
2005\. The increase was due primarily to the purchase of building and land
adjacent to the Lung Rx office for approximately $2.8 million.

Accounts payable at June 30, 2005 were
approximately $3.8 million, as compared to approximately $6.1 million at December 31,
2004\. The decrease was due generally to the timing of payments to vendors.

Accrued expenses at June 30, 2005 were
approximately $11.0 million, as compared to approximately $7.7 million at December 31,
2004\. The increase was due primarily to accrued expenses for royalties,
government rebates and clinical trial related expenses.

Total stockholders’ equity
at June 30, 2005 was approximately $216.8 million, as compared to $191.6
million at December 31, 2004. The increase in stockholders’ equity of
approximately $25.2 million was due primarily to net income earned and the
proceeds collected from exercises of stock options during the six months ended June 30,
2005\.

**Results Of Operations**

**_Three Months ended June 30,  2005 and 2004_**

| | |**Revenues for the  
Three Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**(in thousands)** | |
|Remodulin | |$ |28,456 | |$ |16,238 | |
|Telemedicine
services and products | |1,385 | |1,320 | |
|Other products | |151 | |741 | |
|License fees | |65 | |— | |
|Total revenues | |$ |30,057 | |$ |18,299 | |

Revenues for the three months ended June 30, 2005
were approximately $30.1 million, as compared to approximately $18.3 million
for the three months ended June 30, 2004. The increase of approximately
$11.8 million was due primarily to growth in patient use of Remodulin. For the
three-month periods ended June 30, 2005 and 2004, approximately 91 percent
and 86 percent of United Therapeutics revenues were earned from customers
located in the United States, respectively.

Total revenues are reported net of estimated
government rebates, prompt pay discounts and fees due to a distributor for
services. Government rebates are paid to state Medicaid agencies that pay for
Remodulin. Historically, United Therapeutics estimated its liability for such
rebates based on the volume of Remodulin dispensed to Medicaid patients as
reported to United Therapeutics by its distributors and the expected rebate per
unit of Remodulin as determined by United Therapeutics in accordance with
federal guidelines. Since April 1, 2005, United Therapeutics estimates its
liability for such rebates based on the historical level of government rebates
invoiced by state Medicaid agencies relative to U.S. sales of Remodulin. Prompt
pay discounts are offered on sales of Remodulin if the related invoices are
paid in full generally within 60 days from the date of sale. United
Therapeutics estimates its liability for prompt pay

18

  
* * *

  
discounts based on historical
payment patterns. Fees paid to a distributor for services are estimated based
on contractual rates for specific services applied to estimated units of
service provided by the distributor for the period.

A roll
forward of the liability accounts associated with estimated government rebates,
prompt pay discounts and fees to a distributor for services as well as the net
amount of reductions to revenues for these items are presented as follows (in
thousands):

| | |**Three Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
|Liability
accounts, at beginning of period | |$ |1,980 | |$ |949 | |
|Additions to
liability | |1,638 | |1,238 | |
|Payments | |(1,793 |) |(1,138 |) |
|Liability
accounts, at end of period | |$ |1,825 | |$ |1,049 | |
|Net reductions to
revenues | |$ |1,638 | |$ |1,238 | |

United Therapeutics’ distributors endeavor to maintain
levels of Remodulin inventories sufficient to satisfy existing and new demand
for the product. Inventory levels held by United States-based distributors (as
reported to United Therapeutics by such distributors) at June 30, 2005 and
December 31, 2004 were approximately $15.5 million and $14.0 million,
respectively, based on United Therapeutics’ selling price. As Remodulin is not
yet approved in the European Union, inventory levels outside of the United
States were not believed to be significant. Product returns were due to
arginine products and totaled approximately none and $5,000 during the three
months ended June 30, 2005 and 2004, respectively.

Research and development expenses consist primarily of
salaries and related expenses, costs to acquire pharmaceutical products and
product rights for development and amounts paid to contract research
organizations, hospitals and laboratories for the provision of services and
materials for drug development and clinical trials. Research and development
expenses were approximately $8.7 million for the three months ended June 30,
2005, as compared to the approximately $7.3 million for the three months ended June 30,
2004\. During the three months ended June 30, 2005, expenses for
Remodulin-related programs and for the infectious disease program increased by
approximately $696,000 and $568,000, respectively, as compared to the three
months ended June 30, 2004. See _Major Research and
Development Projects_ above, for additional information.

Selling, general and administrative expenses consist
primarily of salaries, travel, office expenses, insurance, professional fees,
provision for doubtful accounts receivable, depreciation and amortization.
Selling, general and administrative expenses were approximately $7.0 million
for the three months ended June 30, 2005, as compared to approximately
$5.4 million for the three months ended June 30, 2004. The increase of
approximately $1.6 million is primarily due to the payment of one-time application
fees of approximately $849,000 to European countries as part of the mutual
recognition process for Remodulin in Europe, and an increase in salary and
related expenses of approximately $445,000 during the three months ended June 30,
2005\.

Cost of sales consists of the cost to manufacture or
acquire products that are sold to customers. Cost of service sales consists of
the salaries and related overhead necessary to provide services to customers.
Cost of product sales was approximately 9% of product sales for each of the
three months ended June 30, 2005 and 2004. Cost of service sales was
approximately 41% of service sales for the three months ended June 30,
2005, which is consistent with approximately 45% for the three months ended June 30,
2004\.

Interest income for the
three months ended June 30, 2005 was approximately $1.2 million, as
compared to interest income of approximately $674,000 for the three months
ended June 30, 2004. The

19

  
* * *

  
increase
is due primarily to an increase in cash available for investing during 2005 and
increased market interest rates.

Equity loss in affiliate
represents United Therapeutics’ share of Northern Therapeutics, Inc.’s
losses. At June 30, 2005, United Therapeutics owned approximately 68% of
Northern Therapeutics. The equity loss in affiliate was approximately $195,000
for the three months ended June 30, 2005, as compared to approximately
$111,000 for the three months ended June 30, 2004. Northern Therapeutics, Inc.’s
loss is due primarily to expenditures for its autologous (non-viral vector)
gene therapy research for pulmonary hypertension and sales and marketing
activities for Remodulin in Canada.

United Therapeutics did
not incur income tax expense for the three-month periods ended June 30,
2005 and 2004 generally due to the availability of deductions for tax purposes
and the availability of net operating loss carryforwards which will offset any
taxable income for these periods.  However, United Therapeutics may incur income
tax expenses and benefits in future periods.

**_Six Months ended June 30,
2005 and 2004_**

| | |**Revenues for the  
Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**(in thousands)** | |
|Remodulin | |$ |49,921 | |$ |27,807 | |
|Telemedicine services
and products | |2,765 | |2,487 | |
|Other products | |381 | |1,688 | |
|License fees | |197 | |— | |
|Total revenues | |$ |53,264 | |$ |31,982 | |

Revenues for the six months ended June 30, 2005
were approximately $53.3 million, as compared to approximately $32.0 million
for the six months ended June 30, 2004. The increase of approximately
$21.3 million was due primarily to growth in patient use of Remodulin. For the
six-month periods ended June 30, 2005 and 2004, approximately 90 percent
and 85 percent of United Therapeutics revenues were earned from customers
located in the United States, respectively.

A roll
forward of the liability accounts associated with estimated government rebates,
prompt pay discounts and fees to a distributor for services as well as the net
amount of reductions to revenues for these items are presented as follows (in
thousands):

| | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
|Liability accounts, at
beginning of period | |$ |2,121 | |$ |936 | |
|Additions to liability | |3,005 | |2,127 | |
|Payments | |(3,301 |) |(2,014 |) |
|Liability accounts, at
end of period | |$ |1,825 | |$ |1,049 | |
|Net reductions to revenues | |$ |3,005 | |$ |2,127 | |

Product returns were due to arginine products and
totaled approximately $2,000 and $28,000 during the six months ended
June 30, 2005 and 2004, respectively.

Research and development expenses were approximately
$17.2 million for the six months ended June 30, 2005, as compared to
approximately $15.9  million for the six
months ended June 30, 2004. The increase was due primarily to increased
expenses for the infectious disease program of approximately $1.1 million
during the six months ended June 30, 2005. See _Major
Research and Development Projects_ above, for additional information.

20  
* * *  
Selling, general and administrative expenses were
approximately $12.4 million for the six months ended June 30, 2005, as
compared to approximately $11.1 million for the six months ended June 30,
2004\. The increase in selling, general and administrative expenses was due
primarily to the payment of one-time application fees of approximately $849,000
to European countries as part of the mutual recognition process for Remodulin
approval in Europe.

Cost of product sales was approximately 9% of product
sales for the six months ended June 30, 2005, which is consistent with
approximately 10% for the six months ended June 30, 2004. Cost of service
sales was approximately 43% of service sales for the six months ended June 30,
2005 which is consistent with approximately 45% for the six months ended June 30,
2004\.

Interest income for the six months ended June 30,
2005 was approximately $2.2 million, as compared to interest income of
approximately $1.3 million for the six months ended June 30, 2004. The
increase is due primarily to an increase in cash available for investing during
2005 and increased market interest rates.

The equity loss in affiliate was approximately
$375,000 for the six months ended June 30, 2005, as compared to
approximately $238,000 for the six months ended June 30, 2004. Northern
Therapeutics, Inc.’s loss is due primarily to expenditures for its
autologous (non-viral vector) gene therapy research for pulmonary hypertension
and sales and marketing activities for Remodulin in Canada.

United Therapeutics did
not incur income tax expense for the six-month periods ended June 30, 2005
and 2004 generally due to the availability of deductions for tax purposes and
the availability of net operating loss carryforwards which will offset any
taxable income for these periods.  However, United Therapeutics may incur income
tax expenses and benefits in future periods.

**Liquidity and Capital Resources**

Until June 1999, United Therapeutics financed its
operations principally through private placements of common stock. On June 17,
1999, United Therapeutics completed its initial public offering. Net proceeds
to United Therapeutics from the initial public offering and sale of the
over-allotment shares, after deducting underwriting commissions and offering
expenses, were approximately $56.4 million. In 2000, United Therapeutics issued
common stock in two private placements and received aggregate net proceeds of
approximately $209.0 million. Until 2002, United Therapeutics funded the
majority of its operations from such net proceeds of equity. During 2005,
United Therapeutics funded the majority of its operations from revenues, mainly
Remodulin related, and this is expected to continue.

In addition, in February 2005, United
Therapeutics filed a primary shelf registration statement with the SEC to
enable United Therapeutics to offer and sell up to five million shares of its
common stock from time to time in one or more offerings. The shelf registration
statement will provide United Therapeutics the flexibility to take advantage of
future financing opportunities on terms that United Therapeutics considers advantageous,
with terms that would be established at the time of any such offering. The
shelf registration statement was declared effective in February 2005.

United Therapeutics’ working capital at June 30,
2005 was approximately $110.9 million, as compared to approximately $96.6
million at December 31, 2004. The increase is primarily due to a net
increase in cash and current marketable investments of approximately $12.4
million.

Net cash provided by operating activities was
approximately $20.4 million for the six months ended June 30, 2005 as
compared to approximately $7.8 million for the six months ended June 30,
2004\. The increase in cash provided by operating activities is due primarily to
growth in sales and collections of Remodulin. For each of the six month periods
ended June 30, 2005 and 2004, United Therapeutics invested approximately
$3.7 million in cash for property, plant and equipment.

21

  
* * *

  
United Therapeutics made milestone payments totaling
$20,000 pursuant to existing license agreements during the six months ended June 30,
2005\. United Therapeutics is obligated to make royalty payments on sales of
Remodulin which exceed annual net sales of $25.0 million and on all arginine
products. Royalties on sales of all products currently marketed will range up
to 10% of sales of those products.

United Therapeutics
believes that its existing revenues, together with existing capital resources
(comprised primarily of unrestricted cash, cash equivalents and marketable
investments), will be adequate to fund its operations. Factors that could cause
actual results of operations to differ from these expectations include the
following:

· Continued
regulatory approval of Remodulin in the United States and other countries;

· Size,
scope, timely completion and outcome of the Remodulin post-marketing Phase IV
clinical study;

· Additional
regulatory approvals of Remodulin in other countries;

· Retention
and growth of reimbursable patients treated with Remodulin;

· Impact
of infusion site pain and infusion site reaction and other Remodulin side
effects;

· Changes
in the current Remodulin pricing and dosing;

· Changes
in the length of time that Remodulin vials may be used by patients;

· Reimbursement
of Remodulin by public and private payers and the level of reimbursement;

· Impact
of other approved and investigational competitive products and changes in their
pricing;

· Impact of the possible
future introduction of a generic prostacyclin or prostacyclin analog;

· Changes
in prescribers’ opinions about Remodulin;

· Impact
of medical and scientific opinion on United Therapeutics’ products;

· Cost,
timing and outcomes of regulatory reviews;

· Rate
of technological advances;

· Continued
performance by Remodulin distributors under existing agreements;

· Development
of manufacturing resources or the establishment, continuation or termination of
third-party manufacturing arrangements;

· Development
of sales and marketing resources or the establishment, continuation or
termination of third-party sales and marketing arrangements;

· Impact
of any regulatory restrictions on United Therapeutics’ marketing and
promotional activities;

· Establishment,
continuation or termination of third-party clinical trial arrangements;

· Defending
and enforcing intellectual property rights;

· Impact of any future
impairment of goodwill or intangible assets;

· Future
milestone and royalty payments;

· Risks
associated with acquisitions, including the ability to integrate acquired
businesses;

· Actual
expenses incurred in future periods;

22

  
* * *

  
· Establishment
of additional strategic acquisitions or licensing arrangements; and

· Ability
of United Therapeutics to maintain and grow its telemedicine and arginine
revenues.

United Therapeutics did
not incur income tax expense for the three and six-month periods ended June 30,
2005 generally due to the availability of deductions for tax purposes and net
operating loss carryforwards which will offset any taxable income for this
period. As of June 30, 2005, United Therapeutics had available
approximately $101.3 million in net operating loss carryforwards and
approximately $27.7 million in business tax credit carryforwards for federal
income tax purposes that expire at various dates through 2024. United
Therapeutics is currently conducting a study to determine whether any limitations
under Section 382 of the Internal Revenue Code have been triggered.
Preliminary results of this study indicate that multiple limitations occurred
through the middle of 2004. As a result, portions of these carry-forward items
that were generated prior to the middle of 2004 will be subject to certain
limitations on their use. United Therapeutics does not believe that these
limitations will cause the net operating loss and general business credit
carryforwards to expire unused.

**Off Balance Sheet Arrangement**

In June 2004, United Therapeutics entered into a
synthetic operating lease and related agreements with Wachovia Development
Corporation and its affiliates (Wachovia) to fund the construction of a
laboratory facility in Silver Spring, Maryland. Under these agreements,
Wachovia will fund up to $32.0 million towards the construction of the
laboratory facility on ground owned by United Therapeutics. The construction
phase commenced in 2004 and is expected to be completed in early 2006.
Following construction, Wachovia will lease the laboratory facility to United
Therapeutics with a term ending in May 2011. Under the 99-year ground
lease, Wachovia will pay fair value rent to United Therapeutics for use of the
land both during the construction phase and after the laboratory lease is
terminated. During the term of the laboratory lease, Wachovia will pay $1 per
year to United Therapeutics for use of the land.

Upon completion of the construction, Wachovia will
receive rents from United Therapeutics generally based on applying the 30-day
LIBOR rate plus approximately 55 basis points to the amount funded by Wachovia
towards the construction of the laboratory. These rents will be paid monthly
from the time that the laboratory construction is completed until the termination
of the lease in May 2011. Upon termination of the lease, United
Therapeutics will generally have the option of renewing the lease (subject to
approval of both parties), purchasing the laboratory at a price approximately
equal to the funded construction cost or selling it and repaying Wachovia the
cost of its construction. United Therapeutics has guaranteed that if the
laboratory is sold, Wachovia will receive at least 86 percent of the amount it
funded towards the construction.

In addition, United Therapeutics agreed to pledge, as
collateral, a portion of its marketable investments to secure its lease
obligations. At June 30, 2005, approximately $10.3 million of marketable
investments and cash were pledged as collateral and are reported as restricted
marketable investments and cash in the consolidated balance sheets.

This arrangement allows United Therapeutics to
construct its laboratory facility without using its own working capital. United
Therapeutics will manage the construction and incur construction costs.
Wachovia will then reimburse these construction costs each month as they are
incurred. United Therapeutics will make rent payments to Wachovia starting when
construction of the facility is completed and through the lease termination in May 2011.
There will not be any depreciation expense associated with the laboratory
facility, since these improvements will be owned by Wachovia. The amount of
rent to be paid to Wachovia will vary as it is tied to the then current 30-day
LIBOR rate plus approximately 55 basis points. As this rate increases, so will
the rents to be paid. Similarly, if this rate decreases, then the amount of
rent to be paid to Wachovia will also decrease.

23

  
* * *

  
United Therapeutics anticipates that rent payments
will commence in early 2006, after completion of construction, and continue
through termination of the lease in May 2011. Based on construction costs
of up to approximately $32.0 million and the current effective rate of
approximately 3.9 percent (equivalent to the current 30-day LIBOR rate plus
approximately 55 basis points at June 30, 2005), the rents to be paid
could approximate $1.2 million annually. In addition, Wachovia has paid to
United Therapeutics ground rent totaling an aggregate of approximately $307,000
that will be recognized in income ratably through May 2011.

United Therapeutics has guaranteed a minimum residual
value of the laboratory facility. This guaranteed residual is generally equal
to 86 percent of the amount funded by Wachovia towards construction. If, at the
end of the lease term, United Therapeutics does not renew the lease or purchase
the improvements, then the building will be sold to a third party. In that
event, United Therapeutics has guaranteed that Wachovia will receive at least
this residual value amount. The maximum potential amount of this guarantee is
approximately $27.5 million, equivalent to 86 percent of expected total
construction costs of $32.0 million. United Therapeutics has estimated the fair
value of this guarantee liability at approximately $839,000 and this amount is
classified as a non-current liability in its balance sheet at June 30,
2005\.

The lease and other agreements with Wachovia require
that, among other things, United Therapeutics maintain a consolidated current
ratio of not less than 1.2:1.0 and a consolidated net worth of at least $70.0
million. The agreements contain other covenants and conditions with which
United Therapeutics must comply throughout the construction and lease periods
and upon termination of the lease. If United Therapeutics was unable to comply
with these covenants and conditions, the agreements could terminate if the
noncompliance was uncured and the parties could not agree otherwise. A
termination of these agreements could result in United Therapeutics acquiring the
improvements from Wachovia or the loss of its liquid collateral. If the
agreements are terminated during the construction period due to United
Therapeutics’ default, then United Therapeutics could be required to purchase
the improvements. During construction, the amount United Therapeutics would be
required to pay is limited to 89.9 percent of the construction costs.

In March 2005, United
Therapeutics entered into a construction management agreement with Turner
Construction Company (“Turner”). Turner will manage the construction of the new
laboratory facility. Under the terms of the agreement, Turner will be
responsible for the construction of the facility. The agreement has a
guaranteed maximum price clause in which Turner agrees that the construction cost
of the facility will not exceed approximately $27.0 million, which amount is
subject to change based on agreed-upon changes to the scope of work. Turner
will be responsible for covering any costs in excess of the guaranteed maximum
price guarantee. If the ultimate cost of the project is less than the
guaranteed maximum price of $27.0 million, then a portion of the costs savings
will be shared with Turner. In addition, Turner must pay penalties to United
Therapeutics if the construction is not completed by April 2006, which
date is subject to change based on agreed-upon changes to the scope of work.

24  
* * *  
**Contractual
Obligations**

At June 30,
2005, United Therapeutics had contractual obligations coming due approximately
as follows (in thousands):

| | |**Payment Due In** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Total** | |**Remainder  
of  
2005** | |**2006  
to  
2008** | |**2009  
to  
2010** | |**2011  
and  
Later** | |
|Notes payable and
capital lease  
obligations | |$ |811 | | |$ |430 | | |$ |381 | |$ |— | |$ |— | |
|Operating lease
obligations(1) | |10,878 | | |517 | | |6,429 | |3,205 | |727 | |
|Construction
agreement(2) | |28,837 | | |16,896 | | |6,941 | |— | |— | |
|Purchase
obligations | |481 | | |481 | | |— | |— | |— | |
|Other long-term
liabilities reflected in the statement of financial position(1) | |839 | | |— | | |— | |— | |839 | |
|Milestone
payments(3) | |9,745 | | |— | | |4,685 | |3,040 | |2,020 | |
| | |$ |46,591 | | |$ |18,324 | | |$ |18,436 | |$ |6,245 | |$ |3,586 | |

* * *

(1) Operating lease obligations include the
estimated lease payments on the laboratory facility being constructed in Silver
Spring, Maryland. The lease is expected to commence in early 2006 and will
expire in May 2011. The lease payments will generally be equal to applying
the current 30-day LIBOR rate plus approximately 55 basis points
(approximately 3.9 percent at June 30, 2005) to the cost of the
construction of the laboratory. Upon termination of the lease, United
Therapeutics will generally have the option of renewing the lease, purchasing
the laboratory or selling it and repaying Wachovia the cost of its
construction. United Therapeutics has guaranteed that if the laboratory is
sold, Wachovia will receive at least 86 percent of the amount it funded towards
the construction. It is estimated that the laboratory will cost approximately
$32.0 million to construct and the guarantee is estimated at approximately
$27.5 million. The estimated fair value of the guarantee is included in other
long-term liabilities reflected in the statement of financial position. See _Off Balance Sheet Arrangement_ for additional information.

(2) Wachovia is contractually obligated to reimburse these
amounts to United Therapeutics under the synthetic operating lease agreement
described above under _Off Balance Sheet
Arrangement._

(3) United Therapeutics has licensed certain
products from other companies under certain license agreements. These
agreements generally include milestone payments to be paid in cash by United
Therapeutics upon the achievement of certain product development and
commercialization goals set forth in each license agreement. Total milestone
payments under these license agreements have been estimated based on the
estimated timing of these development and commercialization goals.

**Summary
of Critical Accounting Policies**

_Income Taxes_

United Therapeutics accounts for income taxes in
accordance with SFAS No. 109, Accounting for Income Taxes. Under the asset
and liability method of SFAS No. 109, deferred tax assets and liabilities
are determined based on the differences between the financial reporting and the
tax bases of assets and liabilities and are measured using the tax rates and
laws that are expected to apply to taxable income in the years in which those
temporary differences are expected to be recovered or settled.  A net deferred tax asset or liability is
reported in the balance sheet.

At each reporting date,
management considers whether it is more-likely-than-not that some portion or
all of the net deferred tax asset is realizable. If the net deferred tax asset
is not fully realizable, then a valuation allowance is established to reduce
the amount of net deferred tax asset reported in the balance sheet.  Based on the weight of available evidence at June 30,
2005, it was determined that a full valuation allowance was necessary at June 30,
2005\.

25

  
* * *

  
_Remodulin Revenue
Recognition_

Product sales of Remodulin are recognized when
delivered to distributors, which are United Therapeutics’ customers for
Remodulin. Product sales of Remodulin delivery pumps and related supplies are
recognized when delivered to distributors on a gross basis in accordance with
EITF Issue No. 99-19, _Reporting Revenue Gross as
a Principal versus Net as an Agent_ . Title to these products passes
upon delivery. Had the net basis been applied, the amounts of revenues and cost
of product sales reported in the consolidated financial statements would have
been lower, but there would have been no impact on net income or losses. Prompt
payment discounts, government rebates and fees to a distributor (customer) are
estimated and recognized as reductions of revenue in the same period that
revenues are recognized. Had these discounts, rebates and fees not been
reported as reductions of revenue, the amounts reported as revenues and selling
expenses would have been higher, but there would have been no impact on net
income or losses. Return policies provide that product that has expired or
become damaged in shipment may be replaced, but not returned. Therefore,
reserves for exchanges are not recorded unless product expiration or damage
occurs. The shelf life of Remodulin is two and one-half years from the date of
its manufacture. United Therapeutics relies on its distributors to report
damage in shipment or expirations of Remodulin product.

One of United Therapeutics’
Remodulin distribution agreements stipulates minimum quarterly purchases by the
distributor for periods through June 30, 2005. The distribution agreement,
however, does not permit the distributor to return Remodulin product solely
based on the distributor’s ability or inability to resell the product. As such,
revenues from sales to this distributor are recognized in the period that the
Remodulin product is delivered to the distributor. During the three-month
periods ended June 30, 2005 and 2004, approximately $2.0 million and
$503,000, of Remodulin products were sold to this distributor and recognized as
revenue, respectively. During the six-month periods ended June 30, 2005
and 2004, approximately $4.0 million and $1.0 million, of Remodulin products
were sold to this distributor and recognized as revenue, respectively.

_Intangible Assets_

United Therapeutics
adopted the provisions of Statement of Financial Accounting Standards No. 142 _, Goodwill and Other Intangible Assets_ (SFAS No. 142),
on January 1, 2002, which eliminated the amortization of goodwill. Rather,
goodwill is subject to at least an annual assessment for impairment by applying
a fair value-based test that is performed on October 1 st of
each year. United Therapeutics continually evaluates whether events and
circumstances have occurred that indicate that the remaining value of goodwill
may not be recoverable. At June 30, 2005, management believed that
goodwill was not impaired and therefore no impairment losses have been
recorded. This conclusion is based on management’s judgment, taking into
consideration expectations regarding future profitability and the status of the
reporting units which have reported goodwill. However, changes in strategy or
adverse changes in market conditions could impact this judgment and require an
impairment loss to be recognized for the amount that the carrying value of
goodwill exceeds its fair value.

_Marketable
Investments_

Currently, United
Therapeutics invests portions of its cash in debt securities issued by
federally-sponsored agencies and state-sponsored student loan agencies. Due to
United Therapeutics’ intent and ability to hold these marketable debt
investments until their maturities, these investments are reported at their
amortized cost. United Therapeutics believes that it is able to hold these
investments to maturity, due to the significant level of cash and cash
equivalents it has. If United Therapeutics did not have the ability and intent
to hold these investments to maturity, it would have reported them in the
consolidated balance sheets at their fair market values. At June 30, 2005,
the amortized cost of these debt securities was approximately $67.2 million and
their fair values were approximately $66.3 million.

26

  
* * *

  
_Earnings per Share_

In accordance with SFAS No. 128, _Earnings Per Share_ , for the periods with
net income, the dilutive effect of outstanding stock options is included in the
calculation of dilutive earnings per share using the treasury stock method.

_Stock Options_

United
Therapeutics applies the principles of APB No. 25, _Accounting
for Stock Issued to Employees,_ in accounting for its stock options
issued to its employees. The following table details the pro forma results had
United Therapeutics applied the fair value principles of SFAS No. 123, _Accounting for Stock-Based Compensation_ , for its employee
options (in thousands):

| | |**Three Months Ended  
June 30,** | |**Six Months Ended  
June 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income, as reported | |$ |12,181 | |$ |4,140 | |$ |19,843 | |$ |2,293 | |
|Less total
stock-based employee compensation expense determined under fair value based
method for all awards | |(3,279 |) |(1,774 |) |(6,558 |) |(3,548 |) |
|Pro forma net income
(loss) | |$ |8,902 | |$ |2,366 | |$ |13,285 | |$ |(1,255 |) |

_Investments in
Affiliates_

The equity method of accounting is used to account for
most of United Therapeutics’ investments in affiliates. The equity method of
accounting generally requires United Therapeutics to report its share of the
affiliates’ net losses or profits in its financial statements, but does not
require that assets, liabilities, revenues and expenses of the affiliates be
consolidated with United Therapeutics’ consolidated financial statements. The
equity method of accounting is being applied generally due to the lack of
control over these affiliates and the levels of ownership held by United
Therapeutics. Although United Therapeutics’ investment in Northern Therapeutics
exceeds 50 percent, minority shareholders possess substantive participating
rights that preclude Northern Therapeutics’ financial statements from being
consolidated.

Other investments in affiliates are accounted for on
the cost method generally due to the lack of significant influence over these
affiliates and a less than 20 percent ownership by United Therapeutics. The
cost method of accounting does not require that United Therapeutics report its
share of the affiliates’ net losses or profits in its financial statements, nor
are affiliates’ assets, liabilities, revenues and expenses consolidated with
United Therapeutics’ consolidated financial statements.

The investment in ViRexx
Medical Corporation (formerly AltaRex Medical Corp.) is accounted for as an
available-for-sale security because its stock is publicly traded.
Available-for-sale securities are reported at their fair values in the balance
sheet. Changes in their fair values are reported as other comprehensive income
or loss. Declines in values that are considered other-than-temporary are
reported as losses in the statement of operations. For the three months ended June 30,
2005, the fair value of the investment in ViRexx decreased by approximately
$2.2 million as compared to an increase in fair market value of approximately
$394,000 for the three months ended June 30, 2004, based on quoted market
prices. For the six months ended June 30, 2005, the fair value of the
investment in ViRexx decreased by approximately $790,000 as compared to a
decrease in fair market value of approximately $1.1 million for the six months
ended June 30, 2004, based on quoted market prices. These changes in fair
market value were reported as other comprehensive income or loss.

27

  
* * *

  
_Options Issued in
Exchange for License_

In June 2000, in
connection with the license from Toray Industries for the sustained release
formulation of beraprost (an oral prostacyclin analog), United Therapeutics
agreed to grant options to purchase 500,000 shares of common stock to Toray
upon Toray’s adequate documentation of sustained release beraprost in humans
and its transfer of clinical trial material for use in clinical trials in the
United States. These options will not be priced until Toray has met this
milestone. If and when the milestone is met, the options would be granted at
the fair market value of United Therapeutics’ common stock at that time. Before
Toray can produce the clinical trial material, it will need to complete
formulation, preclinical testing and early clinical studies. Due to the
uncertainties in drug development, it is not yet known if Toray will provide
the appropriate clinical trial material. Therefore, in accordance with EITF
Issue No. 96-18, _Accounting for Equity
Instruments that are Issued to Other than Employees_ , these options
are measured at their lowest aggregate fair value at each interim reporting
date, which amount has been zero. As a result, no expense related to these
options has been recorded in the consolidated financial statements.

_Lease of Laboratory
Facility_

In June 2004, United Therapeutics entered into a
synthetic operating lease and related agreements with Wachovia to fund the
construction of a laboratory facility in Silver Spring, Maryland. The total
amount of the construction is expected to be $32.0 million. The laboratory
facility will be owned by Wachovia, which will act as the lessor, and United
Therapeutics will be the lessee and pay rents to Wachovia once the facility is
completed. This arrangement is a form of off-balance sheet financing under
which Wachovia will fund 100 percent of the costs for the construction of the property
and lease the laboratory facility to United Therapeutics. United Therapeutics
has provided a residual value guarantee which guarantees Wachovia that the
residual value of the leased assets will be at least equal to a specified
amount at lease termination.

In accordance with the guidance in Statement of
Financial Accounting Standards No. 13, _Accounting_ _for Leases_ , EITF Issue No. 97-1, _Implementation Issues in Accounting for Lease Transactions, Including
Those Involving Special-Purpose Entities_ , EITF Issue No. 97-10, _The Effect of Lessee Involvement in Asset
Construction_ , and FASB Interpretation No. 46, _Consolidation of Variable Interest Entities_ , United
Therapeutics has determined that the lease is properly classified as an
operating lease for accounting purposes. Furthermore, United Therapeutics has
determined that Wachovia has sufficient substance such that it can be treated
as an unrelated entity to United Therapeutics and, accordingly, does not
require consolidation into United Therapeutics’ financial statements.

Operating leases of assets
do not require that the leased asset and the related rent obligation be
reported in the lessee’s balance sheet, but rather be disclosed. In contrast,
capital leases do require that the leased asset and rent obligations be
reported in the lessee’s balance sheet as assets and debt. Changes in the
equity participation by Wachovia and its affiliates under the agreements could
affect the classification of the lease from operating to capital. In that
event, United Therapeutics would include both the assets and debt associated
with the laboratory facility on its balance sheet.

**Recent Accounting Pronouncements**

_Stock-Based
Compensation_

On December 16, 2004, the Financial Accounting
Standards Board (FASB) issued a revision of Statement of Financial Accounting
Standards No. 123 (revised 2004), _Share-Based
Payment_ (Statement 123(R)), which is a revision of FASB Statement No. 123, _Accounting for Stock-Based Compensation_ (Statement 123) _._ Statement 123(R) supersedes APB Opinion No. 25, _Accounting for Stock Issued to Employees_ (Opinion 25), and amends FASB
Statement No. 95 _, Statement of Cash
Flows._ Generally, the approach in Statement 123(R) is similar
to the approach described in Statement 123.

28

  
* * *

  
Statement 123(R) was
initially required to be implemented by July 1, 2005, but its effective
date has been delayed until January 1, 2006 by the Securities and Exchange
Commission. Accordingly, United Therapeutics anticipates that it will adopt
Statement 123(R) on January 1, 2006.

As permitted by Statement 123, United Therapeutics
currently accounts for share-based payments to employees using Opinion 25’s
intrinsic value method and, as such, generally recognizes no compensation cost
for employee stock options. However, Statement 123(R) requires all share-based payments to
employees, including grants of employee stock options, to be recognized in the
income statement based on their fair values over the expected period of
service. Accordingly, the adoption of Statement 123(R)’s fair value method will
have a significant impact on United Therapeutics’ results of operations,
although it will have no impact on United Therapeutics’ overall financial
position.

The full impact of
adoption of Statement 123(R) cannot be predicted at this time because it
will depend on levels of share-based payments granted in the future. However,
had United Therapeutics adopted Statement 123(R) in prior periods, the
impact of that standard would have approximated the impact of Statement 123 as
described in the disclosure of pro forma net income and earnings per share in
Note 2 to the consolidated financial statements contained in United
Therapeutics’ Annual Report on Form 10-K for the year ended December 31,
2004 and in Note 3 to the interim consolidated financial statements contained
in this Form 10-Q. Statement 123(R) also requires the benefits
of tax deductions in excess of recognized compensation cost to be reported as a
financing cash flow, rather than as an operating cash flow as required under
current literature. This requirement will reduce net operating cash flows and
increase net financing cash flows in periods after adoption. United
Therapeutics is unable to estimate what those amounts will be in the future
because they depend on, among other things, when employees exercise stock
options.

_Other-than-Temporary
Impairment_

In March 2004, the
Emerging Issues Task Force (EITF) reached a consensus on Issue No. 03-01,
“ _The Meaning of Other-Than-Temporary Impairment and
Its Application to Certain Investments._ ” EITF Issue No. 03-01
provides guidance on other-than-temporary impairment models for marketable debt
and equity securities accounted for under SFAS No. 115, “ _Accounting for Certain Investments in Debt and Equity Securities_ ”
and non-marketable equity securities accounted for under the cost method. The
EITF developed a basic three-step model to evaluate whether an investment is
other-than-temporarily impaired. The effective date of the recognition and
measurement provisions of EITF Issue No. 03-01 has been delayed by
the FASB, however, the FASB did not suspend the requirement to recognize
other-than-temporary impairments as required by existing authoritative
literature. United Therapeutics does not expect the adoption of EITF Issue No. 03-01
to have a significant impact on United Therapeutics’ results of operations and
financial condition.

_Inventory Costs_

In December 2004, the
FASB issued SFAS Statement No. 151 _Inventory
Cost,_ which is an amendment to Accounting Research Bulletin No. 43,
“ _Restatement and Revision of Accounting Research
Bulletins”._ SFAS 151 clarifies the accounting treatment of certain
expenses for inventory costing. The new standard will be effective for the
first fiscal year beginning after June 15, 2005. United Therapeutics has
not yet completed its assessment of the impact of adopting this new standard.

29

  
* * *

  
**Item 3.** Quantitative
and Qualitative Disclosures about Market Risk

At March 31,
2005, a substantial portion of United Therapeutics’ assets were comprised of
debt securities issued by federally-sponsored agencies. The market value of
these investments fluctuates with changes in current market interest rates. In
general, as rates increase, the market value of a debt investment would be
expected to decrease. Likewise, as rates decrease, the market value of a debt investment
would be expected to increase. To minimize such market risk, United
Therapeutics holds such instruments to maturity at which time these instruments
will be redeemed at their stated or face value. At June 30, 2005, United
Therapeutics had approximately $67.2 million in debt securities issued by
federally sponsored agencies with a weighted average stated interest rate of
approximately 3.6 percent maturing through March 2012 and callable
annually. The fair market value of this held-to-maturity portfolio at June 30,
2005 was approximately $66.3 million.

At June 30, 2005, a portion of United
Therapeutics’ assets were comprised of auction rate debt securities. While
these securities have long term maturities, their interest rates are reset
approximately every 7-28 days through an auction process. As a result,
the interest income from these securities is subject to market risk since the
rate is adjusted to accommodate market conditions on each reset date. However,
since the interest rates are reflective of current market conditions, the fair
value of these securities typically does not fluctuate from par or cost. At June 30,
2005, United Therapeutics had approximately $37.7 million in these debt
securities with a weighted average stated interest rate of approximately 3.2
percent. The fair market value of these available-for-sale debt securities at June 30,
2005 was approximately $37.7 million.

In June 2004, United
Therapeutics entered into a synthetic operating lease and related agreements
with Wachovia Development Corporation and its affiliates (Wachovia) to fund the
construction of a laboratory facility in Silver Spring, Maryland. Under these
agreements, United Therapeutics will pay rents to Wachovia generally based on
applying the 30-day LIBOR rate plus approximately 55 basis points to the
amount funded by Wachovia towards the construction of the laboratory. The total
amount of construction is estimated to be approximately $32.0 million. At June 30,
2005, the total amount incurred related to the construction was approximately
$8.2 million. Rents will be paid monthly from the time that the laboratory
construction is completed until the termination of the lease in May 2011.
These rents, therefore, are subject to the risk that LIBOR will increase or
decrease during the period until termination in May 2011. At June 30,
2005, the 30-day LIBOR was approximately 3.3 percent. For every movement
of 100 basis points (1 percent) in the 30-day LIBOR rate, the rents under
this lease could increase or decrease by approximately $320,000 on an
annualized basis.

**Item 4.** Controls
and Procedures

Based on their evaluation, as of June 30, 2005,
United Therapeutics’ Chief Executive Officer and Chief Financial Officer have
concluded that United Therapeutics’ disclosure controls and procedures (as
defined in Rule 13a-15(e) and 15d-15(e) under the
Securities Exchange Act of 1934, as amended) are effective. There have been no
changes in United Therapeutics’ internal control over financial reporting that
occurred during the period covered by this report that have materially
affected, or are reasonably likely to materially affect, such internal control
over financial reporting.

30  
* * *  
**Part II. OTHER INFORMATION**

**Item 4.** Submission
of Matters to a Vote of Security Holders

United
Therapeutics held its annual meeting of stockholders on June 29, 2005. All
of the following persons nominated were elected to serve as directors for a
term expiring in 2008 and received the votes set opposite their respective
names:

| | |**For** | |**Withheld** | |
| --- | --- | --- | --- | --- | --- |
|Raymond Dwek | |16,417,231 | |1,790,431 | |
|Roger Jeffs | |16,275,807 | |1,931,855 | |
|Christopher Patusky | |16,853,011 | |1,354,651 | |

**Item 6.** Exhibits
and Reports on Form 8-K

(a) Exhibits

|Exhibit No. | | | |Description | | |
| --- | --- | --- | --- | --- | --- | --- |
|31\.1 | |Certification of Chief
Executive Officer pursuant to Rule 13a-14(a) of the Securities
Exchange Act of 1934. |
|31\.2 | |Certification of Chief
Financial Officer pursuant to Rule 13a-14(a) of the Securities
Exchange Act of 1934. |
|32\.1 | |Certification of Chief
Executive Officer pursuant to Section 906 of the Sarbanes-Oxley Act of
2002\. |
|32\.2 | |Certification of Chief
Financial Officer pursuant to Section 906 of the Sarbanes-Oxley Act of
2002\. |

31  
* * *  
**SIGNATURES**

Pursuant
to the requirements of the Securities Exchange Act of 1934, the registrant has
duly caused this report to be signed on its behalf by the undersigned thereunto
duly authorized.

|UNITED THERAPEUTICS CORPORATION |
| --- | --- | --- |
|Date: August 3,
2005 |/s/ MARTINE A. ROTHBLATT |
| |By: |Martine A. Rothblatt |
| |Title: |_Chairman and Chief Executive Officer_ |
| |/s/ FRED T. HADEED |
| |By: |Fred T. Hadeed |
| |Title: |_Executive Vice President for Business_ |
| | |_Development and Chief Financial Officer_ |

32  
* * *