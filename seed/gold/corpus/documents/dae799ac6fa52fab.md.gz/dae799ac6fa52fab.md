XML 37 R24.htm IDEA: XBRL DOCUMENT **Segment Information  
**

12 Months Ended

Dec. 31, 2017

[**Segment Reporting [Abstract]**](javascript:void\(0\);)

Segment Reporting Disclosure

SEGMENT INFORMATION

We have one operating segment, which primarily focuses on the discovery, development and commercialization of innovative medicines in areas of unmet medical need. Therefore, our results of operations are reported on a consolidated basis consistent with internal management reporting reviewed by our chief operating decision maker, who is our chief executive officer. Enterprise-wide disclosures about product sales, revenues and long-lived assets by geographic area, and revenues from major customers are presented below.

Product Sales

Our product sales consist of the following (in millions):

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | |
| | |Year Ended December 31, |
| | |2017 | |2016 | |2015 |
|Antiviral products: | | | | | | |
|Harvoni | |$ |4,370 | | |$ |9,081 | | |$ |13,864 | |
|Genvoya | |3,674 | | |1,484 | | |45 | |
|Epclusa | |3,510 | | |1,752 | | |— | |
|Truvada | |3,134 | | |3,566 | | |3,459 | |
|Atripla | |1,806 | | |2,605 | | |3,134 | |
|Descovy | |1,218 | | |298 | | |— | |
|Stribild | |1,053 | | |1,914 | | |1,825 | |
|Viread | |1,046 | | |1,186 | | |1,108 | |
|Odefsey | |1,106 | | |329 | | |— | |
|Complera/Eviplera | |966 | | |1,457 | | |1,427 | |
|Sovaldi | |964 | | |4,001 | | |5,276 | |
|Vosevi | |293 | | |— | | |— | |
|Other antiviral | |196 | | |72 | | |69 | |
|Total antiviral products | |23,336 | | |27,745 | | |30,207 | |
|Other products: | | | | | | |
|Letairis | |887 | | |819 | | |700 | |
|Ranexa | |717 | | |677 | | |588 | |
|AmBisome | |366 | | |356 | | |350 | |
|Zydelig | |149 | | |168 | | |132 | |
|Other products | |207 | | |188 | | |174 | |
|Total product sales | |$ |25,662 | | |$ |29,953 | | |$ |32,151 | |

Revenues by Geographic Region

The following table summarizes total revenues from external customers and collaboration partners by geographic region (in millions). Product sales and product-related contract revenue are attributed to regions based on ship-to location. Royalty and non-product related contract revenue are attributed to regions based on the location of the collaboration partner.

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | |
| | |Year Ended December 31, |
| | |2017 | |2016 | |2015 |
|Revenues: | | | | | | |
|United States | |$ |18,194 | | |$ |19,354 | | |$ |21,234 | |
|Europe | |5,311 | | |6,365 | | |7,528 | |
|Other countries | |2,602 | | |4,671 | | |3,877 | |
|Total revenues | |$ |26,107 | | |$ |30,390 | | |$ |32,639 | |

Long-lived Assets

The net book value of our property, plant and equipment (less office and computer equipment) in the United States was $2.6 billion as of December 31, 2017 , $2.2 billion as of December 31, 2016 and $1.8 billion as of December 31, 2015 . The corresponding amount in international locations was $520 million as of December 31, 2017 , $430 million as of December 31, 2016 and $334 million as of December 31, 2015 . All individual international locations accounted for less than ten percent of the total balances.

Revenues from Major Customers

The following table summarizes revenues from each of our customers who individually accounted for 10% or more of our total revenues (as a percentage of total revenues):

| |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | |
| | |Year Ended December 31, |
| | |2017 | |2016 | |2015 |
|McKesson Corp. | |23 |% | |22 |% | |24 |% |
|AmerisourceBergen Corp. | |20 |% | |18 |% | |19 |% |
|Cardinal Health, Inc. | |19 |% | |16 |% | |15 |% |