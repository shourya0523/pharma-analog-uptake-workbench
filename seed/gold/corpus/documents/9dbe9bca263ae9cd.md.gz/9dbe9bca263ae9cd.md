XML 29 R39.htm IDEA: XBRL DOCUMENT **Segment, Geographic and Other Revenue Information (Tables)  
**

12 Months Ended

Dec. 31, 2013

[**Segment Reporting [Abstract]**](javascript:void\(0\);)

Schedule of Selected Income Statement Information by Segment

| | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|The following table provides selected income statement information by reportable segment: |
| | |Revenues | |Earnings (a) | |Depreciation and

Amortization (b) |
| | |Year Ended December 31, | |Year Ended December 31, | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2013 | | |2012 | | |2011 (c) | | |2013 | | |2012 | | |2011 (c) | | |2013 | | |2012 | | |2011 (c) | |
|Reportable Segments: | | | | | | | | | | | | | | | | | | |
|Primary Care (d) | |$ |13,272 | | |$ |15,558 | | |$ |22,670 | | |$ |7,981 | | |$ |9,613 | | |$ |15,001 | | |$ |155 | | |$ |244 | | |$ |249 | |
|Specialty Care and Oncology | |14,934 | | |15,461 | | |16,568 | | |10,350 | | |10,499 | | |10,789 | | |351 | | |403 | | |427 | |
|Established Products and Emerging Markets (e) | |19,672 | | |20,195 | | |18,509 | | |11,159 | | |11,217 | | |9,417 | | |390 | | |408 | | |430 | |
|Total reportable segments | |47,878 | | |51,214 | | |57,747 | | |29,490 | | |31,329 | | |35,207 | | |896 | | |1,055 | | |1,106 | |
|Consumer Healthcare and other business activities (f) | |3,574 | | |3,443 | | |3,288 | | |(2,005 |) | |(2,397 |) | |(2,608 |) | |166 | | |190 | | |223 | |
|Reconciling Items: | | | | | | | | | | | | | | | | | | | | | | |
|Corporate | |— | | |— | | |— | | |(5,800 |) | |(6,112 |) | |(7,317 |) | |382 | | |485 | | |540 | |
|Purchase accounting adjustments (g) | |— | | |— | | |— | | |(4,344 |) | |(4,905 |) | |(6,672 |) | |4,487 | | |4,988 | | |5,476 | |
|Acquisition-related costs (h) | |— | | |— | | |— | | |(376 |) | |(946 |) | |(1,913 |) | |124 | | |273 | | |614 | |
|Certain significant items (i) | |132 | | |— | | |— | | |(692 |) | |(5,039 |) | |(4,255 |) | |167 | | |300 | | |614 | |
|Other unallocated (j) | |— | | |— | | |— | | |(557 |) | |(688 |) | |(961 |) | |84 | | |103 | | |128 | |
| | |$ |51,584 | | |$ |54,657 | | |$ |61,035 | | |$ |15,716 | | |$ |11,242 | | |$ |11,481 | | |$ |6,306 | | |$ |7,394 | | |$ |8,701 | |

|(a) |Income from continuing operations before provision for taxes on income. |
| --- | --- |

|(b) |Certain production facilities are shared. Depreciation is allocated based on estimates of physical production. Amounts here relate solely to the depreciation and amortization associated with continuing operations. |
| --- | --- |

|(c) |For 2011, includes King commencing on the acquisition date of January 31, 2011. |
| --- | --- |

|(d) |Revenues and Earnings from the Primary Care segment decreased for 2013 as compared to the prior year, and Earnings as a percentage of revenues for 2013 also declined, primarily due to the loss of exclusivity of Lipitor in developed Europe and Australia; the subsequent shift in the reporting of Lipitor in those major markets to the Established Products business unit; the losses of exclusivity of certain other products in various markets; lower Alliance revenues from Spiriva due to the ongoing expiration of the Spiriva collaboration in certain countries; and the termination of the co-promotion agreement for Aricept in Japan in December 2012. Revenues and Earnings from the Primary Care segment decreased for 2012 as compared to 2011, and Earnings as a percentage of revenues also declined, primarily due to the loss of exclusivity of Lipitor in most major markets, and the subsequent shift in the reporting of Lipitor in those major markets to the Established Products business unit. |
| --- | --- |

|(e) |Revenues and Earnings from the Established Products and Emerging Markets segment decreased in 2013 as compared to the prior year, primarily due to the continued erosion of branded Lipitor in the U.S. and Japan, partially offset by the addition of products in certain markets that shifted to the Established Products unit from other business units beginning January 1, 2013 and strong volume growth in China. Revenues and Earnings from the Established Products and Emerging Markets segment increased in 2012 as compared to 2011, primarily due to additional products losing exclusivity and moving to the Established Products unit and increased operational sales in emerging markets, partially offset by unfavorable foreign exchange. Earnings as a percentage of revenue in 2012 increased due to the change in the mix of products. |
| --- | --- |

|(f) |Other business activities includes the revenues and operating results of Pfizer CentreSource, our contract manufacturing and bulk pharmaceutical chemical sales operation, and the R&D costs managed by our Worldwide Research and Development organization and our Pfizer Medical organization. |
| --- | --- |

|(g) |Purchase accounting adjustments include certain charges related to the fair value adjustments to inventory, intangible assets and property, plant and equipment. |
| --- | --- |

|(h) |Acquisition-related costs can include costs associated with acquiring, integrating and restructuring newly acquired businesses, such as transaction costs, integration costs, restructuring charges and additional depreciation associated with asset restructuring. For additional information, see Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and Cost-Reduction/Productivity Initiatives . |
| --- | --- |

|(i) |Certain significant items are substantive, unusual items that, either as a result of their nature or size, would not be expected to occur as part of our normal business on a regular basis. |
| --- | --- |

For Revenues in 2013, certain significant items represent revenues related to our transitional manufacturing and supply agreements with Zoetis. For additional information, see Note 2B. Acquisitions, Divestitures, Collaborative Arrangements and Equity-Method Investments: Divestitures.

For Earnings in 2013, certain significant items includes: (i) patent litigation settlement income of $1.3 billion , (ii) the gain associated with the transfer of certain product rights to our equity-method investment in China of $459 million , (iii) income related to our transitional manufacturing and supply agreements with Zoetis of $16 million , (iv) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $1.3 billion , (v) certain asset impairments and related charges of $1.1 billion , (vi) other charges of $83 million , (vii) net charges for certain legal matters of $21 million and (viii) costs associated with the separation of Zoetis of $18 million . For additional information, see Note 2D. Acquisitions, Divestitures, Collaborative Arrangements and Equity-Method Investments: Equity-Method Investments, Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and Cost-Reduction/Productivity Initiatives and Note 4. Other (Income)/Deductions––Net .

For Earnings in 2012 , certain significant items includes: (i) net charges for certain legal matters of 2\.2 billion , (ii) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $1.8 billion , (iii) certain asset impairment charges of $875 million , (iv) costs associated with the separation of Zoetis of $125 million and (v) other charges of $19 million . For additional information see Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and Cost-Reduction/Productivity Initiatives and Note 4. Other (Income)/Deductions––Net .

For Earnings in 2011 , certain significant items includes: (i) restructuring charges and implementation costs associated with our cost-reduction initiatives that are not associated with an acquisition of $2.5 billion (ii) certain asset impairment charges of $827 million , (iii) charges for certain legal matters of $822 million , (iv) other charges of $69 million and (v) costs associated with the separation of Zoetis of $35 million (see Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and Cost-Reduction/Productivity Initiatives and Note 4. Other (Income)/Deductions––Net for additional information).

|(j) |Includes overhead expenses associated with our manufacturing and commercial operations not directly attributable to an operating segment |
| --- | --- |

Schedule of Revenues by Geographic Region

| | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|The following table provides revenues by geographic area: |
| | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2013 | | |2012 | | |2011 (a) | |
|United States | |$ |20,274 | | |$ |21,313 | | |$ |25,277 | |
|Developed Europe (b) | |11,739 | | |12,545 | | |15,221 | |
|Developed Rest of World (c) | |8,346 | | |9,956 | | |10,422 | |
|Emerging Markets (d) | |11,225 | | |10,843 | | |10,115 | |
|Revenues | |$ |51,584 | | |$ |54,657 | | |$ |61,035 | |

|(a) |For 2011, includes King commencing on the acquisition date of January 31, 2011. |
| --- | --- |

|(b) |Developed Europe region includes the following markets: Western Europe, Finland and the Scandinavian countries. Revenues denominated in euros were $8.9 billion in 2013 , $9.4 billion in 2012 and $11.4 billion in 2011 . |
| --- | --- |

|(c) |Developed Rest of World region includes the following markets: Australia, Canada, Japan, New Zealand and South Korea. |
| --- | --- |

|(d) |Emerging Markets region includes, but is not limited to, the following markets: Asia (excluding Japan and South Korea), Latin America, the Middle East, Eastern Europe, Africa, Turkey and Central Europe |
| --- | --- |

Schedule of Long-Lived Assets by Geographic Region

.

| | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Long-lived assets by geographic region follow: |
| | |As of December 31, |
|(MILLIONS OF DOLLARS) | |2013 | | |2012 | | |2011 | |
|Property, plant and equipment, net | | | | | | |
|United States | |$ |5,885 | | |$ |6,485 | | |$ |7,116 | |
|Developed Europe (a) | |4,845 | | |4,895 | | |5,640 | |
|Developed Rest of World (b) | |696 | | |816 | | |872 | |
|Emerging Markets (c) | |971 | | |1,017 | | |1,045 | |
|Property, plant and equipment, net | |$ |12,397 | | |$ |13,213 | | |$ |14,673 | |

|(a) |Developed Europe region includes the following markets: Western Europe, Finland and the Scandinavian countries. |
| --- | --- |

|(b) |Developed Rest of World region includes the following markets: Australia, Canada, Japan, New Zealand, and South Korea. |
| --- | --- |

|(c) |Emerging Markets region includes, but is not limited to, the following markets: Asia (excluding Japan and South Korea), Latin America, the Middle East, Eastern Europe, Africa, Turkey and Central Europe |
| --- | --- |

Schedule of Significant Product Revenues

| | | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|The following table provides revenues by product: |
| | |Year Ended December 31, |
|(MILLIONS OF DOLLARS) | |2013 | | |2012 | | |2011 (a) | |
|Revenues from biopharmaceutical products: | | | | | | |
|Lyrica | |$ |4,595 | | |$ |4,158 | | |$ |3,693 | |
|Prevnar family | |3,974 | | |4,117 | | |4,145 | |
|Enbrel (Outside the U.S. and Canada) | |3,774 | | |3,737 | | |3,666 | |
|Celebrex | |2,918 | | |2,719 | | |2,523 | |
|Lipitor (b) | |2,315 | | |3,948 | | |9,577 | |
|Viagra | |1,881 | | |2,051 | | |1,981 | |
|Zyvox | |1,353 | | |1,345 | | |1,283 | |
|Norvasc | |1,229 | | |1,349 | | |1,445 | |
|Sutent | |1,204 | | |1,236 | | |1,187 | |
|Premarin family | |1,092 | | |1,073 | | |1,013 | |
|BeneFIX | |832 | | |775 | | |693 | |
|Vfend | |775 | | |754 | | |747 | |
|Genotropin | |772 | | |832 | | |889 | |
|Pristiq | |698 | | |630 | | |577 | |
|Chantix/Champix | |648 | | |670 | | |720 | |
|Refacto AF/Xyntha | |602 | | |584 | | |506 | |
|Xalatan/Xalacom | |589 | | |806 | | |1,250 | |
|Detrol/Detrol LA | |562 | | |761 | | |883 | |
|Zoloft | |469 | | |541 | | |573 | |
|Medrol | |464 | | |523 | | |510 | |
|Effexor | |440 | | |425 | | |678 | |
|Zosyn/Tazocin | |395 | | |484 | | |636 | |
|Zithromax/Zmax | |387 | | |435 | | |453 | |
|Fragmin | |359 | | |381 | | |382 | |
|Relpax | |359 | | |368 | | |341 | |
|Tygacil | |358 | | |335 | | |298 | |
|Rapamune | |350 | | |346 | | |372 | |
|Inlyta | |319 | | |100 | | |— | |
|Sulperazon | |309 | | |262 | | |218 | |
|Revatio | |307 | | |534 | | |535 | |
|Cardura | |296 | | |338 | | |380 | |
|Xalkori | |282 | | |123 | | |16 | |
|Xanax/Xanax XR | |276 | | |274 | | |306 | |
|Diflucan | |242 | | |259 | | |265 | |
|Toviaz | |236 | | |207 | | |187 | |
|Aricept (c) | |235 | | |326 | | |450 | |
|Inspra | |233 | | |214 | | |195 | |
|Caduet | |223 | | |258 | | |538 | |
|Somavert | |217 | | |197 | | |183 | |
|Neurontin | |216 | | |235 | | |289 | |
|Unasyn | |212 | | |228 | | |231 | |
|BMP2 | |209 | | |263 | | |340 | |
|Geodon | |194 | | |353 | | |1,022 | |
|Depo-Provera | |191 | | |148 | | |139 | |
|Aromasin | |185 | | |210 | | |361 | |
|Xeljanz | |114 | | |6 | | |— | |
|Alliance revenues (d) | |2,628 | | |3,492 | | |3,630 | |
|All other biopharmaceutical products | |7,360 | | |7,804 | | |7,441 | |
|Total revenues from biopharmaceutical products | |47,878 | | |51,214 | | |57,747 | |
|Other revenues: | | | | | | |
|Consumer Healthcare | |3,342 | | |3,212 | | |3,028 | |
|Other (e) | |364 | | |231 | | |260 | |
|Revenues | |$ |51,584 | | |$ |54,657 | | |$ |61,035 | |

|(a) |For 2011, includes King commencing on the acquisition date of January 31, 2011. |
| --- | --- |

|(b) |Lipitor lost exclusivity in Australia in April 2012, most of developed Europe in March and May 2012, the U.S. in November 2011 and various other major markets in 2011 and 2012. This loss of exclusivity reduced branded worldwide revenues by $1.7 billion in 2013 , in comparison with 2012, and reduced branded worldwide revenues by $5.6 billion in 2012 , in comparison with 2011. |
| --- | --- |

|(c) |Represents direct sales under license agreement with Eisai Co., Ltd. |
| --- | --- |

|(d) |Includes Enbrel (in the U.S. and Canada through October 31, 2013), Spiriva, Rebif, Aricept and Eliquis. |
| --- | --- |

|(e) |Other represents revenues generated from Pfizer CentreSource, our contract manufacturing and bulk pharmaceutical chemical sales organization, and includes, in 2013, the revenues related to our transitional manufacturing and supply agreements with Zoetis. |
| --- | --- |