1. 
2. News Releases
3. Gilead-Sciences-Announces-Third-Quarter-2024-Financial-Results

November 6, 2024

# Gilead Sciences Announces Third Quarter 2024 Financial Results

Back

_Product Sales Excluding Veklury Increased 7% Year-Over-Year to $6.8 billion_

_Biktarvy Sales Increased 13% Year-Over-Year to $3.5 billion_

_Oncology Sales Increased 6% Year-Over-Year to $816 million_

FOSTER CITY, Calif.--(BUSINESS WIRE)-- Gilead Sciences, Inc. (Nasdaq: GILD) announced today its third quarter 2024 results of operations.

“Gilead’s third quarter results are the strongest of the year to date, with 7% year-over-year revenue growth, including 13% year-over-year growth for Biktarvy. Based on this very strong topline growth and disciplined operating expense management, we are increasing our full year revenue, operating income, and earnings per share guidance,” said Daniel O’Day, Gilead’s Chairman and Chief Executive Officer. “We are excited to further increase our impact for patients and communities in the months ahead. This includes building on the momentum from the U.S. launch of Livdelzi for primary biliary cholangitis and preparing for the potential launch of the first twice-yearly option for HIV prevention option, lenacapavir.”

**Third Quarter 2024 Financial Results**

* Total third quarter 2024 revenue increased 7% to $7.5 billion compared to the same period in 2023, primarily due to higher sales in HIV as well as in Veklury **®** (remdesivir), Oncology and Liver Disease.
* Diluted earnings per share (“EPS”) was $1.00 in the third quarter 2024 compared to $1.73 in the same period in 2023. The decrease was primarily driven by a pre-tax in-process research and development (“IPR&D”) impairment of $1.75 billion, or $1.04 per share net of tax impact, related to assets acquired by Gilead from Immunomedics, Inc. (“Immunomedics”) in 2020, as well as higher acquired IPR&D expense. This was partially offset by higher product sales and higher net unrealized gains on equity securities.
* Non-GAAP diluted EPS was $2.02 in the third quarter 2024 compared to $2.29 in the same period in 2023. The decrease was primarily driven by higher acquired IPR&D and tax expense, partially offset by higher product sales.
* As of September 30, 2024, Gilead had $5.0 billion of cash, cash equivalents and marketable debt securities compared to $8.4 billion as of December 31, 2023. The decrease primarily reflects the $3.9 billion acquisition of CymaBay Therapeutics, Inc.
* During the third quarter 2024 Gilead generated $4.3 billion in operating cash flow.
* During the third quarter 2024 Gilead paid dividends of $983 million and repurchased $300 million of common stock.

**Third Quarter 2024 Product Sales**

Total third quarter 2024 product sales increased 7% to $7.5 billion compared to the same period in 2023. Total third quarter 2024 product sales, excluding Veklury, increased 7% to $6.8 billion compared to the same period in 2023, primarily due to higher sales in HIV as well as in Oncology and Liver Disease.

**HIV** product sales increased 9% to $5.1 billion in the third quarter 2024 compared to the same period in 2023, driven by higher average realized price, primarily due to shifts in channel mix, and higher demand, partially offset by inventory dynamics.

* **Biktarvy ®** (bictegravir 50mg/emtricitabine 200mg (“FTC”)/tenofovir alafenamide 25mg (“TAF”)) sales increased 13% to $3.5 billion in the third quarter 2024 compared to the same period in 2023, primarily driven by higher demand and average realized price, partially offset by inventory dynamics.
* **Descovy ®** (FTC 200mg/TAF 25mg) sales increased 15% to $586 million in the third quarter 2024 compared to the same period in 2023, primarily driven by higher demand and average realized price, partially offset by inventory dynamics.

The **Liver Disease** portfolio sales increased 4% to $733 million in the third quarter 2024 compared to the same period in 2023. This was primarily driven by higher demand in viral hepatitis medicines, partially offset by unfavorable pricing dynamics.

**Veklury** sales increased 9% to $692 million in the third quarter 2024 compared to the same period in 2023, primarily driven by increased rates of COVID-19 related hospitalizations, particularly in the United States.

**Cell Therapy** product sales of $485 million in the third quarter 2024 were relatively flat compared to the same period in 2023.

* **Yescarta ®** (axicabtagene ciloleucel) sales decreased 1% to $387 million in the third quarter 2024 compared to the same period in 2023, reflecting increased in- and out-of-class competition in the United States, partially offset by increased demand in relapsed or refractory (“R/R”) large B-cell lymphoma (“LBCL”) in other regions.
* **Tecartus ®** (brexucabtagene autoleucel) sales increased 2% to $98 million in the third quarter 2024 compared to the same period in 2023, driven by increased demand in adult acute lymphoblastic leukemia (“ALL”).

**Trodelvy ®** (sacituzumab govitecan-hziy) sales increased 17% to $332 million in the third quarter 2024 compared to the same period in 2023, primarily driven by higher demand across all regions.

**Third Quarter 2024 Product Gross Margin, Operating Expenses and Effective Tax Rate**

* Product gross margin was 79.1% in the third quarter 2024 compared to 77.6% in the same period in 2023. Non-GAAP product gross margin was 86.8% in the third quarter 2024 compared to 85.9% in the same period in 2023. The increases in GAAP and non-GAAP were primarily driven by product mix.
* Research & development (“R&D”) expenses and non-GAAP R&D expenses were $1.4 billion in the third quarter 2024 compared to $1.5 billion in the same period in 2023. The decreases were primarily driven by the timing of clinical activities, including the wind-down of the magrolimab and obeldesivir COVID programs.
* Acquired IPR&D expenses were $505 million in the third quarter 2024, primarily driven by a $320 million charge related to the buy-out of global Livdelzi **®** (seladelpar) royalties from Janssen Pharmaceutica NV, as well as payments related to ongoing collaborations.
* IPR&D impairment was $1.75 billion related to the assets acquired from Immunomedics in 2020 with no similar charges in 2023.
* Selling, general and administrative (“SG&A”) expenses and non-GAAP SG&A expenses were $1.4 billion in the third quarter 2024 compared to $1.3 billion in the same period in 2023. The increases reflect the timing of commercial activities, including the launch of Livdelzi in the United States, and other corporate activities.
* The effective tax rate (“ETR”) was (31.1)% in the third quarter 2024 compared to 6.3% in the same period in 2023. The decrease in ETR primarily reflects the impact of a legal entity restructuring and the aforementioned Immunomedics IPR&D impairment expense, partially offset by a prior year decrease in tax reserves that did not repeat. Non-GAAP ETR was 17.5% in the third quarter 2024 compared to 7.0% in the same period in 2023, primarily reflecting the impact of the prior year decrease in tax reserves.

**Guidance and Outlook**

For the full-year 2024, Gilead expects:

|**(in millions, except per share amounts)** | |**November 6, 2024 Guidance** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| |**Low End** |**High End** |**Comparison to August 8, 2024 Guidance** |
|Product sales | |$ |27,800 | |$ |28,100 | |Previously $27,100 to $27,500 |
|Product sales, excluding Veklury | |$ |26,000 | |$ |26,300 | |Previously $25,800 to $26,200 |
|Veklury | |$ |1,800 | |$ |1,800 | |Previously $1,300 |
|Diluted EPS | |$ |0\.05 | |$ |0\.25 | |Previously $0.00 to $0.30 |
|Non-GAAP diluted EPS | |$ |4\.25 | |$ |4\.45 | |Previously $3.60 to $3.90 |

Additional information and a reconciliation between GAAP and non-GAAP financial information for the 2024 guidance is provided in the accompanying tables. The financial guidance is subject to a number of risks and uncertainties. See the Forward-Looking Statements section below.

**Key Updates Since Our Last Quarterly Release**

**Virology**

* Announced results of PURPOSE 2, the second Phase 3 study of twice-yearly lenacapavir for HIV prevention, with data presented at the HIV Research for Prevention Conference. In the lenacapavir group, 99.9% of participants did not acquire HIV infection, with 2 incident cases among 2,179 participants. Lenacapavir reduced HIV infections by 96% compared to background HIV incidence in cisgender men and gender-diverse people, and additionally demonstrated superiority to daily Truvada ® (FTC 200mg and tenofovir disoproxil fumarate 300mg; 89% relative risk reduction). Lenacapavir was generally well-tolerated and no significant or new safety concerns were identified. Gilead expects to file for U.S. Food and Drug Administration (“FDA”) approval before the end of the year, with global filings to follow. The use of lenacapavir for the prevention of HIV is investigational.
* Presented HIV treatment data at the Infection Disease Week (“IDWeek”) meeting, including Week 48 data from the Phase 2 study evaluating the investigational oral once-weekly combination regimen of lenacapavir with Merck’s, known as MSD outside of the United States and Canada (“Merck”), islatravir. In addition, Phase 1a data of the investigational once-weekly GS-1720 and 3-year follow up from the Phase 2/3 CAPELLA trial of twice-yearly lenacapavir in people with multi-drug resistant HIV were also highlighted.
* Signed royalty-free voluntary licensing agreements with six manufacturers to make and sell generic lenacapavir for HIV prevention and for HIV treatment in heavily treatment-experienced adults with multi-drug resistant HIV in 120 high-incidence, resource-limited countries, subject to regulatory approval of lenacapavir in those markets.
* Presented data at IDWeek from the Phase 3 BIRCH and OAKTREE trials of investigational obeldesivir in non-hospitalized participants at high-risk or standard-risk for severe COVID-19, respectively. Previously, Gilead announced the early termination of the BIRCH trial and top-line results from the OAKTREE trial which found that while the study did not meet its primary endpoint, obeldesivir was found to have a generally well tolerated safety profile. The detailed data presented add to the breadth of safety data on obeldesivir.
* Donated approximately 5,000 vials of remdesivir to the Rwanda Medical Supply in response to the Marburg Virus Disease (“MVD”) outbreak for emergency use. Remdesivir is not approved for the treatment of MVD anywhere globally, and the safety and efficacy of this use is not known.

**Oncology**

* Announced abstracts for the American Society of Hematology 2024 Annual Meeting (“ASH”), including preliminary data from the registrational Phase 2 iMMagine-1 trial evaluating the Arcellx, Inc. (“Arcellx”) partnered investigational CAR T anito-cel (anitocabtagene autoleucel) in R/R multiple myeloma, as well as updated results from the Phase 1 trial. Additionally, the first patient has been dosed in the Phase 3 iMMagine-3 trial in 2L+ R/R multiple myeloma.
* Announced ASH abstracts for long-term follow-up of Yescarta in R/R indolent non-Hodgkin’s lymphoma and Tecartus in R/R mantle cell lymphoma, as well as real world data for Tecartus in B-cell precursor ALL.
* Presented Trodelvy data at the International Association for the Study of Lung Cancer World Conference on Lung Cancer across first- and second-line advanced or metastatic non-small cell lung cancer, as well as in extensive-stage small cell lung cancer. The use of Trodelvy for lung cancer is investigational.
* Announced plans to voluntarily withdraw the U.S. accelerated approval of Trodelvy for use in pre-treated adult patients with locally advanced or metastatic urothelial cancer, following the results of the Phase 3 TROPiCS-04 trial announced in May 2024.
* Received FDA Regenerative Medicine Advanced Therapy Designation for the evaluation of Yescarta as first-line treatment for adult patients with newly diagnosed, high-risk LBCL, an investigational use.

**Inflammation**

* Received FDA accelerated approval for Livdelzi for the treatment of primary biliary cholangitis in combination with ursodeoxycholic acid (“UDCA”) in adults who have an inadequate response to UDCA, or as monotherapy in patients unable to tolerate UDCA. The use of Livdelzi is not recommended for people who have or develop decompensated cirrhosis.

**Corporate**

* Announced a strategic collaboration with Genesis Therapeutics, Inc. (“Genesis”) to discover and develop novel small molecule therapies across multiple targets using Genesis’ GEMS AI platform.
* The Board declared a quarterly dividend of $0.77 per share of common stock for the fourth quarter of 2024. The dividend is payable on December 30, 2024, to stockholders of record at the close of business on December 13, 2024. Future dividends will be subject to Board approval.

Certain amounts and percentages in this press release may not sum or recalculate due to rounding.

**Conference Call**

At 1:30 p.m. Pacific Time today, Gilead will host a conference call to discuss Gilead’s results. A live webcast will be available on [http://investors.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Finvestors.gilead.com&esheet=54147774&newsitemid=20241105006667&lan=en-US&anchor=http%3A%2F%2Finvestors.gilead.com&index=1&md5=0cd34a4bbd0e5af5ec46637281318106) and will be archived on [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=54147774&newsitemid=20241105006667&lan=en-US&anchor=www.gilead.com&index=2&md5=f9e0a6365e87824ac1fd3c9ed0087f39) for one year.

**Non-GAAP Financial Information**

The information presented in this document has been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), unless otherwise noted as non-GAAP. Management believes non-GAAP information is useful for investors, when considered in conjunction with Gilead’s GAAP financial information, because management uses such information internally for its operating, budgeting and financial planning purposes. Non-GAAP information is not prepared under a comprehensive set of accounting rules and should only be used to supplement an understanding of Gilead’s operating results as reported under GAAP. Non-GAAP financial information generally excludes acquisition-related expenses including amortization of acquired intangible assets and other items that are considered unusual or not representative of underlying trends of Gilead’s business, fair value adjustments of equity securities and discrete and related tax charges or benefits associated with such exclusions as well as changes in tax-related laws and guidelines, transfers of intangible assets between certain legal entities, and legal entity restructurings. Although Gilead consistently excludes the amortization of acquired intangible assets from the non-GAAP financial information, management believes that it is important for investors to understand that such intangible assets were recorded as part of acquisitions and contribute to ongoing revenue generation. Non-GAAP measures may be defined and calculated differently by other companies in the same industry. Reconciliations of the non-GAAP financial measures to the most directly comparable GAAP financial measures are provided in the accompanying tables.

**About Gilead Sciences**

Gilead Sciences, Inc. is a biopharmaceutical company that has pursued and achieved breakthroughs in medicine for more than three decades, with the goal of creating a healthier world for all people. The company is committed to advancing innovative medicines to prevent and treat life-threatening diseases, including HIV, viral hepatitis, COVID-19 and cancer. Gilead operates in more than 35 countries worldwide, with headquarters in Foster City, California.

**Forward-Looking Statements**

Statements included in this press release that are not historical in nature are forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. Gilead cautions readers that forward-looking statements are subject to certain risks and uncertainties that could cause actual results to differ materially. These risks and uncertainties include those relating to: Gilead’s ability to achieve its anticipated full year 2024 financial results, including as a result of the uncertainty of the amount and timing of Veklury revenues; Gilead’s ability to make progress on any of its long-term ambitions or priorities laid out in its corporate strategy; Gilead’s ability to accelerate or sustain revenues for its virology, oncology and other programs; Gilead’s ability to realize the potential benefits of acquisitions, collaborations or licensing arrangements, including the arrangements with Arcellx, Genesis and Merck; patent protection and estimated loss of exclusivity for our products and product candidates; Gilead’s ability to initiate, progress or complete clinical trials within currently anticipated timeframes or at all, the possibility of unfavorable results from ongoing and additional clinical trials, including those involving Trodelvy, anito-cel, GS-1720, lenacapavir, and obeldesivir (such as the BIRCH, CAPELLA, iMMagine-1, iMMagine-3, OAKTREE, and PURPOSE-2 studies), and the risk that safety and efficacy data from clinical trials may not warrant further development of Gilead’s product candidates or the product candidates of Gilead’s strategic partners; Gilead’s ability to submit new drug applications for new product candidates or expanded indications in the currently anticipated timelines, including for lenacapavir for HIV PrEP; Gilead’s ability to receive or maintain regulatory approvals in a timely manner or at all, and the risk that any such approvals, if granted, may be subject to significant limitations on use and may be subject to withdrawal or other adverse actions by the applicable regulatory authority; Gilead’s ability to successfully commercialize its products; the risk of potential disruptions to the manufacturing and supply chain of Gilead’s products; pricing and reimbursement pressures from government agencies and other third parties, including required rebates and other discounts; a larger than anticipated shift in payer mix to more highly discounted payer segments; market share and price erosion caused by the introduction of generic versions of Gilead products; the risk that physicians and patients may not see advantages of Gilead’s products over other therapies and may therefore be reluctant to prescribe the products, including Livdelzi; and other risks identified from time to time in Gilead’s reports filed with the SEC, including annual reports on Form 10-K, quarterly reports on Form 10-Q and current reports on Form 8-K. In addition, Gilead makes estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses and related disclosures. Gilead bases its estimates on historical experience and on various other market specific and other relevant assumptions that it believes to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. There may be other factors of which Gilead is not currently aware that may affect matters discussed in the forward-looking statements and may also cause actual results to differ significantly from these estimates. Further, results for the quarter ended September 30, 2024 are not necessarily indicative of operating results for any future periods. Gilead directs readers to its press releases, annual reports on Form 10-K, quarterly reports on Form 10-Q and other subsequent disclosure documents filed with the SEC. Gilead claims the protection of the Safe Harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements.

The reader is cautioned that forward-looking statements are not guarantees of future performance and is cautioned not to place undue reliance on these forward-looking statements. All forward-looking statements are based on information currently available to Gilead and Gilead assumes no obligation to update or supplement any such forward-looking statements other than as required by law. Any forward-looking statements speak only as of the date hereof or as of the dates indicated in the statements.

Gilead owns or has rights to various trademarks, copyrights and trade names used in its business, including the following: GILEAD ® , GILEAD SCIENCES ® , KITE TM , AMBISOME ® , ATRIPLA ® , BIKTARVY ® , CAYSTON ® , COMPLERA ® , DESCOVY ® , DESCOVY FOR PREP ® , EMTRIVA ® , EPCLUSA ® , EVIPLERA ® , GENVOYA ® , HARVONI ® , HEPCLUDEX ® , HEPSERA ® , JYSELECA ® , LIVDELZI ® , LETAIRIS ® , ODEFSEY ® , SOVALDI ® , STRIBILD ® , SUNLENCA ® , TECARTUS ® , TRODELVY ® , TRUVADA ® , TRUVADA FOR PREP ® , TYBOST ® , VEKLURY ® , VEMLIDY ® , VIREAD ® , VOSEVI ® , YESCARTA ® and ZYDELIG ® .

_For more information on Gilead Sciences, Inc., please visit [www.gilead.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=http%3A%2F%2Fwww.gilead.com&esheet=54147774&newsitemid=20241105006667&lan=en-US&anchor=www.gilead.com&index=3&md5=da28fce42e7f3b2fb575bfc8c77c9b34) or call the Gilead Public Affairs Department at 1-800-GILEAD-5 (1-800-445-3235)._

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions, except per share amounts)** | |**2024** | |**2023** | |**2024** | |**2023** |
|Revenues: | | | | | | | | |
|Product sales | |$ |7,515 | | |$ |6,994 | | |$ |21,074 | | |$ |19,864 | |
|Royalty, contract and other revenues | | |30 | | | |56 | | | |111 | | | |138 | |
|Total revenues | | |7,545 | | | |7,051 | | | |21,185 | | | |20,002 | |
|Costs and expenses: | | | | | | | | |
|Cost of goods sold | | |1,574 | | | |1,565 | | | |4,670 | | | |4,408 | |
|Research and development expenses | | |1,395 | | | |1,457 | | | |4,266 | | | |4,310 | |
|Acquired in-process research and development expenses | | |505 | | | |91 | | | |4,674 | | | |808 | |
|In-process research and development impairment | | |1,750 | | | |— | | | |4,180 | | | |— | |
|Selling, general and administrative expenses | | |1,433 | | | |1,315 | | | |4,184 | | | |4,482 | |
|Total costs and expenses | | |6,657 | | | |4,428 | | | |21,975 | | | |14,009 | |
|Operating income (loss) | | |888 | | | |2,623 | | | |(790 |) | | |5,993 | |
|Interest expense | | |238 | | | |232 | | | |728 | | | |692 | |
|Other (income) expense, net | | |(306 |) | | |72 | | | |(41 |) | | |95 | |
|Income (loss) before income taxes | | |956 | | | |2,318 | | | |(1,477 |) | | |5,206 | |
|Income tax (benefit) expense | | |(297 |) | | |146 | | | |(174 |) | | |1,010 | |
|Net income (loss) | | |1,253 | | | |2,172 | | | |(1,303 |) | | |4,196 | |
|Net loss attributable to noncontrolling interest | | |— | | | |(8 |) | | |— | | | |(40 |) |
|Net income (loss) attributable to Gilead | |$ |1,253 | | |$ |2,180 | | |$ |(1,303 |) | |$ |4,236 | |
|Basic earnings (loss) per share attributable to Gilead | |$ |1\.00 | | |$ |1\.75 | | |$ |(1.04 |) | |$ |3\.39 | |
|Shares used in basic earnings (loss) per share attributable to Gilead calculation | | |1,247 | | | |1,248 | | | |1,247 | | | |1,249 | |
|Diluted earnings (loss) per share attributable to Gilead | |$ |1\.00 | | |$ |1\.73 | | |$ |(1.04 |) | |$ |3\.37 | |
|Shares used in diluted earnings (loss) per share attributable to Gilead calculation | | |1,254 | | | |1,257 | | | |1,247 | | | |1,259 | |
| | | | | | | | | |
|**Supplemental Information:** | | | | | | | | |
|Cash dividends declared per share | |$ |0\.77 | | |$ |0\.75 | | |$ |2\.31 | | |$ |2\.25 | |
|Product gross margin | | |79\.1 |% | | |77\.6 |% | | |77\.8 |% | | |77\.8 |% |
|Research and development expenses as a % of revenues | | |18\.5 |% | | |20\.7 |% | | |20\.1 |% | | |21\.5 |% |
|Selling, general and administrative expenses as a % of revenues | | |19\.0 |% | | |18\.6 |% | | |19\.8 |% | | |22\.4 |% |
|Operating margin | | |11\.8 |% | | |37\.2 |% | | |(3.7 |)% | | |30\.0 |% |
|Effective tax rate | | |(31.1 |)% | | |6\.3 |% | | |11\.8 |% | | |19\.4 |% |
| | | | | | | | | | | | | | | | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**TOTAL REVENUE SUMMARY** |
|**(unaudited)** |
| | | | | | | | | |
| | |**Three Months Ended** | | | |**Nine Months Ended** | | |
| | |**September 30,** | | | |**September 30,** | | |
|**(in millions, except percentages)** | |**2024** | |**2023** | |**Change** | |**2024** | |**2023** | |**Change** |
|Product sales: | | | | | | | | | | | | |
|HIV | |$ |5,073 | |$ |4,667 | |_9%_ | |$ |14,160 | |$ |13,482 | |_5%_ |
|Liver Disease | | |733 | | |706 | |_4%_ | | |2,302 | | |2,093 | |_10%_ |
|Oncology | | |816 | | |769 | |_6%_ | | |2,446 | | |2,167 | |_13%_ |
|Other | | |201 | | |216 | |_(7)%_ | | |705 | | |658 | |_7%_ |
|Total product sales excluding Veklury | | |6,823 | | |6,358 | |_7%_ | | |19,613 | | |18,400 | |_7%_ |
|Veklury | | |692 | | |636 | |_9%_ | | |1,461 | | |1,465 | |_—%_ |
|Total product sales | | |7,515 | | |6,994 | |_7%_ | | |21,074 | | |19,864 | |_6%_ |
|Royalty, contract and other revenues | | |30 | | |56 | |_(46)%_ | | |111 | | |138 | |_(19)%_ |
|Total revenues | |$ |7,545 | |$ |7,051 | |_7%_ | |$ |21,185 | |$ |20,002 | |_6%_ |
| | | | | | | | | | | | | | | | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**NON-GAAP FINANCIAL INFORMATION (1)** |
|**(unaudited)** |
| |
| | |**Three Months Ended** | | | |**Nine Months Ended** | | |
| | |**September 30,** | | | |**September 30,** | | |
|**(in millions, except percentages)** | |**2024** | |**2023** | |**Change** | |**2024** | |**2023** | |**Change** |
|Non-GAAP: | | | | | | | | | | | | |
|Cost of goods sold | |$ |995 | | |$ |985 | | |_1%_ | |$ |2,933 | | |$ |2,717 | | |_8%_ |
|Research and development expenses | |$ |1,382 | | |$ |1,453 | | |_(5)%_ | |$ |4,120 | | |$ |4,268 | | |_(3)%_ |
|Acquired IPR&D expenses (2) | |$ |505 | | |$ |91 | | |_NM_ | |$ |4,674 | | |$ |808 | | |_NM_ |
|Selling, general and administrative expenses | |$ |1,405 | | |$ |1,298 | | |_8%_ | |$ |4,051 | | |$ |4,464 | | |_(9)%_ |
|Other (income) expense, net | |$ |(48 |) | |$ |(96 |) | |_(50)%_ | |$ |(189 |) | |$ |(261 |) | |_(28)%_ |
|Diluted earnings per share attributable to Gilead | |$ |2\.02 | | |$ |2\.29 | | |_(12)%_ | |$ |2\.72 | | |$ |5\.00 | | |_(46)%_ |
|Shares used in non-GAAP diluted earnings per share attributable to Gilead calculation | | |1,254 | | | |1,257 | | |_—%_ | | |1,254 | | | |1,259 | | |_—%_ |
| | | | | | | | | | | | | |
|Product gross margin | | |86\.8 |% | | |85\.9 |% | |_84 bps_ | | |86\.1 |% | | |86\.3 |% | |_\-24 bps_ |
|Research and development expenses as a % of revenues | | |18\.3 |% | | |20\.6 |% | |_\-229 bps_ | | |19\.4 |% | | |21\.3 |% | |_\-189 bps_ |
|Selling, general and administrative expenses as a % of revenues | | |18\.6 |% | | |18\.4 |% | |_21 bps_ | | |19\.1 |% | | |22\.3 |% | |_\-320 bps_ |
|Operating margin | | |43\.2 |% | | |45\.7 |% | |_\-255 bps_ | | |25\.5 |% | | |38\.7 |% | |_\-1320 bps_ |
|Effective tax rate | | |17\.5 |% | | |7\.0 |% | |_1052 bps_ | | |30\.0 |% | | |14\.5 |% | |_1552 bps_ |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|NM - Not Meaningful |
|(1) | |Refer to Non-GAAP Financial Information section above for further disclosures on non-GAAP financial measures. A reconciliation between GAAP and non-GAAP financial information is provided in the tables below. |
|(2) | |Equal to GAAP financial information. |
| | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions, except percentages and per share amounts)** | |**2024** | |**2023** | |**2024** | |**2023** |
|**Cost of goods sold reconciliation:** | | | | | | | | |
|GAAP cost of goods sold | |$ |1,574 | | |$ |1,565 | | |$ |4,670 | | |$ |4,408 | |
|Acquisition-related – amortization (1) | | |(579 |) | | |(581 |) | | |(1,737 |) | | |(1,691 |) |
|Restructuring | | |— | | | |— | | | |1 | | | |— | |
|Non-GAAP cost of goods sold | |$ |995 | | |$ |985 | | |$ |2,933 | | |$ |2,717 | |
| | | | | | | | | |
|**Product gross margin reconciliation:** | | | | | | | | |
|GAAP product gross margin | | |79\.1 |% | | |77\.6 |% | | |77\.8 |% | | |77\.8 |% |
|Acquisition-related – amortization (1) | | |7\.7 |% | | |8\.3 |% | | |8\.2 |% | | |8\.5 |% |
|Restructuring | | |— |% | | |— |% | | |(— |)% | | |— |% |
|Non-GAAP product gross margin | | |86\.8 |% | | |85\.9 |% | | |86\.1 |% | | |86\.3 |% |
| | | | | | | | | |
|**Research and development expenses reconciliation:** | | | | | | | | |
|GAAP research and development expenses | |$ |1,395 | | |$ |1,457 | | |$ |4,266 | | |$ |4,310 | |
|Acquisition-related – other costs (2) | | |(9 |) | | |1 | | | |(78 |) | | |(37 |) |
|Restructuring | | |(5 |) | | |(5 |) | | |(68 |) | | |(5 |) |
|Non-GAAP research and development expenses | |$ |1,382 | | |$ |1,453 | | |$ |4,120 | | |$ |4,268 | |
| | | | | | | | | |
|**IPR&D impairment reconciliation:** | | | | | | | | |
|GAAP IPR&D impairment | |$ |1,750 | | |$ |— | | |$ |4,180 | | |$ |— | |
|IPR&D impairment | | |(1,750 |) | | |— | | | |(4,180 |) | | |— | |
|Non-GAAP IPR&D impairment | |$ |— | | |$ |— | | |$ |— | | |$ |— | |
| | | | | | | | | |
|**Selling, general and administrative expenses reconciliation:** | | | | | | | | |
|GAAP selling, general and administrative expenses | |$ |1,433 | | |$ |1,315 | | |$ |4,184 | | |$ |4,482 | |
|Acquisition-related – other costs (2) | | |(5 |) | | |— | | | |(88 |) | | |(2 |) |
|Restructuring | | |(23 |) | | |(17 |) | | |(45 |) | | |(17 |) |
|Non-GAAP selling, general and administrative expenses | |$ |1,405 | | |$ |1,298 | | |$ |4,051 | | |$ |4,464 | |
| | | | | | | | | |
|**Operating income (loss) reconciliation:** | | | | | | | | |
|GAAP operating income (loss) | |$ |888 | | |$ |2,623 | | |$ |(790 |) | |$ |5,993 | |
|Acquisition-related – amortization (1) | | |579 | | | |581 | | | |1,737 | | | |1,691 | |
|Acquisition-related – other costs (2) | | |13 | | | |(1 |) | | |167 | | | |39 | |
|Restructuring | | |28 | | | |22 | | | |112 | | | |22 | |
|IPR&D impairment | | |1,750 | | | |— | | | |4,180 | | | |— | |
|Non-GAAP operating income | |$ |3,258 | | |$ |3,224 | | |$ |5,406 | | |$ |7,745 | |
| | | | | | | | | |
|**Operating margin reconciliation:** | | | | | | | | |
|GAAP operating margin | | |11\.8 |% | | |37\.2 |% | | |(3.7 |)% | | |30\.0 |% |
|Acquisition-related – amortization (1) | | |7\.7 |% | | |8\.2 |% | | |8\.2 |% | | |8\.5 |% |
|Acquisition-related – other costs (2) | | |0\.2 |% | | |— |% | | |0\.8 |% | | |0\.2 |% |
|Restructuring | | |0\.4 |% | | |0\.3 |% | | |0\.5 |% | | |0\.1 |% |
|IPR&D impairment | | |23\.2 |% | | |— |% | | |19\.7 |% | | |— |% |
|Non-GAAP operating margin | | |43\.2 |% | | |45\.7 |% | | |25\.5 |% | | |38\.7 |% |
| | | | | | | | | |
|**Other (income) expense, net reconciliation:** | | | | | | | | |
|GAAP other (income) expense, net | |$ |(306 |) | |$ |72 | | |$ |(41 |) | |$ |95 | |
|Gain (loss) from equity securities, net | | |258 | | | |(168 |) | | |(148 |) | | |(356 |) |
|Non-GAAP other (income) expense, net | |$ |(48 |) | |$ |(96 |) | |$ |(189 |) | |$ |(261 |) |
| | | | | | | | | |
|**Income (loss) before income taxes reconciliation:** | | | | | | | | |
|GAAP income (loss) before income taxes | |$ |956 | | |$ |2,318 | | |$ |(1,477 |) | |$ |5,206 | |
|Acquisition-related – amortization (1) | | |579 | | | |581 | | | |1,737 | | | |1,691 | |
|Acquisition-related – other costs (2) | | |13 | | | |(1 |) | | |167 | | | |39 | |
|Restructuring | | |28 | | | |22 | | | |112 | | | |22 | |
|IPR&D impairment | | |1,750 | | | |— | | | |4,180 | | | |— | |
|(Gain) loss from equity securities, net | | |(258 |) | | |168 | | | |148 | | | |356 | |
|Non-GAAP income before income taxes | |$ |3,068 | | |$ |3,088 | | |$ |4,866 | | |$ |7,314 | |
| | | | | | | | | | | | | | | | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL INFORMATION - (Continued)** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions, except percentages and per share amounts)** | |**2024** | |**2023** | |**2024** | |**2023** |
|**Income tax (benefit) expense reconciliation:** | | | | | | | | |
|GAAP income tax (benefit) expense | |$ |(297 |) | |$ |146 | | |$ |(174 |) | |$ |1,010 | |
|Income tax effect of non-GAAP adjustments: | | | | | | | | |
|Acquisition-related – amortization (1) | | |121 | | | |120 | | | |363 | | | |347 | |
|Acquisition-related – other costs (2) | | |2 | | | |— | | | |39 | | | |8 | |
|Restructuring | | |4 | | | |5 | | | |21 | | | |5 | |
|IPR&D impairment | | |440 | | | |— | | | |1,051 | | | |— | |
|(Gain) loss from equity securities, net | | |(46 |) | | |4 | | | |(52 |) | | |5 | |
|Discrete and related tax charges (3) | | |314 | | | |(58 |) | | |214 | | | |(314 |) |
|Non-GAAP income tax expense | |$ |538 | | |$ |216 | | |$ |1,461 | | |$ |1,061 | |
| | | | | | | | | |
|**Effective tax rate reconciliation:** | | | | | | | | |
|GAAP effective tax rate | | |(31.1 |)% | | |6\.3 |% | | |11\.8 |% | | |19\.4 |% |
|Income tax effect of above non-GAAP adjustments and discrete and related tax adjustments (3) | | |48\.6 |% | | |0\.7 |% | | |18\.2 |% | | |(4.9 |)% |
|Non-GAAP effective tax rate | | |17\.5 |% | | |7\.0 |% | | |30\.0 |% | | |14\.5 |% |
| | | | | | | | | |
|**Net income (loss) attributable to Gilead reconciliation:** | | | | | | | | |
|GAAP net income (loss) attributable to Gilead | |$ |1,253 | | |$ |2,180 | | |$ |(1,303 |) | |$ |4,236 | |
|Acquisition-related – amortization (1) | | |458 | | | |461 | | | |1,374 | | | |1,345 | |
|Acquisition-related – other costs (2) | | |11 | | | |(1 |) | | |128 | | | |31 | |
|Restructuring | | |24 | | | |17 | | | |92 | | | |17 | |
|IPR&D impairment | | |1,310 | | | |— | | | |3,129 | | | |— | |
|(Gain) loss from equity securities, net | | |(212 |) | | |164 | | | |200 | | | |351 | |
|Discrete and related tax charges (3) | | |(314 |) | | |58 | | | |(214 |) | | |314 | |
|Non-GAAP net income attributable to Gilead | |$ |2,531 | | |$ |2,879 | | |$ |3,405 | | |$ |6,293 | |
| | | | | | | | | |
|**Diluted earnings (loss) per share reconciliation:** | | | | | | | | |
|GAAP diluted earnings (loss) per share | |$ |1\.00 | | |$ |1\.73 | | |$ |(1.04 |) | |$ |3\.37 | |
|Acquisition-related – amortization (1) | | |0\.37 | | | |0\.37 | | | |1\.10 | | | |1\.07 | |
|Acquisition-related – other costs (2) | | |0\.01 | | | |— | | | |0\.10 | | | |0\.02 | |
|Restructuring | | |0\.02 | | | |0\.01 | | | |0\.07 | | | |0\.01 | |
|IPR&D impairment | | |1\.04 | | | |— | | | |2\.51 | | | |— | |
|(Gain) loss from equity securities, net | | |(0.17 |) | | |0\.13 | | | |0\.16 | | | |0\.28 | |
|Discrete and related tax charges (3) | | |(0.25 |) | | |0\.05 | | | |(0.17 |) | | |0\.25 | |
|Difference in shares used for GAAP vs. Non-GAAP | | |— | | | |— | | | |(0.01 |) | | |— | |
|Non-GAAP diluted earnings per share | |$ |2\.02 | | |$ |2\.29 | | |$ |2\.72 | | |$ |5\.00 | |
| | | | | | | | | |
|**Non-GAAP adjustment summary:** | | | | | | | | |
|Cost of goods sold adjustments | |$ |579 | | |$ |581 | | |$ |1,736 | | |$ |1,691 | |
|Research and development expenses adjustments | | |13 | | | |4 | | | |146 | | | |42 | |
|IPR&D impairment adjustments | | |1,750 | | | |— | | | |4,180 | | | |— | |
|Selling, general and administrative expenses adjustments | | |28 | | | |17 | | | |133 | | | |19 | |
|Total non-GAAP adjustments to costs and expenses | | |2,370 | | | |602 | | | |6,196 | | | |1,752 | |
|Other (income) expense, net adjustments | | |(258 |) | | |168 | | | |148 | | | |356 | |
|Total non-GAAP adjustments before income taxes | | |2,113 | | | |770 | | | |6,343 | | | |2,108 | |
|Income tax effect of non-GAAP adjustments above | | |(521 |) | | |(129 |) | | |(1,421 |) | | |(364 |) |
|Discrete and related tax charges (3) | | |(314 |) | | |58 | | | |(214 |) | | |314 | |
|Total non-GAAP adjustments to net income attributable to Gilead | |$ |1,278 | | |$ |699 | | |$ |4,708 | | |$ |2,057 | |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|(1) | |Relates to amortization of acquired intangibles. |
|(2) | |Adjustments include integration expenses, contingent consideration fair value adjustments and other expenses associated with Gilead’s acquisitions of MYR GmbH, MiroBio, Ltd., Tmunity Therapeutics, Inc., XinThera, Inc. and CymaBay Therapeutics, Inc. |
|(3) | |Represents discrete and related deferred tax charges or benefits primarily associated with acquired intangible assets and in-process research and development, transfers of intangible assets from a foreign subsidiary to Ireland and the United States, and legal entity restructurings. |
| | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**RECONCILIATION OF GAAP TO NON-GAAP 2024 FULL-YEAR GUIDANCE (1)** |
|**(unaudited)** |
| | | | | | | | | |
|**(in millions, except percentages and per share amounts)** | |**Provided  
** **February 6, 2024** | |**Updated  
** **April 25, 2024** | |**Updated  
** **August 8, 2024** | |**Updated  
November 6, 2024** |
|**Projected product gross margin GAAP to non-GAAP reconciliation:** | | | | | | | | |
|GAAP projected product gross margin | |76\.0% - 77.0% | |76\.0% - 77.0% | |76\.0% - 77.0% | |78\.0% |
|Acquisition-related expenses and restructuring expenses | |~ 9.0% | |~ 9.0% | |~ 9.0% | |~ 8.0% |
|Non-GAAP projected product gross margin | |85\.0% - 86.0% | |85\.0% - 86.0% | |85\.0% - 86.0% | |86\.0% |
| | | | | | | | | |
|**Projected operating income GAAP to non-GAAP reconciliation:** | | | | | | | | |
|GAAP projected operating income | |$8,700 - $9,200 | |$1,900 - $2,400 | |$2,100 - $2,500 | |$1,100 - $1,400 |
|IPR&D impairment, acquisition-related and restructuring expenses | |~ 2,500 | |~ 5,100 | |~ 5,100 | |~ 6,900 |
|Non-GAAP projected operating income | |$11,200 - $11,700 | |$7,000 - $7,500 | |$7,200 - $7,600 | |$8,000 - $8,300 |
| | | | | | | | | |
|**Projected effective tax rate GAAP to non-GAAP reconciliation:** | | | | | | | | |
|GAAP projected effective tax rate | |~ 21% | |~ 65% | |~ 87% | |~ 56% |
|Income tax effect of above non-GAAP adjustments and fair value adjustments of equity securities, and discrete and related tax adjustments | |(~ 2%) | |(~ 35%) | |(~ 57%) | |(~ 29%) |
|Non-GAAP projected effective tax rate | |~ 19% | |~ 30% | |~ 30% | |~ 27% |
| | | | | | | | | |
|**Projected diluted EPS GAAP to non-GAAP reconciliation:** | | | | | | | | |
|GAAP projected diluted EPS | |$5.15 - $5.55 | |$0.10 - $0.50 | |$0.00 - $0.30 | |$0.05 - $0.25 |
|IPR&D impairment, acquisition-related and restructuring expenses, fair value adjustments of equity securities and discrete and related tax adjustments | |~ 1.70 | |~ 3.35 | |~ 3.60 | |~ 4.20 |
|Non-GAAP projected diluted EPS | |$6.85 - $7.25 | |$3.45 - $3.85 | |$3.60 - $3.90 | |$4.25 - $4.45 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|(1) | |Our full-year guidance excludes the potential impact of any (i) acquisitions or business development transactions that have not been executed, (ii) future fair value adjustments of equity securities and (iii) discrete tax charges or benefits associated with changes in tax related laws and guidelines that have not been enacted, as Gilead is unable to project such amounts. The non-GAAP full-year guidance includes non-GAAP adjustments to actual current period results as well as adjustments for the known future impact associated with events that have already occurred, such as future amortization of our intangible assets and the future impact of discrete and related deferred tax charges or benefits primarily associated with acquired intangible assets and in-process research and development, transfers of intangible assets from a foreign subsidiary to Ireland and the United States, and legal entity restructurings. |
| | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- |
|**CONDENSED CONSOLIDATED BALANCE SHEETS** |
|**(unaudited)** |
| | |**September 30,** | |**December 31,** |
|**(in millions)** | |**2024** | |**2023** |
|**Assets** | | | | |
|Cash, cash equivalents and marketable debt securities | |$ |5,037 | |$ |8,428 |
|Accounts receivable, net | | |4,587 | | |4,660 |
|Inventories | | |3,435 | | |3,366 |
|Property, plant and equipment, net | | |5,391 | | |5,317 |
|Intangible assets, net | | |20,546 | | |26,454 |
|Goodwill | | |8,314 | | |8,314 |
|Other assets | | |7,215 | | |5,586 |
|Total assets | |$ |54,525 | |$ |62,125 |
|**Liabilities and Stockholders’ Equity** | | | | |
|Current liabilities | |$ |11,725 | |$ |11,280 |
|Long-term liabilities | | |24,409 | | |28,096 |
|Stockholders’ equity (1) | | |18,390 | | |22,749 |
|Total liabilities and stockholders’ equity | |$ |54,525 | |$ |62,125 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|(1) | |As of September 30, 2024 and December 31, 2023, there were 1,246 shares of common stock issued and outstanding. |
| | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**SELECTED CASH FLOW INFORMATION** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions)** | |**2024** | |**2023** | |**2024** | |**2023** |
|Net cash provided by operating activities | |$ |4,309 | | |$ |1,756 | | |$ |7,853 | | |$ |5,837 | |
|Net cash used in investing activities | | |(710 |) | | |(229 |) | | |(3,224 |) | | |(1,538 |) |
|Net cash used in financing activities | | |(1,379 |) | | |(1,518 |) | | |(5,693 |) | | |(4,026 |) |
|Effect of exchange rate changes on cash and cash equivalents | | |44 | | | |(7 |) | | |15 | | | |20 | |
|Net change in cash and cash equivalents | | |2,265 | | | |1 | | | |(1,049 |) | | |293 | |
|Cash and cash equivalents at beginning of period | | |2,772 | | | |5,704 | | | |6,085 | | | |5,412 | |
|Cash and cash equivalents at end of period | |$ |5,037 | | |$ |5,705 | | |$ |5,037 | | |$ |5,705 | |
| | | | | | | | | |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions)** | |**2024** | |**2023** | |**2024** | |**2023** |
|Net cash provided by operating activities | |$ |4,309 | | |$ |1,756 | | |$ |7,853 | | |$ |5,837 | |
|Capital expenditures | | |(140 |) | | |(122 |) | | |(376 |) | | |(370 |) |
|Free cash flow (1) | |$ |4,169 | | |$ |1,633 | | |$ |7,478 | | |$ |5,467 | |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|(1) | |Free cash flow is a non-GAAP liquidity measure. Please refer to our disclosures in the Non-GAAP Financial Information section above. |
| | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**PRODUCT SALES SUMMARY** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions)** | |**2024** | |**2023** | |**2024** | |**2023** |
|**HIV** | | | | | | | | |
|Biktarvy – U.S. | |$ |2,826 | |$ |2,504 | |$ |7,726 | |$ |7,104 |
|Biktarvy – Europe | | |375 | | |313 | | |1,110 | | |920 |
|Biktarvy – Rest of World | | |272 | | |268 | | |814 | | |717 |
| | | |3,472 | | |3,085 | | |9,649 | | |8,741 |
|Descovy – U.S. | | |534 | | |460 | | |1,339 | | |1,314 |
|Descovy – Europe | | |24 | | |25 | | |75 | | |75 |
|Descovy – Rest of World | | |28 | | |26 | | |82 | | |86 |
| | | |586 | | |511 | | |1,496 | | |1,475 |
|Genvoya – U.S. | | |384 | | |433 | | |1,088 | | |1,305 |
|Genvoya – Europe | | |44 | | |47 | | |138 | | |157 |
|Genvoya – Rest of World | | |21 | | |23 | | |66 | | |81 |
| | | |449 | | |503 | | |1,292 | | |1,544 |
|Odefsey – U.S. | | |248 | | |257 | | |705 | | |754 |
|Odefsey – Europe | | |69 | | |74 | | |217 | | |223 |
|Odefsey – Rest of World | | |9 | | |11 | | |30 | | |33 |
| | | |326 | | |343 | | |952 | | |1,011 |
|Symtuza - Revenue share (1) – U.S. | | |103 | | |96 | | |338 | | |278 |
|Symtuza - Revenue share (1) – Europe | | |33 | | |32 | | |101 | | |101 |
|Symtuza - Revenue share (1) – Rest of World | | |3 | | |3 | | |9 | | |10 |
| | | |139 | | |131 | | |448 | | |390 |
|Other HIV (2) – U.S. | | |65 | | |56 | | |190 | | |192 |
|Other HIV (2) – Europe | | |26 | | |28 | | |96 | | |91 |
|Other HIV (2) – Rest of World | | |9 | | |9 | | |36 | | |38 |
| | | |100 | | |94 | | |322 | | |321 |
|Total HIV – U.S. | | |4,161 | | |3,807 | | |11,386 | | |10,949 |
|Total HIV – Europe | | |570 | | |519 | | |1,737 | | |1,568 |
|Total HIV – Rest of World | | |342 | | |341 | | |1,038 | | |965 |
| | | |5,073 | | |4,667 | | |14,160 | | |13,482 |
|**Liver Disease** | | | | | | | | |
|Sofosbuvir / Velpatasvir (3) – U.S. | | |222 | | |215 | | |737 | | |643 |
|Sofosbuvir / Velpatasvir (3) – Europe | | |67 | | |76 | | |230 | | |250 |
|Sofosbuvir / Velpatasvir (3) – Rest of World | | |96 | | |85 | | |299 | | |266 |
| | | |385 | | |377 | | |1,266 | | |1,159 |
|Vemlidy – U.S. | | |126 | | |112 | | |338 | | |295 |
|Vemlidy – Europe | | |11 | | |9 | | |33 | | |28 |
|Vemlidy – Rest of World | | |95 | | |106 | | |328 | | |322 |
| | | |232 | | |228 | | |699 | | |645 |
|Other Liver Disease (4) – U.S. | | |45 | | |49 | | |134 | | |113 |
|Other Liver Disease (4) – Europe | | |54 | | |33 | | |148 | | |112 |
|Other Liver Disease (4) – Rest of World | | |17 | | |20 | | |55 | | |64 |
| | | |116 | | |102 | | |337 | | |289 |
|Total Liver Disease – U.S. | | |393 | | |376 | | |1,210 | | |1,051 |
|Total Liver Disease – Europe | | |132 | | |119 | | |411 | | |390 |
|Total Liver Disease – Rest of World | | |207 | | |211 | | |682 | | |652 |
| | | |733 | | |706 | | |2,302 | | |2,093 |
|**Veklury** | | | | | | | | |
|Veklury – U.S. | | |393 | | |258 | | |784 | | |607 |
|Veklury – Europe | | |81 | | |65 | | |204 | | |227 |
|Veklury – Rest of World | | |219 | | |313 | | |473 | | |630 |
| | | |692 | | |636 | | |1,461 | | |1,465 |
| | | | | | | | | | | | | |

|**GILEAD SCIENCES, INC.** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|**PRODUCT SALES SUMMARY - (Continued)** |
|**(unaudited)** |
| | |**Three Months Ended** | |**Nine Months Ended** |
| | |**September 30,** | |**September 30,** |
|**(in millions)** | |**2024** | |**2023** | |**2024** | |**2023** |
|**Oncology** | | | | | | | | |
|**_Cell Therapy_** | | | | | | | | |
|Tecartus – U.S. | | |63 | | |64 | | |181 | | |179 |
|Tecartus – Europe | | |29 | | |27 | | |102 | | |83 |
|Tecartus – Rest of World | | |6 | | |4 | | |22 | | |11 |
| | | |98 | | |96 | | |305 | | |272 |
|Yescarta – U.S. | | |145 | | |197 | | |502 | | |624 |
|Yescarta – Europe | | |182 | | |154 | | |509 | | |408 |
|Yescarta – Rest of World | | |60 | | |40 | | |170 | | |99 |
| | | |387 | | |391 | | |1,181 | | |1,130 |
|Total Cell Therapy – U.S. | | |208 | | |261 | | |683 | | |802 |
|Total Cell Therapy – Europe | | |211 | | |181 | | |611 | | |491 |
|Total Cell Therapy – Rest of World | | |66 | | |45 | | |192 | | |109 |
| | | |485 | | |486 | | |1,485 | | |1,402 |
|**_Trodelvy_** | | | | | | | | |
|Trodelvy – U.S. | | |226 | | |201 | | |655 | | |551 |
|Trodelvy – Europe | | |80 | | |62 | | |217 | | |169 |
|Trodelvy – Rest of World | | |26 | | |21 | | |88 | | |44 |
| | | |332 | | |283 | | |960 | | |764 |
|Total Oncology – U.S. | | |433 | | |462 | | |1,338 | | |1,354 |
|Total Oncology – Europe | | |291 | | |243 | | |828 | | |660 |
|Total Oncology – Rest of World | | |92 | | |65 | | |280 | | |153 |
| | | |816 | | |769 | | |2,446 | | |2,167 |
|**Other** | | | | | | | | |
|AmBisome – U.S. | | |6 | | |12 | | |37 | | |39 |
|AmBisome – Europe | | |71 | | |63 | | |210 | | |192 |
|AmBisome – Rest of World | | |52 | | |39 | | |176 | | |150 |
| | | |130 | | |115 | | |424 | | |381 |
|Other (5) – U.S. | | |47 | | |69 | | |203 | | |197 |
|Other (5) – Europe | | |8 | | |9 | | |26 | | |31 |
|Other (5) – Rest of World | | |16 | | |23 | | |52 | | |49 |
| | | |71 | | |101 | | |281 | | |277 |
|Total Other – U.S. | | |53 | | |82 | | |241 | | |236 |
|Total Other – Europe | | |80 | | |72 | | |236 | | |224 |
|Total Other – Rest of World | | |68 | | |62 | | |228 | | |199 |
| | | |201 | | |216 | | |705 | | |658 |
|Total product sales – U.S. | | |5,433 | | |4,985 | | |14,958 | | |14,196 |
|Total product sales – Europe | | |1,154 | | |1,017 | | |3,416 | | |3,069 |
|Total product sales – Rest of World | | |928 | | |992 | | |2,700 | | |2,599 |
| | |$ |7,515 | |$ |6,994 | |$ |21,074 | |$ |19,864 |

|\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| --- | --- | --- |
|(1) | |Represents Gilead’s revenue from cobicistat (“C”), FTC and TAF in Symtuza (darunavir/C/FTC/TAF), a fixed dose combination product commercialized by Janssen Sciences Ireland Unlimited Company. |
|(2) | |Includes Atripla, Complera/Eviplera, Emtriva, Sunlenca, Stribild, Truvada and Tybost. |
|(3) | |Includes Epclusa and the authorized generic version of Epclusa sold by Gilead’s separate subsidiary, Asegua Therapeutics LLC (“Asegua”). |
|(4) | |Includes ledipasvir/sofosbuvir (Harvoni and the authorized generic version of Harvoni sold by Asegua), Hepcludex, Hepsera, Livdelzi, Sovaldi, Viread and Vosevi. |
|(5) | |Includes Cayston, Jyseleca, Letairis, Ranexa and Zydelig. |

**Investors:  
** Jacquie Ross, CFA  
[investor\_relations@gilead.com](mailto:investor_relations@gilead.com)

**Media:  
** Ashleigh Koss  
[public\_affairs@gilead.com](mailto:public_affairs@gilead.com)

Source: Gilead Sciences, Inc.

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2024 Financial Results&body=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2024 Financial Results&url=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results&via=Gilead)

Share Article

* [mail-icon](mailto:?subject=Gilead Sciences Announces Third Quarter 2024 Financial Results&body=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* copy-icon
* [linkedin-icon](https://www.linkedin.com/sharing/share-offsite/?url=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* [facebook-icon](https://www.facebook.com/sharer/sharer.php?u=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results)
* [twitter-icon](https://twitter.com/intent/tweet?text=Gilead Sciences Announces Third Quarter 2024 Financial Results&url=https://www.gilead.com/news/news-details/2024/gilead-sciences-announces-third-quarter-2024-financial-results&via=Gilead)

## Other News

_Some of the content on this page is not intended for users outside the U.S._

View All

No Results Found

Loading Results...

### Discover More

##### Therapeutic Areas

##### Research

##### Giving@Gilead

This is our global website, intended for visitors seeking information on Gilead’s worldwide business. Some content on this site is not intended for people outside the United States. Visit our Global Operations page for links to our international corporate websites.

* [](https://twitter.com/GileadSciences)
* [](https://www.linkedin.com/company/gilead-sciences/)
* [](https://www.instagram.com/gileadsciences/)
* [](https://www.facebook.com/GileadSciences)
* [](https://www.youtube.com/channel/UCNSt7PtsfNGbezR9hmvRI1w)

### QUICK LINKS

* [Investors](https://investors.gilead.com/overview/default.aspx)
* [Find a Trial](https://www.gileadclinicaltrials.com)
* Pipeline
* [Search for Jobs](https://gilead.wd1.myworkdayjobs.com/gileadcareers)
* News
* Stories@Gilead

### GET IN TOUCH

* Contact Us
* Report an Adverse Event
* [Medical Information](https://www.askgileadmedical.com)
* Partnership Request

### LEGAL

* [Modern Slavery Act Statement](https://www.gilead.com/-/media/files/pdfs/company/policies-and-disclosures/modern-slavery-statement.pdf)
* Public Policy Engagement
* Social Media Guidelines
* Privacy Statement
* Consumer Health Data Privacy Policy
* Terms of Use
* Cookie Statement

* * *