EX-99.1 2 q424lillysalesandearningsp.htm EX-99.1  Document created using Wdesk  Copyright 2025 Workiva Document

Feb. 6, 2025

For release: Immediately

Refer to: Ashley Hennessey; gentry_ashley_jo@lilly.com; (317) 416-4363 (Media)

Mike Czapar; czapar_michael_c@lilly.com; (317) 617-0983 (Investors)

Lilly reports full Q4 2024 financial results and provides 2025 guidance

•Revenue in Q4 2024 increased 45% to $13.53 billion driven by volume growth from Mounjaro and Zepbound. Non-incretin revenue(i) grew by 20% compared to Q4 2023.

•Pipeline progress included the approval of Zepbound in the U.S. for moderate-to-severe obstructive sleep apnea in adults with obesity and the approval of Omvoh in the U.S. for moderately to severely active Crohn's disease.

•Notable recent events include the pending acquisition of Scorpion Therapeutics, Inc's mutant-selective PI3Kα inhibitor program.

•Q4 2024 EPS increased 102% to $4.88 on a reported basis, and 114% to $5.32 on a non-GAAP basis, both inclusive of $0.19 of acquired IPR&D charges.

•2025 guidance issued with revenue in the range of $58.0 billion to $61.0 billion, EPS in the range of $22.05 to $23.55 and non-GAAP EPS in the range of $22.50 to $24.00.

(i) Excludes one-time payments related to business development.

INDIANAPOLIS, Feb. 6, 2025 - Eli Lilly and Company (NYSE: LLY) today announced its financial results for the fourth quarter of 2024 and detailed 2025 financial guidance.

"2024 was a highly successful year for Lilly," said David A. Ricks, Lilly's chair and CEO. "We had major data readouts for tirzepatide in treating chronic disease associated with obesity, invested billions more in expanding our manufacturing capacity and launched Kisunla and Ebglyss — important drivers of our long-term balanced growth outlook. We enter 2025 with tremendous momentum and look forward to strong financial performance and several important Phase 3 readouts which, if positive, will further accelerate our long-term growth."

Eli Lilly and Company | Lilly Corporate Center | Indianapolis, Indiana 46285 | U.S.A.

Lilly shared numerous updates recently on key regulatory, clinical, business development and other events, including:

•U.S. Food and Drug Administration (FDA) approval of Zepbound for a new indication as the first and only prescription medicine for moderate-to-severe obstructive sleep apnea (OSA) in adults with obesity;

•FDA approval of Omvoh for the treatment of moderately to severely active Crohn's disease in adults and a recommendation for approval by the European Medicines Agency's Committee for Medicinal Products for Human Use;

•Approval of Kisunla in China for the treatment of early symptomatic Alzheimer's disease;

•Positive topline results from the SURMOUNT-5 Phase 3b open-label randomized trial in which Zepbound (tirzepatide) showed a 47% greater relative weight loss compared to Wegovy (semaglutide) head-to-head;

•Positive Phase 3 results from the BRUIN CLL-321 trial evaluating pirtobrutinib, a non-covalent (reversible) Bruton's tyrosine kinase (BTK) inhibitor in adult patients with chronic lymphocytic leukemia or small lymphocytic lymphoma (CLL/SLL) previously treated with a covalent BTK inhibitor;

•Presentation and publication of the EMBER-3 study showing that imlunestrant (oral SERD), in patients with second-line ER+, HER2- metastatic breast cancer, reduced the risk of progression or death as a monotherapy in patients with ESR1 mutations, and in combination with Verzenio, regardless of ESR1 mutation status;

•Positive Phase 2 results for muvalaplin, an investigational once-daily, orally administered selective inhibitor of lipoprotein(a) [Lp(a)], a genetically inherited risk factor for heart disease;

•The announcement of an agreement to acquire Scorpion Therapeutics' mutant-selective PI3Kα inhibitor program;

•A commitment to expand the company's manufacturing facility in Kenosha County, Wisconsin, with a $3 billion investment to enhance Lilly's global parenteral (injectable) product manufacturing network; and

•Announced a $15 billion share repurchase program and, for the seventh consecutive year, a

|2 |

15% increase in Lilly's quarterly dividend.

For information on important public announcements, visit the news section of Lilly's website.

Financial Results

|$ in millions, except per share data |Fourth Quarter | | | |
| |2024 | |2023 | |% Change | | | | | |
|Revenue |$ |13,532.8 | | |$ |9,353.4 | | |45% | | | | | |
|Net income – Reported |4,409.8 | | |2,189.6 | | |101% | | | | | |
|Earnings per share – Reported |4.88 | | |2.42 | | |102% | | | | | |
|Net income – Non-GAAP |4,805.5 | | |2,249.4 | | |114% | | | | | |
|Earnings per share – Non-GAAP |5.32 | | |2.49 | | |114% | | | | | |

A discussion of the non-GAAP financial measures is included below under "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)."

Fourth-Quarter Reported Results

In Q4 2024, worldwide revenue was $13.53 billion, an increase of 45% compared with Q4 2023, driven by a 48% increase in volume, partially offset by a 4% decrease due to lower realized prices. The volume increase was driven by growth from Mounjaro and Zepbound. Lower realized prices were primarily driven by Mounjaro, partially offset by Zepbound and Humalog. New Products1 revenue grew by $3.15 billion to $5.64 billion in Q4 2024, led by Zepbound and Mounjaro. Growth Products2 revenue increased 13% to $5.95 billion in Q4 2024 driven by growth in Verzenio and Jardiance, partially offset by lower Trulicity sales. The growth in Jardiance revenue included a one-time benefit of $300.0 million associated with an amendment to the company's collaboration with Boehringer Ingelheim.

1 Lilly defines new products as select products launched since 2022, which currently consist of Ebglyss, Jaypirca, Kisunla, Mounjaro, Omvoh and Zepbound.

2 Lilly defines Growth Products as select products launched prior to 2022, which currently consist of Cyramza, Emgality, Jardiance, Olumiant, Retevmo, Taltz, Trulicity, Tyvyt and Verzenio.

|3 |

Revenue in the U.S. increased 40% to $9.03 billion, driven by a 45% increase in volume, partially offset by a 5% decrease due to lower realized prices. The increase in U.S. volume was primarily driven by Zepbound and Mounjaro, partially offset by Trulicity. The lower realized prices in the U.S. were primarily driven by Mounjaro, partially offset by Zepbound and Humalog.

Revenue outside the U.S. increased 55% to $4.50 billion, driven by a 56% increase in volume. The volume increase outside the U.S was driven primarily by Mounjaro and, to a lesser extent, Verzenio. This volume increase also reflected the aforementioned $300.0 million payment received related to Jardiance.

Gross margin increased 47% to $11.13 billion in Q4 2024. Gross margin as a percent of revenue was 82.2%, an increase of 1.3 percentage points. The increase in gross margin percent was primarily driven by favorable product mix, partially offset by lower realized prices.

In Q4 2024, research and development expenses increased 18% to $3.02 billion, or 22.3% of revenue, driven by continued investments in the company's early and late-stage portfolio.

Marketing, selling and administrative expenses increased 26% to $2.42 billion in Q4 2024, primarily driven by promotional efforts supporting ongoing and future launches.

In Q4 2024, the company recognized acquired in-process research and development (IPR&D) charges of $189.2 million compared with $622.6 million in Q4 2023. The Q4 2023 charges primarily related to the acquisition of Mablink Biosciences SAS and the business development transaction with Beam Therapeutics Inc.

In Q4 2024, the company recognized asset impairment, restructuring and other special charges of $344.0 million, compared with $67.7 million in Q4 2023. The charges in Q4 2024 primarily included an intangible asset impairment associated with Vitrakvi.

|4 |

The effective tax rate was 12.5% in Q4 2024 compared with 12.7% in Q4 2023. The effective tax rate for Q4 2024 reflects a higher net discrete tax benefit compared with Q4 2023, as well as the favorable tax impact of the Vitrakvi impairment charge, partially offset by an unfavorable impact from the mix of earnings in higher tax jurisdictions.

In Q4 2024, net income and earnings per share (EPS) were $4.41 billion and $4.88, respectively, compared with net income of $2.19 billion and EPS of $2.42 in Q4 2023. EPS in Q4 2024 and Q4 2023 included acquired IPR&D charges of $0.19 and $0.62, respectively.

Fourth-Quarter Non-GAAP Measures

On a non-GAAP basis, Q4 2024 gross margin increased 46.0% to $11.26 billion. Gross margin as a percent of revenue was 83.2%, an increase of 0.9 percentage points. The increase in gross margin percent was primarily driven by favorable product mix, partially offset by lower realized prices.

The effective tax rate on a non-GAAP basis was 13.2% in Q4 2024 compared with 13.1% in Q4 2023. The effective tax rate for Q4 2024 was unfavorably impacted by a mix of earnings in higher tax jurisdictions, partially offset by a higher net discrete tax benefit compared with Q4 2023.

On a non-GAAP basis, Q4 2024 net income and EPS were $4.81 billion and $5.32, respectively, compared with net income of $2.25 billion and EPS of $2.49 in Q4 2023. Non-GAAP EPS in Q4 2024 and Q4 2023 included acquired IPR&D charges of $0.19 and$0.62, respectively.

|5 |

For further detail on non-GAAP measures, see the reconciliation below as well as the "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)" table later in this press release.

| |Fourth Quarter |
| |2024 | |2023 | |% Change |
|Earnings per share (reported) |$ |4.88 | | |$ |2.42 | | |102% |
|Amortization of intangible assets |.12 | | |.11 | | | |
|Asset impairment, restructuring and other special charges |.30 | | |.06 | | | |
|Net losses (gains) on investments in equity securities |.02 | | |(.11) | | | |
|Earnings per share (non-GAAP) |$ |5.32 | | |$ |2.49 | | |114% |
|Acquired IPR&D |.19 | | |.62 | | |(69)% |
|Numbers may not add due to rounding | | | | | |

|6 |

Selected Revenue Highlights

|(Dollars in millions) |Fourth Quarter | |Full Year |
|Selected Products |2024 | |2023 | |% Change | |2024 | |2023 | |% Change |
|Mounjaro |$ |3,530.1 | | |$ |2,205.6 | | |60% | |$ |11,540.1 | | |$ |5,163.1 | | |124% |
|Verzenio |1,555.2 | | |1,145.4 | | |36% | |5,306.6 | | |3,863.4 | | |37% |
|Trulicity |1,250.2 | | |1,669.3 | | |-25% | |5,253.5 | | |7,132.6 | | |-26% |
|Zepbound |1,907.2 | | |175.8 | | |NM | |4,925.7 | | |175.8 | | |NM |
|Jardiance (a) |1,198.4 | | |798.1 | | |50% | |3,340.9 | | |2,744.7 | | |22% |
|Taltz |952.0 | | |784.6 | | |21% | |3,260.4 | | |2,759.6 | | |18% |
|Humalog (b) |619.9 | | |366.6 | | |69% | |2,324.8 | | |1,663.3 | | |40% |
|Total Revenue |13,532.8 | | |9,353.4 | | |45% | |45,042.7 | | |34,124.1 | | |32% |
|(a) Jardiance includes Glyxambi, Synjardy and Trijardy XR (b) Humalog includes Insulin Lispro NM – not meaningful |

|7 |

Mounjaro

For Q4 2024, worldwide Mounjaro revenue increased 60% to $3.53 billion. U.S. revenue was $2.63 billion, an increase of 25%, reflecting continued strong demand and increased supply, partially offset by lower realized prices due to favorable changes in Q4 2023 to estimates for rebates and discounts. Revenue outside the U.S. increased to $898.9 million compared with $100.5 million in Q4 2023, primarily driven by volume growth in launched markets.

Verzenio

For Q4 2024, worldwide Verzenio revenue increased 36% to $1.56 billion. U.S. revenue was $1.04 billion, an increase of 35%, primarily driven by increased demand and wholesaler buying patterns. Revenue outside the U.S. was $513.0 million, an increase of 38%, primarily driven by increased demand.

Trulicity

For Q4 2024, worldwide Trulicity revenue decreased 25% to $1.25 billion. U.S. revenue decreased 36% to $799.8 million, driven by decreased sales volume primarily due to competitive dynamics and, to a lesser extent, lower realized prices primarily due to changes to estimates for rebates and discounts. Revenue outside the U.S. increased 9% to $450.4 million, driven by higher realized prices and increased volume.

Zepbound

For Q4 2024, U.S. Zepbound revenue was $1.91 billion, compared with $175.8 million in Q4 2023. Zepbound launched in the U.S. for the treatment of adult patients with obesity or overweight with weight-related comorbidities in November 2023.

Jardiance

For Q4 2024, the company's worldwide Jardiance revenue increased 50% compared with Q4 2023 to $1.20 billion. U.S. revenue was $464.5 million, a decrease of 1%, driven by lower realized prices, largely offset by increased demand. Revenue outside the U.S. was $733.9 million, compared with

|8 |

$329.1 million in Q4 2023, primarily driven by a one-time payment received of $300.0 million associated with an amendment to the company's collaboration with Boehringer Ingelheim. Pursuant to the amendment, we and Boehringer Ingelheim adjusted commercialization responsibilities for Jardiance within certain smaller markets.

Jardiance is part of the company's alliance with Boehringer Ingelheim. Lilly reports as revenue royalties received on net sales of Jardiance.

Taltz

For Q4 2024, worldwide Taltz revenue increased 21% to $952.0 million. U.S. revenue increased 24% to $665.5 million, driven by higher realized prices due to changes in estimates for rebates and discounts, as well as increased demand. Revenue outside the U.S. increased 16% to $286.5 million, primarily driven by increased demand.

Humalog

For Q4 2024, worldwide Humalog revenue increased 69% to $619.9 million. U.S. revenue was $405.8 million compared with $167.6 million in Q4 2023, driven by higher realized prices primarily due to a one-time impact in Q4 2023 related to the implementation of list price decreases. Revenue outside the U.S. was $214.1 million, an increase of 8%, driven by higher realized prices in China and, to a lesser extent, increased volume.

2025 Financial Guidance

The company anticipates 2025 revenue to be between $58.0 billion and $61.0 billion. The midpoint represents approximately 32% growth compared to 2024, driven by new Lilly medicines such as Zepbound, Mounjaro, Jaypirca, Ebglyss, Omvoh and Kisunla; approvals of new indications for existing Lilly medicines; launches of Mounjaro in additional worldwide markets; and potential launches of new medicines such as imlunestrant for metastatic breast cancer. The company continues to invest heavily in increasing manufacturing capacity and estimates producing at least 1.6 times the amount of salable incretin doses in the first half of 2025, compared to the first half of

|9 |

2024.

The ratio of (Gross Margin - OPEX) / Revenue, where OPEX is defined as the sum of research and development expenses and marketing, selling and administrative expenses, is expected to be in the range of 40.5% and 42.5% on a reported basis and 41.5% and 43.5% on a non-GAAP basis.

Other income (expense) is expected to be expense in the range of $700 million to $600 million, primarily driven by higher interest expense.

The 2025 effective tax rate is expected to be approximately 16%.

EPS for 2025 is expected to be in the range of $22.05 to $23.55 on a reported basis and $22.50 to $24.00 on a non-GAAP basis. The company's 2025 financial guidance reflects adjustments shown in the reconciliation table below.

| |2025 Guidance | |
|Earnings per share (reported) |$22.05 to $23.55 | |
|Amortization of intangible assets |.45 | |
|Earnings per share (non-GAAP) |$22.50 to $24.00 | |
|Numbers may not add due to rounding | | |

|10 |

The following table summarizes the company's 2025 financial guidance:

| |2025 Guidance (1) |
|Revenue | | |$58.0 to $61.0 billion |
|(Gross Margin - OPEX (2) ) / Revenue: | | | |
|(reported) | | |40.5% to 42.5% |
|(non-GAAP) | | |41.5% to 43.5% |
|Other Income/(Expense) | | |($700) to ($600) million |
|Tax Rate | | |Approx. 16% |
|Earnings per Share (reported) | | |$22.05 to $23.55 |
|Earnings per Share (non-GAAP) | | |$22.50 to $24.00 |
|(1) Non-GAAP guidance reflects adjustments presented in the earnings per share reconciliation table above. |
|(2) OPEX is defined as the sum of research and development expenses and marketing, selling and administrative expenses. |

Webcast of Conference Call

As previously announced, investors and the general public can access a live webcast of the Q4 2024 financial results conference call through a link on Lilly's website at investor.lilly.com/webcasts-and-presentations. The conference call will begin at 10 a.m. Eastern time today and will be available for replay via the website.

|11 |

Non-GAAP Financial Measures

Certain financial information is presented on both a reported and a non-GAAP basis. Some numbers in this press release may not add due to rounding. Reported results were prepared in accordance with U.S. generally accepted accounting principles (GAAP) and include all revenue and expenses recognized during the periods. Non-GAAP measures reflect adjustments for the items described in the reconciliation tables later in the release. Related materials provide certain GAAP and non-GAAP figures excluding the impact of foreign exchange rates. Lilly recalculates current period figures on a constant currency basis by keeping constant the exchange rates from the base period. The company's 2025 financial guidance is provided on both a reported and a non-GAAP basis. The non-GAAP measures are presented to provide additional insights into the underlying trends in the company's business.

About Lilly

Lilly is a medicine company turning science into healing to make life better for people around the world. We've been pioneering life-changing discoveries for nearly 150 years, and today our medicines help tens of millions of people across the globe. Harnessing the power of biotechnology, chemistry and genetic medicine, our scientists are urgently advancing new discoveries to solve some of the world's most significant health challenges: redefining diabetes care; treating obesity and curtailing its most devastating long-term effects; advancing the fight against Alzheimer's disease; providing solutions to some of the most debilitating immune system disorders; and transforming the most difficult-to-treat cancers into manageable diseases. With each step toward a healthier world, we're motivated by one thing: making life better for millions more people. That includes delivering innovative clinical trials that reflect the diversity of our world and working to ensure our medicines are accessible and affordable. To learn more, visit Lilly.com and Lilly.com/news. F-LLY

|12 |

Cautionary Statement Regarding Forward-Looking Statements

This press release contains management's current intentions and expectations for the future, all of which are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933 and Section 21E of the Securities Exchange Act of 1934. The words "estimate", "project", "intend", "expect", "believe", "target", "anticipate", "may", "could", "aim", "seek", "will", "continue", and similar expressions are intended to identify forward-looking statements. Actual results may differ materially due to various factors. The following include some but not all of the factors that could cause actual results or events to differ from those anticipated, including the significant costs and uncertainties in the pharmaceutical research and development process, including with respect to the timing and process of obtaining regulatory approvals; the impact and uncertain outcome of acquisitions and business development transactions and related costs; intense competition affecting the company's products, pipeline, or industry; market uptake of launched products and indications; continued pricing pressures and the impact of actions of governmental and private payers affecting pricing of, reimbursement for, and patient access to pharmaceuticals, or reporting obligations related thereto; safety or efficacy concerns associated with the company's or competitive products; dependence on relatively few products or product classes for a significant percentage of the company's total revenue and a consolidated supply chain; the expiration of intellectual property protection for certain of the company's products and competition from generic and biosimilar products; the company's ability to protect and enforce patents and other intellectual property and changes in patent law or regulations related to data package exclusivity; information technology system inadequacies, inadequate controls or procedures, security breaches, or operating failures; unauthorized access, disclosure, misappropriation, or compromise of confidential information or other data stored in the company's information technology systems, networks, and facilities, or those of third parties with whom the company shares its data and violations of data protection laws or regulations; issues with product supply and regulatory approvals stemming from manufacturing difficulties, disruptions, or shortages, including as a result of unpredictability and variability in demand, labor shortages, third-party performance, quality, cyber-attacks, or regulatory actions related to the company's and third-party facilities; reliance on third-party relationships and outsourcing arrangements; the use of artificial intelligence or other emerging technologies in various facets of the company's operations which may exacerbate competitive, regulatory, litigation, cybersecurity, and other risks; the impact of global macroeconomic conditions, including uneven economic growth or downturns or uncertainty, trade disruptions, international tension, conflicts, regional dependencies, or other costs, uncertainties, and risks related to engaging in business globally; fluctuations in foreign currency exchange rates or changes in interest rates and inflation or deflation; significant and sudden declines or volatility in the trading price of the company's common stock and market capitalization; litigation, investigations, or other similar proceedings involving past, current, or future products or activities; changes in tax law and regulations, tax rates, or events that differ from our assumptions related to tax positions; regulatory changes and developments; regulatory oversight and actions regarding the company's operations and products; regulatory compliance problems or government investigations; risks from the proliferation of counterfeit, misbranded, adulterated or illegally compounded products; actual or perceived deviation from environmental-, social-, or governance-related requirements or expectations; asset impairments and restructuring charges; and changes in accounting and reporting standards. For additional information about the factors that could cause actual results or events to differ materially from forward-looking statements, please see the company's latest Form 10-K and subsequent Forms 8-K and 10-Q filed with the Securities and Exchange Commission. You should not place undue reliance on forward-looking statements, which speak only as of the date of this release. Except as is required by law, the company expressly disclaims any obligation to publicly release any revisions to forward-looking statements to reflect events after the date of this release.

 # # #

Trademarks and Trade Names

All trademarks or trade names referred to in this press release are the property of the company, or, to the extent trademarks or trade names belonging to other companies are references in this press release, the property of their respective owners. Solely for convenience, the trademarks and trade names in this press release are referred to without

|13 |

the ® and ™ symbols, but such references should not be construed as any indicator that the company or, to the extent applicable, their respective owners will not assert, to the fullest extent under applicable law, the company's or their rights thereto. We do not intend the use or display of other companies’ trademarks and trade names to imply a relationship with, or endorsement or sponsorship of us by, any other companies.

|14 |

|Eli Lilly and Company |
|Operating Results (Unaudited) – REPORTED |
|(Dollars in millions, except per share data) |

| | |Three Months Ended | | |Twelve Months Ended |
| | |December 31, | | |December 31, |
| | |2024 | |2023 | |% Chg. | | |2024 | |2023 | |% Chg. |
|Revenue |$ |13,532.8 | |$ |9,353.4 | | |45% | |$ |45,042.7 | |$ |34,124.1 | | |32% |
|Cost of sales | |2,403.8 | | |1,788.0 | | |34% | | |8,418.3 | | |7,082.2 | | |19% |
|Research and development | |3,022.5 | | |2,562.7 | | |18% | | |10,990.6 | | |9,313.4 | | |18% |
|Marketing, selling and administrative | |2,424.5 | | |1,924.6 | | |26% | | |8,593.8 | | |7,403.1 | | |16% |
|Acquired IPR&D | |189.2 | | |622.6 | | |(70)% | | |3,280.4 | | |3,799.8 | | |(14)% |
|Asset impairment, restructuring and other special charges | |344.0 | | |67.7 | | |NM | | |860.6 | | |67.7 | | |NM |
|Operating income | |5,148.8 | | |2,387.8 | | |116% | | |12,899.0 | | |6,457.9 | | |100% |
|Net interest income (expense) | |(180.4) | | |(93.7) | | | | | |(605.4) | | |(312.3) | | | |
|Net other income (expense) | |70.3 | | |214.7 | | | | | |386.8 | | |409.0 | | | |
|Other income (expense) | |(110.1) | | |121.0 | | |(191)% | | |(218.6) | | |96.7 | | |NM |
|Income before income taxes | |5,038.7 | | |2,508.8 | | |101% | | |12,680.4 | | |6,554.6 | | |93% |
|Income tax expense | |628.9 | | |319.2 | | |97% | | |2,090.4 | | |1,314.2 | | |59% |
|Net income |$ |4,409.8 | |$ |2,189.6 | | |101% | |$ |10,590.0 | |$ |5,240.4 | | |102% |
|Earnings per share - diluted |$ |4.88 | |$ |2.42 | | |102% | |$ |11.71 | |$ |5.80 | | |102% |
|Dividends paid per share |$ |1.30 | |$ |1.13 | | |15% | |$ |5.20 | |$ |4.52 | | |15% |
|Weighted-average shares outstanding (thousands) - diluted | |903,158 | | |903,980 | | | | | |904,059 | | |903,284 | | | |

|15 |

|Eli Lilly and Company |
|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) |
|(Dollars in millions, except per share data) |
| | |Three Months Ended December 31, | |Twelve Months Ended December 31, |
| | |2024 |2023 | |2024 |2023 |
|Gross Margin - As Reported | |$ |11,129.0 | |$ |7,565.4 | | |$ |36,624.4 | |$ |27,041.9 | |
|Increase for excluded items: | | | | | | |
|Amortization of intangible assets (Cost of sales) (i) | |135.6 | |129.0 | | |553.2 | |506.2 | |
|Gross Margin - Non-GAAP | |$ |11,264.6 | |$ |7,694.4 | | |$ |37,177.6 | |$ |27,548.1 | |
|Gross Margin as a percent of revenue - As Reported | |82.2 |% |80.9 |% | |81.3 |% |79.2 |% |
|Gross Margin as a percent of revenue - Non-GAAP (ii) | |83.2 |% |82.3 |% | |82.5 |% |80.7 |% |

Numbers may not add due to rounding.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.Non-GAAP gross margin as a percent of revenue reflects the gross margin effects of the adjustments presented above.

|16 |

| | |Three Months Ended December 31, | |Twelve Months Ended December 31, |
| | |2024 |2023 | |2024 |2023 |
|Net income - Reported | |$ |4,409.8 | |$ |2,189.6 | | |$ |10,590.0 | |$ |5,240.4 | |
|Increase (decrease) for excluded items: | | | | | | |
|Amortization of intangible assets (Cost of sales) (i) | |135.6 | |129.0 | | |553.2 | |506.2 | |
|Asset impairment, restructuring and other special charges (ii) | |344.0 | |67.7 | | |860.6 | |67.7 | |
|Net (gains) losses on investments in equity securities (Other income/expense) | |17.3 | |(117.0) | | |38.6 | |24.8 | |
|Corresponding tax effects (Income taxes) | |(101.2) | |(19.9) | | |(295.9) | |(126.6) | |
|Net income - Non-GAAP | |$ |4,805.5 | |$ |2,249.4 | | |$ |11,746.5 | |$ |5,712.5 | |
|Effective tax rate - Reported | |12.5 |% |12.7 |% | |16.5 |% |20.1 |% |
|Effective tax rate - Non-GAAP (iii) | |13.2 |% |13.1 |% | |16.9 |% |20.1 |% |
|Earnings per share (diluted) - Reported | |$ |4.88 | |$ |2.42 | | |$ |11.71 | |$ |5.80 | |
|Earnings per share (diluted) - Non-GAAP | |$ |5.32 | |$ |2.49 | | |$ |12.99 | |$ |6.32 | |

Numbers may not add due to rounding.

i.Exclude amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

ii.For the three and twelve months ended December 31, 2024, excludes charges related to intangible asset impairment for Vitrakvi. For the twelve months ended December 31, 2024 also excludes charges related to litigation.

iii.Non-GAAP tax rate reflects the tax effects of the adjustments presented above.

|17 |
