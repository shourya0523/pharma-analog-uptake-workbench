EX-99.1 2 a16-17213\_3ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: James Edgemond

(301) 608-9292

Jedgemond@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**THIRD QUARTER 2016 FINANCIAL RESULTS**

Silver Spring, MD and Research Triangle Park, NC, October 27, 2016: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the third quarter ended September 30, 2016.

“Our financial performance continues its strength this quarter,” said Martine Rothblatt, Ph.D., United Therapeutics’ Chairman and Chief Executive Officer. “Our growth potential is higher than ever, with new programs in our pipeline for pulmonary hypertension associated with emphysema, fibrosis, heart failure and sickle cell disease. In addition we are launching the clinical development of our dinutuximab monoclonal antibody for small cell lung cancer and other high-risk forms of cancer with GD2 expressing cell tumors. Finally, our second generation parenteral drug delivery systems for treprostinil are continuing their march toward anticipated approvals in 2017 for implantable and 2018 for subcutaneous.”

Key financial highlights include (dollars in millions, except per share data):

| | |**Three Months Ended  
September 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Changes** | |
| | | | | | | | |
|Revenues | |$ |408\.2 | |$ |386\.2 | |5\.7 |% |
|Net income | |$ |161\.8 | |$ |464\.4 | |(65.2 |)% |
|Non-GAAP earnings (1) | |$ |201\.5 | |$ |174\.7 | |15\.3 |% |
|Net income, per diluted share | |$ |3\.50 | |$ |9\.24 | |(62.1 |)% |
|Non-GAAP earnings, per diluted share (1) | |$ |4\.36 | |$ |3\.48 | |25\.3 |% |

* * *

(1)  See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net income to non-GAAP earnings below.

**Financial Results for the Three Months Ended September 30, 2016**

**Revenues**

The table below summarizes the components of total revenues (dollars in millions):

| | |**Three Months Ended  
September 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Net product sales: | | | | | | | |
|Remodulin ® | |$ |152\.4 | |$ |150\.1 | |1\.5 |% |
|Tyvaso ® | |101\.8 | |121\.7 | |(16.4 |)% |
|Adcirca ® | |96\.0 | |73\.8 | |30\.1 |% |
|Orenitram ® | |40\.7 | |34\.4 | |18\.3 |% |
|Unituxin ® | |17\.3 | |4\.7 | |268\.1 |% |
|Other | |— | |1\.5 | |(100.0 |)% |
|Total revenues | |$ |408\.2 | |$ |386\.2 | |5\.7 |% |

Revenues for the three months ended September 30, 2016 increased by $22.0 million, compared to the same period in 2015. The growth in revenues primarily resulted from the following: (1) a $22.2 million increase in Adcirca net product sales; (2) a $12.6 million increase in Unituxin net product sales; (3) a $6.3 million increase in Orenitram net product sales; and (4) a $2.3 million increase in Remodulin net product sales. These increases were partially offset by a $19.9 million decrease in Tyvaso net product sales.

1

* * *  
**Expenses**

**Cost of product sales.** The table below summarizes cost of product sales by major categories (dollars in millions):

| | |**Three Months Ended  
September 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|Cost of product sales | |$ |20\.0 | |$ |15\.0 | |33\.3 |% |
|Share-based compensation expense (benefit) | |3\.6 | |(8.1 |) |144\.4 |% |
|Total cost of product sales | |$ |23\.6 | |$ |6\.9 | |242\.0 |% |

_Cost of product sales._ The increase in cost of product sales of $5.0 million for the three months ended September 30, 2016, as compared to the same period in 2015, was attributable to increased sales.

_Share-based compensation._ The increase in share-based compensation of $11.7 million for the three months ended September 30, 2016, as compared to the same period in 2015, corresponded to an 11 percent increase in the price of our common stock during the three months ended September 30, 2016, compared to a 25 percent decrease in the price of our common stock during the same period in 2015.

**Research and development expense.** The table below summarizes research and development expense by major category (dollars in millions):

| | |**Three Months Ended  
September 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|Research and development expense | |$ |37\.2 | |$ |40\.6 | |(8.4 |)% |
|Share-based compensation expense (benefit) | |8\.7 | |(31.0 |) |128\.1 |% |
|Total research and development expense | |$ |45\.9 | |$ |9\.6 | |378\.1 |% |

_Share-based compensation._ The increase in share-based compensation of $39.7 million for the three months ended September 30, 2016, as compared to the same period in 2015, corresponded to an 11 percent increase in the price of our common stock during the three months ended September 30, 2016, compared to a 25 percent decrease in the price of our common stock during the same period in 2015.

**Selling, general and administrative expense.** The table below summarizes selling, general and administrative expense by major categories (dollars in millions):

| | |**Three Months Ended  
September 30,** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |**Change** | |
|Category: | | | | | | | |
|General and administrative | |$ |42\.4 | |$ |41\.0 | |3\.4 |% |
|Sales and marketing | |20\.1 | |21\.5 | |(6.5 |)% |
|Share-based compensation expense (benefit) | |37\.6 | |(79.8 |) |147\.1 |% |
|Total selling, general and administrative expense | |$ |100\.1 | |$ |(17.3 |) |678\.6 |% |

_Share-based compensation._ The increase in share-based compensation of $117.4 million for the three months ended September 30, 2016, as compared to the same period in 2015, was primarily attributable to an 11 percent increase in the price of our common stock during the three months ended September 30, 2016, compared to a 25 percent decrease in the price of our common stock during the same period in 2015.

2

* * *  
**Gain on Sale of Intangible Asset**

In September 2015, we sold the Rare Pediatric Priority Review Voucher (PPRV) we received from the FDA in connection with the approval of our Biologics License Application for Unituxin. In exchange for the voucher we received $350.0 million from AbbVie Ireland Unlimited Company. The proceeds from the sale of the PPRV were recognized as a gain on the sale of an intangible asset, as the PPRV did not have a carrying value on our consolidated balance sheet at the time of sale.

**Income Tax Expense**

Our 2016 effective income tax rate decreased as compared to 2015 primarily due to a decrease in non-deductible share-based compensation, which was driven largely by a decrease in our stock price during 2016 compared to 2015.

**Share Repurchases**

In the third quarter of 2016, we repurchased approximately 1.1 million shares of our common stock at an aggregate cost of $135.8 million. These purchases were made pursuant to our $500 million stock repurchase program, which is effective during calendar year 2016, with $104.5 million of that amount remaining available for additional share repurchases at September 30, 2016.

**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for: (1) interest expense; (2) license fees; (3) depreciation and amortization; (4) impairment charges; (5) share-based compensation expense (benefit), net (including expenses relating to stock options, share tracking awards, restricted stock units and our employee stock purchase plan); and (6) tax impact on non-GAAP earnings adjustments. For 2015, we also adjusted non-GAAP earnings to eliminate the gain resulting from the sale of the PPRV in September 2015.

A reconciliation of net income to non-GAAP earnings is presented below (in millions, except per share data):

| | |**Three Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |
|Net income, as reported | |$ |161\.8 | |$ |464\.4 | |
|Adjusted for: | | | | | |
|Interest expense | |0\.5 | |0\.8 | |
|Depreciation and amortization | |8\.2 | |8\.2 | |
|Share-based compensation expense, net | |49\.9 | |(118.9 |) |
|Gain on sale of intangible asset | |— | |(350.0 |) |
|Tax (benefit) expense (1) | |(18.9 |) |170\.2 | |
|Non-GAAP earnings | |$ |201\.5 | |$ |174\.7 | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |4\.66 | |$ |3\.84 | |
|Diluted | |$ |4\.36 | |$ |3\.48 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.2 | |45\.5 | |
|Diluted | |46\.2 | |50\.2 | |

* * *

(1) Represents the total tax impact of the quarterly non-GAAP earnings adjustments based on our actual quarterly effective income tax rates of approximately 32 percent and approximately 37 percent as of September 30, 2016 and 2015, respectively.

3

* * *  
**Conference Call**

We will host a half-hour teleconference on Thursday, October 27, 2016, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406, and using access code: 94365649.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.cfm.

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of innovative products to address the unmet medical needs of patients with chronic and life-threatening conditions.

**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, which does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, the calculation of our non-GAAP financial measure may differ from the methodology used by other companies. The presentation of our non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, Non-GAAP Earnings.

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, statements relating to our growth potential, our expectations regarding receipt of FDA approvals for our products and the timing of such approvals. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of October 27, 2016, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason.  [uthr-g]

Orenitram, Remodulin, Tyvaso and Unituxin are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

4

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In millions, except per share data)**

| | |**Three Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2016** | |**2015** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |408\.2 | |$ |384\.7 | |
|Other | |— | |1\.5 | |
|Total revenues | |408\.2 | |386\.2 | |
|Operating expenses: | | | | | |
|Cost of product sales | |23\.6 | |6\.9 | |
|Research and development | |45\.9 | |9\.6 | |
|Selling, general and administrative | |100\.1 | |(17.3 |) |
|Total operating expenses | |169\.6 | |(0.8 |) |
|Operating income | |238\.6 | |387\.0 | |
|Other income (expense): | | | | | |
|Interest expense | |(0.5 |) |(0.8 |) |
|Gain on sale of intangible asset | |— | |350\.0 | |
|Other, net | |1\.0 | |0\.6 | |
|Total other income, net | |0\.5 | |349\.8 | |
|Income before income taxes | |239\.1 | |736\.8 | |
|Income tax expense | |(77.3 |) |(272.4 |) |
|Net income | |$ |161\.8 | |$ |464\.4 | |
|Net income per common share: | | | | | |
|Basic | |$ |3\.75 | |$ |10\.20 | |
|Diluted | |$ |3\.50 | |$ |9\.24 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.2 | |45\.5 | |
|Diluted | |46\.2 | |50\.2 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**(Unaudited, in millions)**

| | |**September 30,  
2016** | |
| --- | --- | --- | --- | --- |
|Cash, cash equivalents and marketable securities | |$ |1,034.9 | |
|Total assets | |2,269.2 | |
|Total liabilities and temporary equity | |430\.5 | |
|Total stockholders’ equity | |1,838.7 | |

5

* * *