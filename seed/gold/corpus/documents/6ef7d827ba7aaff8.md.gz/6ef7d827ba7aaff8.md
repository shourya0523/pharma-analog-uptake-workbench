10-Q 1 a05-17960\_110q.htm QUARTERLY REPORT PURSUANT TO SECTIONS 13 OR 15(D) **UNITED STATES**

**SECURITIES AND EXCHANGE COMMISSION**

**WASHINGTON,
D.C. 20549**

**FORM 10-Q**

|**(Mark One)** | | |
| --- | --- | --- |
|x | |**QUARTERLY REPORT PURSUANT TO SECTION 13 OR
15(d) OF THE SECURITIES EXCHANGE ACT OF 1934.** |
|**For the quarterly period ended September 30,
2005** |
|**OR** |
|o | |**TRANSITION REPORT PURSUANT TO
SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934.** |

**For
the transition period from
          to**

**Commission
file number 0-26301**

**United Therapeutics Corporation**

(Exact Name of Registrant
as Specified in Its Charter)

|**Delaware** | |**52-1984749** |
| --- | --- | --- |
|(State or Other
Jurisdiction of  
Incorporation or Organization) | |(I.R.S. Employer  
Identification No.) |
|**1110 Spring Street, Silver Spring, MD** | |**20910** |
|(Address of
Principal Executive Offices) | |(Zip Code) |

**(301) 608-9292**

Registrant’s Telephone
Number, Including Area Code

(Former Name, Former
Address and Former Fiscal Year, If Changed Since Last Report)

Indicate by check mark
whether the registrant: (1) has filed all reports required to be filed by Section 13
or 15(d) of the Securities Exchange Act of 1934 during the preceding 12
months (or for such shorter period that the registrant was required to file
such reports), and (2) has been subject to such filing requirements for
the past 90 days.  Yes x No o

Indicate by check mark
whether the registrant is an accelerated filer (as defined in Rule 12b-2
of the Exchange Act).  Yes x No o

Indicate by check mark
whether the registrant is a shell company (as defined in Rule 12b-2
of the Exchange Act).  Yes o No x

The
number of shares outstanding of the issuer’s common stock, par value $.01 per
share, as of October 28, 2005 was 23,114,694.  
* * *  
**INDEX**

| | | |**Page** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|**Part I. FINANCIAL INFORMATION (UNAUDITED)** | | | | | |
|Item 1. | |Consolidated Financial Statements | | |1 | | |
| | |Consolidated Balance Sheets | | |1 | | |
| | |Consolidated Statements of Operations | | |2 | | |
| | |Consolidated Statements of Cash Flows | | |3 | | |
| | |Notes to Consolidated Financial Statements | | |4 | | |
|Item 2. | |Management’s Discussion and Analysis of Financial Condition and Results of Operations | | |13 | | |
|Item 3. | |Quantitative and Qualitative Disclosures About Market Risk | | |42 | | |
|Item 4. | |Controls and Procedures | | |43 | | |
|**Part II. OTHER INFORMATION** | | | | | |
|Item 6. | |Exhibits | | |44 | | |
|**SIGNATURES** | | |45 | | |  
* * *  
**PART I.
FINANCIAL INFORMATION**

**Item
1\.** Consolidated
Financial Statements

**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED BALANCE SHEETS  
(In thousands, except share and per share data)**

| | |**September 30,  
2005** | |**December 31,  
2004** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**(Unaudited)** | | | |
|**Assets** | | | | | | | | | |
|Current
assets: | | | | | | | | | |
|Cash and cash equivalents | | |$ |71,019 | | | |$ |82,586 | | |
|Marketable investments | | |41,638 | | | |200 | | |
|Accounts receivable, net of allowance of $16 for 2005
and $23 for 2004 | | |15,967 | | | |13,743 | | |
|Interest receivable | | |483 | | | |499 | | |
|Due from affiliates | | |81 | | | |524 | | |
|Prepaid expenses | | |3,115 | | | |3,230 | | |
|Inventories, net | | |10,276 | | | |8,014 | | |
|Other receivables | | |3,667 | | | |467 | | |
|Other current assets | | |645 | | | |1,229 | | |
|Total current assets | | |146,891 | | | |110,492 | | |
|Marketable investments | | |48,349 | | | |46,233 | | |
|Marketable investments and cash—restricted | | |20,557 | | | |10,121 | | |
|Goodwill, net | | |7,465 | | | |7,465 | | |
|Other intangible assets, net | | |5,607 | | | |5,967 | | |
|Property, plant and equipment, net | | |20,392 | | | |17,799 | | |
|Investments in affiliates | | |6,343 | | | |7,444 | | |
|Due from affiliates | | |433 | | | |— | | |
|Notes receivable from employees | | |— | | | |446 | | |
|Other assets | | |1,136 | | | |1,191 | | |
|Total assets | | |$ |257,173 | | | |$ |207,158 | | |
|**Liabilities
and Stockholders’ Equity** | | | | | | | | | |
|Current
liabilities: | | | | | | | | | |
|Accounts payable | | |$ |4,057 | | | |$ |6,098 | | |
|Accounts payable to affiliates and related parties | | |6 | | | |29 | | |
|Accrued expenses | | |12,433 | | | |7,689 | | |
|Due to affiliates and related parties | | |41 | | | |32 | | |
|Current portion of notes and leases payable | | |586 | | | |16 | | |
|Total current liabilities | | |17,123 | | | |13,864 | | |
|Notes and leases payable, excluding current portion | | |9 | | | |10 | | |
|Other liabilities | | |1,684 | | | |1,648 | | |
|Total liabilities | | |18,816 | | | |15,522 | | |
|Commitments and
contingencies | | | | | | | | | |
|Stockholders’ equity: | | | | | | | | | |
|Preferred stock, par value $.01, 10,000,000 shares
authorized, no shares issued | | |— | | | |— | | |
|Series A junior participating preferred stock,
par value $.01, 100,000 authorized, no shares issued | | |— | | | |— | | |
|Common stock, par value $.01, 100,000,000 shares
authorized, 23,618,906 and 22,955,129 shares issued at September 30,
2005 and December 31, 2004, respectively, and 23,092,306 and 22,428,529
outstanding at September 30, 2005 and December 31, 2004,
respectively | | |236 | | | |229 | | |
|Additional paid-in capital | | |387,720 | | | |375,945 | | |
|Accumulated other comprehensive income | | |2,010 | | | |2,677 | | |
|Treasury stock at cost, 526,600 shares | | |(6,874 |) | | |(6,874 |) | |
|Accumulated deficit | | |(144,735 |) | | |(180,341 |) | |
|Total stockholders’ equity | | |238,357 | | | |191,636 | | |
|Total liabilities
and stockholders’ equity | | |$ |257,173 | | | |$ |207,158 | | |

See accompanying notes to consolidated financial statements.

1  
* * *  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS
OF OPERATIONS  
(In thousands, except per share data)**

| | |**Three Months Ended  
September 30,** | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | | | | | |
|Net product sales | |$ |31,562 | |$ |19,027 | |$ |82,142 | |$ |49,002 | |
|Service sales | |1,383 | |968 | |3,870 | |2,975 | |
|License fees | |65 | |— | |262 | |— | |
|Total revenues | |33,010 | |19,995 | |86,274 | |51,977 | |
|Operating expenses: | | | | | | | | | |
|Research and development | |9,423 | |7,322 | |26,589 | |23,212 | |
|Selling, general and
administrative | |5,620 | |4,815 | |17,985 | |15,872 | |
|Cost of product sales | |2,936 | |1,690 | |7,609 | |4,632 | |
|Cost of service sales | |496 | |470 | |1,553 | |1,366 | |
|Total operating expenses | |18,475 | |14,297 | |53,736 | |45,082 | |
|Income from operations | |14,535 | |5,698 | |32,538 | |6,895 | |
|Other income (expense): | | | | | | | | | |
|Interest income | |1,418 | |771 | |3,600 | |2,094 | |
|Interest expense | |(7 |) |(4 |) |(8 |) |(6 |) |
|Equity loss in affiliate | |(189 |) |(244 |) |(564 |) |(482 |) |
|Other, net | |6 | |45 | |40 | |58 | |
|Total other income, net | |1,228 | |568 | |3,068 | |1,664 | |
|Income before income tax | |15,763 | |6,266 | |35,606 | |8,559 | |
|Income tax expense | |— | |— | |— | |— | |
|Net income | |$ |15,763 | |$ |6,266 | |$ |35,606 | |$ |8,559 | |
|Net income per common share: | | | | | | | | | |
|Basic | |$ |0\.69 | |$ |0\.29 | |$ |1\.57 | |$ |0\.40 | |
|Diluted | |$ |0\.61 | |$ |0\.27 | |$ |1\.41 | |$ |0\.37 | |
|Weighted average
number of common shares outstanding: | | | | | | | | | |
|Basic | |22,913 | |21,850 | |22,700 | |21,525 | |
|Diluted | |25,708 | |23,418 | |25,268 | |22,856 | |

See accompanying notes to consolidated financial statements.

2  
* * *  
**UNITED THERAPEUTICS CORPORATION  
CONSOLIDATED STATEMENTS
OF CASH FLOWS  
(In thousands)**

| | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**(Unaudited)** | |
|Cash flows from operating
activities: | | | | | |
|Net income | |$ |35,606 | |$ |8,559 | |
|Adjustments to
reconcile net income to net cash provided by operating activities: | | | | | |
|Depreciation and amortization | |1,884 | |1,739 | |
|Provision for bad debt | |67 | |21 | |
|Provision for inventory obsolescence | |(27 |) |43 | |
|Loss on disposals of equipment | |4 | |— | |
|Options issued in exchange for services | |657 | |215 | |
|Amortization of discount or premium on investments | |(88 |) |(78 |) |
|Equity loss in affiliate | |564 | |482 | |
|Changes in
operating assets and liabilities: | | | | | |
|Accounts receivable | |(2,292 |) |(662 |) |
|Interest receivable | |16 | |223 | |
|Inventories | |(2,265 |) |787 | |
|Prepaid expenses | |892 | |388 | |
|Other assets | |(2,559 |) |2,469 | |
|Accounts payable | |(2,065 |) |(1,665 |) |
|Accrued expenses | |4,744 | |4,984 | |
|Due to (from) affiliates | |464 | |54 | |
|Other liabilities | |(10 |) |(78 |) |
|Net cash provided by operating activities | |35,592 | |17,481 | |
|Cash flows from
investing activities: | | | | | |
|Purchases of property, plant and equipment | |(4,160 |) |(4,295 |) |
|Proceeds from disposals of property, plant and
equipment | |— | |816 | |
|Purchases of held-to-maturity investments | |(16,402 |) |— | |
|Purchases of available-for-sale investments | |(38,000 |) |— | |
|Maturities of held-to-maturity investments | |— | |(29,973 |) |
|Sales of available-for-sale investments | |500 | |30,000 | |
|Net cash used in investing activities | |(58,062 |) |(3,452 |) |
|Cash flows from
financing activities: | | | | | |
|Proceeds from the exercise of stock options | |11,126 | |4,554 | |
|Principal payments on notes payable and capital lease
obligations | |(223 |) |(767 |) |
|Net cash provided by financing activities | |10,903 | |3,787 | |
|Net increase (decrease) in cash and cash equivalents | |(11,567 |) |17,816 | |
|Cash and cash equivalents, beginning of period | |82,586 | |68,562 | |
|Cash and cash equivalents, end of period | |$ |71,019 | |$ |86,378 | |
|Supplemental
schedule of cash flow information: | | | | | |
|Cash paid for
interest | |$ |9 | |$ |1 | |

See accompanying notes to consolidated financial statements.

3  
* * *  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS  
September 30, 2005  
(Unaudited)**

**1\.
ORGANIZATION AND BUSINESS DESCRIPTION**

United Therapeutics Corporation (“United Therapeutics”)
is a biotechnology company focused on the development and commercialization of
unique products for patients with chronic and life-threatening cardiovascular,
cancer and infectious diseases. United Therapeutics was incorporated on June 26,
1996 under the laws of the State of Delaware and has the following wholly owned
subsidiaries: Lung Rx, Inc., Unither Pharmaceuticals, Inc. (“UPI”),
Unither Telemedicine Services Corp. (“UTSC”), Unither.com, Inc., United
Therapeutics Europe, Ltd., Unither Pharma, Inc., Medicomp, Inc.,
Unither Nutriceuticals, Inc., Lung Rx, Ltd. and Unither Biotech Inc.

United Therapeutics’ lead product is Remodulin®. On May 21,
2002, the United States Food and Drug Administration (“FDA”) approved
Remodulin (treprostinil sodium) Injection for the treatment of pulmonary
arterial hypertension in patients with NYHA class II-IV symptoms to diminish
symptoms associated with exercise. United Therapeutics was required by the FDA
to perform a post-marketing Phase IV clinical study to further assess the
clinical benefits of Remodulin. Continued FDA approval of Remodulin is subject
to the diligent and timely completion of the Phase IV trial, as well as its outcome.
On November 24, 2004, the FDA approved intravenous infusion of Remodulin,
based on data establishing its bioequivalence with the subcutaneous
administration of Remodulin, for patients who are not able to tolerate a
subcutaneous infusion. This approval was also conditioned upon the diligent and
timely completion of the Phase IV trial, as well as its outcome. Several
international applications for the approval of Remodulin have been granted and
others are pending.

United Therapeutics has
generated pharmaceutical revenues from sales of Remodulin and arginine products
in the United States, Europe and Asia. In addition, United Therapeutics has
generated non-pharmaceutical revenues from telemedicine products and services
in the United States.

**2\. BASIS OF PRESENTATION**

The consolidated financial statements included herein
have been prepared, without audit, pursuant to Regulation S-X of the Securities
and Exchange Commission. Certain information and footnote disclosures normally
included in consolidated financial statements prepared in accordance with
accounting principles generally accepted in the United States have been
condensed or omitted pursuant to such rules and regulations. These
consolidated financial statements should be read in conjunction with the audited
financial statements and notes thereto contained in United Therapeutics’ Annual
Report on Form 10-K for the year ended December 31, 2004 as
filed with the Securities and Exchange Commission.

In the opinion of United Therapeutics’ management, any
adjustments contained in the accompanying unaudited consolidated financial
statements are of a normal recurring nature, necessary to present fairly the
financial position as of September 30, 2005 and results of operations and
cash flows for the three and nine-month periods ended September 30, 2005
and 2004. Interim results are not necessarily indicative of results for an
entire year.

Certain amounts in the
2004 balance sheet and statement of operations were reclassified to conform to
the 2005 presentation.

4

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS (Continued)  
September 30, 2005  
(Unaudited)**

**3\. STOCKHOLDERS’ EQUITY**

**_Earnings per Common
Share_**

Basic
earnings per common share is computed by dividing net income by the weighted
average number of shares of common stock outstanding during the respective
periods. Diluted earnings per common share is computed by dividing net income
by the weighted average number of shares of common stock outstanding during the
period plus the effects of outstanding stock options that could potentially
dilute earnings per share in the future. The effects of potentially dilutive
stock options were calculated using the treasury stock method. The components
of basic and dilutive earnings per share are as follows (in thousands, except
per share amounts):

| | |**Three Months Ended  
September 30,** | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income
(Numerator) | |$ |15,763 | |$ |6,266 | |$ |35,606 | |$ |8,559 | |
|Shares (Denominator): | | | | | | | | | |
|Weighted average outstanding shares for basic EPS | |22,913 | |21,850 | |22,700 | |21,525 | |
|Dilutive effect of stock options | |2,795 | |1,568 | |2,568 | |1,331 | |
|Adjusted weighted average shares for diluted EPS | |25,708 | |23,418 | |25,268 | |22,856 | |
|Earnings per share | | | | | | | | | |
|Basic | |$ |0\.69 | |$ |0\.29 | |$ |1\.57 | |$ |0\.40 | |
|Diluted | |$ |0\.61 | |$ |0\.27 | |$ |1\.41 | |$ |0\.37 | |

**_Stock Option Plan_**

United Therapeutics accounts for its stock-based
compensation under the intrinsic value method in accordance with the provisions
of Accounting Principles Board (“APB”) Opinion No. 25, _Accounting for Stock Issued to Employees_ , and has provided
the pro forma disclosures of net income and net income per share in accordance
with Statement of Financial Accounting Standards (“SFAS”) No. 123, _Accounting for Stock-Based Compensation_ , using the fair
value method. Under APB No. 25, compensation expense for stock options
granted to employees is based on the difference, if any, on the date of the
grant between the fair value of United Therapeutics’ stock and the exercise
price of the option and is recognized ratably over the vesting period of the
option. United Therapeutics accounts for equity instruments issued to
consultants in accordance with SFAS No. 123 and Emerging Issues Task Force
(“EITF”) Issue No. 96-18, _Accounting for Equity
Instruments that are Issued to Other than Employees for Acquiring, or in
Conjunction with Selling Goods or Services_ .

5

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS (Continued)  
September 30, 2005  
(Unaudited)**

In
accordance with SFAS No. 148, _Accounting for Stock-Based
Compensation—Transition and Disclosure_ , the effect on net income and
net income per share if United Therapeutics had applied the fair value
recognition provisions of SFAS No. 123 to stock-based employee
compensation is as follows (in thousands, except per share amounts):

| | |**Three Months Ended  
September 30,** | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income, as
reported | |$ |15,763 | |$ |6,266 | |$ |35,606 | |$ |8,559 | |
|Less total
stock-based employee compensation expense determined under fair value based
method for all awards | |(4,551 |) |(1,732 |) |(13,652 |) |(5,195 |) |
|Pro forma net
income | |$ |11,212 | |$ |4,534 | |$ |21,954 | |$ |3,364 | |
|Basic net income per
common share: | | | | | | | | | |
|As reported | |$ |0\.69 | |$ |0\.29 | |$ |1\.57 | |$ |0\.40 | |
|Pro forma | |$ |0\.49 | |$ |0\.21 | |$ |0\.97 | |$ |0\.16 | |
|Diluted net income per
common share: | | | | | | | | | |
|As reported | |$ |0\.61 | |$ |0\.27 | |$ |1\.41 | |$ |0\.37 | |
|Pro forma | |$ |0\.44 | |$ |0\.19 | |$ |0\.87 | |$ |0\.15 | |

The effect of applying SFAS No. 123 on 2005 and
2004 pro forma net income and net income per share as stated above, is not
necessarily representative of the effects on reported net income for future
years due to, among other things, the vesting period of the stock options and
the fair value of additional stock options that may be granted in future years.

The Financial Accounting Standards Board has issued a
revision to SFAS No. 123 (“SFAS 123(R)”). SFAS 123(R) was
initially required to be implemented by July 1, 2005, but its
effectiveness has been delayed until January 1, 2006 by the Securities and
Exchange Commission. Accordingly, United Therapeutics will adopt SFAS 123(R)
on January 1, 2006. SFAS 123(R) is expected to have significant
impacts on the accounting and disclosure of employee stock options and future
operating results since, among other things, it will require that stock-based
employee compensation be expensed in the statement of operations.

The full impact of adoption of SFAS 123(R) cannot
be predicted at this time because it will depend on levels of share-based
payments granted in the future. However, had we adopted SFAS 123(R) in
prior periods, the impact of that standard would have approximated the impact
of SFAS 123 as described in the disclosure of pro forma net income and
earnings per share in Note 2 to the consolidated financial statements
contained in our Annual Report on Form 10-K for the year ended December 31,
2004 and as shown above. SFAS 123(R) also requires the benefits of tax
deductions in excess of recognized compensation cost to be reported as a
financing cash flow, rather than as an operating cash flow as required under
current literature. This requirement will reduce net operating cash flows and
increase net financing cash flows in periods after adoption. We are unable to
estimate what those amounts will be in the future because they depend on, among
other things, when employees exercise stock options.

6

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS (Continued)  
September 30, 2005  
(Unaudited)**

During the nine months
ended September 30, 2005, options to purchase 659,068 shares were
exercised.

**4\. INVENTORIES**

United
Therapeutics manufactures certain compounds, such as treprostinil and purchases
medical supplies, such as external pumps, for use in its product sales and
ongoing clinical trials. United Therapeutics subcontracts the manufacture of
cardiac monitoring equipment. United Therapeutics contracts with a third-party
manufacturer to make the HeartBar® and related products. These inventories are
accounted for under the first-in, first-out method and are carried at the lower
of cost or market. Inventories consisted of the following, net of reserves of
approximately $357,000 and $447,000 at September 30, 2005 and December 31,
2004, respectively (in thousands):

| | |**September 30,  
2005** | |**December 31,  
2004** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|Remodulin: | | | | | | | | | |
|Raw materials | | |$ |396 | | | |$ |553 | | |
|Work-in-progress | | |7,178 | | | |5,428 | | |
|Finished goods | | |1,578 | | | |960 | | |
|Remodulin
delivery pumps and other medical supplies | | |764 | | | |804 | | |
|Cardiac
monitoring equipment components | | |129 | | | |— | | |
|HeartBar and
related product lines | | |231 | | | |269 | | |
|Total inventories | | |$ |10,276 | | | |$ |8,014 | | |

**5\.
GOODWILL AND OTHER INTANGIBLE ASSETS**

Goodwill
and other intangible assets were comprised as follows (in thousands):

| | |**As of September 30, 2005** | |**As of December 31, 2004** | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |**Gross** | |**Accumulated  
Amortization** | |**Net** | |
|Goodwill | |$ |9,072 | | |$ |(1,607 |) | |$ |7,465 | |$ |9,072 | | |$ |(1,607 |) | |$ |7,465 | | |
|Intangible assets: | | | | | | | | | | | | | | | | | | |
|Noncompete agreements | |$ |273 | | |$ |(273 |) | |$ |— | |$ |273 | | |$ |(273 |) | |$ |— | | |
|Trademarks | |2,802 | | |(1,169 |) | |1,633 | |2,802 | | |(984 |) | |1,818 | | |
|Technology and patents | |6,164 | | |(2,190 |) | |3,974 | |6,164 | | |(2,015 |) | |4,149 | | |
|Total intangible
assets | |$ |9,239 | | |$ |(3,632 |) | |$ |5,607 | |$ |9,239 | | |$ |(3,272 |) | |$ |5,967 | | |

7

  
* * *

  
**UNITED THERAPEUTICS CORPORATION  
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS (Continued)  
September 30, 2005  
(Unaudited)**

Total
amortization expense for each of the three-month periods ended
September 30, 2005 and 2004 was approximately $120,000. Total amortization
expense for each of the nine-month periods ended September 30, 2005 and
2004 was approximately $360,000. As of December 31, 2004, the aggregate
amortization expense related to these intangible assets for each of the five
succeeding years was estimated as follows (in thousands):

|**Year ending December 31,** | | | | | |
| --- | --- | --- | --- | --- | --- |
|2005 | |$ |479 | |
|2006 | |479 | |
|2007 | |432 | |
|2008 | |432 | |
|2009 | |432 | |

**6\. SEGMENT INFORMATION**

United Therapeutics has two reportable business
segments. The pharmaceutical segment includes all activities associated with
the research, development, manufacture and commercialization of therapeutic
products. The telemedicine segment includes all activities associated with the
development and manufacture of patient monitoring products and the delivery of
patient monitoring services. The telemedicine segment is managed separately
because diagnostic services require different technology and marketing
strategies.

8  
* * *  
Segment
information as of and for the three and nine months ended September 30,
2005 and 2004 was as follows (in thousands):

| | |**Three Months Ended September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from
external customers | | |$ |31,526 | | | |$ |1,484 | | | |$ |33,010 | | | |$ |18,770 | | | |$ |1,225 | | | |$ |19,995 | | |
|Income (loss)
before income tax | | |15,814 | | | |(51 |) | | |15,763 | | | |6,603 | | | |(337 |) | | |6,266 | | |
|Interest income | | |1,414 | | | |4 | | | |1,418 | | | |769 | | | |2 | | | |771 | | |
|Interest expense | | |(8 |) | | |1 | | | |(7 |) | | |— | | | |(4 |) | | |(4 |) | |
|Depreciation and
amortization | | |(420 |) | | |(204 |) | | |(624 |) | | |(399 |) | | |(203 |) | | |(602 |) | |
|Equity loss in
affiliate | | |(189 |) | | |— | | | |(189 |) | | |(244 |) | | |— | | | |(244 |) | |
|Total investment
in equity method investees | | |2,249 | | | |— | | | |2,249 | | | |3,110 | | | |— | | | |3,110 | | |
|Expenditures for
long-lived assets | | |3,352 | | | |344 | | | |3,696 | | | |512 | | | |120 | | | |632 | | |
|Goodwill, net | | |1,287 | | | |6,178 | | | |7,465 | | | |1,287 | | | |6,178 | | | |7,465 | | |
|Total assets | | |247,714 | | | |9,459 | | | |257,173 | | | |185,513 | | | |9,597 | | | |195,110 | | |

| | |**Nine Months Ended September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |**Pharmaceutical** | |**Telemedicine** | |**Consolidated  
Totals** | |
|Revenues from
external customers | | |$ |82,024 | | | |$ |4,250 | | | |$ |86,274 | | | |$ |48,265 | | | |$ |3,712 | | | |$ |51,977 | | |
|Income (loss)
before income tax | | |36,310 | | | |(704 |) | | |35,606 | | | |9,574 | | | |(1,015 |) | | |8,559 | | |
|Interest income | | |3,590 | | | |10 | | | |3,600 | | | |2,088 | | | |6 | | | |2,094 | | |
|Interest expense | | |(8 |) | | |— | | | |(8 |) | | |(1 |) | | |(5 |) | | |(6 |) | |
|Depreciation and
amortization | | |(1,251 |) | | |(633 |) | | |(1,884 |) | | |(1,155 |) | | |(584 |) | | |(1,739 |) | |
|Equity loss in
affiliate | | |(564 |) | | |— | | | |(564 |) | | |(482 |) | | |— | | | |(482 |) | |
|Total investment
in equity method investees | | |2,249 | | | |— | | | |2,249 | | | |3,110 | | | |— | | | |3,110 | | |
|Expenditures for
long-lived assets | | |3,658 | | | |502 | | | |4,160 | | | |3,877 | | | |418 | | | |4,295 | | |
|Goodwill, net | | |1,287 | | | |6,178 | | | |7,465 | | | |1,287 | | | |6,178 | | | |7,465 | | |
|Total assets | | |247,714 | | | |9,459 | | | |257,173 | | | |185,513 | | | |9,597 | | | |195,110 | | |

The segment information shown above equals the
consolidated totals when combined. These consolidated totals equal the amounts
reported in the consolidated financial statements without further
reconciliation for those categories which are reported in the consolidated
financial statements. There are no inter-segment transactions.

For the three-month
periods ended September 30, 2005 and 2004 approximately 92 percent
and 88 percent of United Therapeutics revenues were earned from customers
located in the United States, respectively. For the nine-month periods ended September 30,
2005 and 2004 approximately 90 percent and 86 percent of United
Therapeutics revenues, respectively, were earned from customers located in the
United States.

9

  
* * *

  
**7\. COMPREHENSIVE INCOME**

SFAS No. 130, _Reporting Comprehensive Income,_ establishes standards for the reporting and display of comprehensive income and
its components. SFAS No. 130 requires, among other things, that unrealized
gains and losses on available-for-sale securities and foreign currency
translation adjustments be included in other comprehensive income (loss). The
following statement presents comprehensive income for the three and nine-months
ended September 30, 2005 and 2004 (in thousands):

| | |**Three Months Ended  
September 30,** | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income | |$ |15,763 | |$ |6,266 | |$ |35,606 | |$ |8,559 | |
|Other comprehensive
income (loss): | | | | | | | | | |
|Foreign currency translation adjustment | |(69 |) |(22 |) |(130 |) |(102 |) |
|Unrealized gain (loss) on available-for-sale
securities | |253 | |(535 |) |(537 |) |(1,653 |) |
|Comprehensive income | |$ |15,947 | |$ |5,709 | |$ |34,939 | |$ |6,804 | |

**8\. INCOME TAXES**

United Therapeutics did
not incur income tax expense for the three-month and nine-month periods ended September 30,
2005 and 2004 due to the availability of deductions for tax purposes and the
availability of net operating loss carryforwards which will offset any taxable
income for these periods. As of September 30, 2005, United Therapeutics
had available approximately $100.0 million in net operating loss carryforwards
and approximately $28.3 million in business tax credit carryforwards for
federal income tax purposes that expire at various dates through 2024. United
Therapeutics has conducted a study to determine whether any limitations under Section 382
of the Internal Revenue Code have been triggered. Results of this study
indicate that multiple limitations occurred through November 2004. As a
result, portions of these carryforward items that were generated prior to November 2004
will be subject to certain limitations on their use. United Therapeutics does
not believe that the potential limitations will cause the net operating loss
and general business credit carryforwards to expire unused.

**9\. NORTHERN THERAPEUTICS**

Northern Therapeutics, Inc.
is a Canadian affiliate of United Therapeutics. The CEO of United Therapeutics
served as Chairman of the Board and acting CEO of Northern Therapeutics from
2001 until March 2005.

**10\. LICENSE FEES**

In March 2005, United
Therapeutics entered into an agreement providing a third-party with a one-year
exclusivity period in which to perform due diligence with respect to certain glycobiology
intellectual property rights controlled by United Therapeutics, in exchange for
approximately $325,000. The fee is payable in installments over the one-year
period. Amounts paid to United Therapeutics by the licensee during the three
and nine months ended September 30, 2005 are nonrefundable and were
recognized as revenues in the periods in which they were paid. At any time
during the one-year period, the third-party has the right to enter into
negotiations with United Therapeutics to acquire an exclusive license to
commercialize products under such intellectual property rights for a field of
use outside of United Therapeutics’ core therapeutic areas. The agreement may
be terminated by the third party at any time. If terminated by the third party,
subsequent installments would no longer be due.

10

  
* * *

  
**11\. PHASE IV CLINICAL STUDY**

During the nine months ended September 30, 2005,
Remodulin drug sales accounted for approximately 94 percent of total revenues.
Upon FDA approval in 2002, United Therapeutics was required by the FDA to
perform a post-marketing Phase IV clinical study to confirm the clinical
benefits of Remodulin. Continued FDA approval of Remodulin is subject to the
diligent and timely completion of the Phase IV trial, as well as its outcome.

The 39-patient Phase IV clinical trial was
required to be one-half enrolled by June 2004 and fully enrolled by June 2005.
These enrollment deadlines were not met. However, the FDA permitted an interim
assessment and opportunity to terminate the Phase IV study after only 21
patients completed the study. The final study report is required to be
submitted in December 2005.

In July 2005, the first 21 patients completed the
study and United Therapeutics chose to perform the interim assessment. The
results of the interim assessment from these first 21 patients, as analyzed by
an independent statistician are positive (p=.0006). Specifically, 13 of
14 patients (93%) in the Remodulin arm were able to successfully
transition from Flolan® and complete the study without the need to institute
rescue therapy, compared to only 1 of 7 patients (14%) in the placebo arm.
Based on this positive outcome, United Therapeutics has submitted the interim
study results to the FDA and has requested permission to end the Phase IV
clinical study in satisfaction of its Phase IV commitments. By agreement
with the FDA, enrollment in the Phase IV clinical study was suspended
pending FDA review and acceptance of the interim study results.

If the FDA does not accept
the interim study results or does not otherwise agree with United Therapeutics’
assessment of the interim results, the FDA could, among other things, grant an
extension of time to continue to enroll the trial, or institute a public
hearing to withdraw marketing approval for Remodulin. If a withdrawal hearing
were instituted by the FDA, United Therapeutics would pursue the opportunity to
participate, as it believes that it has exercised good faith due diligence in
pursuing enrollment of this trial.

**12\.
LABORATORY CONSTRUCTION AGREEMENT**

In March 2005, United
Therapeutics entered into a construction management agreement with Turner
Construction Company (“Turner”), under which Turner will be responsible for
managing the construction of the new laboratory facility in Silver Spring,
Maryland. The agreement has a guaranteed maximum price clause in which Turner
has agreed that the construction cost of the facility will not exceed
approximately $27.0 million, which amount is subject to change based on agreed-upon
changes to the scope of work. Turner will be responsible for covering any costs
in excess of the guaranteed maximum price. If the ultimate cost of the project
is less than the guaranteed maximum price of $27.0 million, then a portion of
the costs savings will be shared with Turner. In addition, Turner must pay
penalties to United Therapeutics if the construction is not completed by April 2006,
which date is subject to change based on agreed-upon changes to the scope of
work. Construction costs to be incurred under this agreement will be reimbursed
to United Therapeutics by Wachovia Development Corporation in accordance with
the synthetic operating lease and related agreements.

**13\. NOTE
RECEIVABLE FROM VIREXX MEDICAL CORP.**

In August 2002, UPI
loaned approximately $433,000 to an affiliate, ViRexx Medical Corp. (formerly
AltaRex Medical Corp.). The related note receivable was a secured debenture due
in August 2005 with interest of six percent due quarterly and was
convertible into common stock. In October 2005, ViRexx and UPI agreed to
convert the note into 485,300 shares of ViRexx common stock, which were valued
at approximately $433,000 based on quoted market prices as of the maturity date
in August 2005.

11

  
* * *

  
**14\. RECEIVABLE FROM EMPLOYEE**

In April 2002, United
Therapeutics loaned $1.3 million to Dr. Roger Jeffs, its President and
Chief Operating Officer, to purchase his primary residence. The loan and
accrued interest were due at the end of five years or earlier, in part or in
full, if Dr. Jeffs obtained a mortgage on the property, exercised and sold
any United Therapeutics stock options, sold any United Therapeutics stock, or
sold the property. Interest of 6.5 percent per year accrued on the note. At December 31,
2004, the outstanding balance was approximately $445,000. In May 2005, Dr. Jeffs
paid off the remaining balance of this note.

**15\. RELOCATION COSTS**

United Therapeutics is constructing a laboratory
facility adjacent to its headquarters in Silver Spring, Maryland to replace its
current laboratory in Chicago, Illinois. Certain Chicago-based employees will
be relocated to the new facility beginning in 2006. It is anticipated that
approximately $1.0 million will be incurred in 2006 and 2007 in connection with
relocating these employees. Costs associated with these transfers will be
reported in the period in which the employees actually move and incur the
relocation costs.

Additionally, United
Therapeutics has agreed to pay bonuses to a small number of employees in
Chicago to remain employed there until the laboratory closes in the middle of
2007\. Such retention bonuses will be accrued ratably over the period from the
date of agreement with the employees to the date of payment in 2007.

**16\. OTHER RECEIVABLES**

Other receivables consists primarily of recoverable import
duties on shipments of Remodulin to other countries and construction costs that
will be reimbursed by Wachovia as discussed above under _Laboratory
Construction Agreement._

12  
* * *  
**Item 2.** Management’s
Discussion and Analysis of Financial Condition and Results of Operations

The following discussion
should be read in conjunction with the consolidated financial statements and
related notes appearing in our Annual Report on Form 10-K for the
year ended December 31, 2004. The following discussion contains
forward-looking statements made pursuant to the safe harbor provisions of Section 21E
of the Securities Exchange Act of 1934 and the Private Securities Litigation
Reform Act of 1995 concerning, among other things, the pricing of Remodulin,
the dosing and rate of patient consumption of Remodulin, the impacts of price
changes and changes in patient consumption of Remodulin on future revenues,
acceptance by the FDA of the Phase IV clinical trial interim study report
following the 21-patient interim assessments, the timing and outcome of
the Phase IV clinical trial, any actions that may or may not be taken by the
FDA as a result of the timing and outcome of the Phase IV clinical trial, the
timing, resubmission, completion and outcome of the applications for approval
of subcutaneous Remodulin in Ireland, Spain and the United Kingdom, the timing,
completion and outcome of pricing approvals in European Union countries that
approve subcutaneous Remodulin, the outcome of the receipt of a warning letter
and potential future warning letters from the FDA and any actions that may or
may not be taken by the FDA as a result of such warning letter or letters, the
timing and outcome of the 12-week placebo-controlled trial of intravenous
Remodulin in India, the funding of operations from future revenues, the
expectation of continued profits or losses, expectations concerning milestone
and royalty payments in 2005, the use of net operating loss carryforwards and
business tax credit carryforwards and the impact of Section 382 of the
Internal Revenue Code on their use, income tax expenses and benefits in future
periods, the completion of in-process research and development projects and
their impact on our business, the pace and timing of enrollment in clinical
trials, the expectation, outcome and timing of new and continuing regulatory
approvals, the expected levels and timing of Remodulin sales, the adequacy of
our resources to fund operations, the timing and level of spending to construct
a laboratory production facility, the potential amount of the minimum residual
value guarantee to Wachovia under the synthetic lease, events that could occur
upon termination of the Wachovia synthetic lease and related agreements,
expectations concerning payments of contractual obligations in all future years
and their amounts, the potential impacts of new accounting standards, the sale
of common stock at favorable terms under the primary registration statement
filed with the SEC in February 2005, as well as statements preceded by,
followed by or that include the words “believes”, “expects”, “anticipates”, “intends”,
“estimates”, “may” or similar expressions. These statements are based on our
beliefs and expectations as to future outcomes and are subject to risks and
uncertainties that could cause our results to differ materially from
anticipated results. Factors that could cause or contribute to such differences
include those discussed below and the risks described in our Annual Report on Form 10-K
for the year ended December 31, 2004 and the other cautionary statements,
cautionary language and risk factors set forth in other reports and documents
filed with the Securities and Exchange Commission. We undertake no obligation to
publicly update forward-looking statements, whether as a result of new
information, future events or otherwise.

**Overview**

We are a biotechnology
company focused on the development and commercialization of unique products for
patients with chronic and life-threatening cardiovascular, cancer and
infectious diseases. We commenced operations in June 1996 and, since our
inception, have devoted substantially all of our resources to acquisitions and
research and development programs.

**_United Therapeutics Products and
Services_**

Our lead product is Remodulin, which is a prostacyclin
analog, or a stable synthetic form of prostacyclin, an important molecule
produced by the body that has powerful effects on blood-vessel health and
function. On May 21, 2002, the United States Food and Drug Administration
(FDA) approved subcutaneous (injection under the skin) use of Remodulin
(treprostinil sodium) Injection for the treatment

13

  
* * *

  
of pulmonary arterial
hypertension, or PAH, in patients with NYHA class II-IV symptoms to diminish symptoms
associated with exercise. PAH is a life-threatening condition characterized by
elevated blood pressures between the heart and lungs. We were required to
perform a post-marketing Phase IV clinical study to confirm the clinical
benefits of Remodulin. Continued FDA approval of Remodulin is subject to the
diligent and timely completion of that Phase IV trial, as well as its outcome.
The study was originally to have been completed by May 2004 and involve
100 patients. In mid-2003, the FDA agreed to amend the due date of the
final study report and make other changes to the trial design including
reducing the number of patients to 39.

The amended Phase IV clinical trial was required to be
one-half enrolled by June 2004 and fully enrolled by June 2005. These
enrollment deadlines were not met. However, the FDA has permitted an interim
assessment and opportunity to terminate the Phase IV study after only 21
patients have completed the study. The final study report is required to be
submitted in December 2005.

In July 2005, the first 21 patients completed the
study and we chose to perform the interim assessment. The results of the
interim assessment from these first 21 patients, as analyzed by an independent
statistician were positive (p=.0006). Specifically, 13 of 14 patients
(93%) in the Remodulin arm were able to successfully transition from Flolan,
which they had previously been using to treat their condition, and complete the
study without the need to institute rescue therapy, compared to only 1 of 7
patients (14%) in the placebo arm. Based on this positive outcome, we submitted
the interim study results to the FDA and requested permission to end the
Phase IV clinical study in satisfaction of our Phase IV commitments.
By agreement with the FDA, enrollment in the Phase IV clinical study was
suspended pending FDA review and acceptance of the interim study results.

If the FDA does not accept the interim study results
or does not otherwise agree with our assessment of the interim results, the FDA
could, among other things, grant an extension of time to continue to enroll the
trial, or institute a public hearing to withdraw marketing approval for
Remodulin. If a withdrawal hearing were instituted by the FDA, we would pursue
the opportunity to participate, as we believe that we have exercised good faith
due diligence in pursuing enrollment of this trial.

On November 24, 2004, the FDA approved
intravenous infusion of Remodulin, based on data establishing its
bioequivalence with the previously approved subcutaneous administration of
Remodulin, for patients who are not able to tolerate a subcutaneous infusion.
This approval was also conditioned upon the diligent and timely completion of
the Phase IV trial, as well as its outcome. Remodulin is also approved for
subcutaneous use in most of Europe, Canada, Israel, Australia and Argentina. It
is also approved for intravenous use in Canada. Marketing authorization
applications are currently under review in other countries.

The mutual recognition procedure to obtain approvals
from European Union member countries for subcutaneous use of Remodulin was
completed in August 2005, with positive decisions received from most
European Union countries. We withdrew applications in Ireland, Spain and the
United Kingdom and are engaged in regulatory discussions concerning the timing
of resubmission in these three countries. Although these decisions were made in
August 2005, the approving European countries may not provide formal
action letters and pricing approvals required for the commercial sales of
Remodulin for as long as one to two years, or longer. We can give no assurances
as to the timing and receipt of the formal action letters and pricing approvals
from European countries, or the outcome of applications in other countries.

On April 13, 2005, the FDA issued a warning
letter to us citing a professional journal advertisement for Remodulin and a
medical frequently asked questions booklet for Remodulin that the FDA
considered to be false or misleading because they minimize risk information, make
unsubstantiated effectiveness and comparative claims, and omit material facts.
In addition, the FDA-approved product labeling for Remodulin did not accompany
the booklet, and these materials were not submitted to the FDA for review prior
to dissemination and at the time of initial dissemination as required under the
accelerated approval

14

  
* * *

  
regulations. The FDA
warning letter requested that we immediately cease the dissemination of the
violative promotional materials, provide a written response confirming our
compliance with the request, provide a list of all materials to be
discontinued, explain our plan for discontinuing use of such materials, and
include a comprehensive plan of action to disseminate truthful, non-misleading
and complete corrective messages to the audiences that received the violative
promotional materials.

On April 27, 2005, we responded to the FDA
warning letter and proposed corrective measures for its consideration, which
measures were accepted by the FDA on July 14, 2005. These measures include
publication of a corrective advertisement in three issues of a scientific
journal, posting of a “Dear Healthcare Provider” letter and a “Dear Patient”
letter on the www.remodulin.com website, and dissemination of these letters to
affected Remodulin prescribers. We have been working collaboratively with the
FDA to finalize the corrective actions and their implementation. On August 15,
2005, the FDA indicated that it considered the matter closed based upon the
corrective actions taken by Untied Therapeutics.

While we are committed to keeping an open dialog with
the FDA, and to improving its processes and procedures to ensure compliance
with its pre-submission obligations, there can be no assurances that the FDA
will not issue additional warning letters with respect to promotional materials
disseminated following the 2002 approval of Remodulin. In addition, in
accordance with the accelerated approval regulations under which Remodulin was
approved, there is a risk that the FDA may at any time request that we attend a
public hearing to withdraw marketing approval for Remodulin based on the
dissemination of false or misleading promotional materials. Nevertheless, we
are committed to ensuring that all of our advertising and promotional materials
are in compliance with all applicable regulatory requirements and to working
with the FDA to address any issues that arise in connection with our
advertising and labeling materials.

We have generated revenues
from sales of Remodulin and arginine products (such as HeartBar and other
products, which deliver the amino acid that is necessary for maintaining
cardiovascular function)—in the United States and other countries. In addition,
we have generated revenues from telemedicine products and services, primarily
designed for patients with abnormal heart rhythms called cardiac arrhythmias
and poor blood flow to the heart, a condition known as ischemic heart disease,
in the United States. We have funded our operations from the proceeds of sales
of our common stock and from revenues from the sales of our products and
services.

**_Remodulin Marketing and Sales_**

Remodulin is sold and
marketed to patients in the United States by Accredo Therapeutics, Inc. (a
wholly owned subsidiary of Medco Health Solutions, Inc.), CuraScript (a wholly
owned subsidiary of Express Scripts, Inc. and formerly Priority Healthcare
Corporation), and Caremark, Inc., and outside of the United States by
various international distributors. We sell Remodulin in bulk shipments to
these distributors. The timing and extent of our sales of Remodulin are
impacted by the timing and extent of these bulk orders from our distributors.
Bulk orders placed by our distributors are determined by them, based on their
estimates of the amount of drug required for current and newly starting
patients, as well as an inventory equivalent to approximately thirty to sixty
days demand as a contingent supply, since discontinuation of therapy can be
life-threatening to patients. Therefore, sales of Remodulin to distributors in
any given quarter may not be indicative of patient demand in that quarter.
Sales of Remodulin and Remodulin delivery pumps and supplies are recognized as
revenue when delivered to our distributors.

**_Future Prospects_**

While we were profitable
in each quarter since April 1, 2004, we incurred net losses for all
quarters from inception through March 31, 2004. At September 30,
2005, we had an accumulated deficit of

15

  
* * *

  
approximately
$144.7 million. We may again incur net losses and cannot provide assurances
that we will be profitable in the future. Future profitability will depend on
many factors, including timely and successful completion of the Remodulin Phase
IV study discussed above under _United Therapeutics
Products and Services_ , the price, level of sales, level of reimbursement
by public and private insurance payers, the impacts of competitive products and
the number of patients using Remodulin and other currently commercialized
products and services, as well as the results and costs of research and
development projects.

**Major
Research and Development Projects**

Our major research and
development projects are the use of Remodulin to treat cardiovascular diseases,
immunotherapeutic monoclonal antibodies (antibodies that activate a patient’s
immune response) to treat a variety of cancers and glycobiology antiviral
agents (a novel class of small molecules that may be effective as oral
therapies) to treat infectious diseases, such as hepatitis.

**_Cardiovascular Disease Projects_**

Subcutaneous use of Remodulin was approved by the FDA
in May 2002 for the treatment of PAH in NYHA Class II-IV patients to
diminish symptoms associated with exercise. A condition of continued FDA
approval is that a Phase IV clinical study must be completed in a timely and
diligent manner as discussed above under _United Therapeutics
Products and Services_ . Material net cash inflows from the sales of
Remodulin for PAH in May 2002 after FDA approval was received.

Remodulin was also approved in most of Europe, Canada,
Israel, Australia and Argentina for similar uses. Marketing authorization
applications are currently under review in other countries.

On March 29, 2005, the manufacturer of the
Medtronic 407C infusion pump, which is used for the subcutaneous administration
of Remodulin, received FDA approval for intravenous use of the pump. It was
previously approved for subcutaneous use only. We are currently evaluating the
Medtronic 407C infusion pump for use with intravenous Remodulin in patients
with PAH. Studies are underway in adult and pediatric patients to explore
logistics associated with use of this pump and to expand clinical information.

In March 2005, we commenced a 12-week
placebo-controlled trial of intravenous Remodulin in patients with PAH to
further assess the clinical benefits of Remodulin. The trial is being conducted
in India and was designed to enroll up to 126 patients. Interim results of this
trial may be assessed after 33, 66 and 99 patients have completed the 12-week
trial. In August 2005, after achieving enrollment of approximately 45
patients, enrollment of new patients was suspended as recommended by the trial’s
independent Data Safety Monitoring Board, which is a panel of independent
experts.

We are in the early stages of developing oral and
inhaled formulations of treprostinil, which is the active bulk ingredient in
Remodulin. During 2004, we completed dosage studies of oral formulations of
treprostinil in healthy volunteers. We filed an Investigational New Drug
Application on January 28, 2005 to perform an additional Phase I healthy
volunteer study. On July 21, 2005, the European Medicines Agency announced
that oral treprostinil had been granted orphan product status in the European
Union.

16  
* * *  
During 2004, independent clinical investigators in
Germany and the United States performed small uncontrolled trials of inhaled
formulations of treprostinil in patients with PAH. In June 2005, Lung
Rx, Inc., a subsidiary of United Therapeutics, commenced a 12-week
placebo-controlled trial of inhaled treprostinil in patients with PAH who are
also being treated with Tracleer®. The trial is being conducted at 15 centers
in the United States and in Europe and will include 150 patients. As of
September 30, 2005, approximately 30 patients have been enrolled in this
trial.

We incurred expenses of
approximately $5.6 million and $3.6 million during the three-month periods
ended September 30, 2005 and 2004, respectively, on Remodulin development.
We incurred expenses of approximately $14.6 million and $12.6 million during
each of the nine-month periods ended September 30, 2005 and 2004,
respectively, on Remodulin development. Approximately $155.4 million from
inception to date has been incurred on Remodulin development.

**_Cancer Disease Projects_**

Our monoclonal antibody
immunotherapies were licensed in April 2002 from AltaRex Medical Corp.
OvaRex® MAb is the lead product and is currently being studied in two identical
Phase III clinical trials in advanced ovarian cancer (Stage III and IV)
patients. These studies, which commenced in January 2003, are being
conducted at approximately 60 centers throughout the United States and will
enroll up to 354 patients. As of September 30, 2005 approximately 310
patients have been enrolled in these trials. These studies could take up to two
years to complete following full enrollment, depending on how long it takes for
236 patients to relapse. We incurred expenses of approximately $2.2 million and
$1.8 million during each of the three-month periods ended September 30,
2005 and 2004, respectively on OvaRex development. We incurred expenses of
approximately $5.9 million and $5.5 million during each of the nine-month
periods ended September 30, 2005 and 2004, respectively on OvaRex
development. Approximately $29.6 million from inception to date has been
incurred on OvaRex development.

**_Infectious Disease Projects_**

Our infectious disease
program includes glycobiology antiviral drug candidates in the preclinical and
clinical stages of testing. The drugs in this program are being developed for
hepatitis C, hepatitis B and other infectious diseases. We completed acute and
chronic Phase I clinical dosing studies for our first candidate for the
treatment of hepatitis C, UT-231B, to assess safety in healthy volunteers
in early 2003. We initiated Phase II clinical studies in patients infected with
hepatitis C in July 2003 and completed those studies in October 2004.
In that trial, UT-231B did not demonstrate efficacy against hepatitis C
in a population of patients that previously failed conventional treatments. We
are now researching new glycobiology drug candidates for the treatment of
infectious diseases. We incurred expenses of approximately $400,000 and
$971,000 during the three-month periods ended September 30, 2005 and 2004,
respectively, for our infectious disease programs. We incurred expenses of
approximately $3.0 million and $2.4 million during the nine-month periods ended
September 30, 2005 and 2004, respectively, for our infectious disease
programs. Approximately $34.7 million from inception to date has been incurred
for infectious disease programs.

**_Project Risks_**

Due to the inherent
uncertainties involved in the drug development, regulatory review and approval
processes, the anticipated completion dates, the cost of completing the
research and development and the period in which material net cash inflows from
these projects are expected to commence are not known or estimable. There are
many risks and uncertainties associated with completing the development of the
unapproved products discussed above, including the following:

· Products may fail in clinical studies;

17

  
* * *

  
· Hospitals, physicians and patients may not be
willing to participate in clinical studies;

· Hospitals, physicians and patients may not
properly adhere to clinical study procedures;

· The drugs may not be safe and effective or may
not be perceived as safe and effective;

· Other approved or investigational therapies
may be viewed as safer, more effective or more convenient;

· Patients may experience severe side effects
during treatment;

· Patients may die during the clinical study
because their disease is too advanced or because they experience medical
problems that are not related to the drug being studied;

· Patients may not enroll in the studies at the
rate we expect;

· The FDA and foreign regulatory authorities may
delay or withhold approvals to commence clinical trials or to manufacture
drugs;

· The FDA and foreign regulatory authorities may
request that additional studies be performed;

· Higher than anticipated costs may be incurred
due to the high cost of contractors for drug manufacture, research and clinical
trials;

· Drug supplies may not be sufficient to treat
the patients in the studies; and

· The results of preclinical testing may cause
delays in clinical trials.

If these projects are not
completed in a timely manner, regulatory approvals would be delayed and our
operations, liquidity and financial position could suffer. Without regulatory
approvals, we could not commercialize and sell these products and, therefore,
potential revenues and profits from these products would be delayed or
impossible to achieve.

**Financial Position**

Cash, cash equivalents and marketable investments
(including all unrestricted and restricted amounts) at September 30, 2005
were approximately $181.6 million, as compared to approximately $139.1 million
at December 31, 2004. The increase of approximately $42.5 million is due
primarily to cash provided by operating activities and proceeds from the
exercise of stock options. Restricted cash and marketable investments pledged
to secure our obligations under the synthetic operating lease discussed below
under _Off Balance Sheet Arrangement_ at September 30,
2005 totaled approximately $20.6 million, as compared with approximately $10.1
million at December 31, 2004. The increase in restricted cash and
marketable investments was due to additional funds placed in these accounts to
provide adequate collateral under the lease.

Accounts receivable, net of allowances, at September 30,
2005 were approximately $16.0 million, as compared to approximately $13.7
million at December 31, 2004. The increase was due to increased sales of
Remodulin.

Inventories, net of reserves for obsolescence, at September 30,
2005 were approximately $10.3 million, as compared to approximately $8.0
million at December 31, 2004. The increase was due primarily to increased
levels of Remodulin finished goods and work-in-process.

Other receivables at September 30, 2005 were
approximately $3.7 million, as compared to approximately $467,000 at December 31,
2004\. The increase was due primarily to an increase in recoverable import
duties on shipments of Remodulin to foreign countries of approximately
$1.4 million

18

  
* * *

  
and construction draws
receivable from Wachovia Development Corporation of approximately $1.8 million.

Investments in affiliates at September 30, 2005
were approximately $6.3 million, as compared to approximately $7.4 million at December 31,
2004\. The decrease was due primarily to a decrease in the fair value of our
investment in ViRexx Medical Corp., based on quoted market prices.

Property, plant and equipment at September 30,
2005 were approximately $20.4 million, as compared to $17.8 million at December 31,
2004\. The increase was due primarily to the purchase of building and land
adjacent to the Lung Rx, Inc. office located in Satellite Beach, Florida
for approximately $2.8 million.

Accounts payable at September 30, 2005 were
approximately $4.1 million, as compared to approximately $6.1 million at December 31,
2004\. The decrease was due generally to the timing of payments to vendors.

Accrued expenses at September 30, 2005 were
approximately $12.4 million, as compared to approximately $7.7 million at December 31,
2004\. The increase was due primarily to accrued expenses for royalties and
clinical trial related expenses.

Total stockholders’ equity
at September 30, 2005 was approximately $238.4 million, as compared to
$191.6 million at December 31, 2004. The increase in stockholders’ equity
of approximately $46.8 million was due primarily to net income earned and the
proceeds collected from exercises of stock options during the nine months ended
September 30, 2005.

**Results Of 
Operations**

**_Three Months ended September 30, 2005 and 2004_**

Revenues for the three months ended September 30,
2005 were approximately $33.0 million, as compared to approximately $20.0
million for the three months ended September 30, 2004. The increase of
approximately $13.0 million was due primarily to growth in sales of Remodulin
to our distributors.

The
following sets forth our revenues by source for the periods presented.

| | |**Revenues for the  
Three Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**(in thousands)** | |
|Remodulin | | |$ |31,352 | | |$ |18,369 | |
|Telemedicine
services and products | | |1,484 | | |1,225 | |
|Other products | | |109 | | |401 | |
|License fees | | |65 | | |— | |
|Total revenues | | |$ |33,010 | | |$ |19,995 | |

For the three-month periods ended September 30,
2005 and 2004, approximately 92 percent and 88 percent of our revenues,
respectively, were earned from customers located in the United States.

Total revenues are reported net of estimated
government rebates, prompt pay discounts and fees due to a distributor for
services. Government rebates are paid to state Medicaid agencies that pay for
Remodulin. Historically, we estimated our liability for such rebates based on
the volume of Remodulin dispensed to Medicaid patients as reported to us by our
distributors and the expected rebate per unit of Remodulin as determined by us
in accordance with federal guidelines. Since April 1, 2005, we have
estimated our liability for such rebates based on the historical level of
government rebates invoiced by state Medicaid agencies relative to U.S. sales
of Remodulin. Prompt pay discounts are offered on sales of Remodulin if the
related invoices are paid in full generally within 60 days from the date of
sale. We

19

  
* * *

  
estimated our liability
for prompt pay discounts based on historical payment patterns. Fees paid to a
distributor for services are estimated based on contractual rates for specific
services applied to estimated units of service provided by the distributor for
the period.

A
roll-forward of the liability accounts associated with estimated government
rebates, prompt pay discounts and fees to a distributor for services as well as
the net amount of reductions to revenues for these items are presented as
follows (in thousands):

| | |**Three Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
|Liability
accounts, at beginning of period | |$ |1,825 | |$ |1,049 | |
|Additions to
liability | |1,795 | |2,903 | |
|Payments | |(1,828 |) |(1,816 |) |
|Liability
accounts, at end of period | |$ |1,792 | |$ |2,136 | |
|Net reductions to
revenues | |$ |1,795 | |$ |2,903 | |

Our distributors endeavor to maintain levels of
Remodulin inventories sufficient to satisfy existing and new demand for the
product. Inventory levels held by United States-based distributors (as reported
to us by our distributors) at September 30, 2005 and December 31,
2004 were approximately $16.4 million and $14.0 million, respectively, based on
our gross selling price. As Remodulin was only recently approved by certain
member countries of the European Union, inventory levels outside of the United
States were not believed to be significant. Product returns were due to
arginine products and totaled approximately $1,500 and $2,500 during the three
months ended September 30, 2005 and 2004, respectively.

Research and development expenses consist primarily of
salaries and related expenses, costs to acquire pharmaceutical products and
product rights for development and amounts paid to contract research
organizations, hospitals and laboratories for the provision of services and
materials for drug development and clinical trials. Research and development
expenses were approximately $9.4 million for the three months ended September 30,
2005, as compared to the approximately $7.3 million for the three months ended September 30,
2004\. The increase of approximately $2.1 million is due primarily to increased
expenses for Remodulin related programs. See _Major
Research and Development Projects_ above, for additional information
regarding our research programs.

Selling, general and administrative expenses consist
primarily of salaries, travel, office expenses, insurance, professional fees,
provision for doubtful accounts receivable, depreciation and amortization.
Selling, general and administrative expenses were approximately $5.6 million
for the three months ended September 30, 2005, as compared to
approximately $4.8 million for the three months ended September 30, 2004.
The increase of approximately $800,000 is primarily due to increases in salary
and related expenses.

Cost of sales consists of the cost to manufacture or
acquire products that are sold to customers. Cost of service sales consists of
the salaries and related overhead necessary to provide services to customers.
Cost of product sales was approximately 9% of product sales for each of the
three months ended September 30, 2005 and 2004. Cost of service sales was
approximately 36% of service sales for the three months ended September 30,
2005, as compared to approximately 49% for the three months ended September 30,
2004\. The improvement in the cost of service sales as a percentage of service
revenues was due to the growth in service sales during 2005 with no
corresponding increase in costs.

Interest income for the three months ended September 30,
2005 was approximately $1.4 million, as compared to interest income of
approximately $771,000 for the three months ended September 30, 2004. The
increase was due primarily to an increase in cash available for investing
during 2005 and increased market interest rates.

20

  
* * *

  
Equity loss in affiliate represents our share of
Northern Therapeutics, Inc.’s losses. At September 30, 2005, we owned
approximately 68% of Northern Therapeutics. The equity loss in affiliate was
approximately $189,000 for the three months ended September 30, 2005, as
compared to approximately $244,000 for the three months ended September 30,
2004\. Northern Therapeutics, Inc.’s loss was due primarily to expenditures
for its autologous (non-viral vector) gene therapy research for pulmonary
hypertension and sales and marketing activities for Remodulin in Canada.

We did not incur income
tax expense for the three-month periods ended September 30, 2005 and 2004
due to the availability of deductions for tax purposes and the availability of
net operating loss carryforwards which will offset any taxable income for these
periods. However, we may incur income tax expenses and benefits in future
periods.

**_Nine Months ended September 30, 2005 and 2004_**

Revenues for the nine months ended September 30,
2005 were approximately $86.3 million, as compared to approximately $52.0
million for the nine months ended September 30, 2004. The increase of approximately
$34.3 million was due primarily to growth in sales of Remodulin to our
distributors.

The
following sets forth our revenues by source for the periods presented.

| | |**Revenues for the  
Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
| | |**(in thousands)** | |
|Remodulin | | |$ |81,272 | | |$ |46,176 | |
|Telemedicine
services and products | | |4,250 | | |3,712 | |
|Other products | | |490 | | |2,089 | |
|License fees | | |262 | | |— | |
|Total revenues | | |$ |86,274 | | |$ |51,977 | |

For the nine-month periods ended September 30,
2005 and 2004, approximately 90 percent and 86 percent of our revenues,
respectively, were earned from customers located in the United States.

A
roll-forward of the liability accounts associated with estimated government
rebates, prompt pay discounts and fees to a distributor for services as well as
the net amount of reductions to revenues for these items are presented as
follows (in thousands):

| | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |
|Liability
accounts, at beginning of period | |$ |2,121 | |$ |936 | |
|Additions to
liability | |4,801 | |5,030 | |
|Payments | |(5,130 |) |(3,830 |) |
|Liability
accounts, at end of period | |$ |1,792 | |$ |2,136 | |
|Net reductions to
revenues | |$ |4,801 | |$ |5,030 | |

Product returns were due to arginine products and
totaled approximately $3,000 and $30,000 during the nine months ended September 30,
2005 and 2004, respectively.

Research and development expenses were approximately
$26.6 million for the nine months ended September 30, 2005, as compared to
approximately $23.2 million for the nine months ended September 30, 2004.
The increase was due primarily to increased expenses for the Remodulin-related
programs, cancer disease programs and infectious disease programs of
approximately $2.0 million, $432,000 and $581,000,

21

  
* * *

  
respectively, during the
nine months ended September 30, 2005, as compared to the nine months ended
September 30, 2004. _See Major Research and
Development Projects above_ , for additional information regarding our
research programs.

Selling, general and administrative expenses were
approximately $18.0 million for the nine months ended September 30, 2005,
as compared to approximately $15.9 million for the nine months ended September 30,
2004\. The increase in selling, general and administrative expenses was due
primarily to the payment of one-time application fees of approximately $849,000
to European countries as part of the mutual recognition process for Remodulin
approval in Europe and an increase in salary and related expense of
approximately $937,000, during the nine months ended September 30, 2005.

Cost of product sales was approximately 9% of product
sales for the nine months ended September 30, 2005, which is consistent
with approximately 10% for the nine months ended September 30, 2004. Cost
of service sales was approximately 40% of service sales for the nine months ended
September 30, 2005, as compared to approximately 46% for the nine months
ended September 30, 2004. The improvement in the cost of service sales as
a percentage of service revenues was due to the growth in service sales during
2005 with no corresponding increase in costs.

Interest income for the nine months ended
September 30, 2005 was approximately $3.6 million, as compared to interest
income of approximately $2.1 million for the nine months ended
September 30, 2004. The increase was due primarily to an increase in cash
available for investing during 2005 and increased market interest rates.

The equity loss in affiliate was approximately
$564,000 for the nine months ended September 30, 2005, as compared to
approximately $482,000 for the nine months ended September 30, 2004.
Northern Therapeutics, Inc.’s loss was due primarily to expenditures for
its autologous (non-viral vector) gene therapy research for pulmonary
hypertension and sales and marketing activities for Remodulin in Canada.

We did not incur income
tax expense for the nine-month periods ended September 30, 2005 and 2004
due to the availability of deductions for tax purposes and the availability of
net operating loss carryforwards which will offset any taxable income for these
periods. However, we may incur income tax expenses and benefits in future
periods.

22  
* * *  
**Liquidity and Capital Resources**

Until June 1999, we financed our operations
principally through private placements of common stock. On June 17, 1999,
we completed our initial public offering. Our net proceeds from the initial
public offering and sale of the over-allotment shares, after deducting
underwriting commissions and offering expenses, were approximately $56.4
million. In 2000, we issued common stock in two private placements and received
aggregate net proceeds of approximately $209.0 million. Until 2002, we funded
the majority of our operations from such net proceeds of equity. Since 2004, we
funded the majority of our operations from revenues, mainly Remodulin-related,
and this is expected to continue.

In February 2005, we filed a primary shelf registration
statement with the SEC to enable us to offer and sell up to five million shares
of our common stock from time to time in one or more offerings. The shelf
registration statement will provide us the flexibility to take advantage of
future financing opportunities on terms that we consider advantageous, with
terms that would be established at the time of any such offering. The SEC
declared the shelf registration statement effective in February 2005.

Our working capital at September 30, 2005 was
approximately $129.8 million, as compared to approximately $96.6 million at December 31,
2004\. The increase is primarily due to a net increase in cash and current
marketable investments of approximately $29.9 million.

Restricted cash and marketable investments pledged to
secure our obligations under the synthetic operating lease discussed below
under _Off Balance Sheet Arrangement_ at September 30,
2005 totaled approximately $20.6 million, as compared with approximately $10.1
million at December 31, 2004. The increase in restricted cash and
marketable investments was due to additional funds placed in these accounts to
provide adequate collateral under the lease.

Net cash provided by operating activities was
approximately $35.6 million for the nine months ended September 30,
2005 as compared to approximately $17.5 million for the nine months ended September 30,
2004\. The increase in cash provided by operating activities is due primarily to
growth in sales and collections of Remodulin. For the nine months ended September 30,
2005, we invested approximately $4.2 million in cash for property, plant
and equipment, as compared to approximately $4.3 million in the nine months
ended September 30, 2004.

We made milestone payments totaling $20,000 pursuant
to existing license agreements during the nine months ended September 30,
2005\. We are obligated to make royalty payments on sales of Remodulin which
exceed annual net sales of $25.0 million and on all arginine products.
Royalties on sales of all products currently marketed range up to 10% of sales
of those products.

We believe that our existing revenues, together with
existing capital resources (comprised primarily of unrestricted cash, cash
equivalents and marketable investments), will be adequate to fund our
operations. However, any projections of future cash needs and cash flows are
subject to substantial uncertainty. See _Factors that may affect
United Therapeutics—Actual revenue run rates, consolidated revenues and net
income or losses may differ from our projections._

We did not incur income
tax expense for the three and nine-month periods ended September 30, 2005
due to the availability of deductions for tax purposes and net operating loss
carryforwards which will offset any taxable income for this period. As of September 30,
2005, we had available approximately $100.0 million in net operating loss
carryforwards and approximately $28.3 million in business tax credit
carryforwards for federal income tax purposes that expire at various dates
through 2024. We have determined that portions of these carry-forward items
will be subject to certain limitations on their use under Section 382 of
the Internal Revenue Code. However, we do not believe that these limitations
will cause the net operating loss and general business credit carryforwards to
expire unused.

23

  
* * *

  
**Off Balance Sheet Arrangement**

In June 2004, we entered into a synthetic
operating lease and related agreements with Wachovia Development Corporation
and its affiliates (Wachovia) to fund the construction of a laboratory facility
in Silver Spring, Maryland. Under these agreements, Wachovia will fund up to
$32.0 million towards the construction of the laboratory facility on ground
owned by us. The construction phase commenced in 2004 and is expected to be
completed in early 2006. Following construction, Wachovia will lease the
laboratory facility to us with a term ending in May 2011. Under the 99-year
ground lease, Wachovia will pay fair value rent to us for use of the land both
during the construction phase and after the laboratory lease is terminated.
During the term of the laboratory lease, Wachovia will pay $1 per year to us
for use of the land.

Upon completion of the construction, Wachovia will
receive rents from us generally based on applying the 30-day LIBOR rate
plus approximately 55 basis points to the amount funded by Wachovia towards the
construction of the laboratory. These rents will be paid monthly from the time
that the laboratory construction is completed until the termination of the
lease in May 2011. Upon termination of the lease, we will generally have
the option of renewing the lease (subject to approval of both parties),
purchasing the laboratory at a price approximately equal to the funded
construction cost or selling it and repaying Wachovia the cost of its construction.
We have guaranteed that if the laboratory is sold, Wachovia will receive at
least 86 percent of the amount it funded towards the construction.

In addition, we agreed to pledge, as collateral, a
portion of our marketable investments to secure our lease obligations. At September 30,
2005, approximately $20.6 million of marketable investments and cash were
pledged as collateral and are reported as restricted marketable investments and
cash in our consolidated balance sheet.

This arrangement allows us to construct our laboratory
facility without using our own working capital. We will manage the construction
and incur construction costs. Wachovia will then reimburse these construction
costs each month as they are incurred. We will make rent payments to Wachovia
starting when construction of the facility is completed and through the lease
termination in May 2011. There will not be any depreciation expense
associated with the laboratory facility, since these improvements will be owned
by Wachovia. The amount of rent to be paid to Wachovia will vary as it is tied
to the then current 30-day LIBOR rate plus approximately 55 basis points.
As this rate increases, so will the rents to be paid. Similarly, if this rate
decreases, then the amount of rent to be paid to Wachovia will also decrease.

We anticipate that rent payments will commence in
early 2006, after completion of construction, and continue through termination
of the lease in May 2011. Based on construction costs of up to
approximately $32.0 million and the current effective rate of approximately 4.4
percent (equivalent to the current 30-day LIBOR rate plus approximately
55 basis points at September 30, 2005), the rents to be paid could
approximate $1.4 million annually. In addition, Wachovia paid us ground rent in
June 2004 totaling an aggregate of approximately $307,000 that will be
recognized as income ratably through May 2011.

We guaranteed a minimum residual value of the
laboratory facility. This guaranteed residual is generally equal to 86 percent
of the amount funded by Wachovia towards construction. If, at the end of the
lease term, we do not renew the lease or purchase the improvements, then the
building will be sold to a third party. In that event, we have guaranteed that
Wachovia will receive at least this residual value amount. The maximum
potential amount of this guarantee is approximately $27.5 million,
equivalent to 86 percent of expected total construction costs of $32.0
million. We have estimated the fair value of this guarantee liability at approximately
$839,000 and this amount is classified as a non-current liability in our
balance sheet at September 30, 2005.

The lease and other agreements with Wachovia require
that, among other things, we maintain a consolidated current ratio of not less than
1\.2:1.0 and a consolidated net worth of at least $70.0 million.

24

  
* * *

  
The agreements contain
other covenants and conditions with which we must comply throughout the
construction and lease periods and upon termination of the lease. If we were
unable to comply with these covenants and conditions, the agreements could
terminate if the noncompliance was uncured and the parties could not agree
otherwise. A termination of these agreements could result in our acquisition of
the improvements from Wachovia or the loss of our liquid collateral. If the
agreements are terminated during the construction period due to our default,
then we could be required to purchase the improvements. During construction,
the amount we would be required to pay is limited to 89.9 percent of the
construction costs.

In March 2005, we entered
into a construction management agreement with Turner Construction Company (“Turner”).
Turner will manage the construction of the new laboratory facility. Under the
terms of the agreement, Turner will be responsible for the construction of the
facility. The agreement has a guaranteed maximum price clause in which Turner
agrees that the construction cost of the facility will not exceed approximately
$27.0 million, which amount is subject to change based on agreed-upon changes
to the scope of work. Turner will be responsible for covering any costs in
excess of the guaranteed maximum price guarantee. If the ultimate cost of the
project is less than the guaranteed maximum price of $27.0 million, then a
portion of the costs savings will be shared with Turner. In addition, Turner
must pay us penalties if the construction is not completed by April 2006,
which date is subject to change based on agreed-upon changes to the scope of
work.

**Contractual Obligations**

At September 30,
2005, we had contractual obligations coming due approximately as follows (in
thousands):

| | |**Payment Due In** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**Total** | |**Remainder  
of  
2005** | |**2006  
to  
2008** | |**2009  
to  
2010** | |**2011  
and  
Later** | |
|Notes payable and
capital lease obligations | |$ |597 | | |$ |216 | | |$ |381 | |$ |— | |$ |— | |
|Operating lease
obligations(1) | |11,870 | | |263 | | |7,154 | |3,627 | |826 | |
|Construction
agreement(2) | |19,121 | | |8,703 | | |10,418 | |— | |— | |
|Purchase
obligations | |502 | | |142 | | |360 | |— | |— | |
|Other long-term
liabilities reflected in the statement of financial position(1) | |839 | | |— | | |— | |— | |839 | |
|Milestone
payments(3) | |9,745 | | |— | | |4,685 | |3,040 | |2,020 | |
| | |$ |42,674 | | |$ |9,324 | | |$ |22,998 | |$ |6,667 | |$ |3,685 | |

* * *

(1) Operating lease
obligations include the estimated lease payments on the laboratory facility
being constructed in Silver Spring, Maryland. The lease is expected to commence
in early 2006 and will expire in May 2011. The lease payments will
generally be equal to applying the current 30-day LIBOR rate plus
approximately 55 basis points (approximately 4.4 percent at September 30,
2005) to the cost of the construction of the laboratory. Upon termination of
the lease, we will generally have the option of renewing the lease, purchasing
the laboratory or selling it and repaying Wachovia the cost of its construction.
We guaranteed that if the laboratory is sold, Wachovia will receive at least 86
percent of the amount it funded towards the construction. It is estimated that
the laboratory will cost approximately $32.0 million to construct and the
guarantee is estimated at approximately $27.5 million. The estimated fair
value of the guarantee is included in other long-term liabilities reflected in
the statement of financial position. See _Off Balance Sheet
Arrangement_ for additional information.

(2) Wachovia is
contractually obligated to reimburse these amounts to us under the synthetic
operating lease agreement described above under _Off Balance
Sheet Arrangement._

25

  
* * *

  
(3) We licensed certain
products from other companies under certain license agreements. These
agreements generally include milestone payments to be paid in cash by us upon
the achievement of certain product development and commercialization goals set
forth in each license agreement. Total milestone payments under these license
agreements have been estimated based on the estimated timing of these
development and commercialization goals.

**Summary of Critical Accounting Policies**

**_Income Taxes_**

We account for income taxes in accordance with
Statement of Financial Accounting Standards (SFAS) No. 109, _Accounting for Income Taxes_ . Under the asset and liability
method of SFAS No. 109, deferred tax assets and liabilities are determined
based on the differences between the financial reporting and the tax bases of
assets and liabilities and are measured using the tax rates and laws that are
expected to apply to taxable income in the years in which those temporary
differences are expected to be recovered or settled. A net deferred tax asset
or liability is reported in the balance sheet.

At each reporting date, we consider whether it is
more-likely-than-not that some portion or all of the net deferred tax asset is
realizable. If the net deferred tax asset is not fully realizable, then a
valuation allowance is established to reduce the amount of net deferred tax
asset reported in the balance sheet. Based on the weight of available evidence
at September 30, 2005, it was determined that a full valuation allowance
was necessary at September 30, 2005.

**_Remodulin Revenue Recognition_**

Product sales of Remodulin are recognized when
delivered to distributors, which are our customers for Remodulin. Product sales
of Remodulin delivery pumps and related supplies are recognized when delivered
to distributors on a gross basis in accordance with Emerging Issues Task Force
(EITF) Issue No. 99-19, _Reporting Revenue Gross as
a Principal versus Net as an Agent_ . Title to these products passes
upon delivery. Had the net basis been applied, the amounts of revenues and cost
of product sales reported in the consolidated financial statements would have
been lower, but there would have been no impact on net income or losses. Prompt
payment discounts, government rebates and fees to a distributor are estimated
and recognized as reductions of revenue in the same period that revenues are
recognized. Had these discounts, rebates and fees not been reported as
reductions of revenue, the amounts reported as revenues and selling expenses
would have been higher, but there would have been no impact on net income or
losses. Return policies provide that product that has expired or become damaged
in shipment may be replaced, but not returned. Therefore, reserves for
exchanges are not recorded unless product expiration or damage occurs. The
shelf life of Remodulin is two and one-half years from the date of its
manufacture. We rely on our distributors to report damage in shipment or
expirations of Remodulin product.

One of our Remodulin distribution agreements
stipulated minimum quarterly purchases by the distributor for periods through June 30,
2005\. The distribution agreement, however, does not permit the distributor to
return Remodulin product solely based on the distributor’s ability or inability
to resell the product. As a result, revenues from sales to this distributor are
recognized in the period that the Remodulin product is delivered to the
distributor. During the three-month periods ended September 30, 2005 and
2004, approximately none and $1.0 million, of Remodulin products were sold to
this distributor and recognized as revenue, respectively. During the nine-month
periods ended September 30, 2005 and 2004, approximately $4.0 million and
$2.0 million, of Remodulin products were sold to this distributor and
recognized as revenue, respectively.

**_Intangible Assets_**

We adopted the provisions of SFAS No. 142 _, Goodwill and Other Intangible Assets_ , on January 1,
2002, which eliminated the amortization of goodwill. Rather, goodwill is
subject to at least an annual assessment

26

  
* * *

  
for impairment by applying
a fair value-based test that is performed on October 1 st of each
year. We continually evaluate whether events and circumstances have occurred
that indicate that the remaining value of goodwill may not be recoverable. At September 30,
2005, we believed that goodwill was not impaired and therefore no impairment
losses have been recorded. This conclusion is based on our judgment, taking
into consideration expectations regarding future profitability and the status
of the reporting units which have reported goodwill. However, changes in
strategy or adverse changes in market conditions could impact this judgment and
require an impairment loss to be recognized for the amount that the carrying
value of goodwill exceeds its fair value.

**_Marketable Investments_**

Currently, we invest portions of our cash in
marketable debt securities issued primarily by federally-sponsored agencies.
Due to our intent and ability to hold these marketable debt investments until
their maturities, these investments are reported at their amortized cost. We
believe that we are able to hold these investments to maturity, due to the
significant level of cash and cash equivalents that we have. If we did not have
the ability and intent to hold these investments to maturity, we would have
reported them in the consolidated balance sheets at their fair market values.
At September 30, 2005, the amortized cost of these debt securities was
approximately $72.3 million and their fair values were approximately $70.4 million.

**_Earnings per Share_**

In accordance with SFAS No. 128, _Earnings Per Share_ , for the periods with net income, the
dilutive effect of outstanding stock options is included in the calculation of
dilutive earnings per share using the treasury stock method.

**_Stock Options_**

We
apply the principles of Accounting Principles Board (APB) Opinion No. 25, _Accounting for Stock Issued to Employees,_ in accounting for
its stock options issued to its employees. The following table details the pro
forma results had we applied the fair value principles of SFAS No. 123, _Accounting for Stock-Based Compensation_ , for its employee
options (in thousands):

| | |**Three Months Ended  
September 30,** | |**Nine Months Ended  
September 30,** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2005** | |**2004** | |**2005** | |**2004** | |
|Net income, as
reported | |$ |15,763 | |$ |6,266 | |$ |35,606 | |$ |8,559 | |
|Less total
stock-based employee compensation expense determined under fair value based
method for all awards | |(4,551 |) |(1,732 |) |(13,652 |) |(5,195 |) |
|Pro forma net income | |$ |11,212 | |$ |4,534 | |$ |21,954 | |$ |3,364 | |

27  
* * *  
**_Investments in Affiliates_**

The equity method of accounting is used to account for
some of our investments in affiliates, including Northern Therapeutics. The
equity method of accounting generally requires that we report our share of our
affiliates’ net losses or profits in our financial statements, but does not
require that assets, liabilities, revenues and expenses of the affiliates be
consolidated with our consolidated financial statements. The equity method of
accounting is being applied generally due to the lack of control over these
affiliates and the levels of ownership held by us. Although our investment in
Northern Therapeutics exceeds 50 percent, minority shareholders possess
substantive participating rights that preclude Northern Therapeutics’ financial
statements from being consolidated.

Other investments in affiliates are accounted for on
the cost method generally due to the lack of significant influence over these
affiliates and a less than 20 percent ownership by us. The cost method of accounting
does not require that we report our share of the affiliates’ net losses or
profits in our financial statements, nor are affiliates’ assets, liabilities,
revenues and expenses consolidated with our consolidated financial statements.

The investment in ViRexx
Medical Corp. (formerly AltaRex Medical Corp.) is accounted for as an
available-for-sale security because its stock is publicly traded. We own less
than 10 percent of ViRexx. Available-for-sale securities are reported at their
fair values in the balance sheet. Changes in their fair values are reported as
other comprehensive income or loss. Declines in values that are considered
other-than-temporary are reported as losses in the statement of operations. For
the three months ended September 30, 2005, the fair value of the
investment increased by approximately $253,000, as compared to a decrease in
fair value of approximately $535,000 for the three months ended September 30,
2004, based on quoted market prices. For the nine months ended September 30,
2005, the fair value of the investment in ViRexx decreased by approximately
$537,000, as compared to a decrease in fair market value of approximately $1.7
million for the nine months ended September 30, 2004, based on quoted
market prices. These changes in fair market value were reported as other
comprehensive income or loss.

**_Options Issued in Exchange for License_**

In June 2000, in
connection with our license from Toray Industries of the sustained release
formulation of beraprost (an oral prostacyclin analog), we agreed to grant
options to purchase 500,000 shares of our common stock to Toray upon Toray’s
adequate documentation of sustained release beraprost in humans and its
transfer of clinical trial material for use in clinical trials in the United
States. These options will not be priced until Toray has met this milestone. If
and when the milestone is met, the exercise price of the options would be set
at the fair market value of our common stock at that time. Before Toray can
produce the clinical trial material, it will need to complete formulation,
preclinical testing and early clinical studies. Due to the uncertainties in
drug development, it is not yet known if Toray will provide the appropriate
clinical trial material. Therefore, in accordance with EITF Issue No. 96-18, _Accounting for Equity Instruments that are Issued
to Other than Employees_ , these options are measured at their lowest
aggregate fair value at each interim reporting date, which amount has been
zero. As a result, no expense related to these options has been recorded in the
consolidated financial statements.

**_Lease of Laboratory Facility_**

In June 2004, we entered into a synthetic
operating lease and related agreements with Wachovia to fund the construction
of a laboratory facility in Silver Spring, Maryland. The total amount of the
construction is expected to be $32.0 million. The laboratory facility will be
owned by Wachovia, which will act as the lessor, and we will be the lessee and
pay rents to Wachovia once the facility is completed. This arrangement is a
form of off-balance sheet financing under which Wachovia will fund 100 percent
of the costs for the construction of the property and lease the laboratory
facility to us. We have provided a

28

  
* * *

  
residual value guarantee
to Wachovia that the residual value of the leased assets will be at least equal
to a specified amount at lease termination.

In accordance with the guidance in SFAS No. 13, _Accounting for Leases_ , EITF Issue No. 97-1, _Implementation Issues in Accounting for Lease Transactions, Including
Those Involving Special-Purpose Entities_ , EITF Issue No. 97-10, _The_ _Effect of Lessee
Involvement in Asset Construction_ , and Financial Accounting
Standards Board (FASB) Interpretation No. 46, _Consolidation
of Variable Interest Entities_ , we determined that the lease is
properly classified as an operating lease for accounting purposes. Furthermore,
we determined that Wachovia has sufficient substance such that it can be
treated as an unrelated entity and, accordingly, does not require consolidation
into our financial statements.

Operating leases of assets
do not require that the leased asset and the related rent obligation be
reported in the lessee’s balance sheet, but rather be disclosed as future
commitments. In contrast, capital leases do require that the leased asset and
rent obligations be reported in the lessee’s balance sheet as assets and debt.
Changes in the levels of investment made by Wachovia and its affiliates in the
laboratory could affect the classification of the lease from operating to capital.
In that event, we would include both the assets and debt associated with the
laboratory facility on our balance sheet.

**Recent Accounting Pronouncements**

**_Stock-Based Compensation_**

On December 16, 2004, the FASB issued a revision
of SFAS No. 123 (revised 2004), _Share-Based
Payment_ (Statement 123(R)), which is a revision of FASB Statement No. 123, _Accounting for Stock-Based Compensation_ (Statement 123) _._ Statement 123(R) supersedes APB Opinion No. 25, _Accounting for Stock Issued to Employees_ (Opinion 25), and amends FASB
Statement No. 95 _, Statement of Cash
Flows._ Generally, the approach in Statement 123(R) is similar
to the approach described in Statement 123. Statement 123(R) was initially
required to be implemented by July 1, 2005, but its effective date has
been delayed until January 1, 2006 by the Securities and Exchange
Commission. Accordingly, we anticipate that we will adopt Statement 123(R) on
January 1, 2006.

As permitted by Statement 123, we currently account
for share-based payments to employees using Opinion 25’s intrinsic value method
and, as such, generally recognize no compensation cost for employee stock
options. However, Statement 123(R) requires
all share-based payments to employees, including grants of employee stock
options, to be recognized in the income statement based on their fair values
over the expected period of service. Accordingly, the adoption of Statement
123(R)’s fair value method will have a significant impact on our results of
operations, although it should have no impact on our overall financial
position.

The full impact of
adoption of Statement 123(R) cannot be predicted at this time because it
will depend on levels of share-based payments granted in the future. However,
had we adopted Statement 123(R) in prior periods, the impact of that
standard would have approximated the impact of Statement 123 as described
in the disclosure of pro forma net income and earnings per share in Note 2 to
the consolidated financial statements contained in our Annual Report on Form 10-K
for the year ended December 31, 2004 and in Note 3 to the interim
consolidated financial statements contained in this Quarterly Report on Form 10-Q.
Statement 123(R) also requires the benefits of tax deductions in excess of
recognized compensation cost to be reported as a financing cash flow, rather
than as an operating cash flow as required under current literature. This
requirement will reduce net operating cash flows and increase net financing
cash flows in periods after adoption. We are unable to estimate what those
amounts will be in the future because they depend on, among other things, when
employees exercise stock options.

29

  
* * *

  
**_Other-than-Temporary Impairment_**

In March 2004, the
Emerging Issues Task Force (EITF) reached a consensus on Issue No. 03-01, _The Meaning of Other-Than-Temporary Impairment and
Its Application to Certain Investments._ EITF Issue No. 03-01
provides guidance on other-than-temporary impairment models for marketable debt
and equity securities accounted for under SFAS No. 115, _Accounting for Certain Investments in Debt and Equity Securities_ and non-marketable equity securities accounted for under the cost method. The
EITF developed a basic three-step model to evaluate whether an investment is
other-than-temporarily impaired. The effective date of the recognition and
measurement provisions of EITF Issue No. 03-01 has been delayed by
the FASB, however, the FASB did not suspend the requirement to recognize
other-than-temporary impairments as required by existing authoritative
literature. We do not expect the adoption of EITF Issue No. 03-01 to
have a significant impact on our results of operations and financial condition.

**_Inventory Costs_**

In December 2004, the
FASB issued SFAS Statement No. 151 _Inventory
Cost,_ which is an amendment to Accounting Research Bulletin No. 43, _Restatement and Revision of Accounting Research
Bulletins._ SFAS No. 151 clarifies the accounting treatment
of certain expenses for inventory costing. The new standard will be effective
for the first fiscal year beginning after June 15, 2005. We have not yet
completed our assessment of the impact of adopting this new standard.

**Factors
that may affect United Therapeutics**

The
following risk factors and other information included in this Quarterly Report
should be carefully considered. The risks and uncertainties described below are
not the only ones we face. Additional risks and uncertainties not presently
known to us or that we currently deem immaterial may also impair our business
operations. If any of the following risks occur, our business, financial
condition, operating results, cash flows and stock price could be materially
adversely affected.

**_Actual revenue run rates, consolidated revenues and
net income or losses may differ from our projections. In addition, we have a
history of losses and may not continue to be profitable._**

We have made public projections regarding our revenues
and profitability in 2005. These projections were based on numerous factors and
assumptions taken into consideration at the time the estimates were made. Those
factors and assumptions are inherently subject to a degree of uncertainty. As a
result, the actual revenues and net income or losses may be greater or less
than projected. Even small differences in the factors and assumptions can lead
to significant changes in our stock price.

In addition, although we were profitable for every
quarter ended after March 31, 2004, we lost money from the date of our
inception in 1996 through March 31, 2004. At September 30, 2005, our
accumulated deficit was approximately $144.7 million. We may incur additional
losses and may not remain profitable.

Factors that could
affect the accuracy of our expectations of revenue run rates, consolidated
revenues, and profitability and cause our quarterly and annual operating
results to fluctuate include the following:

· Extent and timing of sales of
Remodulin to distributors;

· Levels of Remodulin inventory
held by our distributors and changes to those levels from quarter to quarter:

· Level of patient demand for
Remodulin and other products;

· Changes in prescribers’ opinions
about Remodulin;

· Impact of medical and scientific
opinion about our products;

30

  
* * *

  
· Levels of research and
development, selling, general and administrative expenses;

· Timing
of payments to licensors and corporate partners;

· Retention
and growth of patients treated with Remodulin;

· Remodulin
side effects, including impact of infusion site pain and reaction from
subcutaneous use of Remodulin;

· Changes
in the current pricing and dosing of Remodulin;

· Changes
in the length of time that Remodulin vials may be used by patients;

· Changes
in the pricing of other therapies approved for PAH, including possible generic
formulations of other approved therapies, such as Flolan;

· Willingness
of private insurance companies, Medicare and Medicaid to reimburse Remodulin at
current pricing levels;

· Impacts
of new legislation and regulations and changes to the Medicare and Medicaid
programs;

· Diligent
and timely completion, as well as the outcome, of the Phase IV post-marketing
study of Remodulin;

· Our
ability to maintain regulatory approval of Remodulin in the United States and
other countries;

· Additional
regulatory approvals for Remodulin in countries other than where it is
currently sold;

· Status
and impact of other approved competitive products such as Ventavis®, Revatio®,
Tracleer and Flolan and investigational competitive products such as
Ambrisentan®, Thelin Ô , Cialis®, Gleevec®
and other potential investigational competitive products;

· Continued
performance by current Remodulin distributors under existing agreements;

· Size,
scope and outcome of development efforts for existing and additional products;

· Future
milestone and royalty payments under license and other agreements;

· Cost,
timing and outcomes of regulatory reviews;

· Rate
of technological advances;

· Our
ability to establish, defend and enforce intellectual property rights;

· Development
of manufacturing resources or the establishment, continuation or termination of
third-party manufacturing arrangements;

· Establishment,
continuation or termination of third-party clinical trial arrangements;

· Development
of sales and marketing resources or the establishment, continuation or
termination of third-party sales and marketing arrangements;

· Impact
of any regulatory restrictions on our marketing and promotional activities;

· Recovery
of goodwill, intangible assets and investments in affiliates;

· Collection
of accounts receivable and realization of inventories;

· Risks
associated with acquisitions, including the ability to integrate acquired
businesses;

· Unforeseen
expenses;

· Actual
growth in sales of telemedicine and arginine products;

· Actual
expenses incurred in future periods; and

· Completion
of additional acquisitions and execution of licensing agreements.

31  
* * *  
Most of our pharmaceutical products are in clinical
studies. We might not maintain or obtain regulatory approvals for our
pharmaceutical products and may not be able to sell our pharmaceutical products
commercially. Even if we sell our products, we may not be profitable and may
not be able to sustain any profitability we achieve.

**_We may not successfully compete with established drugs
and the companies that develop and market them._**

We
compete with established drug companies during product development for, among
other things, funding, access to licenses, expertise, personnel and third-party
collaborators. We will also compete with these companies following approval of
our products. Almost all of these competitors have substantially greater
financial, marketing, sales, distribution and technical resources, and more
experience in research and development, clinical trials and regulatory matters,
than we do.

We
are aware of existing treatments that compete with our products, especially in
the field of PAH. Patients and doctors may perceive these competing
products to be safer, more effective, more convenient or less expensive than
Remodulin. Accordingly, sales of Remodulin may not increase or may even
decrease if doctors prescribe less Remodulin than they are prescribing at
present.

For the treatment
of PAH, we compete with many approved products in the United States and
worldwide, including the following:

· Flolan was the first product
approved by the FDA for treating PAH and has been marketed by GlaxoSmithKline
PLC since 1996. Generic formulations of Flolan could be available for
commercial sale as early as 2007. Flolan is delivered by intravenous infusion
and considered to be an effective treatment by most PAH experts;

· Ventavis was approved in
December 2004 in the United States and in September 2003 in Europe.
Ventavis is the only prostacyclin that has been approved for inhalation, whereas
Remodulin is only currently approved to be delivered through intravenous or
subcutaneous (through the skin) infusion. Ventavis is marketed by
CoTherix, Inc. in the United States and Schering AG in Europe;

· Tracleer, the first oral drug to
be approved for PAH, is also the first drug in its class known as endothelin
receptor antagonists. Tracleer was approved in December 2001 in the United
States and May 2002 in Europe. Tracleer is marketed by Actelion, Ltd.
worldwide. As an oral therapy, Tracleer is a very convenient therapy; and

· Revatio was approved in
June 2005. Revatio is also an oral therapy and is marketed by Pfizer.
Revatio is a different formulation of the very successful drug Viagra® and is
the first drug in its class known as PDE-5 inhibitors to be approved for
PAH.

Doctors may reduce the dose of Remodulin given to
their patients if they prescribe these products in combination with Remodulin.

Many companies are
marketing and developing products containing arginine which compete with the
HeartBar product line. Many local and regional competitors and a few national
competitors provide cardiac Holter and event monitoring services and systems
that compete with our telemedicine products. A number of drug companies
are pursuing treatments for ovarian and other cancers and hepatitis that will
compete with any products we may develop from our immunotherapeutic monoclonal
antibody platform and glycobiology antiviral agents platform.

**_Discoveries or developments of new technologies by
others may make our products obsolete or less useful._**

Other companies may make
discoveries or introduce new products that render all or some of our
technologies and products obsolete or not commercially viable. Researchers are
continually making new discoveries that may lead to new technologies to treat
the diseases for which our products are intended. In

32

  
* * *

  
addition,
alternative approaches to treating chronic diseases, such as gene therapy, may
make our products obsolete or noncompetitive. Other investigational therapies
for PAH could be used in combination with Remodulin. If this happens, doctors
may reduce the dose of Remodulin given to their patients. This could result in
less Remodulin being used by such patients and, hence, reduced sales of
Remodulin.

**_We are aware of investigational products being
developed for the treatment of PAH with which our products may have to compete._**

· Sitaxentan (Thelin) is being
developed by Encysive Pharmaceuticals, Inc. worldwide for the treatment of
PAH. Encysive has completed testing of Sitaxentan, an oral tablet, and, based
on favorable results, has filed for approval with the Food and Drug
Administration in the United States. This application is currently being
reviewed. If approved, Thelin would become the second drug available in the
class known as endothelin receptor antagonists;

· Ambrisentan is being developed
by Myogen, Inc. for the treatment of PAH. Ambrisentan, an oral tablet, is
still in clinical testing and is also an endothelin receptor antagonist;

· Cialis is an approved oral
treatment for erectile dysfunction and is currently marketed by Lilly ICOS
LLC, a joint venture of Eli Lilly & Company and ICOS Corporation.
Cialis is currently being studied in patients with PAH. Cialis is in the same
class of drugs as Revatio;

· Gleevec is an approved oral treatment
for chronic myeloid leukemia (a cancer of the blood and bone marrow) and is
currently marketed by Novartis Pharmaceuticals Corporation. Recently,
researchers experienced in PAH have conducted studies of Gleevec and believe
that it may be effective in treating PAH;

· PRX-08066, a serotonin
receptor 5-HT2B antagonist, is being developed by Predix Pharmaceuticals
Holdings, Inc., as an oral tablet for the treatment of PAH. Two Phase I
clinical trials of PRX-08066 are being conducted in healthy volunteers;

· PulmoLAR, a once-a-month
injectible which contains a metabolite of estradiol, has been shown in animal
and cell models to address the key pathological processes associated with PAH;
and

· Aviptadil, an inhaled
formulation of vasoactive intestinal protein, is being developed by
mondoBIOTECH Holding SA, for the treatment of PAH.

There may be additional
drugs in development for PAH and there may also be currently approved drugs
that may be effective in treating the disease. If any of these drugs in development
or other currently approved drugs are used to treat PAH, sales of Remodulin may
fall.

**_If third-party payers will not reimburse
patients for our drug products or if third-party payers limit the amount
of reimbursement, our sales will suffer._**

Our commercial success
depends heavily on third-party payers, such as Medicare, Medicaid and
private insurance companies, agreeing to reimburse patients for the costs of
our pharmaceutical products. These third-party payers frequently
challenge the pricing of new and expensive drugs, and it may be difficult for
pharmacies selling Remodulin to convince these payers to reimburse patients for
the cost of Remodulin. Remodulin and the associated infusion pump and supplies
are very expensive. Intravenous infusion of Remodulin was approved in November 2004,
and payers may or may not agree to reimburse it. We believe our investigational
products, if approved, will also be very expensive. Presently, most third-party
payers, including Medicare and Medicaid, reimburse patients for the cost of
Remodulin therapy. In the past, Medicare has not reimbursed the full cost of
the therapy for some patients. Beginning on January 1, 2007, Medicare may
change the amount it pays for Remodulin, along with many other infusion drugs,
as required by the Medicare Modernization Act. Third-party payers may not
approve our

33

  
* * *

  
new
products for reimbursement or continue to approve Remodulin for reimbursement.
If third-party payers do not approve a product of ours for reimbursement
or limit the amount of reimbursement, sales will suffer, as patients will opt
for a competing product that is approved for reimbursement.

**_We rely on third parties to develop, market,
distribute and sell most of our products and those third parties may not
perform._**

We are currently marketing products in three of our
five therapeutic platforms: Remodulin in the prostacyclin analog platform, the
HeartBar and other product lines in the arginine formulations platform, and
CardioPAL cardiac event monitors and Holter monitors in the telemedicine
platform. We do not have the ability to independently conduct clinical studies,
obtain regulatory approvals, market, distribute or sell most of our products
and intend to rely substantially on experienced third parties to perform all of
those functions. We may not locate acceptable contractors or enter into
favorable agreements with them. If third parties do not successfully carry out
their contractual duties or meet expected deadlines, we might not be able to
obtain marketing approvals and sell our products.

Medtronic MiniMed is our exclusive partner for the
subcutaneous delivery of Remodulin using the MiniMed microinfusion device for
PAH. We rely on Medtronic MiniMed’s experience, expertise and performance. Any
disruption in the supply to PAH patients of MiniMed’s microinfusion device
could delay or prevent patients from initiating or continuing Remodulin
therapy, which could adversely affect our revenues. Similarly, we rely on
Accredo Therapeutics, Inc. (a wholly owned subsidiary of Medco Health Solutions, Inc.),
CuraScript (a wholly owned subsidiary of Express Scripts, Inc. and
formerly Priority Healthcare Corporation) and Caremark, Inc. to market,
distribute, and sell Remodulin in the United States. Accredo, CuraScript
and Caremark are also responsible for convincing third-party payers to
reimburse patients for the cost of Remodulin, which is very expensive. If our
partners and contractors do not achieve acceptable profit margins, they may not
continue to distribute our products. If our partners in the United States and
internationally are unsuccessful in their efforts, our revenues will suffer.

During 2005, two of our Remodulin
distributors in the United States were sold to larger companies. These
distributors continue to purchase Remodulin from us and distribute it.
Together, they account for most of the Remodulin sales we have made thus far.
When these distributors were independently managed, distribution of Remodulin was
more significant to them, because they were much smaller. Now, Remodulin is
much less significant to them because they are divisions or subsidiaries of
multi-billion dollar companies. It is possible, therefore, that these
distributors may devote fewer resources to the distribution of Remodulin. If
so, this may negatively impact our sales.

**_If we cannot maintain regulatory approvals for our
products, we cannot sell those products and our revenues will suffer._**

The process of obtaining and maintaining regulatory
approvals for new drugs is lengthy, expensive and uncertain. The manufacture,
distribution, advertising and marketing of these products are subject to
extensive regulation. Any new product approvals we receive in the future could
include significant restrictions on the use or marketing of the product.
Product approvals, if granted, can be withdrawn for failure to comply with
regulatory requirements (including those relating to misleading advertising) or
upon the occurrence of adverse events following commercial introduction of the
products.

The FDA has approved Remodulin for the treatment of
PAH in patients with Class II-IV symptoms to diminish symptoms associated
with exercise. This approval is subject to the requirement that we perform a
post-marketing Phase IV clinical study to further assess the clinical benefits
of Remodulin. Continued FDA approval of Remodulin is subject to the diligent
and timely completion of that trial, as well as its outcome. The 39-patient
Phase IV clinical trial was required to be one-half enrolled by June 2004
and fully enrolled by June 2005. The final study report is required to be
submitted in December 2005. To date,

34

  
* * *

  
22 patients have been
enrolled in the Phase IV trial. Enrolling patients in this study is difficult,
in part because it involves randomizing some of the patients to placebo despite
the fact that approved drugs are available for these patients. We did not
enroll the Phase IV trial within the time frame specified by the FDA, and
therefore are at risk of the FDA at any time instituting a public hearing to
withdraw marketing approval for Remodulin.

The FDA permitted an interim assessment and
opportunity to terminate the Phase IV study after only 21 patients completed
the study. In July 2005, the first 21 patients completed the study and we
chose to perform the interim assessment. The results of the interim assessment
from these first 21 patients, as analyzed by an independent statistician
are positive (p=.0006). Specifically, 13 of 14 patients (93%) in the Remodulin
arm were able to successfully transition from Flolan and complete the study
without the need to institute rescue therapy, compared to only 1 of 7 patients
(14%) in the placebo arm. Based on this positive outcome, we have submitted the
interim study results to the FDA and have requested permission to end the Phase
IV clinical study in satisfaction of our Phase IV commitments. By agreement
with the FDA, enrollment in the Phase IV clinical study was suspended pending
FDA review and acceptance of the interim study results.

We do not know how long the FDA will take to review
the interim study results, and we cannot predict the outcome of the review. If
the FDA does not accept the interim study results or does not agree with our
assessment of the interim results, we would still be required to comply with
the FDA-approved protocol for the Phase IV clinical study, including enrolling
39 patients in the study and submitting the final study report by December 2005.
The FDA could, among other things, grant an extension of time to continue to
enroll the trial, or institute a public hearing to withdraw marketing approval
for Remodulin.

We rely heavily on sales
of Remodulin. During the nine months ended September 30, 2005, our
Remodulin sales accounted for 94 percent of our total revenues. If approvals
are withdrawn for a product, we cannot sell that product and our revenues will
suffer. In addition, if product approvals are withdrawn, governmental
authorities could seize our products or force us to recall our products.

**_Our products may not be commercially successful
because physicians and patients may not accept them._**

Even if regulatory authorities approve our products,
these products may not be commercially successful. We expect that most of our
products, including Remodulin, which is already approved by the FDA, will be
very expensive. Patient acceptance of and demand for our products will depend
largely on the following factors:

· Acceptance by physicians and
patients of our products as safe and effective therapies;

· Willingness of payers to
reimburse and the level of reimbursement of drug and treatment costs by third-party
payers such as Medicare, Medicaid and private insurance companies;

· Safety, efficacy, pricing and
convenience of alternative products;

· Convenience and ease of
administration of our products; and

· Prevalence
and severity of side effects associated with our products, including the
infusion site pain and reaction associated with the use of subcutaneous
Remodulin and the potential for infections associated with intravenous
Remodulin.

**_We have limited experience with manufacturing and
depend on third parties, who may not perform, to synthesize and manufacture
many of our products._**

Prior to the 1999
acquisition of SynQuest, Inc., a company that manufactured treprostinil,
the bulk active ingredient in Remodulin, we had no experience with
manufacturing. Presently, treprostinil is being manufactured only by us. We
rely on third parties for the manufacture of all our products other than

35

  
* * *

  
treprostinil.
We rely on Baxter Healthcare Corporation for the formulation of Remodulin from
treprostinil. We rely on Cardinal Health, Inc. for stability studies on
Remodulin and to analyze other products that we are developing. We rely on MSI
of Central Florida, Inc. to manufacture our telemedicine devices. We rely
on other manufacturers to make our investigational drugs for use in trials.
Although there are a limited number of companies that could replace each of
these suppliers, we believe that other suppliers could provide similar services
and materials. A change in suppliers, however, could cause a delay in
distribution of Remodulin and other products, and in the conduct of clinical
trials and commercial launch, which would adversely affect our research and
development efforts and future sales efforts. Our manufacturing strategy
presents the following risks:

· The manufacturing processes for
some of our products have not been tested in quantities needed for commercial
sales;

· Delays in scale-up to commercial
quantities could delay clinical studies, regulatory submissions and
commercialization of our products;

· A long lead time is needed to
manufacture Remodulin, and the manufacturing process is complex;

· We and manufacturers of our
products are subject to the FDA’s good manufacturing practices regulations and
similar foreign standards, and although we control compliance issues with
respect to synthesis and manufacturing conducted internally, we do not have
control over compliance with these regulations by our third-party
manufacturers;

· Even if we and the manufacturers
of our products comply with the FDA’s good manufacturing practices regulations
and similar foreign standards, the sterility and quality of the products being manufactured
may be deficient. If this occurred, such products would not be available for
sale or use.

· If we have to change to another
manufacturing contractor or abandon our own manufacturing operations, the FDA
and comparable foreign regulators would require new testing and compliance
inspections, and the new manufacturer would have to be educated in the
processes necessary for the production of the affected product;

· We may not be able to develop or
commercialize our products, other than Remodulin, as planned or at all and will
have to rely solely on internal manufacturing capacity;

· We intend to transfer all of our
drug laboratory operations to the Silver Spring, Maryland facility currently
being built, and such transfer could result in manufacturing inefficiencies or
delays because the buildings, equipment and many of the employees being
the FDA and comparable foreign regulators will require new testing and
compliance inspections and this could result in delays;

· The supply of raw and advanced
materials and components used in the manufacture of Remodulin and other
products may be interrupted, which could delay the manufacture and subsequent
sale of such products. Any proposed substitute materials and components are
subject to approval by the FDA before any manufactured product can be sold. The
timing of such FDA approvals are difficult to predict and approvals may not be
timely obtained;

· Without substantial experience
in operating a manufacturing facility, we may not be able to successfully
manufacture Remodulin without a third-party manufacturer; and

· We may not have intellectual
property rights, or may have to share intellectual property rights, to many
improvements in the manufacturing processes or new manufacturing processes for
our products.

36

  
* * *

  
Any of these factors could delay clinical studies or
commercialization of our products, entail higher costs and, result in our being
unable to effectively sell our products.

**_If our products fail in clinical studies, we will not
be able to obtain or maintain FDA and foreign approvals and will not be able to
sell those products._**

In order to sell our pharmaceutical products, we must
receive regulatory approvals. To obtain those approvals, we must conduct
clinical studies demonstrating that the drug product, including its delivery
mechanism, is safe and effective. If we cannot obtain approval from the FDA for
a product, that product cannot be sold, and our revenues will suffer.

We are currently conducting a Phase IV clinical study
for Remodulin. For a description of the status of this Phase IV study, see our
discussion above under _“Factors that may affect
United Therapeutics—If we cannot maintain regulatory approvals for our
products, we cannot sell those products and our revenues will suffer.”_ We have initiated a Phase II/III clinical
study of an inhaled formulation of treprostinil and Phase I studies of an oral
formulation of Remodulin. Our lead glycobiology antiviral agent, UT-231B,
recently completed a Phase II, proof-of-concept study. In that trial, UT-231B
did not demonstrate efficacy against hepatitis C in a population of patients
that previously failed conventional treatments. We are now performing
preclinical testing to help determine the feasibility of a trial of UT-231B
in patients who responded positively to conventional treatments for hepatitis C
in order to prevent relapse. We are also researching new drug candidates for
infectious disease. We are also currently conducting two Phase III pivotal
studies of OvaRex for the treatment of metastatic ovarian cancer. We are still
completing or planning pre-clinical studies for our other products.

In the past, several of our product candidates have
failed or been discontinued at various stages in the product development
process, including, but not limited to, beraprost which failed in Phase III
testing for early stage peripheral vascular disease, Ketotop which failed in
Phase III testing for osteoarthritis of the knee and UT-77 which failed
in Phase II testing for chronic obstructive pulmonary disease.   Also, the length of time that it takes for us
to complete clinical trials and obtain regulatory approval for product
marketing has in the past varied by product and by the intended use of a
product. We expect that this will likely be the case with future product
candidates and we cannot predict the length of time to complete necessary
clinical trials and obtain regulatory approval.

Our ongoing and planned
clinical studies might be delayed or halted for various reasons, including:

· The drug is not effective, or
physicians think that the drug is not effective;

· Patients do not enroll in the
studies at the rate we expect;

· Patients experience severe side
effects during treatment, including site pain;

· Other investigational or
approved therapies are viewed as more effective or convenient by physicians or
patients;

· Patients die during the clinical
study because their disease is too advanced or because they experience medical
problems that are not related to the drug being studied;

· Drug supplies are not available
or suitable for use in the studies; and

· The results of preclinical
testing cause delays in clinical trials.

In addition, the FDA and foreign regulatory
authorities have substantial discretion in the approval process. The FDA and
foreign regulatory authorities may not agree that we have demonstrated that our
products are safe and effective.

37  
* * *  
**_Our corporate compliance program cannot guarantee that
we are in compliance with all potentially applicable federal, state and foreign
regulations._**

The development,
manufacture, distribution, pricing, sales, marketing, and reimbursement of our
products, together with our general operations, are subject to extensive
federal, state and foreign regulation. While we have developed and instituted
corporate compliance programs, we cannot assure that we or our employees are or
will be in compliance with all potentially applicable federal, state and
foreign regulations. If we fail to comply with any of these regulations a range
of actions could result, including, but not limited to, the termination of
clinical trials, the failure to approve a product candidate, restrictions on
our products or manufacturing processes, including withdrawal of our products
from the market, significant fines, exclusion from government healthcare
programs, or other sanctions or litigation.

**_If the licenses, assignments and alliance agreements
we depend on are breached or terminated, we would lose our right to develop and
sell the products covered by the licenses, assignments and alliance agreements._**

Our business
depends upon the acquisition, assignment and license of drugs and other products
which have been discovered and initially developed by others, including
Remodulin, all of the products in the immunotherapeutic monoclonal antibody
platform, all of the products in the glycobiology antiviral agents platform,
and the HeartBar line of products. Under our product license agreements, we are
granted certain rights  to existing
intellectual property owned by third parties subject to the terms of each
license agreement, whereas assignment agreements transfer all right, title and
ownership of the intellectual property to us, subject to the terms of each
assignment agreement. In addition, we have obtained licenses to other third-party
technology to conduct our business, including licenses for our products and an
alliance agreement for the use of the Medtronic MiniMed microinfusion device
for the administration of Remodulin. In addition, we may be required to obtain
licenses to other third-party technology to commercialize our early-stage
products. This dependence has the following risks:

· We may not be able to obtain
future licenses, assignments and agreements at a reasonable cost or at all;

· If any of our licenses or
assignments are terminated, we will lose our rights to develop and market the
products covered by such licenses or assignments;

· The licenses and assignments
that we hold generally provide for termination by the licensor or assignor in
the event we breach the license or assignment agreement, including failing to
pay royalties and other fees on a timely basis;

· In the event that GlaxoSmithKline
(formerly Glaxo Wellcome) terminates its assignment agreement or Pfizer
(formerly Pharmacia) terminates its license agreement, we will have no further
rights to utilize the assigned patents or trade secrets to develop and
commercialize Remodulin. For the nine months ended September 30, 2005,
sales of Remodulin accounted for approximately 94 percent of our revenues.
GlaxoSmithKline or Pfizer could seek to terminate the assignment in the event
that we fail to pay royalties based on sales of Remodulin; and

· If
licensors fail to maintain the intellectual property licensed or assigned to us
as required by most of our license and assignment agreements, we may lose our
rights to develop and market some or all of our products and may be forced to
incur substantial additional costs to maintain the intellectual property
ourselves or force the licensor or assignor to do so.

38

  
* * *

  
**_Certain license and
assignment agreements relating to our products may restrict our ability to
develop products in certain countries and/or for particular diseases and impose
other restrictions on our freedom to develop and market our products._**

When we acquire, license or receive assignments of
drugs and other products that have been discovered and initially developed by
others, we may receive rights only to develop such drugs or products in certain
territories and not throughout the world. For example, we do not have the right
to develop OvaRex and all our other monoclonal antibody immunotherapies for sale
in most of Europe and the Middle East, and we only have the rights to develop beraprost
for sale in the United States and Canada.

In addition, provisions in
our license and assignment agreements impose other restrictions on our freedom
to develop and market our products. For example, in assigning Remodulin to us,
GlaxoSmithKline retained an exclusive option and right of first refusal to
negotiate a license agreement with us if we ever decide to license any aspect
of the commercialization of Remodulin anywhere in the world. Similarly, in
connection with its licenses of beraprost to us, Toray Industries, Inc.
obtained a right of first refusal from us to develop and sell in Japan up to
two compounds that we develop. We also agreed to provisions giving Toray the
conditional right to approve our North American distributor, a conditional
restricted non-competition clause, and to minimum annual sales in order to
maintain exclusivity to beraprost. The restrictions that we have accepted in
our license and assignment agreements restrict our freedom to develop and
market our products in the future.

**_If our patent and other intellectual property
protection is inadequate, our sales and profits could suffer or competitors
could force our products completely out of the market._**

Our United States patent for the method of treating
pulmonary hypertension with Remodulin is currently set to expire in October 2014.
The patent for OvaRex and its method of use are the subject of a combination of
issued patents and pending applications in the United States and around the
world. The issued patents for OvaRex have expiration dates ranging from 2017 to
2020\. We believe that some of the patents to which we have rights may be
eligible for extensions of up to five years based upon patent term restoration
procedures in Europe and in the United States under the Waxman-Hatch Act.
Competitors may develop products based on the same active ingredients as our
products, including Remodulin, and market those products after the patents
expire, or may design around our existing patents. If this happens, our sales
would suffer and our profits could be severely impacted.

Patents may be issued to others that prevent the
manufacture or sale of our products. We may have to license those patents and
pay significant fees or royalties to the owners of the patents in order to keep
marketing our products. This would cause profits on sales to suffer.

We have been granted patents in the United States for
the synthesis of Remodulin, but patent applications that have been, or may in
the future be, filed by us may not result in the issuance of additional
patents. The scope of any patent issued may not be sufficient to protect our
technology. The laws of foreign jurisdictions in which we intend to sell our
products may not protect our rights to the same extent as the laws of the
United States.

In addition to patent protection, we also rely on
trade secrets, proprietary know-how and technology advances. We enter into
confidentiality agreements with our employees and others, but these agreements
may not be effective in protecting our proprietary information. Others may
independently develop substantially equivalent proprietary information or
obtain access to our know-how.

Litigation, which is very
expensive, may be necessary to enforce or defend our patents or proprietary
rights and may not end favorably for us. We are currently a party to pending
litigation initiated by us against other parties believed to have violated our
patents related to our arginine products line, and the validity and
enforceability of the patents related to our arginine products is currently
being challenged. We

39

  
* * *

  
may also
choose to initiate litigation against other parties who we come to believe are
infringing these patents. If such litigation is unsuccessful or if the patents
are invalidated or canceled, we may have to write off the related intangible
assets and such an event could significantly reduce our earnings. Any of our
licenses, patents or other intellectual property may be challenged,
invalidated, canceled, infringed or circumvented and may not provide any
competitive advantage to us.

**_If our highly qualified management and technical
personnel leave us, our business may suffer._**

We are dependent on our
current management, particularly our founder and Chief Executive Officer,
Martine Rothblatt, Ph.D., our President and Chief Operating Officer, Roger
Jeffs, Ph.D., our Executive Vice President for Business Development and Chief
Financial Officer, Fred Hadeed, our Executive Vice President for Strategic
Planning, General Counsel and Corporate Secretary, Paul Mahon, our Executive
Vice President and Chief Operating Officer for Production, David Walsh, our
Vice President for Pharmaceutical Development, David Zaccardelli, and our Vice
President for Manufacturing and Development, James Levin. While these
individuals are employed by us pursuant to multi-year employment agreements,
employment agreements do not ensure the continued retention of employees. We do
not maintain key person life insurance on these officers. Our success will
depend in part on retaining the services of our existing management and key
personnel and attracting and retaining new highly qualified personnel.
Expertise in the field of cardiovascular medicine, infectious disease and
oncology is not generally available in the market, and competition for qualified
management and personnel is intense.

**_We may not have adequate insurance and may have
substantial exposure to payment of product liability claims._**

The testing, manufacture,
marketing, and sale of human drugs involve product liability risks. Although we
currently have product liability insurance covering claims up to
$20 million per occurrence, we may not be able to maintain this product
liability insurance at an acceptable cost, if at all, and this insurance may
not provide adequate coverage against potential losses. If claims or losses
exceed our liability insurance coverage, we may go out of business.

**_We may not have, or may have to share rights to,
future inventions arising from our license, assignment and alliance agreements
and may lose potential profits or savings._**

Pursuant to our agreements
with certain business partners, any new inventions or intellectual property
that arise from our activities will be owned jointly by us and these partners.
If we do not have rights to new developments or inventions that arise during
the terms of these agreements, or we have to share the rights with others, we
may lose some or all of the benefit of these new rights, which may mean a loss
of future profits or savings generated from improved technology.

**_If we need additional financing and cannot obtain it,
product development and sales may be limited._**

We may need to spend more
money than currently expected because we may need to change our product
development plans or product offerings to address difficulties with clinical
studies, to prepare for commercial sales or to continue sales of Remodulin. We
may not be able to obtain additional funds on commercially reasonable terms or
at all. If additional funds are not available, we may be compelled to delay
clinical studies, curtail operations or obtain funds through collaborative
arrangements that may require us to relinquish rights to certain products or
potential markets.

40

  
* * *

  
**_Our activities involve hazardous materials, and
improper handling of these materials could expose us to significant
liabilities._**

Our research and
development and manufacturing activities involve the controlled use of
chemicals and hazardous materials. As a consequence, we are subject to numerous
federal, state, and local environmental and safety laws and regulations,
including those governing the management, storage and disposal of hazardous
materials. We may be required to incur significant costs to comply with current
or future environmental laws and regulations, and substantial fines and
penalties for failure to comply with these laws and regulations. While we
believe that we are currently in substantial compliance with laws and
regulations governing these materials, the risk of accidental contamination or
injury from these materials cannot be eliminated. In the event of such an
accident, we could be liable for civil damages that result or for the cleanup
of any release of hazardous materials, the cost of which could be substantial.
Any such liability could exceed our resources and could have a material adverse
effect on our business, financial condition and results of operations.

**_Our stock price could be volatile and could decline._**

The
market prices for securities of drug and biotechnology companies are highly
volatile, and there are significant price and volume fluctuations in the market
that may be unrelated to particular companies’ operating performances. The
table below sets forth the high and low closing prices for our common stock for
the periods indicated:

| | |**High** | |**Low** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
|January 1,
2003 - December 31, 2003 | |$ |24\.65 | |$ |14\.70 | |
|January 1,
2004 - December 31, 2004 | |$ |46\.73 | |$ |20\.51 | |
|January 1, 2005 - September 30,
2005 | |$ |73\.90 | |$ |41\.37 | |

Our stock price could decline suddenly due to the
following factors, among others:

· Quarterly and annual financial
and operating results;

· Failure to meet estimates or
expectations of securities analysts or our projections;

· Public concern as to the safety
of products developed by us or by others;

· Changes in or new legislation
and regulations affecting reimbursement of Remodulin by Medicare or Medicaid;

· Announcements by us or others of
technological innovations or new products or announcements regarding our
existing products;

· Developments in patent or other
proprietary rights;

· Future sales of substantial amounts
of common stock by our existing stockholders;

· The pace of enrollment in and
the results of clinical trials;

· Future sales of common stock by
our directors and officers;

· Failure to maintain approvals to
sell Remodulin;

· Timing and outcome of additional
regulatory approvals; and

· General
market conditions.

41

  
* * *

  
**_Future sales of shares of our common stock may depress
our stock price._**

If we issue common stock
to raise capital, or our stockholders transfer their ownership of our common
stock or sell a substantial number of shares of common stock in the public
market, or investors become concerned that substantial sales might occur, the
market price of our common stock could decrease. Each of our four executive
officers has announced their adoption of 10b5-1 prearranged trading
plans. In accordance with these plans, twice each month these executives sell a
specified number of our common stock either owned by them or acquired through
the exercise of stock options. However, these executives and our directors may
choose to sell additional shares outside of 10b5-1 trading plans and one
executive and five directors have done so. In addition, Toray
Industries Inc. has an option to acquire 500,000 shares of our common
stock and piggyback registration rights with respect to such shares that arise
if and when this option becomes exercisable. A decrease in our common stock
price could make it difficult for us to raise capital by selling stock or to
pay for acquisitions using stock. To the extent outstanding options are
exercised or additional shares of capital stock are issued, existing
stockholders may incur additional dilution.

**_Provisions of Delaware law and our certificate of
incorporation, by-laws and shareholder rights plan could prevent or delay a
change of control or change in management that could be beneficial to us and
our public stockholders._**

Certain provisions
of Delaware law and our certificate of incorporation, by-laws and shareholder
rights plan may prevent, delay or discourage:

· A merger, tender offer or proxy
contest;

· The assumption of control by a
holder of a large block of our securities; and

· The replacement or removal of
current management by our stockholders.

For example, our
certificate of incorporation divides the board of directors into three classes,
with members of each class to be elected for staggered three-year terms. This
provision may make it more difficult for stockholders to change the majority of
directors and may frustrate accumulations of large blocks of common stock by
limiting the voting power of such blocks. This may further result in
discouraging a change of control or change in current management.

**_Our existing directors and executive officers own a
substantial block of our stock and might be able to influence the outcome of
matters requiring stockholder approval._**

Our directors and named
executive officers beneficially owned approximately 8.4% percent of our
outstanding common stock as of September 30, 2005, including stock options
that could be exercised by those directors and executive officers within
60 days of that date. Accordingly, these stockholders as a group might be
able to influence the outcome of matters requiring approval by our
stockholders, including the election of our directors. Such stockholder
influence could delay or prevent a change of control with respect to us.

**_If stockholders do not receive dividends, stockholders
must rely on stock appreciation for any return on their investment in us._**

We have never declared or
paid cash dividends on any of our capital stock. We currently intend to retain
our earnings for future growth and therefore do not anticipate paying cash
dividends in the future.

42

  
* * *

  
**Item
3\.** Quantitative
and Qualitative Disclosures about Market Risk

At September 30, 2005, a substantial portion of
our assets was comprised of debt securities issued by federally-sponsored
agencies. The market value of these investments fluctuates with changes in
current market interest rates. In general, as rates increase, the market value
of a debt investment would be expected to decrease. Likewise, as rates
decrease, the market value of a debt investment would be expected to increase.
To minimize such market risk, we hold such instruments to maturity at which
time these instruments will be redeemed at their stated or face value. At September 30,
2005, we had approximately $72.3 million in debt securities issued by
federally-sponsored agencies with a weighted average stated interest rate of
approximately 3.7 percent maturing through March 2012 and callable
annually. The fair market value of this held-to-maturity portfolio at September 30,
2005 was approximately $70.4 million.

At September 30, 2005, a portion of our assets
was comprised of auction rate debt securities issued by state-sponsored
agencies. While these securities have long term maturities, their interest
rates are reset approximately every 7-28 days through an auction process.
As a result, the interest income from these securities is subject to market
risk since the rate is adjusted to accommodate market conditions on each reset
date. However, since the interest rates are reflective of current market
conditions, the fair value of these securities typically does not fluctuate
from par or cost. At September 30, 2005, we had approximately $37.7
million in these debt securities with a weighted average stated interest rate
of approximately 3.8 percent. The fair market value of these
available-for-sale debt securities at September 30, 2005 was approximately
$37.7 million.

In June 2004, we
entered into a synthetic operating lease and related agreements with Wachovia
Development Corporation and its affiliates (Wachovia) to fund the construction
of a laboratory facility in Silver Spring, Maryland. Under these agreements, we
will pay rents to Wachovia generally based on applying the 30-day LIBOR
rate plus approximately 55 basis points to the amount funded by Wachovia
towards the construction of the laboratory. The total amount of construction is
estimated to be approximately $32.0 million. At September 30, 2005, the
total amount incurred related to the construction was approximately $10.7
million. Rents will be paid monthly from the time that the laboratory
construction is completed until the termination of the lease in May 2011.
These rents, therefore, are subject to the risk that LIBOR will increase or
decrease during the period until termination in May 2011. At September 30,
2005, the 30-day LIBOR was approximately 4.4 percent. For every movement
of 100 basis points (1 percent) in the 30-day LIBOR rate, the rents
under this lease could increase or decrease by approximately $320,000 on an
annualized basis.

**Item 4.** Controls
and Procedures

Based on their evaluation, as of September 30,
2005, the Chief Executive Officer and Chief Financial Officer have concluded
that our disclosure controls and procedures (as defined in Rule 13a-15(e) and
15d-15(e) under the Securities Exchange Act of 1934, as amended) are
effective. There have been no changes in our internal control over financial
reporting that occurred during the period covered by this report that have
materially affected, or are reasonably likely to materially affect, such
internal control over financial reporting.

43  
* * *  
**Part II. OTHER INFORMATION**

**Item 6.** Exhibits

|Exhibit No. | |Description | | |
| --- | --- | --- | --- | --- |
|3\.1 | |Amended and Restated
Certificate of Incorporation of the Registrant, incorporated by reference to
Exhibit 3.1 of the Registrant’s Registration Statement on Form S-1
(Registration No. 333-76409). |
|3\.2 | |Amended and
Restated Bylaws of the Registrant, incorporated by reference to
Exhibit 3.2 of the Registrant’s Registration Statement on Form S-1
(Registration No. 333-76409) |
|31\.1 | |Certification of
Chief Executive Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934. |
|31\.2 | |Certification of
Chief Financial Officer pursuant to Rule 13a-14(a) of the
Securities Exchange Act of 1934. |
|32\.1 | |Certification of
Chief Executive Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002. |
|32\.2 | |Certification of
Chief Financial Officer pursuant to Section 906 of the Sarbanes-Oxley
Act of 2002. |

44  
* * *  
**SIGNATURES**

Pursuant
to the requirements of the Securities Exchange Act of 1934, the registrant has
duly caused this report to be signed on its behalf by the undersigned thereunto
duly authorized.

| |UNITED THERAPEUTICS CORPORATION |
| --- | --- | --- | --- | --- |
|Date: November 3,
2005 | |/s/ MARTINE A. ROTHBLATT |
| | |By: | |Martine A. Rothblatt |
| | |Title: | |_Chairman and Chief Executive Officer_ |
| | |/s/ FRED T. HADEED |
| | |By: | |Fred T. Hadeed |
| | |Title: | |_Executive Vice President for Business  
Development and Chief Financial Officer_ |

45  
* * *