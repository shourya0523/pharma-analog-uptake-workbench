EX-99.1 2 a18-8657\_3ex99d1.htm EX-99.1 **Exhibit 99.1**

For Immediate Release

Contact: James Edgemond

(301) 608-9292

jedgemond@unither.com

**UNITED THERAPEUTICS CORPORATION REPORTS**

**FIRST QUARTER 2018 FINANCIAL RESULTS**

Silver Spring, MD and Research Triangle Park, NC, May 2, 2018: United Therapeutics Corporation (NASDAQ: UTHR) today announced its financial results for the first quarter ended March 31, 2018.

“Our first quarter net revenues totaled $389 million,” said Martine Rothblatt, Ph.D., Chairman and Chief Executive Officer of United Therapeutics. “Orenitram posted a strong performance, representing the fourth consecutive quarter of greater than 20% net revenue growth on a year-over-year basis. In addition, we continue to treat an increasing number of pulmonary arterial hypertension (PAH) patients with our prostacyclin product franchise, which consists of Orenitram, Remodulin, and Tyvaso, confirming our belief in the organic growth opportunity for these proven therapies. During the first quarter of 2018, we also continued to advance our expanding product pipeline, which currently includes seven Phase III programs and multiple second-generation Remodulin drug delivery systems, as well as regenerative medicine and organ manufacturing programs. We believe that this pipeline positions United Therapeutics as an innovative market leader with the resources in place to ultimately find a cure for PAH and other end-stage organ diseases.”

Key financial highlights include (dollars in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |**Dollar  
Change** | |**Percentage  
Change** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | | | |
| | | | | | | | | | |
|Revenues | |$ |389\.2 | |$ |370\.5 | |$ |18\.7 | |5 |% |
|Net income | |$ |244\.5 | |$ |178\.6 | |$ |65\.9 | |37 |% |
|Non-GAAP earnings (1) | |$ |164\.9 | |$ |165\.7 | |$ |(0.8 |) |— |% |
|Net income, per basic share | |$ |5\.65 | |$ |4\.01 | |$ |1\.64 | |41 |% |
|Net income, per diluted share | |$ |5\.57 | |$ |3\.89 | |$ |1\.68 | |43 |% |
|Non-GAAP earnings, per diluted share (1) | |$ |3\.76 | |$ |3\.61 | |$ |0\.15 | |4 |% |

* * *

(1) See definition of non-GAAP earnings, a non-GAAP financial measure, and a reconciliation of net income to non-GAAP earnings below.

1

* * *  
**Financial Results for the Three Months Ended March 31, 2018 compared to the Three Months Ended March 31, 2017**

**Revenues**

The following table presents the components of total revenues (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | |**Change** | |**Change** | |
|Net product sales: | | | | | | | | | |
|Remodulin ® | |$ |126\.8 | |$ |145\.8 | |$ |(19.0 |) |(13 |)% |
|Tyvaso ® | |94\.6 | |87\.4 | |7\.2 | |8 |% |
|Adcirca ® | |97\.6 | |80\.0 | |17\.6 | |22 |% |
|Orenitram ® | |52\.2 | |39\.3 | |12\.9 | |33 |% |
|Unituxin ® | |18\.0 | |18\.0 | |— | |— |% |
|Total revenues | |$ |389\.2 | |$ |370\.5 | |$ |18\.7 | |5 |% |

Revenues for the three months ended March 31, 2018 increased by $18.7 million as compared to the same period in 2017. Adcirca net product sales increased by $17.6 million primarily due to price increases, which were determined by Eli Lilly and Company (Lilly). Orenitram net product sales increased by $12.9 million primarily due to an increase in the number of patients being treated with Orenitram and the one-time impact of a change in contractual minimum inventory levels with a U.S. distributor, as discussed below. Tyvaso net product sales increased by $7.2 million primarily due to price increases, partially offset by the one-time impact of a change in contractual minimum inventory levels with a U.S. distributor, as discussed below. These net increases in Adcirca, Orenitram and Tyvaso revenues were partially offset by a $19.0 million decrease in Remodulin net product sales due to: (1) a reduction in quantities ordered, based on variations in the timing and magnitude of orders from our U.S. and international distributors, which do not precisely reflect underlying patient demand; (2) a $7.3 million reduction in sales due to a decrease in the international sales price of Remodulin to an international distributor, which we agreed to in connection with a transfer of additional regulatory and commercial responsibilities to that distributor; and (3) the one-time impact of a change in contractual minimum inventory levels with a U.S. distributor, as discussed below.

During the fourth quarter of 2017, we amended our agreements with one of our U.S. specialty pharmacy distributors, in part to make the monthly minimum inventory days-on-hand requirement consistent across Remodulin, Tyvaso, and Orenitram. This change resulted in a one-time decrease in total net product sales of $4.3 million as the distributor adjusted to the new contractual inventory requirement levels in the first quarter of 2018. On an individual product basis, net product sales of Orenitram increased by $3.7 million, net product sales of Tyvaso decreased by $3.5 million, and net product sales of Remodulin decreased by $4.5 million.

**Expenses**

**Cost of product sales** . The following table summarizes cost of product sales by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar** | |**Percentage** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | |**Change** | |**Change** | |
|**Category:** | | | | | | | | | |
|Cost of product sales | |$ |59\.1 | |$ |15\.8 | |$ |43\.3 | |274 |% |
|Share-based compensation benefit (1) | |(5.9 |) |(1.5 |) |(4.4 |) |(293 |)% |
|Total cost of product sales | |$ |53\.2 | |$ |14\.3 | |$ |38\.9 | |272 |% |

* * *

(1) Refer to _Share-based compensation (benefit) expense_ below for discussion.

_Cost of product sales, excluding share-based compensation._ The increase in cost of product sales of $43.3 million for the three months ended March 31, 2018, as compared to the same period in 2017, was primarily attributable to a $37.3 million increase in the royalty expense for Adcirca. As a result of an amendment to our license agreement with Lilly, effective December 1, 2017, our royalty rate on net product sales of Adcirca increased from five percent to an effective rate of approximately 42.5 percent.

2

* * *  
**Research and development expense** . The following table summarizes research and development expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar  
Change** | |**Percentage  
Change** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | | | |
|**Project and non-project:** | | | | | | | | | |
|Research and development projects | |$ |58\.2 | |$ |41\.3 | |$ |16\.9 | |41 |% |
|Share-based compensation benefit (1) | |(22.5 |) |(5.1 |) |(17.4 |) |(341 |)% |
|Total research and development expense | |$ |35\.7 | |$ |36\.2 | |$ |(0.5 |) |(1 |)% |

* * *

(1) Refer to _Share-based compensation (benefit) expense_ below for discussion.

_Research and development expense, excluding share-based compensation._ The increase in research and development expense of $16.9 million for the three months ended March 31, 2018, as compared to the same period in 2017, was driven by the expansion of our pipeline programs to treat cardiopulmonary diseases and cancer.

**Selling, general and administrative expense** . The following table summarizes selling, general and administrative expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar  
Change** | |**Percentage  
Change** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | | | |
|**Category:** | | | | | | | | | |
|General and administrative | |$ |52\.8 | |$ |53\.5 | |$ |(0.7 |) |(1 |)% |
|Sales and marketing | |13\.3 | |15\.4 | |(2.1 |) |(14 |)% |
|Share-based compensation benefit (1) | |(72.7 |) |(12.5 |) |(60.2 |) |(482 |)% |
|Total selling, general and administrative expense | |$ |(6.6 |) |$ |56\.4 | |$ |(63.0 |) |(112 |)% |

* * *

(1) Refer to _Share-based compensation (benefit) expense_ below for discussion.

**Share-based compensation (benefit) expense** . The following table summarizes share-based compensation (benefit) expense by major category (dollars in millions):

| | |**Three Months Ended  
March 31,** | |**Dollar  
Change** | |**Percentage  
Change** | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | | | |
|**Category:** | | | | | | | | | |
|Stock options | |$ |12\.7 | |$ |4\.6 | |$ |8\.1 | |176 |% |
|Restricted stock units | |0\.9 | |0\.5 | |0\.4 | |80 |% |
|Share tracking awards plan | |(115.0 |) |(24.6 |) |(90.4 |) |(367 |)% |
|Employee stock purchase plan | |0\.3 | |0\.4 | |(0.1 |) |(25 |)% |
|Total share-based compensation benefit | |$ |(101.1 |) |$ |(19.1 |) |$ |(82.0 |) |(429 |)% |

_Share-based compensation._ The increase in share-based compensation benefit of $82.0 million for the three months ended March 31, 2018, as compared to the same period in 2017, was primarily due to a $90.4 million decrease in our STAP liability, driven by a greater decrease in our stock price during the three months ended March 31, 2018, as compared to the same period in 2017, partially offset by an $8.1 million increase in stock option expense due to additional awards granted and outstanding in 2018.

**Income Tax Expense**

The provision for income taxes was $64.5 million for the three months ended March 31, 2018, as compared to $85.0 million for the same period in 2017. Our effective tax rate as of March 31, 2018 and March 31, 2017, was approximately 21 percent and 32 percent, respectively. Our 2018 effective tax rate decreased compared to 2017 primarily due to a reduced federal corporate tax rate, partially offset by the reduction of the Orphan Drug Credit and the repeal of the Section 199 deduction.

3

* * *  
**Non-GAAP Earnings**

Non-GAAP earnings is defined as net income, adjusted for: (1) share-based compensation expense (including expenses relating to stock options, restricted stock units, share tracking awards, and our employee stock purchase plan); and (2) tax impact on non-GAAP earnings adjustments.

A reconciliation of net income to non-GAAP earnings is presented in the following table (in millions, except per share data):

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | |
|Net income, as reported | |$ |244\.5 | |$ |178\.6 | |
|Adjusted for the following charges: | | | | | |
|Share-based compensation benefit (1) | |(101.1 |) |(19.1 |) |
|Tax expense (1) | |21\.5 | |6\.2 | |
|Non-GAAP earnings | |$ |164\.9 | |$ |165\.7 | |
|Non-GAAP earnings per share: | | | | | |
|Basic | |$ |3\.81 | |$ |3\.72 | |
|Diluted | |$ |3\.76 | |$ |3\.61 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.3 | |44\.5 | |
|Diluted | |43\.9 | |45\.9 | |

* * *

(1) We calculated the total tax impact of non-discrete quarterly non-GAAP earnings adjustments based on our estimated annual effective tax rates, before considering discrete items, of approximately 21 percent and approximately 32 percent for the quarters ended March 31, 2018 and March 31, 2017, respectively.

**Conference Call**

We will host a half-hour teleconference on Wednesday, May 2, 2018, at 9:00 a.m. Eastern Time. The teleconference is accessible by dialing 1-877-351-5881, with international callers dialing 1-970-315-0533. A rebroadcast of the teleconference will be available for one week by dialing 1-855-859-2056, with international callers dialing 1-404-537-3406, and using access code: 5778455.

This teleconference is also being webcast and can be accessed via our website at http://ir.unither.com/events.

**About United Therapeutics**

United Therapeutics Corporation is a biotechnology company focused on the development and commercialization of innovative products to address the unmet medical needs of patients with chronic and life-threatening conditions.

**Non-GAAP Financial Information**

This press release contains a financial measure, non-GAAP earnings, which does not comply with United States generally accepted accounting principles (GAAP). This measure supplements our financial results prepared in accordance with GAAP as reported below.

We use non-GAAP earnings to assist us in: (1) planning, including the preparation of our annual operating budget; (2) allocating resources in an effort to enhance the financial performance of our business; (3) evaluating the effectiveness of our operational strategies; and (4) assessing our capacity to fund capital expenditures and expand our business. We believe this non-GAAP financial measure improves investors’ understanding of our financial results by excluding certain expenses that we do not consider when evaluating and comparing the performance of our core operations and making operating decisions. However, there are limitations in the use of this non-GAAP financial measure in that it excludes certain operating expenses that are recurring in nature. In addition, our calculation of this non-GAAP financial measure may differ from the methodology used by

4

* * *  
other companies. The presentation of this non-GAAP financial measure should not be considered in isolation or as a substitute for our financial results prepared in accordance with GAAP. A reconciliation of net income, the most directly comparable GAAP financial measure, to non-GAAP earnings can be found in the table above under the heading, Non-GAAP Earnings.

**Forward-looking Statements**

Statements included in this press release that are not historical in nature are “forward-looking statements” within the meaning of the Private Securities Litigation Reform Act of 1995. Forward-looking statements include, among others, statements relating to the growth opportunities for our products, our ability to advance products within our pipeline, and the potential for these programs to result in a cure for PAH and other end-stage organ diseases. These forward-looking statements are subject to certain risks and uncertainties, such as those described in our periodic reports filed with the Securities and Exchange Commission, that could cause actual results to differ materially from anticipated results. Consequently, such forward-looking statements are qualified by the cautionary statements, cautionary language and risk factors set forth in our periodic reports and documents filed with the Securities and Exchange Commission, including our most recent Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and Current Reports on Form 8-K. We claim the protection of the safe harbor contained in the Private Securities Litigation Reform Act of 1995 for forward-looking statements. We are providing this information as of May 2, 2018, and assume no obligation to update or revise the information contained in this press release whether as a result of new information, future events or any other reason.  [uthr-g]

Orenitram, Remodulin, Tyvaso and Unituxin are registered trademarks of United Therapeutics Corporation.

Adcirca is a registered trademark of Eli Lilly and Company.

5

* * *  
**UNITED THERAPEUTICS CORPORATION**

**CONSOLIDATED STATEMENTS OF OPERATIONS**

**(In millions, except per share data)**

| | |**Three Months Ended  
March 31,** | |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | |**2018** | |**2017** | |
| | |**(Unaudited)** | |
|Revenues: | | | | | |
|Net product sales | |$ |389\.2 | |$ |370\.5 | |
|Total revenues | |389\.2 | |370\.5 | |
|Operating expenses: | | | | | |
|Cost of product sales | |53\.2 | |14\.3 | |
|Research and development | |35\.7 | |36\.2 | |
|Selling, general and administrative | |(6.6 |) |56\.4 | |
|Total operating expenses | |82\.3 | |106\.9 | |
|Operating income | |306\.9 | |263\.6 | |
|Other income (expense): | | | | | |
|Interest expense | |(2.6 |) |(0.8 |) |
|Other, net | |4\.7 | |0\.8 | |
|Total other income (expense), net | |2\.1 | |— | |
|Income before income taxes | |309\.0 | |263\.6 | |
|Income tax expense | |(64.5 |) |(85.0 |) |
|Net income | |$ |244\.5 | |$ |178\.6 | |
|Net income per common share: | | | | | |
|Basic | |$ |5\.65 | |$ |4\.01 | |
|Diluted | |$ |5\.57 | |$ |3\.89 | |
|Weighted average number of common shares outstanding: | | | | | |
|Basic | |43\.3 | |44\.5 | |
|Diluted | |43\.9 | |45\.9 | |

**SELECTED CONSOLIDATED BALANCE SHEET DATA**

**(Unaudited, in millions)**

| | |**March 31,  
2018** | |
| --- | --- | --- | --- | --- |
|Cash, cash equivalents and marketable investments | |$ |1,671.6 | |
|Total assets | |3,020.2 | |
|Total liabilities and temporary equity | |650\.8 | |
|Total stockholders’ equity | |2,369.4 | |

6

* * *