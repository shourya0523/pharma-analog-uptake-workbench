EX-99.1 2 q325lillysalesandearningsp.htm EX-99.1  Document created using Wdesk  Copyright 2025 Workiva Document

October 30, 2025

For release: Immediately

Refer to: Ashley Hennessey; gentry_ashley_jo@lilly.com; (317) 416-4363 (Media)

Mike Czapar; czapar_michael_c@lilly.com; (317) 617-0983 (Investors)

Lilly reports third-quarter 2025 financial results, highlights R&D pipeline momentum and raises 2025 guidance

•Revenue in Q3 2025 increased 54% to $17.60 billion driven by volume growth from Mounjaro and Zepbound.

•Q3 2025 EPS increased by $5.14 to $6.21 on a reported basis and increased by $5.84 to $7.02 on a non-GAAP basis.

•Increased our 2025 full-year revenue guidance to be in the range of $63.0 billion to $63.5 billion; reported EPS guidance raised to be in the range of $21.80 to $22.50 and non-GAAP EPS guidance raised to be in the range of $23.00 to $23.70.

•Pipeline progress included positive results in four Phase 3 trials of orforglipron, across type 2 diabetes and obesity, with plans to submit to global regulatory authorities by the end of the year for the treatment of obesity.

•Regulatory progress included U.S. FDA approval of Inluriyo (imlunestrant) for certain adults with advanced or metastatic breast cancer.

•Manufacturing progress included announcements of two new facilities in Virginia and Texas, and the expansion of Lilly's existing Puerto Rico site.

INDIANAPOLIS, October 30, 2025 - Eli Lilly and Company (NYSE: LLY) today announced its financial results for the third-quarter of 2025.

“Lilly delivered another strong quarter, with 54% revenue growth year-over-year driven by continued demand for our incretin portfolio,” said David A. Ricks, Lilly chair and CEO. “We advanced orforglipron through four additional Phase 3 trials, enabling global obesity submissions by year-end, and we achieved U.S. FDA approval of Inluriyo (imlunestrant)—marking key progress across our pipeline. We continue to increase manufacturing capacity, announcing new facilities in Virginia and Texas and an expansion of our site in Puerto Rico.”

Eli Lilly and Company | Lilly Corporate Center | Indianapolis, Indiana 46285 | U.S.A.

Financial Results

|$ in millions, except per share data |Third-Quarter | | | |
| |2025 | |2024 | |% Change | | | | | |
|Revenue |$ |17,600.8 | | |$ |11,439.1 | | |54% | | | | | |
|Net income – Reported |5,582.5 | | |970.3 | | |NM | | | | | |
|Earnings per share – Reported |6.21 | | |1.07 | | |NM | | | | | |
|Net income – Non-GAAP |6,311.9 | | |1,064.5 | | |NM | | | | | |
|Earnings per share – Non-GAAP |7.02 | | |1.18 | | |NM | | | | | |

A discussion of the non-GAAP financial measures is included below under "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)."

Third-Quarter Reported Results

In Q3 2025, worldwide revenue was $17.60 billion, an increase of 54% compared with Q3 2024, driven by a 62% increase in volume, partially offset by a 10% decrease due to lower realized prices. Key Products1 revenue grew to $11.98 billion in Q3 2025, led by Mounjaro and Zepbound.

Revenue in the U.S. increased 45% to $11.30 billion, driven by a 60% increase in volume, partially offset by a 15% decrease due to lower realized prices. Price was negatively impacted by a favorable one-time adjustment to estimates for rebates and discounts in Q3 2024. Excluding this base period effect, U.S. price declined by high single digits.

Revenue outside the U.S. increased 74% to $6.30 billion, driven by a 66% increase in volume and to a lesser extent a 6% favorable impact on foreign exchange rates. The volume increase outside the U.S. was driven primarily by Mounjaro. Revenue included a $200.0 million sales-based milestone payment for Jardiance and $180.0 million of revenue associated with the divestiture of the rights to Cialis in select markets outside of the U.S.

1 The Company defines Key Products as Ebglyss, Jaypirca, Kisunla, Mounjaro, Omvoh, Verzenio, and Zepbound.

|2 |

Gross margin increased 57% to $14.59 billion in Q3 2025. Gross margin as a percent of revenue was 82.9%, an increase of 1.9 percentage points. The increase in gross margin percent was primarily driven by favorable product mix, partially offset by lower realized prices.

In Q3 2025, research and development expenses increased 27% to $3.47 billion, or 19.7% of revenue, driven by continued investments in the company's early and late-stage portfolio.

Marketing, selling and administrative expenses increased 31% to $2.74 billion in Q3 2025, primarily driven by promotional efforts supporting ongoing and future launches.

In Q3 2025, the company recognized acquired in-process research and development (IPR&D) charges of

$655.7 million compared with $2.83 billion in Q3 2024. The Q3 2025 charges primarily related to the

acquisition of SiteOne Therapeutics, Inc. The Q3 2024 charges were primarily related to the acquisition of Morphic Holding, Inc.

Asset impairment, restructuring and other special charges of $364.9 million in Q3 2025 were primarily related to a litigation charge, as well as acquisition and integration costs associated with the closing of our acquisition of Verve Therapeutics, Inc. In Q3 2024, there was a charge of $81.6 million, that primarily related to impairment of an intangible asset associated with a molecule in development.

The effective tax rate was 22.8% in Q3 2025 compared with 38.9% in Q3 2024. The effective tax rates for Q3 2025 and Q3 2024 were both unfavorably impacted by non-deductible acquired IPR&D charges, with a larger impact occurring in Q3 2024. Additionally, the effective tax rate for Q3 2025 was unfavorably impacted by U.S. tax law changes enacted during the quarter.

In Q3 2025, net income and earnings per share (EPS) were $5.58 billion and $6.21, respectively, compared with net income of $970.3 million and EPS of $1.07 in Q3 2024. EPS in Q3 2025 and Q3 2024 included acquired IPR&D charges of $0.71 and $3.08, respectively.

Third-Quarter Non-GAAP Measures

On a non-GAAP basis, Q3 2025 gross margin increased 56% to $14.71 billion. Gross margin as a percent of revenue was 83.6%, an increase of 1.4 percentage points. The increase in gross margin percent was primarily driven by favorable product mix, partially offset by lower realized prices.

|3 |

The non-GAAP effective tax rate was 17.7% in Q3 2025 compared with 37.6% in Q3 2024. The effective tax rates for Q3 2025 and Q3 2024 were both unfavorably impacted by non-deductible acquired IPR&D charges, with a larger impact occurring in Q3 2024.

On a non-GAAP basis, Q3 2025 net income and EPS were $6.31 billion and $7.02, respectively, compared with net income of $1.06 billion and EPS of $1.18 in Q3 2024. Non-GAAP EPS in Q3 2025 and Q3 2024 included acquired IPR&D charges of $0.71 and $3.08, respectively.

For further detail on non-GAAP measures, see the reconciliation below as well as the "Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited)" table later in this press release.

| |Third-Quarter |
| |2025 | |2024 | |% Change |
|Earnings per share (reported) |$ |6.21 | | |$ |1.07 | | |NM |
|Amortization of intangible assets |.11 | | |.12 | | | |
|Asset impairment, restructuring and other special charges |.36 | | |.07 | | | |
|Net losses (gains) on investments in equity securities |(.04) | | |(.09) | | | |
|U.S. Tax Law Change |.39 | | |— | | | |
|Earnings per share (non-GAAP) |$ |7.02 | | |$ |1.18 | | |NM |
|Acquired IPR&D |.71 | | |3.08 | | |(77)% |
|Numbers may not add due to rounding | | | | | |

|4 |

Selected Revenue Highlights

|(Dollars in millions) |Third-Quarter | |Year-to-Date |
|Selected Products |2025 | |2024 | |% Change | |2025 | |2024 | |% Change |
|Mounjaro |$ |6,515.1 | | |$ |3,112.7 | | |109% | |$ |15,555.8 | | |$ |8,010.0 | | |94% |
|Zepbound |3,588.1 | | |1,257.8 | | |185% | |9,281.3 | | |3,018.4 | | |NM |
|Verzenio |1,470.2 | | |1,369.3 | | |7% | |4,118.3 | | |3,751.5 | | |10% |
|Total Revenue |17,600.8 | | |11,439.1 | | |54% | |45,887.0 | | |31,509.9 | | |46% |
|NM – not meaningful |

Mounjaro

For Q3 2025, worldwide Mounjaro revenue increased 109% to $6.52 billion. U.S. revenue was $3.55 billion, an increase of 49%, reflecting strong demand, partially offset by lower realized prices. Revenue outside the U.S. increased to $2.97 billion compared with $728.0 million in Q3 2024, primarily driven by volume growth.

Zepbound

For Q3 2025, U.S. Zepbound revenue increased 184% to $3.57 billion, compared with $1.26 billion in Q3 2024, primarily driven by increased demand, partially offset by lower realized prices.

Verzenio

For Q3 2025, worldwide Verzenio revenue increased 7% to $1.47 billion. U.S. revenue was $880.3 million, compared with $878.8 million in Q3 2024, reflecting an increase in volume which was offset by lower realized prices. Revenue outside the U.S. was $589.8 million, an increase of 20%, primarily driven by volume growth and, to a lesser extent, favorable impact on foreign exchange rates.

|5 |

Lilly shared numerous updates recently on key regulatory, clinical, business development and other events, including:

|Regulatory |Lilly's Omvoh (mirikizumab-mrkz) approved by U.S. FDA as a single-injection maintenance regimen in adults with ulcerative colitis (announcement) |
|Lilly's Kisunla (donanemab) receives marketing authorization by European Commission for the treatment of early symptomatic Alzheimer's disease (announcement) |
|U.S. FDA approves Inluriyo (imlunestrant) for adults with ER+, HER2-, ESR1-mutated advanced or metastatic breast cancer (announcement) |
|Lilly's olomorasib receives U.S. FDA's Breakthrough Therapy designation for the treatment of certain newly diagnosed metastatic KRAS G12C-mutant lung cancers (announcement) |
|Clinical |Lilly's Omvoh (mirikizumab-mrkz) demonstrated early and sustained improvement in bowel urgency outcomes for patients with ulcerative colitis (announcement) |
|Lilly's EBGLYSS (lebrikizumab-lbkz) delivered durable disease control when administered once every eight weeks in patients with moderate-to-severe atopic dermatitis (announcement) |
|Lilly's baricitinib delivered near-complete scalp hair regrowth at one year for adolescents with severe alopecia areata in Phase 3 BRAVE-AA-PEDS trial (announcement) |
|Lilly's Verzenio (abemaciclib) prolonged survival in HR+, HER2-, high-risk early breast cancer with two years of treatment (announcement) |
|Lilly’s oral GLP-1, orforglipron, demonstrated superior glycemic control in two successful Phase 3 trials, reconfirming its potential as a foundational treatment in type 2 diabetes (announcement) |
|Lilly's Omvoh (mirikizumab-mrkz) is the first and only IL-23p19 antagonist to show four years of sustained, corticosteroid-free comprehensive patient outcomes in ulcerative colitis (announcement) |
|Lilly's Mounjaro (tirzepatide), a GIP/GLP-1 dual receptor agonist, reduced A1C by an average of 2.2% in a Phase 3 trial of children and adolescents with type 2 diabetes (announcement) |
|Lilly's oral GLP-1, orforglipron, superior to oral semaglutide in head-to-head trial (announcement) |
|Lilly's oral GLP-1, orforglipron, demonstrated meaningful weight loss and cardiometabolic improvements in complete ATTAIN-1 results published in The New England Journal of Medicine (announcement) |
|Lilly's Jaypirca (pirtobrutinib), the first and only approved non-covalent (reversible) BTK inhibitor, significantly improved progression-free survival in patients with treatment-naïve CLL/SLL (announcement) |
|Lilly's Verzenio® (abemaciclib) increases overall survival in HR+, HER2-, high-risk early breast cancer with two years of therapy (announcement) |
|Lilly's oral GLP-1, orforglipron, is successful in third Phase 3 trial, triggering global regulatory submissions this year for the treatment of obesity (announcement) |

|6 |

|Other |Lilly announces more than $1.2 billion investment in Puerto Rico facility to boost oral medicine manufacturing capacity in the United States (announcement) |
|LillyDirect and Walmart Pharmacy launch first retail pick-up option with direct-to-consumer pricing for Zepbound (announcement) |
|Lilly partners with NVIDIA to build the industry's most powerful AI supercomputer, supercharging medicine discovery and delivery for patients (announcement) |
|Lilly announces roster of Team USA athletes for the Olympic and Paralympic Games Milano Cortina 2026, pledges to translate U.S. Olympic and Paralympic milestones into meaningful community impact (announcement) |
|Lilly to Acquire Adverum Biotechnologies (announcement) |
|Lilly opens newest Gateway Labs site in San Diego to boost local biotechnology ecosystem (announcement) |
|Lilly plans to build a new $6.5 billion facility to manufacture active pharmaceutical ingredients in Texas (announcement) |
|Lilly announces plans to build $5 billion manufacturing facility in Virginia (announcement) |
|Lilly launches TuneLab platform to give biotechnology companies access to AI-enabled drug discovery models built through over $1 billion in research investment (announcement) |
|Anne White to Retire as Executive Vice President and President, Lilly Neuroscience (announcement) |

For information on important public announcements, visit the news section of Lilly's website.

|7 |

2025 Financial Guidance

The company has increased full-year revenue guidance to be in the range of $63.0 billion to $63.5 billion, primarily driven by strong underlying business performance across the portfolio and foreign exchange rates.

The performance margin2 is now expected to be in the range of 43.5% and 44.5% on a reported basis and 45.0% and 46.0% on a non-GAAP basis. Both ratios reflect the increase in revenue guidance.

Other income (expense) on a reported basis is now expected to be expense in the range of $700 million to $600 million due to a decrease in net losses on investments in equity securities and is still expected to be expense in the range of $700 million to $600 million on a non-GAAP basis.

The 2025 estimated effective tax rate on a reported basis and a non-GAAP basis remain unchanged at approximately 19% and 17%, respectively.

Based on these changes, EPS guidance has been increased to be in the range of $21.80 to $22.50 on a reported basis and $23.00 to $23.70 on a non-GAAP basis. The company's updated 2025 financial guidance reflects adjustments shown in the reconciliation table below.

| |2025 Guidance | |
|Earnings per share (reported) |$21.80 to $22.50 | |
|U.S. tax legislation |.39 | |
|Amortization of intangible assets |.43 | |
|Asset impairment, restructuring, and other special charges |.39 | |
|Net losses on investments in equity securities |— | |
|Earnings per share (non-GAAP) |$23.00 to $23.70 | |
|Numbers may not add due to rounding | | |

2 The Company defines performance margin as gross margin less R&D, Marketing, Selling, and Administrative and Asset Impairment, Restructuring and Other Charges divided by Revenue.

|8 |

The following table summarizes the company's updated 2025 financial guidance:

| | | |Prior |Updated (1) (2) (3) |
|Revenue | | |$60.0 to $62.0 billion |$63.0 to $63.5 billion |
|Performance Margin (4) | | | | |
|(reported) | | |42.0% to 43.5% |43.5% to 44.5% |
|(non-GAAP) | | |43.0% to 44.5% |45.0% to 46.0% |
|Other Income/(Expense) (reported) | | |($750) to ($650) million |($700) to ($600) million |
|Other Income/(Expense) (non-GAAP) | | |($700) to ($600) million |Unchanged |
|Tax Rate (reported) | | |Approx. 19% |Unchanged |
|Tax Rate (non-GAAP) | | |Approx. 17% |Unchanged |
|Earnings per Share (reported) | | |$20.85 to $22.10 |$21.80 to $22.50 |
|Earnings per Share (non-GAAP) | | |$21.75 to $23.00 |$23.00 to $23.70 |
|(1) Non-GAAP guidance reflects adjustments presented in the earnings per share reconciliation table above. |
|(2) Guidance includes acquired IPR&D charges through Q3 2025 of $2.38 billion or $2.57 on a per share basis. Guidance does not include acquired IPR&D either incurred, or expected to be incurred, after Q3 2025. |
|(3) This guidance is based on the existing tariff and trade environment as of October 30, 2025, and does not reflect any policy shifts, including pharmaceutical sector tariffs, that could impact business. |
|(4) The Company defines performance margin as gross margin less R&D, Marketing, Selling, and Administrative, and Asset Impairment, Restructuring and Other Charges divided by Revenue. |

|9 |

Webcast of Conference Call

As previously announced, investors and the general public can access a live webcast of the Q3 2025 financial results conference call through a link on Lilly's website at investor.lilly.com/webcasts-and-presentations. The conference call will begin at 10 a.m. Eastern time today and will be available for replay via the website.

Non-GAAP Financial Measures

Certain financial information is presented on both a reported and a non-GAAP basis. Some numbers in this press release may not add due to rounding. Reported results were prepared in accordance with U.S. generally accepted accounting principles (GAAP) and include all revenue and expenses recognized during the periods. Non-GAAP measures reflect adjustments for the items described in the reconciliation tables later in the release. Related materials provide certain GAAP and non-GAAP figures excluding the impact of foreign exchange rates. Lilly recalculates current period figures on a constant currency basis by keeping constant the exchange rates from the base period. The company's 2025 financial guidance is provided on both a reported and a non-GAAP basis. The non-GAAP measures are presented to provide additional insights into the underlying trends in the company's business.

About Lilly

Lilly is a medicine company turning science into healing to make life better for people around the world. We've been pioneering life-changing discoveries for nearly 150 years, and today our medicines help tens of millions of people across the globe. Harnessing the power of biotechnology, chemistry and genetic medicine, our scientists are urgently advancing new discoveries to solve some of the world's most significant health challenges: redefining diabetes care; treating obesity and curtailing its most devastating long-term effects; advancing the fight against Alzheimer's disease; providing solutions to some of the most debilitating immune system disorders; and transforming the most difficult-to-treat cancers into manageable diseases. With each step toward a healthier world, we're motivated by one thing: making life better for millions more people. That includes delivering innovative clinical trials that reflect the diversity of our world and working to ensure our medicines are accessible and affordable. To learn more, visit Lilly.com and Lilly.com/news. F-LLY

|10 |

Cautionary Statement Regarding Forward-Looking Statements

This press release and the related attachments contain management's intentions and expectations for the future, all of which are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933 and Section 21E of the Securities Exchange Act of 1934. The words "estimate", "project", "intend", "expect", "believe", "target", "plan", "anticipate", "may", "could", "aim", "seek", "will", "continue", and similar expressions are intended to identify forward-looking statements. Actual results may differ materially due to various factors. The following include some but not all of the factors that could cause actual results or events to differ from those anticipated, including the significant costs and uncertainties in the pharmaceutical research and development process, including with respect to the timing and process of obtaining regulatory approvals; the impact and uncertain outcome of acquisitions and business development transactions and related costs; intense competition affecting the company's products, pipeline, or industry; market uptake of launched products and indications; continued pricing pressures and the impact of actions of governmental and private actors affecting pricing of, reimbursement for, and patient access to pharmaceuticals, or reporting obligations related thereto; safety or efficacy concerns associated with the company's or competitive products; dependence on relatively few products or product classes for a significant percentage of the company's total revenue and a consolidated supply chain; the expiration of intellectual property protection for certain of the company's products and competition from generic and biosimilar products; the company's ability to protect and enforce patents and other intellectual property and changes in patent law or regulations related to data package exclusivity; information technology system inadequacies, inadequate controls or procedures, security breaches, or operating failures; unauthorized access, disclosure, misappropriation, or compromise of confidential information or other data stored in the company's information technology systems, networks, and facilities, or those of third parties with whom the company shares its data and violations of data protection laws or regulations; issues with product supply and regulatory approvals stemming from manufacturing difficulties, disruptions, or shortages, including as a result of unpredictability and variability in demand, labor shortages, third-party performance, quality, cyber-attacks, or regulatory actions related to the company's and third-party facilities; reliance on third-party relationships and outsourcing arrangements; the use of artificial intelligence or other emerging technologies in various facets of the company's operations, which may exacerbate competitive, regulatory, litigation, cybersecurity, and other risks; the impact of global macroeconomic conditions, including uneven economic growth or downturns or uncertainty, trade and other global disputes and interruptions, including related to tariffs, trade protection measures, and similar restrictions, international tension, conflicts, regional dependencies, or other costs, uncertainties, and risks related to engaging in business globally; fluctuations in foreign currency exchange rates, changes in interest rates and inflation or deflation; significant and sudden declines or volatility in the trading price of the company's common stock and market capitalization; litigation, investigations, or other similar proceedings involving past, current, or future products or activities; changes in tax law and regulations, tax rates, or events that differ from our assumptions related to tax positions; regulatory changes, developments, and uncertainty; regulatory oversight and actions regarding the company's operations and products; regulatory compliance problems or government investigations; risks from the proliferation of counterfeit, misbranded, adulterated or illegally compounded products; actual or perceived deviation from environmental-, social-, or governance-related requirements or expectations; asset impairments and restructuring charges; and changes in accounting and reporting standards. For additional information about the factors that could cause actual results or events to differ materially from forward-looking statements, please see the company's latest Form 10-K and subsequent Forms 8-K and 10-Q filed with the Securities and Exchange Commission. You should not place undue reliance on forward-looking statements contained in this press release and the related attachments, which, except as otherwise noted, speak only as of the date of this release. Except as is required by law, the company expressly disclaims any obligation to publicly release any revisions to forward-looking statements contained in this press release and the related attachments to reflect events or circumstances after the date of this release.

 # # #

Website Information

The information contained on, or that may be accessed through, our website or any third-party website is not incorporated by reference into, and is not a part of, this earnings release.

Trademarks and Trade Names

All trademarks or trade names referred to in this press release are the property of the company, or, to the extent trademarks or trade names belonging to other companies are references in this press release, the property of their respective owners. Solely for convenience, the trademarks and trade names in this press release are referred to without the ® and ™ symbols, but such references should not be construed as any indicator that the company or, to the extent applicable, their respective owners will not assert, to the fullest extent under applicable law, the company's or their rights thereto. We do not intend the use or display of other companies’ trademarks and trade names to imply a relationship with, or endorsement or sponsorship of us by, any other companies

|11 |

|Eli Lilly and Company |
|Operating Results (Unaudited) – REPORTED |
|(Dollars in millions, except per share data and numbers may not add due to rounding) |

| | |Three Months Ended | | |Nine Months Ended |
| | |September 30, | | |September 30, |
| | |2025 | |2024 | |% Chg. | | |2025 | |2024 | |% Chg. |
|Revenue |$ |17,600.8 | |$ |11,439.1 | | |54% | |$ |45,887.0 | |$ |31,509.9 | | |46% |
|Cost of sales | |3,008.3 | | |2,170.8 | | |39% | | |7,680.3 | | |6,014.5 | | |28% |
|Research and development | |3,465.7 | | |2,734.1 | | |27% | | |9,535.5 | | |7,968.1 | | |20% |
|Marketing, selling and administrative | |2,740.7 | | |2,099.8 | | |31% | | |7,962.6 | | |6,169.3 | | |29% |
|Acquired IPR&D | |655.7 | | |2,826.4 | | |(77)% | | |2,381.2 | | |3,091.2 | | |(23)% |
|Asset impairment, restructuring and other special charges | |364.9 | | |81.6 | | |NM | | |399.9 | | |516.6 | | |(23)% |
|Operating income | |7,365.4 | | |1,526.4 | | |NM | | |17,927.5 | | |7,750.2 | | |131% |
|Net interest income (expense) | |(114.7) | | |(144.9) | | | | | |(519.1) | | |(425.0) | | | |
|Net other income (expense) | |(18.4) | | |206.9 | | | | | |56.4 | | |316.5 | | | |
|Other income (expense) | |(133.1) | | |62.0 | | |NM | | |(462.7) | | |(108.5) | | |NM |
|Income before income taxes | |7,232.3 | | |1,588.4 | | |NM | | |17,464.8 | | |7,641.7 | | |129% |
|Income tax expense | |1,649.9 | | |618.1 | | |167% | | |3,462.5 | | |1,461.5 | | |137% |
|Net income |$ |5,582.5 | |$ |970.3 | | |NM | |$ |14,002.3 | |$ |6,180.2 | | |127% |
|Earnings per share - diluted |$ |6.21 | |$ |1.07 | | |NM | |$ |15.56 | |$ |6.83 | | |128% |
|Dividends paid per share |$ |1.50 | |$ |1.30 | | |15% | |$ |4.50 | |$ |3.90 | | |15% |
|Weighted-average shares outstanding (thousands) - diluted | |898,804 | | |905,027 | | | | | |899,734 | | |904,359 | | | |
|NM – not meaningful | | | | | | | | | | | | | |

|12 |

|Eli Lilly and Company |
|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) |
|(Dollars in millions, except per share data and numbers may not add due to rounding) |
| | |Three Months Ended September 30, | |Nine Months Ended September 30, |
| | |2025 |2024 | |2025 |2024 |
|Gross Margin - As Reported | |$ |14,592.5 | |$ |9,268.3 | | |$ |38,206.7 | |$ |25,495.4 | |
|Increase for excluded items: | | | | | | |
|Amortization of intangible assets (Cost of sales) (1) | |119.2 | |139.4 | | |364.0 | |417.6 | |
|Gross Margin - Non-GAAP | |$ |14,711.7 | |$ |9,407.7 | | |$ |38,570.7 | |$ |25,913.0 | |
|Gross Margin as a percent of revenue - As Reported | |82.9 |% |81.0 |% | |83.3 |% |80.9 |% |
|Gross Margin as a percent of revenue - Non-GAAP (2) | |83.6 |% |82.2 |% | |84.1 |% |82.2 |% |

1.Excludes amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

2. Non-GAAP gross margin as a percent of revenue reflects the gross margin effects of the adjustments presented above.

|13 |

|Reconciliation of GAAP Reported to Selected Non-GAAP Adjusted Information (Unaudited) |
|(Dollars in millions, except per share data and numbers may not add due to rounding) |
| | |Three Months Ended September 30, | |Nine Months Ended September 30, |
| | |2025 |2024 | |2025 |2024 |
|Net income - Reported | |$ |5,582.5 | |$ |970.3 | | |$ |14,002.3 | |$ |6,180.2 | |
|Increase (decrease) for excluded items: | | | | | | |
|Amortization of intangible assets (Cost of sales) (1) | |119.2 | |139.4 | | |364.0 | |417.6 | |
|Asset impairment, restructuring and other special charges (2) | |364.9 | |81.6 | | |399.9 | |516.6 | |
|Net (gains) losses on investments in equity securities (Other income/expense) | |(48.0) | |(103.0) | | |5.6 | |21.3 | |
|U.S. Tax Law Change (3) | |350.3 | |— | | |350.3 | |— | |
|Corresponding tax effects (Income taxes) | |(56.9) | |(23.8) | | |(126.5) | |(194.7) | |
|Net income - Non-GAAP | |$ |6,311.9 | |$ |1,064.5 | | |$ |14,995.6 | |$ |6,941.0 | |
|Effective tax rate - Reported | |22.8 |% |38.9 |% | |19.8 |% |19.1 |% |
|Effective tax rate - Non-GAAP (4) | |17.7 |% |37.6 |% | |17.8 |% |19.3 |% |
|Earnings per share (diluted) - Reported | |$ |6.21 | |$ |1.07 | | |$ |15.56 | |$ |6.83 | |
|Earnings per share (diluted) - Non-GAAP | |$ |7.02 | |$ |1.18 | | |$ |16.67 | |$ |7.68 | |

1.Excludes amortization of intangibles primarily associated with costs of marketed products acquired or licensed from third parties.

2. For the three and nine months ended September 30, 2025, excludes litigation charges, as well as acquisition and integration costs associated with the closing of our acquisition of Verve Therapeutics, Inc. For the nine months ended September 30, 2024, excluded charges related to litigation and impairment of an intangible asset associated with a molecule in development.

3. Relates to adjusting our income tax provision for prior periods and remeasuring our deferred tax assets and liabilities.

4. Non-GAAP tax rate reflects the tax effects of the adjustments presented above.

|14 |
